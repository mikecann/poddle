// Types for chef-panel.browser.js (the <chef-panel> web component).

/** Same signature as ConvexClient.setAuth's fetcher. */
export type ChefAuthTokenFetcher = (args: { forceRefreshToken: boolean }) => Promise<string | null | undefined>;

/**
 * `<chef-panel convex-url="…" prefix="chef">` — attributes:
 *   - `convex-url` (required): your deployment URL
 *   - `prefix`: the Convex module exposing `exposeChefApi` (default "chef")
 *   - `member-label`: the launcher's text for non-admins (default "Suggest a feature")
 *   - `open="1"`: start expanded
 *   - `offset-bottom` / `offset-right` (px): lift the launcher clear of your own controls
 *   - `whats-new="off"`: don't pop up the "What's new" card (changelogs from `<prefix>:whatsNew`)
 *
 * Admins (server `amAdmin`) see Chef: branding, build status, questions, approvals
 * (Approve shows the request's snapshot in full; "Approve and build" approves that
 * snapshot's hash), "Ship it" (the plain-language card first: what changed, what to
 * try, screenshots and risk flags; the whole diff main..chef under "Details"; the
 * requests it ships, and "Ship to live", which approves that diff's hash), and cloud builds (phases, preview,
 * screenshots, skill notes, spend approvals, the run log).
 * Everyone else sees a neutral lightbulb launcher with "Request a feature" + their own requests.
 */
export declare class ChefPanelElement extends HTMLElement {
  /**
   * How the panel gets Convex's browser client (default: convex from esm.sh).
   * Replace it before the element connects to supply your own copy.
   */
  static loadConvex: () => Promise<{
    ConvexClient: new (url: string) => unknown;
    makeFunctionReference: (name: string) => unknown;
  }>;
  /** Authenticate the panel's calls as the signed-in user. Safe to call any time. */
  setAuth(fetchToken: ChefAuthTokenFetcher): void;
  /** Drop auth (signed out). */
  clearAuth(): void;
}

/** Whether a code point is hidden (same rules as the React `isInvisibleCodePoint`). */
export declare function isInvisibleCodePoint(cp: number): boolean;
/** The text with every hidden character as a `<U+XXXX>` marker. */
export declare function revealInvisible(text: string): string;
/** A failed run's repair commit ("Chef can fix this: ... [Apply]") as HTML, or "". */
export declare function repairHtml(repair: unknown, busy?: unknown): string;
/** What a merge-only build did (main moved before Ship it), in words; null otherwise. */
export declare function mergedMainText(run: unknown): string | null;
export declare function followAction(follow: unknown): "approve" | "retry" | null;
/** HTML for an approval snapshot (`approvalSnapshot`'s result), in full. */
export declare function snapshotHtml(snapshot: unknown): string;
/** HTML for a cloud run (`runStatus`'s result) and its screenshots, notes, approvals and log. */
export declare function runHtml(run: unknown, options?: Record<string, unknown>): string;
/** The plain-language Ship card (exposeChefApi `buildCard`) as HTML: escaped text, http(s) links only. */
export declare function cardHtml(card: unknown, options?: { loginUsed?: boolean }): string;

/** Registers `<chef-panel>` (idempotent). Importing the module already does this. */
export declare function defineChefPanel(): void;

declare global {
  interface HTMLElementTagNameMap {
    "chef-panel": ChefPanelElement;
  }
}

/** Where a cloud ship is, in words (shipCandidate's `release`). */
export declare function shipStateText(r: { seq: number; state: string; error: string | null }): string;

/** "$1.23" (never negative; NaN reads $0.00). */
export declare function fmtUsd(n: number): string;
/** A build's cost: "$1.23", or "$0.40 so far" while it runs. */
export declare function runCostLabel(cost: { spendUsd: number; status: string }): string;
/** What recent builds cost, in one line ("" for none). */
export declare function costTotalsLine(costs: Array<{ spendUsd: number; status: string }>): string;
/** "#67 Dark mode", or "#67" for an untitled request. */
export declare function requestName(n: { number: number; title?: string | null }): string;
