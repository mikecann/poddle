// The Chef audit log (docs/chef-pipeline.md, "What is audited"). Append-only:
// rows are inserted by writeAudit and nothing patches, replaces or deletes
// them (tests/immutability.test.ts checks the source). Rows never hold
// secrets or request bodies.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx } from "./_generated/server.js";
import type { Id } from "./_generated/dataModel.js";
import { chefAuditFields } from "./schema.js";
import { isAdminUser } from "./access.js";

export type AuditEntry = {
  actor: string;
  action: string;
  outcome: "ok" | "refused" | "error";
  target?: string;
  runId?: Id<"chefRuns">;
  reason?: string;
  detail?: Record<string, string | number | boolean | null>;
};

export async function writeAudit(ctx: MutationCtx, e: AuditEntry): Promise<void> {
  await ctx.db.insert("chefAudit", {
    actor: e.actor.slice(0, 200),
    action: e.action.slice(0, 100),
    outcome: e.outcome,
    ...(e.target !== undefined ? { target: e.target.slice(0, 200) } : {}),
    ...(e.runId !== undefined ? { runId: e.runId } : {}),
    ...(e.reason !== undefined ? { reason: e.reason.slice(0, 500) } : {}),
    ...(e.detail !== undefined ? { detail: e.detail } : {}),
    at: Date.now(),
  });
}

export const userActor = (userId: string) => `user:${userId}`;

/** Newest first, optionally for one run. Admins only; [] for everyone else. */
export const list = query({
  args: {
    viewer: v.optional(v.union(v.string(), v.null())),
    runId: v.optional(v.id("chefRuns")),
    limit: v.optional(v.number()),
  },
  returns: v.array(
    v.object({ _id: v.id("chefAudit"), _creationTime: v.number(), ...chefAuditFields }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const limit = Math.min(500, Math.max(1, Math.floor(args.limit ?? 100) || 100));
    if (args.runId) {
      return await ctx.db
        .query("chefAudit")
        .withIndex("by_runId", (q) => q.eq("runId", args.runId))
        .order("desc")
        .take(limit);
    }
    return await ctx.db.query("chefAudit").order("desc").take(limit);
  },
});

const ACTOR = /^(operator|system):[A-Za-z0-9_.:@-]{1,64}$/;
const ACTION = /^[a-z][A-Za-z0-9_./-]{0,99}$/;

/**
 * One audit row from the host, for what happens outside this component on
 * Chef's behalf: @convex-dev/chef-cloud's repo calls and orchestration
 * (`operator:<name>` for the developer's CLI, `system:<what>` for the
 * orchestration). Only an `operator:` or `system:` actor; never a user's,
 * a run's or a key's, which only this component's own functions write.
 */
export const record = mutation({
  args: {
    actor: v.string(),
    action: v.string(),
    outcome: v.union(v.literal("ok"), v.literal("refused"), v.literal("error")),
    target: v.optional(v.string()),
    runId: v.optional(v.id("chefRuns")),
    reason: v.optional(v.string()),
    detail: v.optional(v.record(v.string(), v.union(v.string(), v.number(), v.boolean(), v.null()))),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (!ACTOR.test(args.actor)) throw new Error("actor must be operator:<name> or system:<what>");
    if (!ACTION.test(args.action)) throw new Error("Bad audit action");
    await writeAudit(ctx, args);
    return null;
  },
});
