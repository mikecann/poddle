// The beta channel (docs/chef-pipeline.md, "The beta channel"). Off unless
// the app configures chefCloud's `beta` (a persistent deployment of its own,
// with its deploy key in CHEF_BETA_DEPLOY_KEY). Then a successful build is
// also (or instead of a throwaway preview) deployed there, so the app's beta
// testers use it; "Promote to everyone" on the Ship card is "Ship it" for
// that build, with the same guards. The first deploy with "admin-copy" on
// seeds the beta with the admin's copy, once.
//
// begin, finish, forHost: the host only. state: admins.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { isAdminUser } from "./access.js";
import { writeAudit } from "./chefAudit.js";
import { runActor } from "./chefRuns.js";

/** A deploy holds the beta for at most this long: one stuck past it no longer blocks the next. */
export const BETA_LEASE_MS = 45 * 60_000;
const DEPLOYMENT_NAME = /^[a-z0-9][a-z0-9-]{0,63}$/;

async function settingsRow(ctx: { db: any }): Promise<Doc<"settings"> | null> {
  return await ctx.db
    .query("settings")
    .withIndex("by_key", (q: any) => q.eq("key", "singleton"))
    .unique();
}

function checkSiteUrl(url: string): string {
  const u = new URL(url);
  if (u.protocol !== "https:" || u.username || u.password) throw new Error("The beta's siteUrl must be https, with no credentials");
  return u.origin;
}

/**
 * The host's beta deploy for one built run starts: the run must be active
 * with its commit; one deploy at a time (a lease). Answers what the host
 * needs, or why not now.
 */
export const begin = mutation({
  args: { runId: v.id("chefRuns"), deploymentName: v.string(), siteUrl: v.string() },
  returns: v.union(
    v.object({ status: v.literal("busy") }),
    v.object({ status: v.literal("done"), siteUrl: v.string() }),
    v.object({ status: v.literal("inactive") }),
    v.object({ status: v.literal("go"), sha: v.string(), baseSha: v.string(), seedWanted: v.boolean() }),
  ),
  handler: async (ctx, args) => {
    if (!DEPLOYMENT_NAME.test(args.deploymentName)) throw new Error("Bad beta deployment name");
    const siteUrl = checkSiteUrl(args.siteUrl);
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.status !== "active" || !run.commitSha || !run.baseSha) return { status: "inactive" as const };
    if (run.beta?.status === "deployed") return { status: "done" as const, siteUrl };
    const row = await settingsRow(ctx);
    const now = Date.now();
    const held = row?.beta?.deploying;
    if (held && held.runId !== run._id && now - held.at < BETA_LEASE_MS) return { status: "busy" as const };
    // A beta that moved to another deployment starts over: not seeded.
    const same = row?.beta?.deploymentName === args.deploymentName;
    const beta = {
      ...(same ? row!.beta! : {}),
      deploymentName: args.deploymentName,
      siteUrl,
      deploying: { runId: run._id, at: now },
    };
    if (row) await ctx.db.patch("settings", row._id, { beta });
    else await ctx.db.insert("settings", { key: "singleton", communityBoardVisible: true, runMode: "local", beta });
    await ctx.db.patch("chefRuns", run._id, { beta: { status: "deploying", deploymentName: args.deploymentName, at: now } });
    const seedWanted = !(same && row?.beta?.seededAt) && row?.previewData === "admin-copy" && typeof row.previewDataUserId === "string";
    return { status: "go" as const, sha: run.commitSha, baseSha: run.baseSha, seedWanted };
  },
});

/**
 * The beta deploy ended. Deployed: the beta now runs this build (and was
 * seeded, if `seeded`); with `asPreview` (chefCloud's `beta.mode:
 * "instead"`) it is also the run's preview. Either way the lease goes.
 * Audited.
 */
export const finish = mutation({
  args: {
    runId: v.id("chefRuns"),
    ok: v.boolean(),
    note: v.optional(v.string()),
    seeded: v.optional(v.boolean()),
    asPreview: v.optional(v.boolean()),
  },
  returns: v.union(v.null(), v.object({ previewUrl: v.union(v.string(), v.null()) })),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || !run.beta) return null;
    const row = await settingsRow(ctx);
    const beta = row?.beta;
    if (!row || !beta) return null;
    const now = Date.now();
    const lease = beta.deploying?.runId === run._id ? { deploying: undefined } : {};
    const note = args.note?.replace(/\s+/g, " ").slice(0, 300);
    let previewUrl: string | null = null;
    if (args.ok) {
      await ctx.db.patch("settings", row._id, {
        beta: {
          ...beta,
          ...lease,
          runId: run._id,
          sha: run.commitSha,
          deployedAt: now,
          ...(args.seeded ? { seededAt: now } : {}),
        },
      });
      // The Convex site of the beta deployment, built from its name, never from the sandbox.
      previewUrl = `https://${run.beta.deploymentName}.convex.site`;
      await ctx.db.patch("chefRuns", run._id, {
        beta: { ...run.beta, status: "deployed", at: now, ...(args.seeded !== undefined ? { seeded: args.seeded } : {}), ...(note ? { note } : {}) },
        ...(args.asPreview && run.status === "active" ? { previewUrl, heartbeatAt: now } : {}),
      });
    } else {
      if (beta.deploying?.runId === run._id) await ctx.db.patch("settings", row._id, { beta: { ...beta, deploying: undefined } });
      await ctx.db.patch("chefRuns", run._id, { beta: { ...run.beta, status: "failed", at: now, ...(note ? { note } : {}) } });
    }
    await writeAudit(ctx, {
      actor: runActor(run._id),
      action: args.ok ? "beta.deployed" : "beta.failed",
      runId: run._id,
      target: run.beta.deploymentName,
      outcome: args.ok ? "ok" : "error",
      detail: { sha: run.commitSha ?? null, seeded: args.seeded ?? false, ...(note ? { note } : {}) },
    });
    return { previewUrl };
  },
});

export const vBetaState = v.object({
  deploymentName: v.string(),
  siteUrl: v.string(),
  runId: v.union(v.id("chefRuns"), v.null()),
  sha: v.union(v.string(), v.null()),
  deployedAt: v.union(v.number(), v.null()),
  deploying: v.boolean(),
  seeded: v.boolean(),
});

export function betaStateOf(row: Doc<"settings"> | null) {
  const b = row?.beta;
  if (!b) return null;
  return {
    deploymentName: b.deploymentName,
    siteUrl: b.siteUrl,
    runId: (b.runId ?? null) as Id<"chefRuns"> | null,
    sha: b.sha ?? null,
    deployedAt: b.deployedAt ?? null,
    deploying: !!b.deploying && Date.now() - b.deploying.at < BETA_LEASE_MS,
    seeded: b.seededAt !== undefined,
  };
}

/** What's on the beta. Admins only: null for everyone else, and before the first beta deploy. */
export const state = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(v.null(), vBetaState),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    return betaStateOf(await settingsRow(ctx));
  },
});

export { settingsRow as betaSettingsRow };
