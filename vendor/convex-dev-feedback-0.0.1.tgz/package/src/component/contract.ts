// What @convex-dev/chef-cloud checks before it sets anything up: the contract
// version this component offers (src/chef/contract.ts). Host-only, like every
// component function.
import { v } from "convex/values";
import { query } from "./_generated/server.js";
import { CHEF_CONTRACT_VERSION } from "../chef/contract.js";

export const version = query({
  args: {},
  returns: v.object({ version: v.number() }),
  handler: async () => ({ version: CHEF_CONTRACT_VERSION }),
});
