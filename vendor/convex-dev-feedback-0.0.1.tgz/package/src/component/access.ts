import type { QueryCtx } from "./_generated/server.js";
import type { Doc } from "./_generated/dataModel.js";
import { findAgentKeyRow } from "./agentKeys.js";

// Role/identity resolution for the component's visibility rules. The host
// forwards a trusted `viewer` (the authenticated userId, or null/omitted for an
// anonymous browser visitor) and/or an `agentKey` (a CLI/agent credential from
// the agentKeys table). The component resolves the actor and enforces access —
// rather than leaving every gate to the host.

export type Actor = "admin" | "agent" | "member" | "anon";

export type ActorArgs = { viewer?: string | null; agentKey?: string };

export async function resolveActor(
  ctx: QueryCtx,
  args: ActorArgs,
): Promise<Actor> {
  // An agent presents a (non-revoked) agent key — full trust, like the build agent.
  if (args.agentKey) {
    const k = await findAgentKeyRow(ctx, args.agentKey);
    if (k && !k.revoked) return "agent";
  }
  if (!args.viewer) return "anon";
  const u = await ctx.db
    .query("users")
    .withIndex("by_userId", (q) => q.eq("userId", args.viewer!))
    .unique();
  if (!u) return "anon";
  return u.role === "admin" ? "admin" : "member";
}

export function isPrivileged(a: Actor): boolean {
  return a === "admin" || a === "agent";
}

// Gate for "list all active requests / refinements" surfaces. Only admins or
// agents may see the full queue; members and anonymous visitors are rejected.
export async function requirePrivileged(
  ctx: QueryCtx,
  args: ActorArgs,
): Promise<Actor> {
  const a = await resolveActor(ctx, args);
  if (!isPrivileged(a)) {
    throw new Error(
      "Unauthorized: only admins or agents can list all active requests and refinements.",
    );
  }
  return a;
}

// Gate for build status (todos + progress feed + open refinements). Visible to
// admins/agents always, and to everyone ONLY while there are no users yet (the
// early "watching the agent build" phase, before anyone has signed up). Once
// real users exist, ordinary visitors no longer see the build chrome.
export async function buildStatusVisible(
  ctx: QueryCtx,
  args: ActorArgs,
): Promise<boolean> {
  if (isPrivileged(await resolveActor(ctx, args))) return true;
  const anyUser = await ctx.db.query("users").take(1);
  return anyUser.length === 0;
}

// Whether `item` is on the public board (mirrors items.listPublic): not merged,
// not a refinement, not rejected, and — for pre-triage "submitted" items — only
// when the owner's communityBoardVisible setting (default true) allows it.
export async function isPubliclyVisible(
  ctx: QueryCtx,
  item: Doc<"items">,
  includeCommunity?: boolean,
): Promise<boolean> {
  if (item.mergedInto || item.kind === "refinement") return false;
  if (item.state === "rejected") return false;
  if (item.state === "submitted") {
    // Hosts that pass includeCommunity to items.listPublic should pass the
    // same value here so attachments follow the board they actually render.
    if (includeCommunity !== undefined) return includeCommunity;
    const s = await ctx.db
      .query("settings")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    return s?.communityBoardVisible ?? true;
  }
  return true;
}

// Who may read an item's private-ish extras (attachments): admins/agents, the
// item's creator, and — while the item is on the public board — anyone who can
// see the board. Same audience as the item itself.
export async function canReadItem(
  ctx: QueryCtx,
  item: Doc<"items">,
  args: ActorArgs & { includeCommunity?: boolean },
): Promise<boolean> {
  if (isPrivileged(await resolveActor(ctx, args))) return true;
  if (args.viewer && args.viewer === item.createdBy) return true;
  return await isPubliclyVisible(ctx, item, args.includeCommunity);
}

// Chef pipeline gates. The host forwards the authenticated userId; Chef state
// is admin-only and never readable with an /agent/* key.
export async function isAdminUser(
  ctx: QueryCtx,
  userId: string | null | undefined,
): Promise<boolean> {
  if (!userId) return false;
  const u = await ctx.db
    .query("users")
    .withIndex("by_userId", (q) => q.eq("userId", userId))
    .unique();
  return u?.role === "admin";
}

/**
 * Whether any app user (anyone but the CLI's `operator:` identities) has
 * registered. Two indexed reads, whatever the table's size: `operator:` ids
 * sort together, from "operator:" up to "operator;" (':' + 1), so any other
 * user sorts before or after them.
 */
export async function hasAppUser(ctx: QueryCtx): Promise<boolean> {
  const before = await ctx.db
    .query("users")
    .withIndex("by_userId", (q) => q.lt("userId", "operator:"))
    .first();
  if (before) return true;
  const after = await ctx.db
    .query("users")
    .withIndex("by_userId", (q) => q.gte("userId", "operator;"))
    .first();
  return after !== null;
}

/** An admin who is an app user (not the CLI's `operator:` identity) exists. */
export async function hasAppAdminUser(ctx: QueryCtx): Promise<boolean> {
  const admins = await ctx.db
    .query("users")
    .withIndex("by_role", (q) => q.eq("role", "admin"))
    .take(100);
  return admins.some((u) => !u.userId.startsWith("operator:"));
}

export async function requireAdminUser(
  ctx: QueryCtx,
  userId: string | null | undefined,
): Promise<string> {
  if (!(await isAdminUser(ctx, userId))) {
    throw new Error("Unauthorized: only admins can do this.");
  }
  return userId!;
}
