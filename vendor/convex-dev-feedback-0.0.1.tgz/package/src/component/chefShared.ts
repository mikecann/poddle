// Pure helpers shared by the Chef pipeline modules. No Convex functions here.
import type { QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
// The canonical serializer and hash live in a module with no Convex imports,
// so the runner hashes snapshots with the same code.
import { bytesToHex } from "../chef/snapshotHash.js";
export {
  bytesToHex,
  canonicalSnapshotJson,
  sha256Hex,
  snapshotContentHash,
} from "../chef/snapshotHash.js";

/** The storage system table keeps sha256 as base64; snapshots use hex. */
export function base64ToHex(b64: string): string {
  const bin = atob(b64);
  let out = "";
  for (let i = 0; i < bin.length; i++) {
    out += bin.charCodeAt(i).toString(16).padStart(2, "0");
  }
  return out;
}

/** A random secret: `<prefix>_` + 32 random bytes as hex. */
export function randomSecret(prefix: string): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return `${prefix}_${bytesToHex(bytes)}`;
}

export type SnapshotContent = {
  itemId: Id<"items">;
  title: string;
  description: string;
  transcript: string | null;
  attachments: Array<{
    kind: "screenshot" | "audio";
    storageId: Id<"_storage">;
    sha256: string;
    size: number;
    contentType: string;
  }>;
};

/** Everything an approval covers, read from the item as it is now. */
export async function readSnapshotContent(
  ctx: QueryCtx,
  item: Doc<"items">,
): Promise<SnapshotContent> {
  // Bounded by the per-item caps (4 screenshots + 1 voice note).
  const rows = await ctx.db
    .query("attachments")
    .withIndex("by_itemId", (q) => q.eq("itemId", item._id))
    .take(20);
  const attachments: SnapshotContent["attachments"] = [];
  for (const a of rows) {
    const file = await ctx.db.system.get("_storage", a.storageId);
    if (!file) throw new Error("An attachment's file is missing; it can't be approved");
    attachments.push({
      kind: a.kind,
      storageId: a.storageId,
      sha256: base64ToHex(file.sha256),
      size: file.size,
      contentType: file.contentType ?? a.mimeType,
    });
  }
  return {
    itemId: item._id,
    title: item.title,
    description: item.description,
    transcript: item.transcript ?? null,
    attachments,
  };
}

export function itemUpdatedAt(item: Doc<"items">): number {
  return item.updatedAt ?? item._creationTime;
}
