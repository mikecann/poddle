// The Chef agent API behind /chef-agent/* (docs/chef-pipeline.md, "The Chef
// agent API" and "Run credentials").
//
// Every call presents a run credential (after Daytona's placeholder
// substitution). It is hashed and looked up, its scope checked, its run must be
// the active run and in a phase the route allows, and the call writes one
// audit row: route, credential kind and prefix, run, outcome. Never bodies,
// never secrets. Each route is one mutation, so the checks and the work
// happen in the same transaction.
import { auditRepeatedRefusal, noteRejected } from "./chefRejected.js";
import { v } from "convex/values";
import { mutation } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { vDemoStep, vGateResult, vProvenance, vRunPhase } from "./schema.js";
import { parseDemoScript } from "../chef/demo.js";
import { previewNameFor } from "../chef/preview.js";
import { clampFixRounds } from "../chef/gates.js";
import { writeAudit } from "./chefAudit.js";
import { randomSecret, sha256Hex, base64ToHex } from "./chefShared.js";
import { scrub, scrubWithReport } from "../chef/scrub.js";
import { RESOLUTION_DIFF_MAX_BYTES } from "../chef/follow.js";
import { finishRun } from "./chefRuns.js";
import { armRunCheck } from "./chefWatchdog.js";
import { cloudBuildsEnabled } from "./chefAgentKeys.js";
import type { FunctionHandle } from "convex/server";

export const RUN_CRED_PREFIX = "chefr";
/** How long past the run's deadline an enrolled runner may still report its push landed. */
export const LATE_PUSH_GRACE_MS = 30 * 60_000;
const PREFIX_LENGTH = RUN_CRED_PREFIX.length + 1 + 8;

export type RunScope = "run.read" | "run.report" | "attachments.read" | "ai.proxy";
export type RunPhase = Doc<"chefRuns">["phase"];
export type CredentialKind = "runner" | "inference";

export const SCOPES: Record<CredentialKind, RunScope[]> = {
  runner: ["run.read", "run.report", "attachments.read"],
  inference: ["ai.proxy"],
};

const ACTIVE_PHASES: RunPhase[] = [
  "launched", "ready", "cloning", "cloned", "agent", "gates", "guards", "committed", "pushing", "pushed",
  "previewing",
];

// What the runner may report. `cloned` and `committed` ask for the next
// phase; the orchestration grants it (chefEffects.setPhase), after it has
// made the sandbox safe for it. Later phases (preview, done) belong to the
// orchestration, not the sandbox.
export const RUNNER_TRANSITIONS: Partial<Record<RunPhase, RunPhase>> = {
  launched: "ready",
  ready: "cloning",
  cloning: "cloned",
  agent: "gates",
  gates: "guards",
  guards: "committed",
  pushing: "pushed",
};

/**
 * A fix round (src/chef/gates.ts): verification failed in a way the agent
 * can fix (a gate that passed on the base fails, a guard on the diff, the
 * frontend build), and the runner resumes the agent's session. Same egress
 * and git state as verification (the launcher's policy for agent, gates
 * and guards is the app's own host, git dead), so no grant; the inference
 * proxy works again only because the phase is `agent` again, within the
 * same run's spend ceiling. At most the configured rounds
 * (chefRunnerConfig.fixRounds), each recorded with its reason and spend.
 */
export const FIX_ROUND_FROM: readonly RunPhase[] = ["gates", "guards"];

/** Whether `from -> to` starts a fix round: verification (the gates, or the guards and the frontend build) back to the agent. */
export function isFixRound(from: RunPhase, to: RunPhase): boolean {
  return to === "agent" && FIX_ROUND_FROM.includes(from);
}

/** Whether the runner may report `from -> to`. */
export function runnerMayMove(from: RunPhase, to: RunPhase): boolean {
  return RUNNER_TRANSITIONS[from] === to || isFixRound(from, to);
}

/** A requested phase and what the orchestration grants for it. */
export const PHASE_GRANTS: Partial<Record<RunPhase, RunPhase>> = { cloned: "agent", committed: "pushing" };

export const credActor = (prefix: string) => `runCred:${prefix}`;

/**
 * Mint a run credential. The plaintext is returned here once; Convex keeps
 * only its hash. Issuing a kind again revokes the earlier one.
 */
export async function issueRunCredential(
  ctx: MutationCtx,
  run: Doc<"chefRuns">,
  kind: CredentialKind,
  actor: string,
): Promise<string> {
  const now = Date.now();
  const existing = await ctx.db
    .query("chefRunTokens")
    .withIndex("by_runId", (q) => q.eq("runId", run._id))
    .take(20);
  for (const tk of existing) {
    if (tk.kind === kind && tk.revokedAt === undefined) {
      await ctx.db.patch("chefRunTokens", tk._id, { revokedAt: now });
    }
  }
  const token = randomSecret(RUN_CRED_PREFIX);
  const prefix = token.slice(0, PREFIX_LENGTH);
  await ctx.db.insert("chefRunTokens", {
    runId: run._id,
    kind,
    hash: await sha256Hex(token),
    prefix,
    scopes: SCOPES[kind],
    ...(run.agentKeyId !== undefined ? { agentKeyId: run.agentKeyId } : {}),
    createdAt: now,
    expiresAt: run.deadline,
  });
  await writeAudit(ctx, {
    actor,
    action: "credential.issued",
    runId: run._id,
    target: prefix,
    outcome: "ok",
    detail: { kind },
  });
  return token;
}

/**
 * Revoke every unrevoked credential of a run. `for: "reconcile"` marks them
 * revoked because the run went to reconciling (see authorize).
 */
export async function revokeRunCredentials(
  ctx: MutationCtx,
  runId: Id<"chefRuns">,
  opts: { for?: "reconcile" } = {},
): Promise<number> {
  const now = Date.now();
  const tokens = await ctx.db
    .query("chefRunTokens")
    .withIndex("by_runId", (q) => q.eq("runId", runId))
    .take(20);
  let n = 0;
  for (const tk of tokens) {
    if (tk.revokedAt === undefined) {
      await ctx.db.patch("chefRunTokens", tk._id, {
        revokedAt: now,
        ...(opts.for ? { revokedFor: opts.for } : {}),
      });
      n++;
    }
  }
  return n;
}

export type Refusal = { ok: false; status: number; error: string };
export type Authorized = {
  ok: true;
  run: Doc<"chefRuns">;
  token: Doc<"chefRunTokens">;
  /**
   * The run is reconciling and this is its enrolled runner's last word: a
   * push report from a credential revoked by the reconcile (only with
   * `need.reconcilingPush`).
   */
  late: boolean;
};

/** Redacts a presented credential and anything else secret-looking. */
export function scrubFor(presented: string): (text: string) => string {
  return (text) => scrub(text, { knownValues: [presented] });
}

/** The checks every route makes. Writes the refusal's audit row itself. */
export async function authorize(
  ctx: MutationCtx,
  presented: string,
  need: {
    route: string;
    scope: RunScope;
    phases: RunPhase[];
    /**
     * Let an enrolled runner whose run went to reconciling (with no host
     * reconciler to read the refs back) report that its push landed. The
     * credential was revoked by the reconcile; nothing else is allowed.
     */
    reconcilingPush?: boolean;
  },
): Promise<Refusal | Authorized> {
  // `repeats`: a refusal the same credential will get every time from now
  // on (revoked, expired, its run over). Whoever holds it can keep sending
  // it, so only the first is audited in full; the rest are counted per
  // minute (chefRejected.ts). Anything else is audited every time.
  const refuse = async (
    status: number,
    error: string,
    who: { prefix?: string; runId?: Id<"chefRuns">; kind?: string } = {},
    repeats = false,
  ): Promise<Refusal> => {
    const entry = {
      actor: who.prefix ? credActor(who.prefix) : "runCred:unknown",
      action: `route.${need.route}`,
      outcome: "refused" as const,
      reason: error,
      ...(who.runId ? { runId: who.runId } : {}),
      ...(who.kind ? { detail: { kind: who.kind } } : {}),
    };
    if (repeats) await auditRepeatedRefusal(ctx, entry);
    else await writeAudit(ctx, entry);
    return { ok: false, status, error };
  };

  // A credential nobody holds (or the wrong kind entirely) is counted per
  // minute, not audited per request: anyone on the internet can send one.
  const unknown = async (): Promise<Refusal> => {
    const { limited } = await noteRejected(ctx, `route.${need.route}`);
    return limited
      ? { ok: false, status: 429, error: "Too many attempts with unknown credentials; try again in a minute" }
      : { ok: false, status: 401, error: "Invalid run credential" };
  };
  // Only run credentials: never the Chef agent key, never an /agent/* key.
  if (!presented.startsWith(`${RUN_CRED_PREFIX}_`)) return await unknown();
  const hash = await sha256Hex(presented);
  const token = await ctx.db
    .query("chefRunTokens")
    .withIndex("by_hash", (q) => q.eq("hash", hash))
    .unique();
  if (!token) return await unknown();
  const who = { prefix: token.prefix, runId: token.runId, kind: token.kind };
  const run = await ctx.db.get("chefRuns", token.runId);
  const state = await ctx.db
    .query("chefState")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
  const late =
    need.reconcilingPush === true &&
    token.revokedAt !== undefined &&
    token.revokedFor === "reconcile" &&
    token.kind === "runner" &&
    run !== null &&
    run.status === "reconciling" &&
    run.startedVia === "enroll" &&
    run.phase === "pushing" &&
    !state?.reconcilerHandle;
  if (token.revokedAt !== undefined && !late) return await refuse(401, "Run credential revoked", who, true);
  // The late push report also outlives the credential's expiry (the run's
  // deadline), by a bounded grace: a push that lands around the deadline is
  // exactly when its deadline check reconciles the run, and without the report the
  // run would hold the build slot until an admin force-cancels it.
  const expiredAt = token.expiresAt + (late ? LATE_PUSH_GRACE_MS : 0);
  if (Date.now() > expiredAt) return await refuse(401, "Run credential expired", who, true);
  if (token.agentKeyId) {
    const key = await ctx.db.get("chefAgentKeys", token.agentKeyId);
    if (!key || key.revokedAt !== undefined) return await refuse(401, "Chef agent key revoked", who, true);
  }
  if (!token.scopes.includes(need.scope)) return await refuse(403, `Missing scope ${need.scope}`, who);
  if (!run || (run.status !== "active" && !late)) return await refuse(403, "Run is not active", who, true);
  if (state?.activeRunId !== run._id) return await refuse(403, "Not the active run", who);
  if (!need.phases.includes(run.phase)) {
    return await refuse(409, `Not allowed in phase ${run.phase}`, who);
  }
  return { ok: true, run, token, late };
}

/** A refusal after authorize passed: audited with the credential's prefix and run. */
export async function refuseAuthorized(
  ctx: MutationCtx,
  a: Authorized,
  route: string,
  status: number,
  error: string,
  detail: Record<string, string | number | boolean | null> = {},
): Promise<Refusal> {
  await writeAudit(ctx, {
    actor: credActor(a.token.prefix),
    action: `route.${route}`,
    runId: a.run._id,
    outcome: "refused",
    reason: error,
    detail: { kind: a.token.kind, ...detail },
  });
  return { ok: false, status, error };
}

export async function auditOk(
  ctx: MutationCtx,
  a: Authorized,
  route: string,
  detail: Record<string, string | number | boolean | null> = {},
) {
  await writeAudit(ctx, {
    actor: credActor(a.token.prefix),
    action: `route.${route}`,
    runId: a.run._id,
    outcome: "ok",
    detail: { kind: a.token.kind, ...detail },
  });
}

export const vRefusal = v.object({ ok: v.literal(false), status: v.number(), error: v.string() });

// --------------------------------------------------------------- GET /run

const vRunSnapshot = v.object({
  title: v.string(),
  description: v.string(),
  transcript: v.union(v.string(), v.null()),
  contentHash: v.string(),
  itemId: v.id("items"),
  // Fetched one by one from /chef-agent/attachments/<index>; never a URL.
  attachments: v.array(
    v.object({
      index: v.number(),
      kind: v.union(v.literal("screenshot"), v.literal("audio")),
      storageId: v.id("_storage"),
      sha256: v.string(),
      size: v.number(),
      contentType: v.string(),
    }),
  ),
});

function runSnapshotOf(snapshot: Doc<"chefSnapshots">) {
  return {
    title: snapshot.title,
    description: snapshot.description,
    transcript: snapshot.transcript,
    contentHash: snapshot.contentHash,
    itemId: snapshot.itemId,
    attachments: snapshot.attachments.map((x, index) => ({ index, ...x })),
  };
}

/** A batch run's other requests, in order, with their snapshots; null when one is gone. */
async function batchMembers(ctx: QueryCtx, run: Doc<"chefRuns">) {
  if (!run.batch) return [];
  const out: Array<{ itemNumber: number; snapshot: Doc<"chefSnapshots"> }> = [];
  for (const m of run.batch.items) {
    if (m.itemId === run.itemId) continue;
    const item = await ctx.db.get("items", m.itemId);
    const snapshot = await ctx.db.get("chefSnapshots", m.snapshotId);
    if (!item || !snapshot || snapshot.itemId !== item._id) return null;
    out.push({ itemNumber: item.number, snapshot });
  }
  return out;
}

export const getRun = mutation({
  args: { token: v.string() },
  returns: v.union(
    vRefusal,
    v.object({
      ok: v.literal(true),
      runId: v.id("chefRuns"),
      seq: v.number(),
      phase: vRunPhase,
      deadline: v.number(),
      itemNumber: v.number(),
      // This run starts from a failed run's work ("Try again"): GET /chef-agent/attempt.
      continues: v.boolean(),
      // "merge": no agent; merge the current main into chef and check it (Ship it found main moved).
      mode: v.optional(v.literal("merge")),
      // A release merge (contract 13, chefShip.followMain): merge main into
      // `fromSha` (the release's approved commit, not chef's tip), let the
      // agent resolve conflicts and fix the checks when `repair`, and push
      // the request branch only.
      release: v.optional(v.object({ seq: v.number(), fromSha: v.string(), repair: v.boolean() })),
      // A follow-up build: why the last build's preview failed on its own code.
      followUp: v.optional(v.object({ reason: v.string() })),
      snapshot: vRunSnapshot,
      // A batch (chefBatches.ts): the other requests this run builds, each
      // with its own approved snapshot (checked by its own hash). Member
      // `k` (1-based, in this order) has its attachments at
      // /chef-agent/attachments/<k>/<index>.
      batch: v.optional(v.array(v.object({ itemNumber: v.number(), snapshot: vRunSnapshot }))),
    }),
  ),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "run", scope: "run.read", phases: ACTIVE_PHASES });
    if (!a.ok) return a;
    const snapshot = await ctx.db.get("chefSnapshots", a.run.snapshotId);
    const item = await ctx.db.get("items", a.run.itemId);
    if (!snapshot || !item) return await refuseAuthorized(ctx, a, "run", 410, "Snapshot is gone");
    const members = await batchMembers(ctx, a.run);
    if (!members) return await refuseAuthorized(ctx, a, "run", 410, "A batched request's snapshot is gone");
    await auditOk(ctx, a, "run", members.length ? { batch: members.length + 1 } : {});
    return {
      ok: true as const,
      runId: a.run._id,
      seq: a.run.seq,
      phase: a.run.phase,
      deadline: a.run.deadline,
      itemNumber: item.number,
      continues: a.run.continueFrom !== undefined,
      ...(a.run.mode ? { mode: a.run.mode } : {}),
      ...(a.run.refresh?.releaseId && a.run.refresh.fromSha
        ? { release: { seq: a.run.refresh.releaseSeq, fromSha: a.run.refresh.fromSha, repair: a.run.refresh.repair === true } }
        : {}),
      ...(a.run.followUp ? { followUp: { reason: a.run.followUp.reason } } : {}),
      snapshot: runSnapshotOf(snapshot),
      ...(members.length ? { batch: members.map((m) => ({ itemNumber: m.itemNumber, snapshot: runSnapshotOf(m.snapshot) })) } : {}),
    };
  },
});

// ---------------------------------------------------- GET /attachments/<i>

/**
 * Authorize one attachment read and hand the HTTP action (server side only)
 * what it needs to stream it: the storage URL, which never leaves the
 * action, and the sha256 the bytes must match. Refusals are audited here;
 * the call's final outcome (served, fetch failed, bytes mismatched) is
 * recorded by the action with recordRoute once it knows it, so each call
 * still writes one row.
 */
export const attachmentSource = mutation({
  // `member`: a batch's other request (1-based, as GET /run lists them); absent for the run's own.
  args: { token: v.string(), index: v.number(), member: v.optional(v.number()) },
  returns: v.union(
    vRefusal,
    v.object({
      ok: v.literal(true),
      url: v.string(),
      sha256: v.string(),
      size: v.number(),
      contentType: v.string(),
    }),
  ),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, {
      route: "attachments",
      scope: "attachments.read",
      phases: ["ready", "cloning"],
    });
    if (!a.ok) return a;
    const index = Number.isInteger(args.index) ? args.index : -1;
    let snapshotId = a.run.snapshotId;
    if (args.member !== undefined) {
      const others = (a.run.batch?.items ?? []).filter((m) => m.itemId !== a.run.itemId);
      const m = Number.isInteger(args.member) && args.member >= 1 ? others[args.member - 1] : undefined;
      if (!m) return await refuseAuthorized(ctx, a, "attachments", 404, "No such batched request", { index, member: args.member });
      snapshotId = m.snapshotId;
    }
    const snapshot = await ctx.db.get("chefSnapshots", snapshotId);
    const att = index >= 0 ? snapshot?.attachments[index] : undefined;
    if (!snapshot || !att) return await refuseAuthorized(ctx, a, "attachments", 404, "No such attachment", { index });
    const file = await ctx.db.system.get("_storage", att.storageId);
    if (!file) return await refuseAuthorized(ctx, a, "attachments", 410, "Attachment file is gone", { index });
    if (base64ToHex(file.sha256) !== att.sha256) {
      return await refuseAuthorized(ctx, a, "attachments", 409, "Attachment hash mismatch", { index });
    }
    const url = await ctx.storage.getUrl(att.storageId);
    if (!url) return await refuseAuthorized(ctx, a, "attachments", 410, "Attachment file is gone", { index });
    return { ok: true as const, url, sha256: att.sha256, size: att.size, contentType: att.contentType };
  },
});

/** The bytes the HTTP action fetched didn't match: record it. Kept for older hosts; the action now uses recordRoute. */
export const attachmentMismatch = mutation({
  args: { token: v.string(), index: v.number() },
  returns: v.null(),
  handler: async (ctx, args) => {
    const who = await resolveCredential(ctx, args.token);
    if (who.actor === "anonymous" || who.actor.endsWith(":unknown")) {
      await noteRejected(ctx, "route.attachments");
      return null;
    }
    await writeAudit(ctx, {
      actor: who.actor,
      action: "route.attachments",
      ...(who.runId ? { runId: who.runId } : {}),
      outcome: "refused",
      reason: "fetched bytes don't match the snapshot sha256",
      detail: { index: args.index },
    });
    return null;
  },
});

// --------------------------------------------- outcomes decided in the action

/**
 * Who a presented credential is, for an audit row: the prefix and run of a
 * run credential, the prefix of a Chef agent key, or unknown. Never any part
 * of an unknown value, which could be a mistyped real credential.
 */
async function resolveCredential(
  ctx: MutationCtx,
  presented: string | null,
): Promise<{ actor: string; runId?: Id<"chefRuns">; kind?: string }> {
  if (presented && presented.startsWith(`${RUN_CRED_PREFIX}_`)) {
    const hash = await sha256Hex(presented);
    const token = await ctx.db
      .query("chefRunTokens")
      .withIndex("by_hash", (q) => q.eq("hash", hash))
      .unique();
    if (token) return { actor: credActor(token.prefix), runId: token.runId, kind: token.kind };
    return { actor: "runCred:unknown" };
  }
  if (presented && presented.startsWith("chefk_")) {
    const hash = await sha256Hex(presented);
    const key = await ctx.db
      .query("chefAgentKeys")
      .withIndex("by_hash", (q) => q.eq("hash", hash))
      .unique();
    return { actor: key ? `chefKey:${key.prefix}` : "chefKey:unknown" };
  }
  return { actor: presented ? "runCred:unknown" : "anonymous" };
}

export const vRouteName = v.union(
  v.literal("enroll"),
  v.literal("run"),
  v.literal("attachments"),
  v.literal("report"),
  v.literal("log"),
  v.literal("heartbeat"),
  v.literal("ai"),
  v.literal("feedback"),
  v.literal("approvals"),
  v.literal("screenshot"),
  v.literal("artifact"),
  v.literal("releaseDiff"),
  v.literal("finish"),
  v.literal("learnings"),
  v.literal("attempt"),
);

/**
 * The audit row for a route outcome the HTTP action decided itself: no or
 * malformed bearer, a malformed body, a bad attachment index, a storage
 * fetch failure, fetched bytes that don't match, a served attachment, an
 * unexpected error. Records the credential's prefix and run, never the
 * credential or the body.
 */
export const recordRoute = mutation({
  args: {
    token: v.union(v.string(), v.null()),
    route: vRouteName,
    outcome: v.union(v.literal("ok"), v.literal("refused"), v.literal("error")),
    status: v.number(),
    reason: v.optional(v.string()),
    index: v.optional(v.number()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const who = await resolveCredential(ctx, args.token);
    // No credential, or one nobody holds: a count, not a row each.
    if (who.actor === "anonymous" || who.actor.endsWith(":unknown")) {
      await noteRejected(ctx, args.route === "enroll" ? "agentKey.enroll" : `route.${args.route}`);
      return null;
    }
    const clean = args.token ? scrubFor(args.token) : (x: string) => scrub(x);
    await writeAudit(ctx, {
      actor: who.actor,
      action: args.route === "enroll" ? "agentKey.enroll" : `route.${args.route}`,
      ...(who.runId ? { runId: who.runId } : {}),
      outcome: args.outcome,
      ...(args.reason !== undefined ? { reason: clean(args.reason.slice(0, 300)) } : {}),
      detail: {
        status: Number.isFinite(args.status) ? args.status : 0,
        ...(who.kind ? { kind: who.kind } : {}),
        ...(args.index !== undefined && Number.isFinite(args.index) ? { index: args.index } : {}),
      },
    });
    return null;
  },
});

// ------------------------------------------------------------ POST /report

const SHA = /^[0-9a-f]{7,64}$/;
const BRANCH = /^chef-req\/[A-Za-z0-9._-]{1,100}$/;

const vFacts = v.object({
  baseSha: v.optional(v.string()),
  branch: v.optional(v.string()),
  commitSha: v.optional(v.string()),
  chefBefore: v.optional(v.string()),
  chefAfter: v.optional(v.string()),
  filesChanged: v.optional(v.array(v.string())),
  depsChanged: v.optional(v.boolean()),
  diffHash: v.optional(v.string()),
  provenance: v.optional(vProvenance),
  error: v.optional(v.string()),
  // The gates against the base and after the agent (src/chef/gates.ts).
  gateResults: v.optional(v.array(vGateResult)),
  // Verification to agent: which fix round starts (1-based), and why.
  fixRound: v.optional(v.number()),
  fixReason: v.optional(v.string()),
  // A merge-only run: how many commits main brought, and their subjects.
  mergedMain: v.optional(v.object({ count: v.number(), subjects: v.array(v.string()) })),
  // The agent's demo script (src/chef/demo.ts), as the runner read and checked it.
  demoScript: v.optional(v.object({ steps: v.array(vDemoStep) })),
  // A release merge whose agent resolved conflicts or fixed the checks: the
  // files, and the resolution diff (the merge as git left it to the commit).
  mergeRepair: v.optional(
    v.object({ conflicts: v.array(v.string()), gates: v.array(v.string()), files: v.array(v.string()), diff: v.string(), truncated: v.boolean() }),
  ),
});

type Facts = typeof vFacts.type;

function checkFacts(f: Facts): string | null {
  for (const k of ["baseSha", "commitSha", "chefBefore", "chefAfter", "diffHash"] as const) {
    if (f[k] !== undefined && !SHA.test(f[k]!)) return `${k} is not a hex sha`;
  }
  if (f.branch !== undefined && !BRANCH.test(f.branch)) return "branch must be chef-req/<name>";
  if (f.filesChanged && (f.filesChanged.length > 1000 || f.filesChanged.some((p) => p.length > 500))) {
    return "filesChanged is too large";
  }
  if (f.provenance && Object.values(f.provenance).some((x) => typeof x === "string" && x.length > 200)) {
    return "provenance value too long";
  }
  if (f.error !== undefined && f.error.length > 20_000) return "error is too long";
  if (
    f.gateResults &&
    (f.gateResults.length > 20 ||
      f.gateResults.some(
        (g) =>
          g.command.length > 500 ||
          (g.newProblems ?? []).length > 20 ||
          (g.baselineFiles ?? []).length > 20 ||
          [...(g.newProblems ?? []), ...(g.baselineFiles ?? [])].some((x) => x.length > 500),
      ))
  ) {
    return "gateResults is too large";
  }
  if (f.fixRound !== undefined && (!Number.isInteger(f.fixRound) || f.fixRound < 1 || f.fixRound > 100)) {
    return "fixRound must be a positive integer";
  }
  if (f.fixReason !== undefined && f.fixReason.length > 2000) return "fixReason is too long";
  if (
    f.mergedMain &&
    (!Number.isInteger(f.mergedMain.count) || f.mergedMain.count < 0 || f.mergedMain.subjects.length > 20 || f.mergedMain.subjects.some((x) => x.length > 500))
  ) {
    return "mergedMain is too large";
  }
  if (
    f.mergeRepair &&
    (f.mergeRepair.conflicts.length > 200 ||
      f.mergeRepair.gates.length > 20 ||
      f.mergeRepair.files.length > 500 ||
      [...f.mergeRepair.conflicts, ...f.mergeRepair.gates, ...f.mergeRepair.files].some((x) => x.length > 500) ||
      f.mergeRepair.diff.length > RESOLUTION_DIFF_MAX_BYTES * 2)
  ) {
    return "mergeRepair is too large";
  }
  if (f.demoScript) {
    const again = parseDemoScript(JSON.stringify(f.demoScript));
    if (!again.script || again.script.steps.length !== f.demoScript.steps.length) return "demoScript is not a valid demo script";
  }
  return null;
}

/**
 * Scrub every string of a report at the trust boundary, with the presented
 * credential as a known value. Fixed-format fields (shas, the branch) are
 * refused if scrubbing would change them; free-form ones (the error,
 * provenance, file names) are stored redacted.
 */
function scrubFacts(f: Facts, clean: (s: string) => string): { facts: Facts } | { error: string } {
  for (const k of ["baseSha", "commitSha", "chefBefore", "chefAfter", "diffHash", "branch"] as const) {
    const x = f[k];
    if (x !== undefined && clean(x) !== x) return { error: `${k} holds a credential` };
  }
  const out: Facts = { ...f };
  if (f.filesChanged) out.filesChanged = f.filesChanged.map(clean);
  if (f.gateResults) {
    out.gateResults = f.gateResults.map((g) => ({
      ...g,
      command: clean(g.command),
      ...(g.newProblems ? { newProblems: g.newProblems.map(clean) } : {}),
      ...(g.baselineFiles ? { baselineFiles: g.baselineFiles.map(clean) } : {}),
    }));
  }
  if (f.fixReason !== undefined) out.fixReason = clean(f.fixReason).slice(0, 300);
  if (f.mergedMain) out.mergedMain = { count: f.mergedMain.count, subjects: f.mergedMain.subjects.map((x) => clean(x).slice(0, 200)) };
  if (f.error !== undefined) out.error = clean(f.error).slice(0, 2000);
  if (f.mergeRepair) {
    out.mergeRepair = {
      conflicts: f.mergeRepair.conflicts.map(clean),
      gates: f.mergeRepair.gates.map(clean),
      files: f.mergeRepair.files.map(clean),
      // Scrubbed like any diff Chef stores; capped for the card.
      diff: scrubWithReport(f.mergeRepair.diff).text.slice(0, RESOLUTION_DIFF_MAX_BYTES),
      truncated: f.mergeRepair.truncated || f.mergeRepair.diff.length > RESOLUTION_DIFF_MAX_BYTES,
    };
  }
  if (f.provenance) {
    const p: Record<string, string> = {};
    for (const [k, x] of Object.entries(f.provenance)) if (typeof x === "string") p[k] = clean(x);
    out.provenance = p as Facts["provenance"];
  }
  return { facts: out };
}

/** JSON with sorted keys and no undefined, so equal reports serialize equally. */
export function canonicalJson(x: unknown): string {
  if (Array.isArray(x)) return `[${x.map(canonicalJson).join(",")}]`;
  if (x !== null && typeof x === "object") {
    const entries = Object.entries(x as Record<string, unknown>)
      .filter(([, val]) => val !== undefined)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
    return `{${entries.map(([k, val]) => `${JSON.stringify(k)}:${canonicalJson(val)}`).join(",")}}`;
  }
  return JSON.stringify(x);
}

/** sha256 of the normalized, scrubbed report: what an exact replay must match. */
export async function reportHash(from: RunPhase, to: RunPhase, facts: Facts): Promise<string> {
  return await sha256Hex(canonicalJson({ v: 1, from, to, facts }));
}

/**
 * A phase change with facts. Compare-and-set on (run, fromPhase): repeating
 * the last applied report exactly is a no-op, the same transition with
 * different facts is refused, and a stale one is refused.
 *
 * An enrolled run that went to reconciling with no host reconciler keeps its
 * slot until an admin force-cancels it or its runner reports that the push
 * landed (pushing to pushed); that report finishes the run as built.
 */
export const report = mutation({
  args: { token: v.string(), fromPhase: vRunPhase, toPhase: vRunPhase, facts: v.optional(vFacts) },
  returns: v.union(
    vRefusal,
    v.object({ ok: v.literal(true), applied: v.boolean(), phase: vRunPhase }),
  ),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, {
      route: "report",
      scope: "run.report",
      phases: ACTIVE_PHASES,
      reconcilingPush: args.fromPhase === "pushing" && args.toPhase === "pushed",
    });
    if (!a.ok) return a;
    const run = a.run;
    const detail = { from: args.fromPhase, to: args.toPhase, phase: run.phase };
    const refuse = (status: number, error: string) =>
      refuseAuthorized(ctx, a, "report", status, error, detail);
    const raw = args.facts ?? {};
    const bad = checkFacts(raw);
    if (bad) return await refuse(400, bad);
    const scrubbed = scrubFacts(raw, scrubFor(args.token));
    if ("error" in scrubbed) return await refuse(400, scrubbed.error);
    const facts = scrubbed.facts;
    const hash = await reportHash(args.fromPhase, args.toPhase, facts);
    if (
      (run.phase === args.toPhase &&
        run.lastReport?.from === args.fromPhase &&
        run.lastReport?.to === args.toPhase) ||
      // A repeated request that was already granted.
      (RUNNER_TRANSITIONS[args.fromPhase] === args.toPhase && PHASE_GRANTS[args.toPhase] === run.phase)
    ) {
      // A row from before report hashes, or one the refs confirmed, has none.
      if (run.lastReport?.hash !== undefined && run.lastReport.hash !== hash) {
        return await refuse(409, "A different report for this transition was already applied");
      }
      await auditOk(ctx, a, "report", { from: args.fromPhase, to: args.toPhase, applied: false });
      return { ok: true as const, applied: false, phase: run.phase };
    }
    if (run.phase !== args.fromPhase) {
      return await refuse(409, `Stale report: the run is in ${run.phase}`);
    }
    if (!runnerMayMove(args.fromPhase, args.toPhase)) {
      return await refuse(400, `The runner can't move ${args.fromPhase} to ${args.toPhase}`);
    }
    let roundLog = run.roundLog;
    if (isFixRound(args.fromPhase, args.toPhase)) {
      const config = await ctx.db
        .query("chefRunnerConfig")
        .withIndex("by_key", (q) => q.eq("key", "singleton"))
        .unique();
      const max = clampFixRounds(config?.fixRounds);
      const want = (run.fixRound ?? 0) + 1;
      if (facts.fixRound !== want) return await refuse(400, `A fix round must say its number (${want})`);
      if (want > max) return await refuse(409, `No fix rounds left (${max} allowed)`);
      roundLog = [
        ...(run.roundLog ?? []),
        { round: want, from: args.fromPhase, reason: facts.fixReason ?? "", at: Date.now(), spendUsd: run.spendUsd ?? 0 },
      ].slice(-10);
    }
    // fixReason goes into the round's record, not onto the run.
    const { fixReason: _fixReason, ...runFacts } = facts;
    const now = Date.now();
    // An external runner (enroll) has no orchestration holding its sandbox's
    // egress or git secret, so its requests are granted at once.
    const grant = run.startedVia === "enroll" ? PHASE_GRANTS[args.toPhase] : undefined;
    const phase = grant ?? args.toPhase;
    await ctx.db.patch("chefRuns", run._id, {
      ...runFacts,
      ...(facts.provenance ? { provenance: { ...run.provenance, ...facts.provenance } } : {}),
      ...(roundLog !== run.roundLog ? { roundLog } : {}),
      phase,
      lastReport: { from: args.fromPhase, to: args.toPhase, at: now, hash },
      heartbeatAt: now,
    });
    await auditOk(ctx, a, "report", {
      from: args.fromPhase,
      to: args.toPhase,
      applied: true,
      ...(a.late ? { reconciling: true } : {}),
    });
    if (a.late) {
      await writeAudit(ctx, {
        actor: credActor(a.token.prefix),
        action: "run.reconciled",
        runId: run._id,
        outcome: "ok",
        reason: "the enrolled runner reported its push while the run was reconciling",
        detail: { outcome: "built", commit: facts.commitSha ?? run.commitSha ?? null },
      });
      await finishRun(ctx, run._id, "built", {
        actor: credActor(a.token.prefix),
        error: `${run.pendingError ?? "stopped"}; its runner reported the push`,
      });
    }
    return { ok: true as const, applied: true, phase };
  },
});

// --------------------------------------------------------------- POST /log

const MAX_LOG_LINES = 200;
const MAX_LOG_LINE = 4000;
const MAX_LOG_SEQ = 100_000;

/**
 * Log lines, stored once per (run, seq). The runner scrubs them, and they are
 * scrubbed again here, with the presented credential as a known value, so a
 * runner that leaks its own credential (or a Chef key, a JWT, a placeholder)
 * still stores only redactions.
 */
export const log = mutation({
  args: { token: v.string(), seq: v.number(), lines: v.array(v.string()) },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.boolean() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "log", scope: "run.report", phases: ACTIVE_PHASES });
    if (!a.ok) return a;
    if (!Number.isInteger(args.seq) || args.seq < 0 || args.seq > MAX_LOG_SEQ) {
      return await refuseAuthorized(ctx, a, "log", 400, "seq must be an integer from 0 to 100000");
    }
    if (args.lines.length > MAX_LOG_LINES) {
      return await refuseAuthorized(ctx, a, "log", 400, `At most ${MAX_LOG_LINES} lines per call`, { seq: args.seq });
    }
    const existing = await ctx.db
      .query("chefRunLogs")
      .withIndex("by_runId_and_seq", (q) => q.eq("runId", a.run._id).eq("seq", args.seq))
      .first();
    if (!existing) {
      const clean = scrubFor(args.token);
      await ctx.db.insert("chefRunLogs", {
        runId: a.run._id,
        seq: args.seq,
        // Scrub the whole line, then cut it, so a cut can't split a secret
        // into pieces no pattern recognises.
        lines: args.lines.map((l) => clean(l.slice(0, MAX_LOG_LINE * 4)).slice(0, MAX_LOG_LINE)),
        at: Date.now(),
      });
    }
    await auditOk(ctx, a, "log", { seq: args.seq, stored: !existing });
    return { ok: true as const, stored: !existing };
  },
});

// --------------------------------------------------------- POST /heartbeat

export const heartbeat = mutation({
  args: { token: v.string() },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), phase: vRunPhase })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, {
      route: "heartbeat",
      scope: "run.report",
      phases: ACTIVE_PHASES,
    });
    if (!a.ok) return a;
    const now = Date.now();
    await ctx.db.patch("chefRuns", a.run._id, { heartbeatAt: now });
    // A run claimed before deadline checks existed gets its one now.
    if (a.run.watchdogDueAt === undefined) await armRunCheck(ctx, { ...a.run, heartbeatAt: now }, now);
    await auditOk(ctx, a, "heartbeat");
    return { ok: true as const, phase: a.run.phase };
  },
});

// ------------------------------------------------------------ POST /finish

const DEPLOYMENT_NAME = /^[a-z0-9-]{1,64}$/;
const FINISH_FAIL_PHASES: RunPhase[] = [
  "launched", "ready", "cloning", "cloned", "agent", "gates", "guards", "committed", "pushing",
];

/**
 * An enrolled run's end, from its own runner (`npx chef work`), since no
 * host orchestration drives it. `failed` from any phase before `pushed`
 * (its commit hasn't reached chef). `built` only once it is `pushed`: with
 * the preview the runner deployed itself (`previewDeploymentName`, the
 * deployment of the request's preview, `chef-req-<number>`; the URL is
 * built here from its name), or
 * with `handoff`, which gives the run to the host's registered
 * orchestrator for the cloud preview (it sees `pushed` and starts there)
 * instead of finishing it, or with neither, for no preview. A handoff needs
 * cloud builds on (a live "cloud" key); otherwise it is refused with 409 and
 * the runner finishes without a cloud preview.
 */
export const finish = mutation({
  args: {
    token: v.string(),
    outcome: v.union(v.literal("built"), v.literal("failed")),
    error: v.optional(v.string()),
    handoff: v.optional(v.boolean()),
    previewDeploymentName: v.optional(v.string()),
  },
  returns: v.union(
    vRefusal,
    v.object({ ok: v.literal(true), finished: v.boolean(), handedOff: v.boolean() }),
  ),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "finish", scope: "run.report", phases: ACTIVE_PHASES });
    if (!a.ok) return a;
    const run = a.run;
    const refuse = (status: number, error: string) =>
      refuseAuthorized(ctx, a, "finish", status, error, { outcome: args.outcome, phase: run.phase });
    if (run.startedVia !== "enroll") return await refuse(403, "Only an enrolled run finishes itself");
    const clean = scrubFor(args.token);
    const error = args.error !== undefined ? clean(args.error).slice(0, 2000) : undefined;
    const actor = credActor(a.token.prefix);
    if (args.outcome === "failed") {
      if (args.handoff || args.previewDeploymentName !== undefined) return await refuse(400, "A failed run has no preview");
      if (!FINISH_FAIL_PHASES.includes(run.phase)) {
        return await refuse(409, `The run is ${run.phase}: its commit is on chef, so it finishes built`);
      }
      await auditOk(ctx, a, "finish", { outcome: "failed", phase: run.phase });
      await finishRun(ctx, run._id, "failed", { actor, error: error ?? "the runner failed" });
      return { ok: true as const, finished: true, handedOff: false };
    }
    if (run.phase !== "pushed") return await refuse(409, `Not allowed in phase ${run.phase}`);
    if (args.handoff && args.previewDeploymentName !== undefined) {
      return await refuse(400, "Either a preview or a handoff, not both");
    }
    if (args.handoff) {
      const state = await ctx.db
        .query("chefState")
        .withIndex("by_key", (q) => q.eq("key", "singleton"))
        .unique();
      const handle = state?.orchestratorHandle;
      if (!handle) return await refuse(409, "No cloud preview: the app registered no orchestrator");
      // The cloud preview is cloud spend: a worker-only app (cloud builds
      // off) finishes without one, or deploys one from the worker.
      if (!(await cloudBuildsEnabled(ctx))) return await refuse(409, "No cloud preview: cloud builds are off");
      if (run.orchestratedAt === undefined) {
        await ctx.scheduler.runAfter(0, handle as FunctionHandle<"action">, { runId: run._id });
        await ctx.db.patch("chefRuns", run._id, { orchestratedAt: Date.now(), heartbeatAt: Date.now() });
      }
      await auditOk(ctx, a, "finish", { outcome: "built", handoff: true });
      return { ok: true as const, finished: false, handedOff: true };
    }
    if (args.previewDeploymentName !== undefined) {
      if (!run.commitSha) return await refuse(409, "The run has no commit");
      if (!DEPLOYMENT_NAME.test(args.previewDeploymentName)) return await refuse(400, "Bad deployment name");
      const item = await ctx.db.get("items", run.itemId);
      await ctx.db.patch("chefRuns", run._id, {
        previewName: previewNameFor({ itemNumber: item?.number ?? null, sha: run.commitSha }),
        previewUrl: `https://${args.previewDeploymentName}.convex.site`,
      });
    }
    await auditOk(ctx, a, "finish", {
      outcome: "built",
      preview: args.previewDeploymentName !== undefined ? args.previewDeploymentName : null,
    });
    await finishRun(ctx, run._id, "built", { actor, ...(error !== undefined ? { error } : {}) });
    return { ok: true as const, finished: true, handedOff: false };
  },
});

// ------------------------------------------------- the orchestrator's side

/**
 * The runner and inference credentials for a Daytona run, returned once so
 * the host's orchestration can put them into Daytona secrets. Host-only: the
 * host must never expose this to clients. Calling it again issues new ones and
 * revokes the old.
 */
export const issueRunCredentials = mutation({
  args: { runId: v.id("chefRuns") },
  returns: v.object({ runner: v.string(), inference: v.string() }),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.status !== "active") throw new Error("Run is not active");
    if (run.startedVia === "enroll") {
      throw new Error("An enrolled run gets its credential from enroll");
    }
    const actor = "system:orchestrator";
    return {
      runner: await issueRunCredential(ctx, run, "runner", actor),
      inference: await issueRunCredential(ctx, run, "inference", actor),
    };
  },
});

