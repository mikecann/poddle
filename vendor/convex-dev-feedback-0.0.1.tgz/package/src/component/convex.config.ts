import { defineComponent } from "convex/server";

// The feedback component has no child components. Cloud builds (Daytona,
// Code Storage, Resend, @convex-dev/workflow) are a separate component,
// @convex-dev/chef-cloud (packages/chef-cloud), which an app installs only
// if it wants them.
const component = defineComponent("feedback");

export default component;
