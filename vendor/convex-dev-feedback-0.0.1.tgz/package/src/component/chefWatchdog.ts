// The watchdog (docs/chef-pipeline.md, "The watchdog"), event-driven: no
// cron. Whatever can get stuck gets ONE scheduled check, created the moment
// it can get stuck, due at the moment it would be stuck; the check does
// nothing if it finished meanwhile, and schedules the next one while it is
// still live. So an idle app has nothing scheduled at all.
//
// A run (checkRun), armed when it is claimed and when it goes to
// reconciling, due at its next deadline:
//
// - active: no heartbeat for HEARTBEAT_STALE_MS, or past its deadline, and
//   it goes to reconciliation (chefRuns.reconcileIfStale, exactly what the
//   claim does for a stale run in the slot). A run that heartbeats is
//   checked again at its new staleness time: at most every 15 minutes, for
//   the 90 minutes it can live.
// - reconciling (its reconciler failed or never ran): the reconciler is
//   scheduled again after RECONCILE_RETRY_MS; past RECONCILE_GIVE_UP_MS the
//   run finishes failed ("stale: reconciliation never finished", which
//   recovery treats as transient: a build that pushed nothing is tried
//   again), the slot frees, the next build is claimed, and the host's
//   cleanup runs once (chefEffects.setCleaner) for whatever it left.
//
// An open ship (checkShip), armed whenever its shipper is started (or will
// be, after a transient failure), due SHIP_STALE_MS after it last changed:
// if it stopped answering, its shipper is started again, which adopts its
// sandbox and script by label (src/chef/recovery.ts: transient, a bounded
// number of times), or, past those, it says so and waits for a person.
//
// Each check carries the due time it was armed for; the row keeps the due
// time of its one pending check (watchdogDueAt, shipWatchdogDueAt), so an
// older check, or one for something that finished, does nothing.
//
// `check` is the old sweep over everything, kept for hosts that still call
// it (chefCloud's chefSweep, `npx chef cleanup`): it does the same per
// run and ship, and arms a check for anything live that has none (a run or
// ship from before deadline checks existed). Audited as watchdog.*.
import { v } from "convex/values";
import { internalMutation, mutation } from "./_generated/server.js";
import type { MutationCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import type { FunctionHandle } from "convex/server";
import { internal } from "./_generated/api.js";
import { writeAudit } from "./chefAudit.js";
import { beginReconcile, finishRun, HEARTBEAT_STALE_MS, reconcileIfStale } from "./chefRuns.js";
import { startShipper } from "./chefShip.js";
import { MAX_AUTO_RETRIES } from "../chef/failures.js";

export const RECONCILE_RETRY_MS = 20 * 60_000;
export const RECONCILE_GIVE_UP_MS = 2 * 3600_000;
export const SHIP_STALE_MS = 45 * 60_000;
/** A check runs this long after the moment it checks, so `now` is past it. */
export const CHECK_SLACK_MS = 1_000;
const ACTOR = "system:watchdog";

// ------------------------------------------------------------------ runs

/** When a live run's next check is due: null for a run that finished. */
export function runCheckDue(run: Doc<"chefRuns">): number | null {
  if (run.status === "active") {
    return Math.min(run.heartbeatAt + HEARTBEAT_STALE_MS, run.deadline) + CHECK_SLACK_MS;
  }
  if (run.status === "reconciling") {
    const since = run.reconcileStartedAt ?? run.heartbeatAt;
    const last = run.reconcileRetriedAt ?? since;
    return Math.min(last + RECONCILE_RETRY_MS, since + RECONCILE_GIVE_UP_MS) + CHECK_SLACK_MS;
  }
  return null;
}

/**
 * Schedule a live run's one check, at its next deadline; the one pending
 * before it, if any, becomes a no-op. Nothing for a run that finished.
 */
export async function armRunCheck(ctx: MutationCtx, run: Doc<"chefRuns">, now = Date.now()): Promise<number | null> {
  const due = runCheckDue(run);
  if (due === null) return null;
  await ctx.db.patch("chefRuns", run._id, { watchdogDueAt: due });
  await ctx.scheduler.runAfter(Math.max(0, due - now), internal.chefWatchdog.checkRun, { runId: run._id, dueAt: due });
  return due;
}

type RunCheck = "none" | "reconciling" | "reconciler" | "finished";

/** What the watchdog does for one run at `now`; the run's next check is the caller's. */
async function watchRun(ctx: MutationCtx, run: Doc<"chefRuns">, now: number): Promise<RunCheck> {
  if (run.status === "active") {
    return (await reconcileIfStale(ctx, run, now, ACTOR)) ? "reconciling" : "none";
  }
  if (run.status !== "reconciling") return "none";
  const since = run.reconcileStartedAt ?? run.heartbeatAt;
  if (now - since > RECONCILE_GIVE_UP_MS) {
    await writeAudit(ctx, {
      actor: ACTOR,
      action: "watchdog.finished",
      runId: run._id,
      outcome: "ok",
      reason: "reconciliation never finished",
      detail: { minutes: Math.round((now - since) / 60_000) },
    });
    // finishRun takes a reconciling run too; the error is classified
    // (runnerLost: transient) and recovery decides what follows. It frees
    // the slot, claims the next build and schedules the host's cleanup.
    await finishRun(ctx, run._id, "failed", { actor: ACTOR, error: `stale: no heartbeat; reconciliation never finished (${run.pendingError ?? "stopped"})` });
    return "finished";
  }
  const last = run.reconcileRetriedAt ?? since;
  if (now - last <= RECONCILE_RETRY_MS) return "none";
  const state = await ctx.db
    .query("chefState")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
  if (state?.reconcilerHandle) {
    await ctx.scheduler.runAfter(0, state.reconcilerHandle as FunctionHandle<"action">, { runId: run._id });
  } else {
    await ctx.scheduler.runAfter(0, internal.chefOrchestrator.reconcileRun, { runId: run._id });
  }
  await ctx.db.patch("chefRuns", run._id, { reconcileRetriedAt: now });
  await writeAudit(ctx, { actor: ACTOR, action: "watchdog.reconcile", runId: run._id, outcome: "ok", detail: { minutes: Math.round((now - since) / 60_000) } });
  return "reconciler";
}

/**
 * A run's deadline check (armRunCheck schedules it). A no-op for a run that
 * finished, or when a newer check replaced this one; otherwise the watchdog
 * for this run, then the next check while it is still live.
 */
export const checkRun = internalMutation({
  args: { runId: v.id("chefRuns"), dueAt: v.number(), now: v.optional(v.number()) },
  returns: v.union(v.literal("superseded"), v.literal("none"), v.literal("reconciling"), v.literal("reconciler"), v.literal("finished")),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.watchdogDueAt !== args.dueAt || runCheckDue(run) === null) return "superseded" as const;
    const now = args.now ?? Date.now();
    const did = await watchRun(ctx, run, now);
    // beginReconcile armed the reconciling run's check; finishRun ended it.
    if (did === "none" || did === "reconciler") await armRunCheck(ctx, (await ctx.db.get("chefRuns", run._id))!, now);
    return did;
  },
});

/**
 * The run's workflow ended without finishing it (chef-cloud's onComplete,
 * for a workflow that failed or was cancelled): a run still active goes to
 * reconciliation at once, as a stale one would 15 minutes later. Host-only.
 */
export const workflowEnded = mutation({
  args: { runId: v.string(), error: v.string() },
  returns: v.boolean(),
  handler: async (ctx, args) => {
    const runId = ctx.db.normalizeId("chefRuns", args.runId);
    const run = runId ? await ctx.db.get("chefRuns", runId) : null;
    if (!run || run.status !== "active") return false;
    const error = `stale: the run's workflow ended without finishing it (${args.error.replace(/[\r\n]+/g, " ").slice(0, 300)})`;
    await writeAudit(ctx, { actor: ACTOR, action: "watchdog.workflowEnded", runId: run._id, outcome: "ok", reason: error.slice(0, 500) });
    return await beginReconcile(ctx, run._id, { outcome: "failed", error, actor: ACTOR });
  },
});

// ----------------------------------------------------------------- ships

/** Whether the watchdog looks after this release's ship at all. */
// Not while it follows main (chefShip.followMain): Chef's merge build has its
// own deadline check, and a release waiting for a person has nothing to restart.
const watchesShip = (r: Doc<"chefReleases">) =>
  r.open && (r.kind === "cloud" || (r.kind === "rollback" && !!r.shipRunId)) && (r.follow === undefined || r.follow.status === "merged");

/** When an open ship's next check is due: null for one that is closed, or waiting for a person. */
export function shipCheckDue(r: Doc<"chefReleases">): number | null {
  if (!watchesShip(r)) return null;
  if ((r.ship?.attempts ?? 0) > MAX_AUTO_RETRIES && r.ship?.error?.startsWith("The ship stopped answering, and Chef already")) return null;
  const lastSeen = Math.max(r.updatedAt, r.ship?.watchdogAt ?? 0);
  return Math.max(lastSeen + SHIP_STALE_MS, r.ship?.retryAt ?? 0) + CHECK_SLACK_MS;
}

/** Schedule an open ship's one check; the one pending before it, if any, becomes a no-op. */
export async function armShipCheck(ctx: MutationCtx, releaseId: Id<"chefReleases">, now = Date.now()): Promise<number | null> {
  const r = await ctx.db.get("chefReleases", releaseId);
  const due = r ? shipCheckDue(r) : null;
  if (!r || due === null) return null;
  await ctx.db.patch("chefReleases", r._id, { shipWatchdogDueAt: due });
  await ctx.scheduler.runAfter(Math.max(0, due - now), internal.chefWatchdog.checkShip, { releaseId: r._id, dueAt: due });
  return due;
}

type ShipCheck = "none" | "restarted" | "refused";

/** What the watchdog does for one ship at `now`. Starting the shipper arms its next check. */
async function watchShip(ctx: MutationCtx, r: Doc<"chefReleases">, now: number): Promise<ShipCheck> {
  if (!watchesShip(r)) return "none";
  if (r.ship?.retryAt !== undefined && r.ship.retryAt > now) return "none";
  const lastSeen = Math.max(r.updatedAt, r.ship?.watchdogAt ?? 0);
  if (now - lastSeen <= SHIP_STALE_MS) return "none";
  const attempts = r.ship?.attempts ?? 0;
  if (attempts > MAX_AUTO_RETRIES) {
    if (r.ship?.error?.startsWith("The ship stopped answering, and Chef already")) return "none";
    await ctx.db.patch("chefReleases", r._id, {
      ship: { ...(r.ship ?? {}), error: "The ship stopped answering, and Chef already started it again; Try again, or roll it back.", errorAt: now, watchdogAt: now },
      updatedAt: now,
    });
    await writeAudit(ctx, { actor: ACTOR, action: "watchdog.ship", target: `release:${r.seq}`, outcome: "refused", reason: "too many attempts" });
    return "refused";
  }
  await ctx.db.patch("chefReleases", r._id, {
    ship: { ...(r.ship ?? {}), error: "The ship stopped answering; Chef started it again.", errorAt: now, watchdogAt: now },
    updatedAt: now,
  });
  await startShipper(ctx, (await ctx.db.get("chefReleases", r._id))!, ACTOR);
  await writeAudit(ctx, { actor: ACTOR, action: "watchdog.ship", target: `release:${r.seq}`, outcome: "ok", detail: { attempts } });
  return "restarted";
}

/**
 * An open ship's check (armShipCheck schedules it). A no-op once the ship
 * closed, or when a newer check replaced this one; otherwise the watchdog
 * for this ship, then the next check while it is still open.
 */
export const checkShip = internalMutation({
  args: { releaseId: v.id("chefReleases"), dueAt: v.number(), now: v.optional(v.number()) },
  returns: v.union(v.literal("superseded"), v.literal("none"), v.literal("restarted"), v.literal("refused")),
  handler: async (ctx, args) => {
    const r = await ctx.db.get("chefReleases", args.releaseId);
    if (!r || r.shipWatchdogDueAt !== args.dueAt || !watchesShip(r)) return "superseded" as const;
    const now = args.now ?? Date.now();
    const did = await watchShip(ctx, r, now);
    // startShipper armed a restarted ship's check; a refused one waits for a person.
    if (did === "none") await armShipCheck(ctx, r._id, now);
    return did;
  },
});

// ------------------------------------------------------------- the sweep

/**
 * Everything at once, as the every-minute cron used to (chefCloud's
 * chefSweep still calls it, and `npx chef cleanup`): the watchdog for each
 * live run and open ship, and a check armed for any that has none pending.
 */
export const check = mutation({
  args: { now: v.optional(v.number()) },
  returns: v.object({ reconcilers: v.number(), finished: v.number(), ships: v.number() }),
  handler: async (ctx, args) => {
    const now = args.now ?? Date.now();
    let reconcilers = 0;
    let finished = 0;
    let ships = 0;
    const live = [
      ...(await ctx.db.query("chefRuns").withIndex("by_status", (q) => q.eq("status", "reconciling")).take(10)),
      ...(await ctx.db.query("chefRuns").withIndex("by_status", (q) => q.eq("status", "active")).take(5)),
    ];
    for (const run of live) {
      const did = run.status === "reconciling" ? await watchRun(ctx, run, now) : "none";
      if (did === "reconciler") reconcilers++;
      if (did === "finished") finished++;
      const after = (await ctx.db.get("chefRuns", run._id))!;
      const due = runCheckDue(after);
      if (due !== null && (did === "reconciler" || after.watchdogDueAt === undefined)) await armRunCheck(ctx, after, now);
    }
    const open = await ctx.db
      .query("chefReleases")
      .withIndex("by_open", (q) => q.eq("open", true))
      .take(5);
    for (const r of open) {
      const did = await watchShip(ctx, r, now);
      if (did === "restarted") ships++;
      const after = (await ctx.db.get("chefReleases", r._id))!;
      if (did === "none" && after.shipWatchdogDueAt === undefined) await armShipCheck(ctx, r._id, now);
    }
    return { reconcilers, finished, ships };
  },
});
