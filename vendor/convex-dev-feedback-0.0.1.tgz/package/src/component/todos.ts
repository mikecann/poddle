import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";

const vStatus = v.union(
  v.literal("pending"),
  v.literal("active"),
  v.literal("done"),
);

/**
 * A checklist holds at most this many rows: `plan` keeps the first MAX_TODOS
 * items, so reading the whole table (as advance and listAll do) stays small.
 */
export const MAX_TODOS = 200;

// Replace the entire checklist in one shot. Typical agent usage: call once
// up front with the plan, then drive state via `advance` / `setStatus`.
export const plan = mutation({
  args: { items: v.array(v.string()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    // MAX_TODOS bounds the table; the margin clears a longer checklist
    // written before the cap.
    const existing = await ctx.db.query("todos").take(MAX_TODOS * 5);
    for (const row of existing) await ctx.db.delete("todos", row._id);
    let order = 0;
    for (const text of args.items.slice(0, MAX_TODOS)) {
      await ctx.db.insert("todos", {
        text: text.slice(0, 400),
        order: order++,
        status: order === 1 ? "active" : "pending",
      });
    }
    return null;
  },
});

// Mark the current active row done and flip the next pending row to active.
// No-op if nothing is pending.
export const advance = mutation({
  args: {},
  returns: v.null(),
  handler: async (ctx) => {
    const rows = await ctx.db.query("todos").withIndex("by_order").take(MAX_TODOS);
    rows.sort((a, b) => a.order - b.order);
    const active = rows.find((r) => r.status === "active");
    if (active) await ctx.db.patch("todos", active._id, { status: "done" });
    const nextPending = rows.find((r) => r.status === "pending");
    if (nextPending) await ctx.db.patch("todos", nextPending._id, { status: "active" });
    return null;
  },
});

export const setStatus = mutation({
  args: { id: v.id("todos"), status: vStatus },
  returns: v.null(),
  handler: async (ctx, args) => {
    await ctx.db.patch("todos", args.id, { status: args.status });
    return null;
  },
});

export const listAll = query({
  args: {},
  handler: async (ctx) => {
    const rows = await ctx.db.query("todos").withIndex("by_order").take(MAX_TODOS);
    rows.sort((a, b) => a.order - b.order);
    return rows;
  },
});
