import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export const vState = v.union(
  v.literal("submitted"),
  v.literal("requested"),
  v.literal("planned"),
  v.literal("inProgress"),
  v.literal("rejected"),
  v.literal("completed"),
);

export const vNotificationType = v.union(
  v.literal("approved"),
  v.literal("rejected"),
  v.literal("stateChanged"),
  v.literal("completed"),
  v.literal("merged"),
  v.literal("devLog"),
);

// ----------- Chef pipeline validators (docs/chef-pipeline.md) -----------

export const vRunStatus = v.union(
  v.literal("active"),
  // Stale (no heartbeat or past its deadline): the slot stays taken until
  // reconciliation finishes, since a sandbox or push may still be live.
  v.literal("reconciling"),
  v.literal("built"),
  v.literal("failed"),
  v.literal("cancelled"),
);

// Where an active run is. The runner reports these with compare-and-set.
// `cloned` and `committed` are the runner asking for the next phase: the
// orchestration grants `agent` only once git is dead and egress narrowed,
// and `pushing` only once the git write credential is live (chefEffects
// .setPhase). The runner waits for the grant before it goes on.
export const vRunPhase = v.union(
  v.literal("launched"),
  v.literal("ready"),
  v.literal("cloning"),
  v.literal("cloned"),
  v.literal("agent"),
  v.literal("gates"),
  v.literal("guards"),
  v.literal("committed"),
  v.literal("pushing"),
  v.literal("pushed"),
  v.literal("previewing"),
  v.literal("done"),
  // A run that finished without building (failed, cancelled): `endedPhase`
  // says where it stopped. A built run ends "done". Never a runner's phase.
  v.literal("ended"),
);

export const vSkillFeedbackKind = v.union(
  v.literal("wrong"),
  v.literal("missing"),
  v.literal("outdated"),
  v.literal("deviation"),
);

export const vApprovalStatus = v.union(
  v.literal("pending"),
  v.literal("approved"),
  v.literal("declined"),
);

export const vRunVia = v.union(
  v.literal("approval"),
  v.literal("button"),
  v.literal("cron"),
  v.literal("enroll"),
  v.literal("finish"),
  // Chef trying a transient failure again on its own (chefRuns.retryTransient).
  v.literal("retry"),
  // Cloud builds or auto-build just turned on (a cloud key created,
  // cloudAutoBuild set): what was approved meanwhile starts.
  v.literal("enable"),
);

// A gate's outcomes (src/chef/gates.ts): on the untouched checkout before the
// agent, and after its last session.
export const vGateResult = v.object({
  command: v.string(),
  baseline: v.union(v.literal("pass"), v.literal("fail"), v.literal("none")),
  baselineCached: v.optional(v.boolean()),
  result: v.optional(v.union(v.literal("pass"), v.literal("fail"))),
  // A merge's baseline is main's own tree (src/chef/gates.ts).
  baselineOn: v.optional(v.literal("main")),
  // Failed on the baseline and now: the problems that are new (blocking when any), and where the old ones are.
  newProblems: v.optional(v.array(v.string())),
  baselineFiles: v.optional(v.array(v.string())),
});

// Why a run failed, for people (src/chef/failures.ts).
export const vFailure = v.object({
  code: v.string(),
  kind: v.union(v.literal("transient"), v.literal("deterministic"), v.literal("environmental")),
  reason: v.string(),
  action: v.string(),
});

export const vRunScope = v.union(
  v.literal("run.read"),
  v.literal("run.report"),
  v.literal("attachments.read"),
  v.literal("ai.proxy"),
);

// What each run records about the code and tools that built it ("Provenance").
export const vProvenance = v.object({
  feedbackSha: v.optional(v.string()),
  runnerSha256: v.optional(v.string()),
  deployScriptSha256: v.optional(v.string()),
  daytonaSnapshot: v.optional(v.string()),
  daytonaSnapshotId: v.optional(v.string()),
  claudeCodeVersion: v.optional(v.string()),
  convexCliVersion: v.optional(v.string()),
  nodeVersion: v.optional(v.string()),
  npmVersion: v.optional(v.string()),
  model: v.optional(v.string()),
  lockfileHash: v.optional(v.string()),
  // "local" for a run built on a developer's machine by `npx chef work`,
  // and that machine's name; absent for the cloud runner.
  runner: v.optional(v.string()),
  host: v.optional(v.string()),
  // The vendored Convex plugin the agent loaded (runner/convex-plugin.ts).
  convexPlugin: v.optional(v.string()),
  // How much the agent used it (src/chef/pluginUsage.ts): "skills 2, agents 1, hooks 6".
  pluginUsage: v.optional(v.string()),
  // "Try again": how the earlier attempt's work was used ("same base",
  // "rebased onto the new base", or "fresh: <why>"; chefAttempts).
  earlierAttempt: v.optional(v.string()),
  // Warm snapshots (docs/chef-pipeline.md, "Warm snapshots"): the app's own
  // snapshot the build sandbox, and the preview's deploy sandbox, started
  // from, with its key (recorded by the host's launcher), and how the
  // runner's install went ("warm <key12>", or "normal: <why not>").
  warmSnapshot: v.optional(v.string()),
  warmKey: v.optional(v.string()),
  previewWarmSnapshot: v.optional(v.string()),
  previewWarmKey: v.optional(v.string()),
  warmInstall: v.optional(v.string()),
});

// "Ship it" found main had moved since the build (docs/chef-pipeline.md,
// "When main moves before Ship it"): what the admin had approved, carried by
// the merge-only build that merges the new main in and checks it again.
export const vRefresh = v.object({
  ofRunId: v.id("chefRuns"),
  releaseSeq: v.number(),
  approvedDiffHash: v.string(),
  approvedBy: v.string(),
  depsAcknowledged: v.boolean(),
  mainSha: v.string(),
  // Contract 13: the open release this merge follows main for (it stays
  // open, approved, while the merge runs), the approved commit the merge
  // starts from (not chef's tip: newer builds on chef wait for their own
  // approval), which merge of this approval it is, and whether Chef's agent
  // may resolve conflicts and fix the checks (a merge repair).
  releaseId: v.optional(v.id("chefReleases")),
  fromSha: v.optional(v.string()),
  attempt: v.optional(v.number()),
  repair: v.optional(v.boolean()),
});

// A build's own change, from its release diff (src/chef/follow.ts
// changeFingerprint): what an approval binds to, apart from main.
export const vChangeFingerprint = v.object({
  changeHash: v.string(),
  blocks: v.optional(v.array(v.string())),
});

// A release that follows main (chefShip.followMain): where it is.
export const vFollow = v.object({
  status: v.union(
    v.literal("merging"),
    v.literal("needsApproval"),
    v.literal("failed"),
    v.literal("stalled"),
    v.literal("merged"),
  ),
  mainSha: v.string(),
  // Merges of this approval so far (MAX_FOLLOW_MERGES, then a person).
  attempts: v.number(),
  // The merge build, once it is claimed (needsApproval: the one to approve).
  runId: v.optional(v.id("chefRuns")),
  reason: v.optional(v.string()),
  files: v.optional(v.array(v.string())),
  conflicts: v.optional(v.array(v.string())),
  repaired: v.optional(v.boolean()),
  at: v.number(),
});

// A risk flag on a build (src/chef/card.ts riskFlags): computed from the
// diff's paths and lines by fixed rules, never from the agent's text.
export const vRiskFlag = v.object({
  kind: v.string(),
  label: v.string(),
  files: v.array(v.string()),
  count: v.number(),
});

// One step of a demo script (src/chef/demo.ts): data, checked by parseDemoScript.
export const vDemoStep = v.union(
  v.object({ do: v.literal("goto"), path: v.string() }),
  v.object({ do: v.literal("click"), role: v.optional(v.string()), name: v.optional(v.string()), text: v.optional(v.string()) }),
  v.object({ do: v.literal("fill"), label: v.optional(v.string()), placeholder: v.optional(v.string()), value: v.string() }),
  v.object({ do: v.literal("press"), key: v.string() }),
  v.object({ do: v.literal("waitFor"), text: v.string() }),
  v.object({ do: v.literal("wait"), ms: v.number() }),
  v.object({ do: v.literal("scroll"), y: v.number() }),
);

export const vDemoVideo = v.object({
  viewport: v.union(v.literal("phone"), v.literal("desktop")),
  storageId: v.id("_storage"),
  sha256: v.string(),
  bytes: v.number(),
  durationMs: v.number(),
  done: v.number(),
  steps: v.number(),
  failed: v.optional(v.object({ step: v.number(), what: v.string(), reason: v.string() })),
  timedOut: v.optional(v.boolean()),
});

export const chefRunFields = {
  seq: v.number(),
  itemId: v.id("items"),
  snapshotId: v.id("chefSnapshots"),
  status: vRunStatus,
  phase: vRunPhase,
  // Where a finished run was when it ended (finishRun): `phase` is then
  // "done" (built) or "ended", so nothing reads a finished run as running.
  endedPhase: v.optional(vRunPhase),
  startedVia: vRunVia,
  // userId for the button, the key's id for enroll; absent for hooks and the sweep.
  startedBy: v.optional(v.string()),
  agentKeyId: v.optional(v.id("chefAgentKeys")),
  // Whether the request's author was an admin when the run was claimed. A
  // local worker builds only "admin" runs unless told otherwise (its agent
  // holds the developer's login). Absent on runs from before this existed.
  requestedBy: v.optional(v.union(v.literal("admin"), v.literal("member"))),
  // The scheduled function that starts the run's orchestration (step 6).
  workflowId: v.optional(v.string()),
  // When startRun handed the run to the host's orchestrator (once per run).
  orchestratedAt: v.optional(v.number()),
  heartbeatAt: v.number(),
  deadline: v.number(),
  createdAt: v.number(),
  finishedAt: v.optional(v.number()),
  // The last applied report, so a repeat of it is a no-op.
  // `hash` is sha256 of the normalized report as stored, so an exact replay is
  // a no-op and a different report for the same transition is refused.
  lastReport: v.optional(
    v.object({ from: vRunPhase, to: vRunPhase, at: v.number(), hash: v.optional(v.string()) }),
  ),
  buildSandboxId: v.optional(v.string()),
  deploySandboxId: v.optional(v.string()),
  secretNames: v.optional(v.array(v.string())),
  baseSha: v.optional(v.string()),
  branch: v.optional(v.string()),
  commitSha: v.optional(v.string()),
  chefBefore: v.optional(v.string()),
  chefAfter: v.optional(v.string()),
  previewName: v.optional(v.string()),
  previewUrl: v.optional(v.string()),
  // A one-time sign-in link for the preview, from the app's own
  // loginLinkFunction (src/chef/previewLogin.ts). It holds a sign-in token:
  // only admins read run rows, and it is never logged or audited.
  previewLoginUrl: v.optional(v.string()),
  // The built frontend the runner uploaded (POST /chef-agent/artifact): a
  // gzipped tar in this component's storage, for the deploy sandbox. Built
  // with the Convex URL placeholder; deleted when the run finishes.
  frontendArtifact: v.optional(
    v.object({
      storageId: v.id("_storage"),
      sha256: v.string(),
      size: v.number(),
      commitSha: v.string(),
      at: v.number(),
    }),
  ),
  // `git diff main..commit` with the release's fixed options, uploaded by the
  // runner (POST /chef-agent/release-diff) next to the frontend: the diff
  // "Ship it" shows and binds by its hash. Its chunks are chefRunDiffChunks.
  // Kept, with frontendArtifact, while this is the newest built run; a
  // newer build or a ship of it drops both.
  releaseDiff: v.optional(
    v.object({
      // main when the run started, merged into the commit: the diff's base.
      baseSha: v.string(),
      commitSha: v.string(),
      sha256: v.string(),
      diffHash: v.string(),
      chunkCount: v.number(),
      bytes: v.number(),
      filesChanged: v.array(v.string()),
      filesTruncated: v.boolean(),
      depsChanged: v.boolean(),
      redactions: v.number(),
      at: v.number(),
      // The build's own change (src/chef/follow.ts), from the raw diff.
      change: v.optional(vChangeFingerprint),
    }),
  ),
  filesChanged: v.optional(v.array(v.string())),
  depsChanged: v.optional(v.boolean()),
  // The Ship card's risk flags, from the release diff when it was uploaded
  // (chefArtifact.recordReleaseDiff). Kept after the diff itself is dropped.
  riskFlags: v.optional(v.array(vRiskFlag)),
  diffFileId: v.optional(v.id("_storage")),
  diffHash: v.optional(v.string()),
  provenance: v.optional(vProvenance),
  spendUsd: v.optional(v.number()),
  // Inference proxy counters (chefInference.ts): requests in flight now, and
  // requests admitted so far. Changed only inside the proxy's mutations.
  aiInFlight: v.optional(v.number()),
  aiRequests: v.optional(v.number()),
  error: v.optional(v.string()),
  // While reconciling: the outcome to record once cleanup is done (a stale
  // run fails, a cancelled one is cancelled), and why.
  pendingOutcome: v.optional(v.union(v.literal("failed"), v.literal("cancelled"))),
  pendingError: v.optional(v.string()),
  reconcileStartedAt: v.optional(v.number()),
  // When the watchdog last scheduled the reconciler again (chefWatchdog.ts).
  reconcileRetriedAt: v.optional(v.number()),
  // When this live run's one pending deadline check (chefWatchdog.checkRun)
  // is due. A check scheduled for any other time is stale and does nothing.
  watchdogDueAt: v.optional(v.number()),
  // When the cleanup sweep dealt with the request branch (deleted it after
  // 14 days, or found there was none).
  branchSweptAt: v.optional(v.number()),
  // The gates against the base and after the agent (src/chef/gates.ts), as
  // the runner last reported them.
  gateResults: v.optional(v.array(vGateResult)),
  // The fix round the agent is in or last had (1-based); absent for none.
  fixRound: v.optional(v.number()),
  // Each fix round: what verification step failed (gates or guards), why,
  // when, and the run's spend when it started.
  roundLog: v.optional(
    v.array(v.object({ round: v.number(), from: v.string(), reason: v.string(), at: v.number(), spendUsd: v.number() })),
  ),
  // What the agent tried, as the runner read it at the end (its summary and
  // the diff stat), scrubbed; kept even when the run fails. Untrusted text.
  summary: v.optional(v.string()),
  diffStat: v.optional(v.string()),
  // A failed run's reason and what to do (src/chef/failures.ts).
  failure: v.optional(vFailure),
  // 1 for the first try of an approval; 2 and 3 for Chef's own retries of a
  // transient failure (its snapshot's `retry`).
  attempt: v.optional(v.number()),
  retryOf: v.optional(v.id("chefRuns")),
  // When Chef will try a transient failure again on its own.
  retryAt: v.optional(v.number()),
  // Spend of the earlier attempts of the same approval: the ceiling covers them all.
  priorSpendUsd: v.optional(v.number()),
  // Tokens through the inference proxy.
  aiInputTokens: v.optional(v.number()),
  aiOutputTokens: v.optional(v.number()),
  // Milliseconds per phase, from the runner (src/chef/learnings.ts TIMING_KEYS).
  phaseMs: v.optional(v.record(v.string(), v.number())),
  // When the runner's learnings for this run were stored (once per run).
  learningsAt: v.optional(v.number()),
  // The failed run whose work this run starts from ("Try again", chefAttempts).
  continueFrom: v.optional(v.id("chefRuns")),
  // "merge": no agent; main moved after `refresh.ofRunId` was approved for
  // Ship it, and this build merges the new main in and checks it again.
  mode: v.optional(v.literal("merge")),
  refresh: v.optional(vRefresh),
  // What the merge brought from main (the runner's count and subjects).
  mergedMain: v.optional(v.object({ count: v.number(), subjects: v.array(v.string()) })),
  // Ship it couldn't ship this built run as it is (main moved): why, for the
  // panel, and "Try again" rebuilds it on the new main.
  shipBlocked: v.optional(v.object({ reason: v.string(), at: v.number() })),
  // A release merge whose agent resolved conflicts or fixed the checks after
  // merging main in (the runner's report): the files, and the resolution
  // diff (from the merge as git left it to the commit), scrubbed and capped,
  // which is what the re-approval card shows.
  mergeRepair: v.optional(
    v.object({
      conflicts: v.array(v.string()),
      gates: v.array(v.string()),
      files: v.array(v.string()),
      diff: v.string(),
      truncated: v.boolean(),
    }),
  ),
  // What Chef did about this run's failure (src/chef/recovery.ts): the
  // class and the action (retry, fixRound, repair, human, stop).
  recovery: v.optional(v.object({ class: v.string(), action: v.string(), repair: v.optional(v.string()) })),
  // A follow-up build: the run whose preview failed on its own code, and why
  // (the runner tells the agent).
  followUp: v.optional(v.object({ ofRunId: v.id("chefRuns"), reason: v.string() })),
  // A batch (chefBatches.ts): this one run builds every request listed, the
  // first being `itemId`/`snapshotId`, each from its own approved snapshot.
  // Each other request also has a chefRunItems row, so "an item's newest
  // run" finds this run.
  batch: v.optional(
    v.object({
      batchId: v.id("chefBatches"),
      items: v.array(v.object({ itemId: v.id("items"), snapshotId: v.id("chefSnapshots") })),
    }),
  ),
  // The agent's demo script (src/chef/demo.ts), checked, from `committed`.
  demoScript: v.optional(v.object({ steps: v.array(vDemoStep) })),
  // A second one-time sign-in link for the preview, for the demo recording
  // only (the demo user); cleared once the demo ran. Admins only, never logged.
  previewDemoLoginUrl: v.optional(v.string()),
  // The demo videos of the preview being used (chefDemo.ts), and what
  // happened when there are none.
  demoVideos: v.optional(v.array(vDemoVideo)),
  demoNote: v.optional(v.string()),
  // "admin-copy" preview data (chefPreviewData.ts): the admin's export in
  // this component's storage while the preview is made, then deleted; and
  // whether the preview got it (it signs in as the copied admin).
  previewExport: v.optional(v.object({ storageId: v.id("_storage"), sha256: v.string(), bytes: v.number(), userId: v.string() })),
  previewAdminCopy: v.optional(v.boolean()),
  // `npx chef ios` (chefIos.ts): the developer's Mac compiled and installed
  // this build on their device (the card's iOS flag shows it).
  iosCheck: v.optional(
    v.object({
      compiled: v.boolean(),
      installed: v.boolean(),
      at: v.number(),
      device: v.optional(v.string()),
      error: v.optional(v.string()),
    }),
  ),
  // The beta channel (chefBeta.ts): this build's deploy to the app's
  // persistent beta deployment, and what happened.
  beta: v.optional(
    v.object({
      status: v.union(v.literal("deploying"), v.literal("deployed"), v.literal("failed")),
      deploymentName: v.string(),
      at: v.number(),
      note: v.optional(v.string()),
      seeded: v.optional(v.boolean()),
    }),
  ),
};

export const vInferenceStatus = v.union(
  // Admitted and forwarded; not finished yet.
  v.literal("pending"),
  // The upstream answered and the response reached its end.
  v.literal("ok"),
  // The upstream refused, failed, or the stream broke.
  v.literal("error"),
  // The client went away mid-stream.
  v.literal("cancelled"),
  // Refused by the proxy before anything was forwarded.
  v.literal("refused"),
  // Pending far longer than any request can take; its action must have died.
  v.literal("abandoned"),
);

export const chefInferenceFields = {
  runId: v.id("chefRuns"),
  model: v.string(),
  maxTokens: v.optional(v.number()),
  stream: v.boolean(),
  status: vInferenceStatus,
  httpStatus: v.optional(v.number()),
  reason: v.optional(v.string()),
  inputTokens: v.optional(v.number()),
  outputTokens: v.optional(v.number()),
  cacheCreationInputTokens: v.optional(v.number()),
  cacheReadInputTokens: v.optional(v.number()),
  costUsd: v.optional(v.number()),
  // "gateway": the cost the AI gateway reported; "estimate": from the price
  // table and the usage; "worstCase": no usage seen, charged as if the input
  // was uncached and max_tokens were all used.
  costSource: v.optional(
    v.union(v.literal("gateway"), v.literal("estimate"), v.literal("worstCase")),
  ),
  requestBytes: v.optional(v.number()),
  startedAt: v.number(),
  firstByteMs: v.optional(v.number()),
  latencyMs: v.optional(v.number()),
};

// What a claim did. Lives here (not chefRuns.ts) so modules that import each
// other can share it without a validator being undefined at load time.
export const vClaimResult = v.union(
  v.object({ outcome: v.literal("claimed"), runId: v.id("chefRuns") }),
  v.object({ outcome: v.literal("busy"), runId: v.id("chefRuns") }),
  v.object({ outcome: v.literal("reconciling"), runId: v.id("chefRuns") }),
  // memberRequests: approved requests a non-admin wrote that an admin-only
  // claim (a local worker's default) passed over, left for a cloud build.
  v.object({ outcome: v.literal("empty"), memberRequests: v.optional(v.number()) }),
  v.object({ outcome: v.literal("disabled"), reason: v.string() }),
  // More than one approved request is waiting and the planner is grouping
  // them (chefBatches.ts); the claim happens when it answers.
  v.object({ outcome: v.literal("planning") }),
);

// A batch as the panel shows it (chefBatches.ts). Here for the same reason.
export const vBatchView = v.object({
  batchId: v.id("chefBatches"),
  status: v.string(),
  title: v.string(),
  reason: v.string(),
  failures: v.number(),
  runId: v.union(v.id("chefRuns"), v.null()),
  items: v.array(v.object({ itemId: v.id("items"), number: v.number(), title: v.string(), state: v.string() })),
});

export const vAuditOutcome = v.union(
  v.literal("ok"),
  v.literal("refused"),
  v.literal("error"),
);

export const chefAuditFields = {
  // "user:<id>", "chefKey:<prefix>", "run:<runId>", "system:<what>".
  actor: v.string(),
  // e.g. "snapshot.approved", "agentKey.revoked", "route./chef-agent/run".
  action: v.string(),
  target: v.optional(v.string()),
  runId: v.optional(v.id("chefRuns")),
  outcome: vAuditOutcome,
  reason: v.optional(v.string()),
  // Small facts only: never secrets, never request or response bodies.
  detail: v.optional(
    v.record(v.string(), v.union(v.string(), v.number(), v.boolean(), v.null())),
  ),
  at: v.number(),
};

// ----------- Chef releases (docs/chef-pipeline.md, "Release") -----------

export const vReleaseState = v.union(
  v.literal("pinned"),
  v.literal("diffReady"),
  v.literal("approved"),
  v.literal("merged"),
  v.literal("sourcePushed"),
  v.literal("gatesPassed"),
  v.literal("backendDeployed"),
  v.literal("frontendPublished"),
  v.literal("verified"),
  v.literal("live"),
  v.literal("done"),
  // Ends other than done: given up before anything reached production, or
  // replaced by a rollback release.
  v.literal("abandoned"),
  v.literal("rolledBack"),
);

export const vTargetRecord = v.object({
  digest: v.string(),
  at: v.number(),
  actor: v.string(),
  detail: v.optional(v.string()),
});

export const chefReleaseFields = {
  seq: v.number(),
  kind: v.union(v.literal("chef"), v.literal("cloud"), v.literal("rollback")),
  state: vReleaseState,
  // Not done, abandoned or rolled back. At most one release is open.
  open: v.boolean(),
  // The pinned `chef` tip (a rollback: the earlier release's mergeSha) and
  // Code Storage `main` when it was pinned.
  sha: v.string(),
  baseSha: v.string(),
  // The built runs whose commits this release covers.
  runIds: v.array(v.id("chefRuns")),
  // Rollbacks: the release rolled back and the one restored.
  rollbackOf: v.optional(v.number()),
  restores: v.optional(v.number()),
  // Set on a release when a later rollback replaced it.
  rolledBackBy: v.optional(v.number()),
  // The diff, uploaded in chunks (chefReleaseDiffChunks). diffHash is fixed
  // by the first chunk; the release reaches diffReady only when every chunk
  // arrived and their hashes add up to it.
  diffHash: v.optional(v.string()),
  diffChunkCount: v.optional(v.number()),
  diffBytes: v.optional(v.number()),
  filesChanged: v.optional(v.array(v.string())),
  filesTruncated: v.optional(v.boolean()),
  depsChanged: v.optional(v.boolean()),
  // How many secrets scrubbing redacted from the stored diff. Never values.
  redactions: v.optional(v.number()),
  approvedBy: v.optional(v.string()),
  approvedAt: v.optional(v.number()),
  approvedDiffHash: v.optional(v.string()),
  depsAcknowledged: v.optional(v.boolean()),
  mergeSha: v.optional(v.string()),
  releaseBranch: v.optional(v.string()),
  artifactDigest: v.optional(v.string()),
  gates: v.optional(v.array(v.string())),
  backend: v.optional(
    v.object({ mergeSha: v.string(), at: v.number(), actor: v.string(), pushId: v.optional(v.string()) }),
  ),
  targets: v.object({
    convexApp: v.optional(vTargetRecord),
    staticHosting: v.optional(vTargetRecord),
  }),
  checks: v.optional(v.array(v.object({ name: v.string(), ok: v.boolean() }))),
  mainSha: v.optional(v.string()),
  // The step that began and hasn't completed (the checkpoint before it).
  inFlight: v.optional(v.object({ to: v.string(), at: v.number(), actor: v.string() })),
  // Every completed checkpoint, in order.
  checkpoints: v.array(v.object({ state: vReleaseState, at: v.number(), actor: v.string(), note: v.optional(v.string()) })),
  cliVersion: v.optional(v.string()),
  // A cloud ship: the built run whose commit, frontend and diff it ships,
  // and what the host's orchestration (packages/chef-cloud/src/client/chefShip.ts) has done.
  shipRunId: v.optional(v.id("chefRuns")),
  // What the admin approved, apart from main (src/chef/follow.ts): a merge of
  // a newer main ships on this approval while it covers what ships.
  approvedChange: v.optional(vChangeFingerprint),
  // Main moved under this release and Chef is following it (chefShip.followMain).
  follow: v.optional(vFollow),
  // A commit of this release that reached production before main moved and
  // Chef merged it in again: the release counts as deployed while it is open.
  deployedSha: v.optional(v.string()),
  ship: v.optional(
    v.object({
      // The deploy sandbox, by label chef-release=<id>, and its one execution.
      sandboxIntentAt: v.optional(v.number()),
      sandboxId: v.optional(v.string()),
      executionId: v.optional(v.string()),
      // The read-only git secret for the one checkout (a name, never a value).
      secretName: v.optional(v.string()),
      deploymentName: v.optional(v.string()),
      siteUrl: v.optional(v.string()),
      // The last failure, shown in the panel; cleared when the ship goes on.
      error: v.optional(v.string()),
      errorAt: v.optional(v.number()),
      attempts: v.optional(v.number()),
      emailId: v.optional(v.string()),
      // The idempotency keys of the emails sent for it (the last few), so a
      // retried step never sends the same one twice.
      emailKeys: v.optional(v.array(v.string())),
      // A transient failure (src/chef/recovery.ts): the ship starts again then.
      retryAt: v.optional(v.number()),
      // When the watchdog last started a ship that had stopped answering.
      watchdogAt: v.optional(v.number()),
      // `main` mirrored to GitHub once it moved (CHEF_GITHUB_MIRROR): pushed,
      // current, ahead (GitHub has it already), diverged (GitHub has commits
      // main doesn't; left alone) or failed (with the error).
      mirror: v.optional(
        v.object({
          github: v.string(),
          status: v.string(),
          sha: v.optional(v.string()),
          target: v.optional(v.string()),
          error: v.optional(v.string()),
          at: v.number(),
        }),
      ),
    }),
  ),
  // When this open ship's one pending check (chefWatchdog.checkShip) is due.
  // A check scheduled for any other time is stale and does nothing.
  shipWatchdogDueAt: v.optional(v.number()),
  preparedBy: v.string(),
  createdAt: v.number(),
  updatedAt: v.number(),
  finishedAt: v.optional(v.number()),
  endReason: v.optional(v.string()),
};

export default defineSchema({
  // Who's who. The host forwards a trusted userId (never ctx.auth); the first
  // registered user is the admin (creator), the rest are members. Roles gate
  // the "list all active" and "build status" visibility rules (see access.ts).
  users: defineTable({
    userId: v.string(),
    role: v.union(v.literal("admin"), v.literal("member")),
    createdAt: v.number(),
  })
    .index("by_userId", ["userId"])
    .index("by_role", ["role"]),

  items: defineTable({
    number: v.number(),
    title: v.string(),
    description: v.string(),
    state: vState,
    createdBy: v.string(),
    completedAt: v.optional(v.number()),
    mergedInto: v.optional(v.id("items")),
    // "feature" (default) for normal requests; "refinement" for agent-asked
    // clarifying questions that use devLogs as the answer thread.
    kind: v.optional(v.union(v.literal("feature"), v.literal("refinement"))),
    // Denormalized stats — updated atomically inside bid mutations so reads
    // never have to join on the bids table. Optional for documents that
    // predate this migration.
    totalAmount: v.optional(v.number()),
    supporterCount: v.optional(v.number()),
    // Verbatim voice-note transcript, kept apart from the (editable)
    // description so readers can tell what was typed from what was said.
    transcript: v.optional(v.string()),
    // Short, user-facing release note ("You can now export your book as a
    // PDF."), written by the admin/agent when the item ships — never the raw
    // request text. Completed items with a changelog power "What's new".
    changelog: v.optional(v.string()),
    // Bumped whenever the request's content (attachments) changes, so an
    // approval snapshot can tell the item moved under it.
    updatedAt: v.optional(v.number()),
    // The approved Chef snapshot (chefSnapshots) this item will be built from.
    // Set only by chefSnapshots.approve; any other way into "requested"
    // (transitionState, /agent/triage, items.review) leaves it unset, so those
    // approvals never start a cloud build.
    snapshotId: v.optional(v.id("chefSnapshots")),
    // When the snapshot approval queued it for a cloud build. Cleared when a
    // run claims it or the item moves any other way; the claim takes the
    // oldest.
    cloudQueuedAt: v.optional(v.number()),
    // "Try again" on a failed build that left its work (chefAttempts): the
    // next build of this request starts from that run's work. Cleared by
    // the claim, which copies it onto the run.
    continueFrom: v.optional(v.id("chefRuns")),
    // Batching (chefBatches.ts): the batch this queued request is planned to
    // be built in, or is being built in; cleared when it builds alone again.
    batchId: v.optional(v.id("chefBatches")),
    // An admin split it out of a batch, or its batch failed and was split:
    // it builds alone, and the planner leaves it out, until it is approved again.
    batchAlone: v.optional(v.boolean()),
    // When a planning call last looked at it. A claim plans again only when a
    // waiting request was queued after its last look.
    batchConsideredAt: v.optional(v.number()),
  })
    .index("by_state", ["state"])
    .index("by_createdBy", ["createdBy"])
    .index("by_number", ["number"])
    .index("by_kind_and_state", ["kind", "state"])
    .index("by_cloudQueuedAt", ["cloudQueuedAt"])
    .index("by_batchId", ["batchId"]),

  // Screenshots / voice notes attached to an item. Files live in the
  // COMPONENT's file storage (hosts upload via attachments.generateUploadUrl),
  // so they are cleaned up with the item and readable by exactly the actors who
  // may read the item (see access.ts canReadItem).
  attachments: defineTable({
    itemId: v.id("items"),
    kind: v.union(v.literal("screenshot"), v.literal("audio")),
    storageId: v.id("_storage"),
    mimeType: v.string(),
    size: v.number(),
    createdAt: v.number(),
    uploadedBy: v.string(),
  })
    .index("by_itemId", ["itemId"])
    .index("by_storageId", ["storageId"]),

  bids: defineTable({
    itemId: v.id("items"),
    userId: v.string(),
    amount: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_item_and_user", ["itemId", "userId"]),

  devLogs: defineTable({
    itemId: v.id("items"),
    authorId: v.string(),
    message: v.string(),
    stamp: v.number(),
  }).index("by_item", ["itemId"]),

  notifications: defineTable({
    userId: v.string(),
    itemId: v.id("items"),
    type: vNotificationType,
    message: v.string(),
    isRead: v.boolean(),
    stamp: v.number(),
  })
    // Newest first across read and unread (notifications.list); the compound
    // index would sort unread before read.
    // eslint-disable-next-line @convex-dev/no-duplicate-indexes
    .index("by_user", ["userId"])
    .index("by_user_and_read", ["userId", "isRead"])
    .index("by_item", ["itemId"]),

  counters: defineTable({
    name: v.string(),
    value: v.number(),
  }).index("by_name", ["name"]),

  agentKeys: defineTable({
    name: v.string(),
    // sha256(key) and "ship_" plus 8 hex characters; the key itself is never
    // stored. Rows from before hashing hold the plaintext in `key` until
    // agentKeys.migrateToHashes (or the key's next use) rewrites them.
    hash: v.optional(v.string()),
    prefix: v.optional(v.string()),
    key: v.optional(v.string()),
    createdBy: v.string(),
    lastUsedAt: v.optional(v.number()),
    revoked: v.boolean(),
    // Capability scope. "build" (default) = queue/claim/log/complete only.
    // "triage" additionally lets a delegated agent approve/reject — the owner
    // grants it explicitly, it is never the default. This is what keeps
    // approval the owner-only authorization gate: a build key cannot
    // self-authorize its own work.
    scopes: v.optional(
      v.array(v.union(v.literal("build"), v.literal("triage"))),
    ),
  })
    .index("by_hash", ["hash"])
    .index("by_key", ["key"]),

  // Owner-controlled settings. Single row (key:"singleton"). Read by the host
  // wrapper to decide public-board visibility and which worker drives builds.
  settings: defineTable({
    key: v.literal("singleton"),
    // Show pre-triage "community" requests on the public board (helps dedup) vs
    // keep them private until the owner approves. Default true.
    communityBoardVisible: v.boolean(),
    // Where approved work executes. "local" = the owner's terminal agent pulls
    // /agent/queue (no inbound execution surface); "cloud" = a managed sandbox
    // worker. Default "local".
    runMode: v.union(v.literal("local"), v.literal("cloud")),
    // Chef: claim a cloud build on approval and when a run finishes. Off by
    // default; the "Build in cloud" button and enroll work either way. Only
    // with cloud builds on (a live "cloud" Chef agent key) do approvals,
    // the sweep and the button claim at all.
    cloudAutoBuild: v.optional(v.boolean()),
    // Batching (chefBatches.ts): group waiting requests that touch the same
    // part of the app into one build. Default on; it only plans when the host
    // registered a planner (chef-cloud does).
    cloudBatching: v.optional(v.boolean()),
    // The non-secret `preview:<team>:<project>` part of the preview deploy key.
    previewKeyPrefix: v.optional(v.string()),
    // The non-secret `prod:<deployment>` (or `dev:`) part of CHEF_DEPLOY_KEY,
    // the host's own deploy key for "Ship it".
    deployKeyPrefix: v.optional(v.string()),
    // Inference spend ceiling per run, in USD (default 20).
    spendCeilingUsd: v.optional(v.number()),
    // Preview data (chefPreviewData.ts): "demo" (default) or "admin-copy",
    // and the admin whose own rows are copied (whoever turned it on).
    previewData: v.optional(v.union(v.literal("demo"), v.literal("admin-copy"))),
    previewDataUserId: v.optional(v.string()),
    // The beta channel (chefBeta.ts): the persistent beta deployment, the
    // build on it, the one deploy in flight (a lease), and whether it was
    // seeded with the admin's copy (once).
    beta: v.optional(
      v.object({
        deploymentName: v.string(),
        siteUrl: v.string(),
        runId: v.optional(v.id("chefRuns")),
        sha: v.optional(v.string()),
        deployedAt: v.optional(v.number()),
        deploying: v.optional(v.object({ runId: v.id("chefRuns"), at: v.number() })),
        seededAt: v.optional(v.number()),
      }),
    ),
    // Inference proxy limits per request and per run (defaults 64000 and 400).
    aiMaxTokens: v.optional(v.number()),
    aiMaxRequests: v.optional(v.number()),
  }).index("by_key", ["key"]),

  // ----------- Chef pipeline (docs/chef-pipeline.md) -----------

  // Exactly the bytes an admin approved for a cloud build. Written by
  // chefSnapshots.prepareApproval and never patched again, except the one-time
  // approval stamp (approvedBy, approvedAt) in chefSnapshots.approve.
  chefSnapshots: defineTable({
    itemId: v.id("items"),
    title: v.string(),
    description: v.string(),
    transcript: v.union(v.string(), v.null()),
    attachments: v.array(
      v.object({
        kind: v.union(v.literal("screenshot"), v.literal("audio")),
        storageId: v.id("_storage"),
        // Hex sha256 of the file, from the storage system table.
        sha256: v.string(),
        size: v.number(),
        contentType: v.string(),
      }),
    ),
    // Hex sha256 of the canonical JSON of everything above (chefShared.ts).
    contentHash: v.string(),
    itemUpdatedAt: v.number(),
    createdBy: v.string(),
    createdAt: v.number(),
    approvedBy: v.optional(v.string()),
    approvedAt: v.optional(v.number()),
    // Set on the copy Chef makes to try a transient failure again
    // (chefRuns.retryTransient): the same bytes and approval as the failed
    // run's snapshot, which it names.
    retry: v.optional(
      v.object({ ofRunId: v.id("chefRuns"), attempt: v.number(), priorSpendUsd: v.number() }),
    ),
    // Set on the copy Chef makes when main moved before Ship it: the build
    // from it merges the new main into the release (chefShip.followMain).
    refresh: v.optional(vRefresh),
    // Set on the copy Chef makes for a follow-up build (a preview that failed
    // on the build's own code; src/chef/recovery.ts): the run, and why.
    followUp: v.optional(v.object({ ofRunId: v.id("chefRuns"), reason: v.string() })),
  }).index("by_itemId", ["itemId"]),

  // The Chef agent key: one root secret per app, created by an admin. Its
  // existence is what allows cloud builds; an external runner presents it once
  // to POST /chef-agent/enroll. Only sha256(key) is stored. Separate from the
  // /agent/* agentKeys on purpose: neither is accepted where the other is.
  chefAgentKeys: defineTable({
    name: v.string(),
    hash: v.string(),
    // The first characters of the key, to tell keys apart in the panel and the
    // audit log. Not enough to use.
    prefix: v.string(),
    createdBy: v.string(),
    createdAt: v.number(),
    // "cloud": its existence turns cloud builds on (the host's orchestrator
    // starts claimed runs). "worker": it only lets an external runner
    // (`npx chef work`) enroll and claim; it never starts a cloud build.
    // Absent on keys made before kinds existed, which act as "cloud".
    kind: v.optional(v.union(v.literal("cloud"), v.literal("worker"))),
    revokedAt: v.optional(v.number()),
    revokedBy: v.optional(v.string()),
  })
    .index("by_hash", ["hash"])
    .index("by_revokedAt", ["revokedAt"]),

  // One cloud build. Every report and workflow step carries the run id, and
  // anything for a run that isn't the active one is refused.
  chefRuns: defineTable(chefRunFields)
    .index("by_status", ["status"])
    .index("by_itemId", ["itemId"])
    .index("by_snapshotId", ["snapshotId"])
    .index("by_branchSweptAt_and_finishedAt", ["branchSweptAt", "finishedAt"]),

  // Singleton (key:"singleton"). Every claim reads and writes this row, so two
  // claims at once conflict and Convex retries one: that is the whole of the
  // one-build-at-a-time rule. No lock, lease or mutex.
  chefState: defineTable({
    key: v.literal("singleton"),
    activeRunId: v.optional(v.id("chefRuns")),
    nextSeq: v.number(),
    // The host's reconcile action, as a function handle (chefEffects
    // .setReconciler). Scheduled whenever a run goes to reconciling.
    reconcilerHandle: v.optional(v.string()),
    // The host's orchestrator (chefEffects.setOrchestrator): a mutation or
    // action handle that drives a claimed run, scheduled once by startRun.
    orchestratorHandle: v.optional(v.string()),
    // The host's shipper (chefShip.setShipper): an action handle that drives
    // an approved cloud release, scheduled by chefShip.approve.
    shipperHandle: v.optional(v.string()),
    // The host's repair applier (chefRepairs.setApplier): an action handle
    // that moves main to an approved repair commit, scheduled by apply.
    repairApplierHandle: v.optional(v.string()),
    // The host's cleanup (chefEffects.setCleaner): a mutation handle,
    // scheduled once each time a run finishes (chefCloud's chefCleanup).
    cleanerHandle: v.optional(v.string()),
    // The host's batch planner (chefBatches.setPlanner): an action handle
    // scheduled with the waiting requests when a claim finds more than one
    // (chef-cloud's chefPlanBatches, one model call through the AI gateway).
    plannerHandle: v.optional(v.string()),
    // The planning call in flight: the claim it stands in for (its trigger,
    // to claim with when the plan arrives) and the requests it was given.
    // While it is set, claims wait ("planning"); its one timeout check
    // gives up on it after PLAN_TIMEOUT_MS.
    planning: v.optional(
      v.object({
        id: v.string(),
        startedAt: v.number(),
        via: vRunVia,
        actor: v.string(),
        startedBy: v.optional(v.string()),
        itemIds: v.array(v.id("items")),
      }),
    ),
  }).index("by_key", ["key"]),

  // A batch: approved requests the planner grouped to be built in one run
  // (chefBatches.ts). "planned" while it waits in the queue (an admin may
  // split a request out), "building" while its run is live, "built" once it
  // built, "split" when its failure split it into single builds, and
  // "dissolved" when it ended any other way (cancelled, released, split down
  // to one request). `failures` counts its failed builds.
  chefBatches: defineTable({
    status: v.union(
      v.literal("planned"),
      v.literal("building"),
      v.literal("built"),
      v.literal("split"),
      v.literal("dissolved"),
    ),
    itemIds: v.array(v.id("items")),
    // The planner's words (untrusted model output, one plain line each).
    title: v.string(),
    reason: v.string(),
    // Every run that built it, oldest first.
    runIds: v.array(v.id("chefRuns")),
    failures: v.number(),
    model: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_status", ["status"]),

  // The other requests a batch run builds, one row each (the run's own
  // itemId is the first): "an item's newest run" looks here too.
  chefRunItems: defineTable({
    runId: v.id("chefRuns"),
    itemId: v.id("items"),
  })
    .index("by_itemId", ["itemId"])
    .index("by_runId", ["runId"]),

  // Run-bound credentials, stored as hashes. Valid only while the run is the
  // active run, before expiresAt, and not revoked.
  chefRunTokens: defineTable({
    runId: v.id("chefRuns"),
    kind: v.union(v.literal("runner"), v.literal("inference")),
    hash: v.string(),
    prefix: v.string(),
    scopes: v.array(vRunScope),
    // Set when the run came from an external runner's enroll.
    agentKeyId: v.optional(v.id("chefAgentKeys")),
    createdAt: v.number(),
    expiresAt: v.number(),
    revokedAt: v.optional(v.number()),
    // "reconcile": revoked because the run went to reconciling. An enrolled
    // runner's revoked credential may still report its push (pushing to
    // pushed) when no host reconciler is registered; nothing else.
    revokedFor: v.optional(v.literal("reconcile")),
  })
    .index("by_hash", ["hash"])
    .index("by_runId", ["runId"]),

  // Scrubbed runner log lines (POST /chef-agent/log), keyed by (runId, seq) so
  // a retried batch is stored once.
  chefRunLogs: defineTable({
    runId: v.id("chefRuns"),
    seq: v.number(),
    lines: v.array(v.string()),
    at: v.number(),
  }).index("by_runId_and_seq", ["runId", "seq"]),

  // What the agent said about the image's skills (POST /chef-agent/feedback):
  // one row per entry of the run's skill-feedback.jsonl, scrubbed, stored
  // once per run. Read by admins to improve the skills.
  chefSkillFeedback: defineTable({
    runId: v.id("chefRuns"),
    itemId: v.id("items"),
    /** Position in the run's report, so a retried report is stored once. */
    entry: v.number(),
    skill: v.string(),
    kind: vSkillFeedbackKind,
    message: v.string(),
    suggestion: v.optional(v.string()),
    /** sha256 of the stored entry, to tell an exact retry from a different report. */
    entryHash: v.string(),
    createdAt: v.number(),
  })
    .index("by_runId_and_entry", ["runId", "entry"])
    .index("by_skill", ["skill"]),

  // Steps a build needed that cost money or reach outside the app (POST
  // /chef-agent/approvals): the agent writes them to needs-approval.jsonl
  // instead of taking them. An admin approves or declines each; approving
  // only records the decision, nothing runs it yet.
  chefApprovalRequests: defineTable({
    runId: v.id("chefRuns"),
    itemId: v.id("items"),
    entry: v.number(),
    action: v.string(),
    skill: v.optional(v.string()),
    estimatedCostUsd: v.optional(v.number()),
    why: v.string(),
    commandOrSteps: v.string(),
    status: vApprovalStatus,
    decidedBy: v.optional(v.string()),
    decidedAt: v.optional(v.number()),
    decisionNote: v.optional(v.string()),
    entryHash: v.string(),
    createdAt: v.number(),
  })
    .index("by_runId_and_entry", ["runId", "entry"])
    .index("by_status", ["status"]),

  // Screenshots of the built app (POST /chef-agent/screenshot): the runner
  // takes them after the guards, with the agent dead, and uploads each PNG.
  // The file is in the component's storage; one row per (run, name), so a
  // retried upload is stored once.
  chefScreenshots: defineTable({
    runId: v.id("chefRuns"),
    itemId: v.id("items"),
    /** Lowercase letters, digits and dashes (src/chef/screenshots.ts). */
    name: v.string(),
    /** The page's path on the app, as the agent's plan gave it. */
    path: v.string(),
    storageId: v.id("_storage"),
    /** Hex sha256 of the PNG. */
    sha256: v.string(),
    size: v.number(),
    width: v.number(),
    height: v.number(),
    createdAt: v.number(),
  }).index("by_runId_and_name", ["runId", "name"]),

  // One row per request through the inference proxy (/chef-agent/ai).
  chefInference: defineTable(chefInferenceFields)
    // Newest first for one run (chefInference.listForRun); the compound index
    // would sort by status first.
    // eslint-disable-next-line @convex-dev/no-duplicate-indexes
    .index("by_runId", ["runId"])
    .index("by_runId_and_status", ["runId", "status"]),

  // The release state machine, one row per release (chefReleases.ts).
  chefReleases: defineTable(chefReleaseFields)
    .index("by_seq", ["seq"])
    .index("by_open", ["open"]),

  // A release's diff as the panel shows it: scrubbed text per chunk, with the
  // sha256 of the chunk as the CLI computed it (before scrubbing).
  chefReleaseDiffChunks: defineTable({
    releaseId: v.id("chefReleases"),
    index: v.number(),
    sha256: v.string(),
    bytes: v.number(),
    text: v.string(),
    redactions: v.number(),
  }).index("by_releaseId_and_index", ["releaseId", "index"]),

  // A built run's release diff (chefRuns.releaseDiff), as "Ship it" shows it:
  // scrubbed text per chunk, with the sha256 of the chunk before scrubbing.
  chefRunDiffChunks: defineTable({
    runId: v.id("chefRuns"),
    index: v.number(),
    sha256: v.string(),
    bytes: v.number(),
    text: v.string(),
    redactions: v.number(),
  }).index("by_runId_and_index", ["runId", "index"]),

  // Append-only. No exported function updates or deletes a row.
  chefAudit: defineTable(chefAuditFields).index("by_runId", ["runId"]),

  // Repair commits (chefRepairs.ts, docs/chef-pipeline.md "Repair commits"):
  // the mechanical fix for a repo problem a run failed on, made by a repair
  // sandbox with no agent on a chef-repair/* branch, offered in the panel,
  // and applied to main only by an admin. One per failed run.
  chefRepairs: defineTable({
    runId: v.id("chefRuns"),
    itemId: v.id("items"),
    kind: v.union(v.literal("lockfile"), v.literal("symlinks"), v.literal("envFiles")),
    status: v.union(
      v.literal("making"),
      v.literal("offered"),
      v.literal("applying"),
      v.literal("applied"),
      v.literal("failed"),
      v.literal("declined"),
    ),
    summary: v.optional(v.string()),
    files: v.optional(v.array(v.object({ path: v.string(), how: v.string() }))),
    branch: v.optional(v.string()),
    sha: v.optional(v.string()),
    // main when the repair was made: its parent, and what Apply moves main from.
    baseSha: v.optional(v.string()),
    error: v.optional(v.string()),
    decidedBy: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_runId", ["runId"])
    .index("by_status", ["status"]),

  // Attempts with a well-formed credential that matches nothing, counted per
  // route per minute instead of one audit row each (chefRejected.ts).
  // Pruned after 30 days.
  chefRejected: defineTable({ route: v.string(), bucket: v.number(), count: v.number() })
    .index("by_route_and_bucket", ["route", "bucket"])
    .index("by_bucket", ["bucket"]),

  // Repeated refusals of a credential Chef issued that is revoked or expired:
  // after the first (in chefAudit, permanent), one row per credential per
  // action per minute, counted (chefRejected.ts). `bucket` is the minute,
  // indexed for the 30-day pruning.
  chefRefusals: defineTable({
    actor: v.string(),
    action: v.string(),
    bucket: v.number(),
    count: v.number(),
    lastAt: v.number(),
    reason: v.optional(v.string()),
    runId: v.optional(v.id("chefRuns")),
  })
    .index("by_actor_action_bucket", ["actor", "action", "bucket"])
    .index("by_bucket", ["bucket"]),

  // What GET /chef-agent/run hands any runner under `config` when the host's
  // mountChefAgentRoutes passes none: the app's repo URL (no credentials),
  // the gates, the frontend build and the local env command. One row, set by
  // whatever orchestrates builds (@convex-dev/chef-cloud's chefCloud records
  // it at setup and at each launch, through the host). Nothing secret.
  chefRunnerConfig: defineTable({
    key: v.literal("singleton"),
    repoUrl: v.optional(v.string()),
    // "auto" lets the runner pick from the checkout's package.json scripts.
    gates: v.optional(v.union(v.literal("auto"), v.array(v.array(v.string())))),
    frontend: v.optional(
      v.union(
        v.literal(false),
        v.object({ command: v.array(v.string()), urlEnvVar: v.string(), distDir: v.string() }),
      ),
    ),
    localEnv: v.optional(v.union(v.literal("auto"), v.literal(false), v.array(v.string()))),
    // Fix rounds after a gate regression (src/chef/gates.ts); default 2.
    fixRounds: v.optional(v.number()),
    // The app's sign-in link function, for the build's signed-in screenshots.
    loginFunction: v.optional(v.string()),
    updatedAt: v.number(),
  }).index("by_key", ["key"]),

  // A failed run's work, for "Try again" to continue from (chefAttempts.ts):
  // the runner's `git diff` of the checkout against the base, with the
  // base's tree. Stored only without a secret in it; once per run.
  chefAttempts: defineTable({
    runId: v.id("chefRuns"),
    baseTree: v.string(),
    sha256: v.string(),
    text: v.string(),
    createdAt: v.number(),
  }).index("by_runId", ["runId"]),

  // What Chef learned about this app from its builds (chefLearnings.ts,
  // src/chef/learnings.ts): the runner's observations, recurring failures,
  // and the agents' notes, which are only ever read-only context for the
  // next agent. One row per key; newest wins.
  chefLearnings: defineTable({
    key: v.string(),
    source: v.union(v.literal("runner"), v.literal("agent"), v.literal("failure")),
    topic: v.string(),
    text: v.string(),
    // A list the text is built from (the recently changed files).
    items: v.optional(v.array(v.string())),
    // Runner-observed baselines only: gates' outcomes on one tree and lockfile.
    baseline: v.optional(
      v.object({
        tree: v.string(),
        lockfileHash: v.optional(v.string()),
        gates: v.array(v.object({ command: v.string(), outcome: v.union(v.literal("pass"), v.literal("fail")) })),
      }),
    ),
    firstRunSeq: v.number(),
    lastRunSeq: v.number(),
    seenCount: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_key", ["key"])
    .index("by_source_and_lastRunSeq", ["source", "lastRunSeq"]),

  // ----------- wow-shell mechanisms (build-mode UX, optional in prod) -----------
  //
  // Refinement questions reuse `items` (with kind="refinement") + `devLogs`
  // (as the answer thread) — no new table needed. See README "Refinement
  // questions" section.

  // Agent-planned checklist the user sees fill in as work progresses.
  // One row per item, ordered. Three states: pending / active / done.
  todos: defineTable({
    text: v.string(),
    order: v.number(),
    status: v.union(
      v.literal("pending"),
      v.literal("active"),
      v.literal("done"),
    ),
  }).index("by_order", ["order"]),

  // Free-form agent progress feed (separate from per-item devLogs).
  // Latest N rows render at the top of the floating Chef bubble.
  progressUpdates: defineTable({
    message: v.string(),
    kind: v.union(
      v.literal("step"),
      v.literal("shipped"),
      v.literal("note"),
    ),
  }),
});
