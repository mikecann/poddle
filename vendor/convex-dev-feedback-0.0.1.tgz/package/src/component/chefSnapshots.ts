// Approval binds an immutable snapshot (docs/chef-pipeline.md, Part 2).
//
// The admin approves exactly the bytes the build will see, not the mutable
// item: prepareApproval copies the item's full text, transcript and each
// attachment's hash into a chefSnapshots row, the panel renders that row, and
// approve() only accepts the snapshot's contentHash while the item is still
// what the snapshot says it is. Snapshots are never patched, except the
// one-time approval stamp.
//
// Like the rest of the component, these trust the userId the host forwards
// (the authenticated caller) and check its role here.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { requireAdminUser, isAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { claimNextBuild, newestRunOf, refreshState, runSnapshotFor } from "./chefRuns.js";
import { leaveBatch } from "./chefBatches.js";
import {
  itemUpdatedAt,
  readSnapshotContent,
  snapshotContentHash,
} from "./chefShared.js";

const vSnapshotAttachment = v.object({
  kind: v.union(v.literal("screenshot"), v.literal("audio")),
  storageId: v.id("_storage"),
  sha256: v.string(),
  size: v.number(),
  contentType: v.string(),
});

export const vSnapshot = v.object({
  _id: v.id("chefSnapshots"),
  _creationTime: v.number(),
  itemId: v.id("items"),
  title: v.string(),
  description: v.string(),
  transcript: v.union(v.string(), v.null()),
  attachments: v.array(vSnapshotAttachment),
  contentHash: v.string(),
  itemUpdatedAt: v.number(),
  createdBy: v.string(),
  createdAt: v.number(),
  approvedBy: v.optional(v.string()),
  approvedAt: v.optional(v.number()),
  retry: v.optional(v.object({ ofRunId: v.id("chefRuns"), attempt: v.number(), priorSpendUsd: v.number() })),
});

/** Items an admin may approve for a cloud build. */
function approvable(item: Doc<"items">): boolean {
  if (item.mergedInto || item.kind === "refinement") return false;
  return item.state === "submitted" || item.state === "requested";
}

/**
 * Snapshot the item as it is now. Reuses the newest unapproved snapshot when
 * nothing changed, so opening the same request twice writes one row.
 */
export async function takeSnapshot(
  ctx: MutationCtx,
  item: Doc<"items">,
  createdBy: string,
): Promise<{ snapshotId: Id<"chefSnapshots">; contentHash: string; reused: boolean }> {
  const content = await readSnapshotContent(ctx, item);
  const contentHash = await snapshotContentHash(content);
  const updatedAt = itemUpdatedAt(item);
  const latest = await ctx.db
    .query("chefSnapshots")
    .withIndex("by_itemId", (q) => q.eq("itemId", item._id))
    .order("desc")
    .first();
  if (
    latest &&
    latest.approvedAt === undefined &&
    latest.contentHash === contentHash &&
    latest.itemUpdatedAt === updatedAt
  ) {
    return { snapshotId: latest._id, contentHash, reused: true };
  }
  const snapshotId = await ctx.db.insert("chefSnapshots", {
    itemId: item._id,
    title: content.title,
    description: content.description,
    transcript: content.transcript,
    attachments: content.attachments,
    contentHash,
    itemUpdatedAt: updatedAt,
    createdBy,
    createdAt: Date.now(),
  });
  await writeAudit(ctx, {
    actor: userActor(createdBy),
    action: "snapshot.prepared",
    target: snapshotId,
    outcome: "ok",
    detail: { itemId: item._id, contentHash },
  });
  return { snapshotId, contentHash, reused: false };
}

/**
 * Check the snapshot still describes the item and stamp the approval. Shared
 * by approve() and an admin's own request at submit time.
 */
export async function approveSnapshot(
  ctx: MutationCtx,
  snapshot: Doc<"chefSnapshots">,
  contentHash: string,
  approverId: string,
): Promise<Doc<"items">> {
  if (contentHash !== snapshot.contentHash) {
    throw new Error("Approval refused: the content hash doesn't match the snapshot.");
  }
  const item = await ctx.db.get("items", snapshot.itemId);
  if (!item) throw new Error("Item not found");
  if (!approvable(item)) {
    throw new Error(`Approval refused: the request is ${item.state}.`);
  }
  if (itemUpdatedAt(item) !== snapshot.itemUpdatedAt) {
    throw new Error("Approval refused: the request changed after the snapshot. Open it again.");
  }
  const current = await snapshotContentHash(await readSnapshotContent(ctx, item));
  if (current !== snapshot.contentHash) {
    throw new Error("Approval refused: the request changed after the snapshot. Open it again.");
  }
  await ctx.db.patch("chefSnapshots", snapshot._id, {
    approvedBy: approverId,
    approvedAt: Date.now(),
  });
  // Approved again: it leaves a batch still waiting (the planner may group
  // it again, with what it says now), and one it was split out of.
  if (item.batchId) await leaveBatch(ctx, item._id, { alone: false });
  await ctx.db.patch("items", item._id, {
    state: "requested",
    snapshotId: snapshot._id,
    cloudQueuedAt: Date.now(),
    batchAlone: undefined,
  });
  await writeAudit(ctx, {
    actor: userActor(approverId),
    action: "snapshot.approved",
    target: snapshot._id,
    outcome: "ok",
    detail: { itemId: item._id, contentHash: snapshot.contentHash },
  });
  return item;
}

/**
 * An admin opened a request in the approvals view: snapshot it. Returns the
 * snapshot id and hash the panel passes back to `approve`.
 */
export const prepareApproval = mutation({
  args: { itemId: v.id("items"), adminUserId: v.string() },
  returns: v.object({
    snapshotId: v.id("chefSnapshots"),
    contentHash: v.string(),
  }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    if (!approvable(item)) {
      throw new Error(`Only submitted or requested items can be approved (this one is ${item.state}).`);
    }
    const { snapshotId, contentHash } = await takeSnapshot(ctx, item, args.adminUserId);
    return { snapshotId, contentHash };
  },
});

/**
 * The approval that can lead to a cloud build. Refuses a wrong hash, an item
 * edited after the snapshot, or a snapshot that was already approved.
 */
export const approve = mutation({
  args: {
    snapshotId: v.id("chefSnapshots"),
    contentHash: v.string(),
    adminUserId: v.string(),
  },
  returns: v.object({ itemId: v.id("items") }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const snapshot = await ctx.db.get("chefSnapshots", args.snapshotId);
    if (!snapshot) throw new Error("Snapshot not found");
    if (snapshot.approvedAt !== undefined) {
      throw new Error("Approval refused: this snapshot was already approved.");
    }
    const before = await approveSnapshot(ctx, snapshot, args.contentHash, args.adminUserId);
    if (before.state === "submitted") {
      await ctx.db.insert("notifications", {
        userId: before.createdBy,
        itemId: before._id,
        type: "approved",
        message: `“${before.title}” was approved`,
        isRead: false,
        stamp: Date.now(),
      });
    }
    // The approval hook: with auto-build on, claim a build in this same
    // transaction (claimNextBuild does nothing when it's off).
    await claimNextBuild(ctx, { via: "approval", actor: userActor(args.adminUserId) });
    return { itemId: before._id };
  },
});

/**
 * An admin's own request lands in "requested" at submit time; it gets a
 * snapshot approved by its author, since they wrote it. Called by the host
 * (exposeChefApi) after the request's attachments are stored.
 */
export const snapshotOwnRequest = mutation({
  args: { itemId: v.id("items"), adminUserId: v.string() },
  returns: v.union(v.id("chefSnapshots"), v.null()),
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    // Only the author, and only while they are an admin and it's queued.
    if (item.createdBy !== args.adminUserId) return null;
    if (!(await isAdminUser(ctx, args.adminUserId))) return null;
    if (item.state !== "requested" || item.snapshotId) return null;
    const { snapshotId, contentHash } = await takeSnapshot(ctx, item, args.adminUserId);
    const snapshot = (await ctx.db.get("chefSnapshots", snapshotId))!;
    await approveSnapshot(ctx, snapshot, contentHash, args.adminUserId);
    await claimNextBuild(ctx, { via: "approval", actor: userActor(args.adminUserId) });
    return snapshotId;
  },
});

/**
 * "Try again" on a request whose last build failed or was cancelled: one
 * step instead of prepareApproval, the snapshot, approve. It snapshots the
 * request as it is now and, only if that is exactly what the admin
 * approved for the last build (the same contentHash), approves the new
 * snapshot and claims a cloud build (with auto-build off too, like the
 * button). If the request changed, nothing is approved: the answer is
 * `needsApproval` with the new snapshot, for the normal approval flow,
 * which shows the admin the new text first. Audited either way.
 */
export const retry = mutation({
  args: { itemId: v.id("items"), adminUserId: v.string() },
  returns: v.union(
    v.object({ outcome: v.literal("started"), claim: v.string(), snapshotId: v.id("chefSnapshots") }),
    v.object({ outcome: v.literal("needsApproval"), snapshotId: v.id("chefSnapshots"), contentHash: v.string() }),
    // Returned, not thrown, so its audit row stays.
    v.object({ outcome: v.literal("refused"), reason: v.string() }),
  ),
  handler: async (ctx, args) => await retryRequest(ctx, args),
});

/**
 * "Try again" for one request, as `adminUserId`: the body of `retry`, for
 * the component's own callers too (a repair applied, chefRepairs.applied).
 */
export async function retryRequest(ctx: MutationCtx, args: { itemId: Id<"items">; adminUserId: string }) {
  {
    await requireAdminUser(ctx, args.adminUserId);
    const actor = userActor(args.adminUserId);
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    const last = await newestRunOf(ctx, item._id);
    const refuse = async (reason: string) => {
      await writeAudit(ctx, { actor, action: "run.retry", target: item._id, outcome: "refused", reason });
      return { outcome: "refused" as const, reason };
    };
    if (!last) return await refuse("Nothing to try again: this request was never built");
    // A built run Ship it couldn't ship as it is (main moved; shipBlocked)
    // can be tried again too: a fresh build of it on the new main.
    if (last.status !== "failed" && last.status !== "cancelled" && !(last.status === "built" && last.shipBlocked)) {
      return await refuse(`Nothing to try again: its last build is ${last.status}`);
    }
    if (!approvable(item)) return await refuse(`Nothing to try again: the request is ${item.state}`);
    // A new snapshot would replace the approved merge-only build Chef queued
    // when main moved before Ship it, and drop it from the queue.
    if (last.status === "built" && last.shipBlocked && (await refreshState(ctx, last))) {
      return await refuse("Chef is already merging the newest main into this build; it ships on its own if the change is the same");
    }
    // A batch run's member was built from its own snapshot.
    const lastSnapshotId = runSnapshotFor(last, item._id) ?? last.snapshotId;
    const approved = await ctx.db.get("chefSnapshots", lastSnapshotId);
    if (!approved || approved.approvedAt === undefined) return await refuse("The last build's approval is gone");
    const { snapshotId, contentHash } = await takeSnapshot(ctx, item, args.adminUserId);
    if (contentHash !== approved.contentHash) {
      await writeAudit(ctx, {
        actor,
        action: "run.retry",
        target: item._id,
        outcome: "refused",
        reason: "the request changed since its last approval: approve it again",
        detail: { runId: last._id, snapshotId, contentHash, approvedHash: approved.contentHash },
      });
      return { outcome: "needsApproval" as const, snapshotId, contentHash };
    }
    const snapshot = (await ctx.db.get("chefSnapshots", snapshotId))!;
    await approveSnapshot(ctx, snapshot, contentHash, args.adminUserId);
    // A retry Chef had scheduled for the failed run is superseded.
    if (last.retryAt !== undefined) await ctx.db.patch("chefRuns", last._id, { retryAt: undefined });
    // The failed run's work, if it left any (chefAttempts): the next build
    // starts from it rather than from scratch.
    const attempt = await ctx.db
      .query("chefAttempts")
      .withIndex("by_runId", (q) => q.eq("runId", last._id))
      .first();
    // Not a batch's: its work holds the other requests' changes too.
    if (attempt && !last.batch) await ctx.db.patch("items", item._id, { continueFrom: last._id });
    const claim = await claimNextBuild(ctx, { via: "button", actor, startedBy: args.adminUserId });
    await writeAudit(ctx, {
      actor,
      action: "run.retry",
      target: item._id,
      runId: last._id,
      outcome: "ok",
      detail: { snapshotId, contentHash, claim: claim.outcome, continues: attempt !== null },
    });
    return { outcome: "started" as const, claim: claim.outcome, snapshotId };
  }
}

/** One snapshot with inline attachment URLs for the approvals view. Admins only; null otherwise. */
export const get = query({
  args: { snapshotId: v.id("chefSnapshots"), viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(
    v.null(),
    v.object({
      snapshot: vSnapshot,
      attachmentUrls: v.array(v.union(v.string(), v.null())),
    }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const snapshot = await ctx.db.get("chefSnapshots", args.snapshotId);
    if (!snapshot) return null;
    const attachmentUrls = await Promise.all(
      snapshot.attachments.map((a) => ctx.storage.getUrl(a.storageId)),
    );
    return { snapshot, attachmentUrls };
  },
});
