/**
 * The Chef agent API (docs/chef-pipeline.md, "The Chef agent API"), mounted by
 * the host next to its other routes:
 *
 *   import { mountChefAgentRoutes } from "@convex-dev/feedback/http";
 *   mountChefAgentRoutes(http, components.feedback);
 *
 * Every route takes a bearer credential. `/chef-agent/enroll` accepts only the
 * Chef agent key; every other route accepts only a run credential. Neither is
 * an /agent/* key, and /agent/* never accepts them.
 */
import type { ComponentApi } from "../component/_generated/component.js";
import { getServiceToken, httpActionGeneric, type HttpRouter } from "convex/server";
import {
  SseUsageParser,
  anthropicError,
  usageFromJson,
  type Usage,
} from "../chef/ai.js";
import { MAX_ARTIFACT_BYTES, isCommitSha, isSha256Hex } from "../chef/frontend.js";
import { RELEASE_DIFF_MAX_BYTES } from "../chef/release.js";

type FeedbackApi = ComponentApi;

export type MountChefAgentRoutesOptions = {
  /** URL prefix for routes. Default "/chef-agent". */
  prefix?: string;
  /**
   * Non-secret run settings returned by GET /run under `config`: repo name,
   * gates, ports, model, provenance pins. Never put a credential here.
   * Merged over what the orchestration recorded in chefRunnerConfig (with
   * @convex-dev/chef-cloud: its repo URL, gates, frontend and local env), so
   * a chefCloud host passes nothing.
   */
  runConfig?: Record<string, unknown>;
  /** How the action reads a stored file by URL. Default: global fetch. For tests. */
  fetch?: (url: string) => Promise<Response>;
  /** The inference proxy's upstream. Defaults are the real ones; tests inject fakes. */
  ai?: {
    /** Default `https://ai-gateway.convex.dev`. */
    upstream?: string;
    /** Default: `getServiceToken("ai-gateway")`, minted inside the action per request. */
    serviceToken?: () => Promise<string>;
    /** Default: global fetch. */
    fetch?: (url: string, init: RequestInit) => Promise<Response>;
  };
};

const AI_UPSTREAM = "https://ai-gateway.convex.dev";
// Claude Code requests run to a few hundred KB; images can make them larger.
const MAX_AI_BODY = 16 * 1024 * 1024;
// Response headers the client may see. Nothing else from upstream passes.
const AI_RESPONSE_HEADERS = ["content-type", "retry-after", "request-id", "x-request-id"];
// Request headers the gateway gets besides content type and its credential.
const AI_FORWARD_HEADERS = ["anthropic-beta", "anthropic-version", "accept"];

const MAX_BODY = 256 * 1024;
// One PNG (src/chef/screenshots.ts SCREENSHOT_LIMITS.fileBytes); the
// component checks the exact limit.
const MAX_SCREENSHOT = 2 * 1024 * 1024;

async function readJson(req: Request): Promise<any> {
  const text = await req.text();
  if (text.length > MAX_BODY) return undefined;
  try {
    return JSON.parse(text || "{}");
  } catch {
    return undefined;
  }
}

async function sha256Hex(bytes: ArrayBuffer): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

async function readJsonUpTo(req: Request, max: number): Promise<any> {
  const text = await req.text();
  if (text.length > max) return undefined;
  try {
    return JSON.parse(text || "{}");
  } catch {
    return undefined;
  }
}

/** Mutation results are either a refusal with a status or { ok: true, ... }. */
function reply(r: any): Response {
  if (!r.ok) return json({ error: r.error }, r.status ?? 400);
  const { ok: _ok, ...rest } = r;
  return json(rest);
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

// The only shapes Chef credentials have (randomSecret: a prefix and 32 random
// bytes in hex). Anything else is refused here, before any mutation and with
// no audit row: it can't be a real credential, and anyone can send it.
const RUN_CREDENTIAL = /^chefr_[0-9a-f]{64}$/;
const AGENT_KEY = /^chefk_[0-9a-f]{64}$/;

function bearer(req: Request): string | null {
  const m = (req.headers.get("authorization") ?? "").match(/^Bearer\s+(\S+)$/i);
  return m ? m[1] : null;
}

export function mountChefAgentRoutes(
  http: HttpRouter,
  component: FeedbackApi,
  opts: MountChefAgentRoutesOptions = {},
) {
  const prefix = opts.prefix ?? "/chef-agent";

  const doFetch = opts.fetch ?? ((url: string) => fetch(url));

  type Route =
    | "enroll"
    | "run"
    | "attachments"
    | "report"
    | "log"
    | "heartbeat"
    | "ai"
    | "feedback"
    | "approvals"
    | "screenshot"
    | "artifact"
    | "releaseDiff"
    | "finish"
    | "learnings"
    | "attempt";

  // Every outcome the action decides itself goes through here, so every call
  // leaves one audit row. Outcomes a mutation decides are audited in the
  // mutation. The component records the credential's prefix and run, never
  // the credential or the body.
  const record = async (
    ctx: any,
    route: Route,
    token: string | null,
    outcome: "ok" | "refused" | "error",
    status: number,
    reason?: string,
    index?: number,
  ) => {
    try {
      await ctx.runMutation(component.chefAgent.recordRoute, {
        token,
        route,
        outcome,
        status,
        ...(reason !== undefined ? { reason } : {}),
        ...(index !== undefined ? { index } : {}),
      });
    } catch {
      // Auditing must not turn a refusal into a 500.
    }
  };
  const fail = async (
    ctx: any,
    route: Route,
    token: string | null,
    status: number,
    error: string,
    opts: { outcome?: "refused" | "error"; index?: number } = {},
  ) => {
    await record(ctx, route, token, opts.outcome ?? (status >= 500 ? "error" : "refused"), status, error, opts.index);
    return json({ error }, status);
  };

  // Only the Chef agent key.
  const enroll = httpActionGeneric(async (ctx, req) => {
    const key = bearer(req);
    if (!key) return json({ error: "Missing Bearer token" }, 401);
    if (!AGENT_KEY.test(key)) return json({ error: "Invalid or revoked Chef agent key" }, 401);
    // Optional JSON body: { requests: "admin" | "any" } (chefAgentKeys.enroll).
    const body = await readJson(req);
    const requests = body?.requests === "admin" || body?.requests === "any" ? body.requests : undefined;
    try {
      const r = await ctx.runMutation(component.chefAgentKeys.enroll, { key, ...(requests ? { requests } : {}) });
      if (!r.ok) return json({ error: r.error }, r.status ?? 401);
      return json({
        claim: r.claim,
        credential: r.credential,
        rotated: r.rotated,
        ...(r.requestedBy ? { requestedBy: r.requestedBy } : {}),
      });
    } catch {
      return await fail(ctx, "enroll", key, 500, "Enrollment failed");
    }
  });

  // Everything below takes only a run credential.
  const withToken = (
    route: Route,
    handler: (ctx: any, req: Request, token: string) => Promise<Response>,
  ) =>
    httpActionGeneric(async (ctx, req) => {
      const token = bearer(req);
      if (!token) return json({ error: "Missing Bearer token" }, 401);
      if (!RUN_CREDENTIAL.test(token)) return json({ error: "Invalid run credential" }, 401);
      try {
        return await handler(ctx, req, token);
      } catch {
        return await fail(ctx, route, token, 500, "Internal error");
      }
    });

  const run = withToken("run", async (ctx, _req, token) => {
    const r = await ctx.runMutation(component.chefAgent.getRun, { token });
    if (!r.ok) return reply(r);
    const { ok: _ok, ...rest } = r;
    // What the orchestration recorded (chefRunnerConfig: the repo URL, gates,
    // frontend, local env), under anything the host passed here itself.
    // Never a credential.
    const stored = await ctx.runQuery(component.chefRunnerConfig.get, {});
    // What earlier builds learned (chefLearnings.forRun): the agent's brief,
    // read-only context, and the runner's cached baselines.
    const learnings = await ctx.runQuery(component.chefLearnings.forRun, {});
    return json({ ...rest, config: { ...stored, ...(opts.runConfig ?? {}) }, learnings });
  });

  // GET <prefix>/attachments/<index>: streams the file, checked against the
  // snapshot's sha256. The storage URL stays inside this action. A batch's
  // other requests' files are at <prefix>/attachments/<member>/<index>.
  const attachments = withToken("attachments", async (ctx, req, token) => {
    const path = new URL(req.url).pathname;
    const m = /\/attachments\/(?:(\d{1,2})\/)?(\d{1,2})$/.exec(path);
    if (!m) return await fail(ctx, "attachments", token, 400, "Bad attachment index");
    const index = Number(m[2]);
    const member = m[1] !== undefined ? Number(m[1]) : undefined;
    const src = await ctx.runMutation(component.chefAgent.attachmentSource, {
      token,
      index,
      ...(member !== undefined ? { member } : {}),
    });
    if (!src.ok) return reply(src);
    let bytes: ArrayBuffer;
    try {
      const res = await doFetch(src.url);
      if (!res.ok) throw new Error("storage fetch failed");
      bytes = await res.arrayBuffer();
    } catch {
      return await fail(ctx, "attachments", token, 502, "Attachment unavailable", { index });
    }
    if ((await sha256Hex(bytes)) !== src.sha256) {
      return await fail(ctx, "attachments", token, 502, "Attachment hash mismatch", {
        outcome: "refused",
        index,
      });
    }
    await record(ctx, "attachments", token, "ok", 200, undefined, index);
    return new Response(bytes, {
      status: 200,
      headers: {
        "content-type": src.contentType || "application/octet-stream",
        "x-chef-sha256": src.sha256,
        "cache-control": "no-store",
      },
    });
  });

  const report = withToken("report", async (ctx, req, token) => {
    const body = await readJson(req);
    if (!body || typeof body.fromPhase !== "string" || typeof body.toPhase !== "string") {
      return await fail(ctx, "report", token, 400, "fromPhase and toPhase required");
    }
    let r: any;
    try {
      r = await ctx.runMutation(component.chefAgent.report, {
        token,
        fromPhase: body.fromPhase,
        toPhase: body.toPhase,
        ...(body.facts !== undefined ? { facts: body.facts } : {}),
      });
    } catch {
      // Argument validation: an unknown phase or fact.
      return await fail(ctx, "report", token, 400, "Invalid report");
    }
    return reply(r);
  });

  const log = withToken("log", async (ctx, req, token) => {
    const body = await readJson(req);
    if (!body || typeof body.seq !== "number" || !Array.isArray(body.lines)) {
      return await fail(ctx, "log", token, 400, "seq and lines required");
    }
    let r: any;
    try {
      r = await ctx.runMutation(component.chefAgent.log, { token, seq: body.seq, lines: body.lines });
    } catch {
      return await fail(ctx, "log", token, 400, "Invalid log");
    }
    return reply(r);
  });

  // POST <prefix>/feedback: the run's skill feedback, read by the runner
  // from skill-feedback.jsonl after the agent is dead.
  const feedback = withToken("feedback", async (ctx, req, token) => {
    const body = await readJson(req);
    if (!body || !Array.isArray(body.skillFeedback)) {
      return await fail(ctx, "feedback", token, 400, "skillFeedback required");
    }
    let r: any;
    try {
      r = await ctx.runMutation(component.chefFeedback.reportSkillFeedback, { token, entries: body.skillFeedback });
    } catch {
      return await fail(ctx, "feedback", token, 400, "Invalid feedback");
    }
    return reply(r);
  });

  // POST <prefix>/learnings: what the runner saw this run and the agent's
  // notes about the repo, once, for the next build (chefLearnings.report).
  const learnings = withToken("learnings", async (ctx, req, token) => {
    const body = await readJson(req);
    if (!body || typeof body.observed !== "object" || body.observed === null || !Array.isArray(body.notes)) {
      return await fail(ctx, "learnings", token, 400, "observed and notes required");
    }
    let r: any;
    try {
      r = await ctx.runMutation(component.chefLearnings.report, {
        token,
        observed: body.observed,
        timings: body.timings && typeof body.timings === "object" ? body.timings : {},
        notes: body.notes,
        ...(body.attempt && typeof body.attempt === "object" ? { attempt: body.attempt } : {}),
      });
    } catch {
      return await fail(ctx, "learnings", token, 400, "Invalid learnings");
    }
    return reply(r);
  });

  // POST <prefix>/attempt: a failed run's work (its diff against the base and
  // the base's tree), so "Try again" continues from it (chefAttempts).
  // GET <prefix>/attempt: that work, for the run that continues from it.
  const attemptPost = withToken("attempt", async (ctx, req, token) => {
    const body = await readJsonUpTo(req, 1024 * 1024);
    if (!body || typeof body.baseTree !== "string" || typeof body.diff !== "string") {
      return await fail(ctx, "attempt", token, 400, "baseTree and diff required");
    }
    return reply(await ctx.runMutation(component.chefAttempts.store, { token, baseTree: body.baseTree, diff: body.diff }));
  });
  const attemptGet = withToken("attempt", async (ctx, _req, token) => reply(await ctx.runMutation(component.chefAttempts.fetch, { token })));

  // POST <prefix>/approvals: steps the build needs that cost money or reach
  // outside the app, from needs-approval.jsonl, for an admin to decide.
  const approvals = withToken("approvals", async (ctx, req, token) => {
    const body = await readJson(req);
    if (!body || !Array.isArray(body.approvalRequests)) {
      return await fail(ctx, "approvals", token, 400, "approvalRequests required");
    }
    let r: any;
    try {
      r = await ctx.runMutation(component.chefFeedback.reportApprovalRequests, { token, entries: body.approvalRequests });
    } catch {
      return await fail(ctx, "approvals", token, 400, "Invalid approval requests");
    }
    return reply(r);
  });

  // POST <prefix>/screenshot?name=<name>&path=<path>: one PNG of the built
  // app, taken by the runner after the guards (runner/screenshots.ts). The
  // body is the file; `x-chef-sha256` is the runner's hash of it. The
  // component checks the PNG, the hash, the run's phase and the caps, and
  // stores it in its own file storage.
  const screenshot = withToken("screenshot", async (ctx, req, token) => {
    const declared = Number(req.headers.get("content-length") ?? "0");
    if (declared > MAX_SCREENSHOT) return await fail(ctx, "screenshot", token, 413, "Screenshot too large");
    const bytes = await req.arrayBuffer();
    if (bytes.byteLength > MAX_SCREENSHOT) return await fail(ctx, "screenshot", token, 413, "Screenshot too large");
    if (bytes.byteLength === 0) return await fail(ctx, "screenshot", token, 400, "No screenshot");
    const q = new URL(req.url).searchParams;
    const name = q.get("name");
    const path = q.get("path");
    if (!name || !path) return await fail(ctx, "screenshot", token, 400, "name and path required");
    const sha256 = req.headers.get("x-chef-sha256");
    let r: any;
    try {
      r = await ctx.runAction(component.chefScreenshots.upload, {
        token,
        name: name.slice(0, 100),
        path: path.slice(0, 1000),
        bytes,
        ...(sha256 ? { sha256: sha256.slice(0, 100) } : {}),
      });
    } catch {
      return await fail(ctx, "screenshot", token, 500, "Screenshot not stored");
    }
    return reply(r);
  });

  // An enrolled run's end, from its own runner (chefAgent.finish).
  const finish = withToken("finish", async (ctx, req, token) => {
    const body = await readJson(req);
    if (!body || typeof body !== "object" || (body.outcome !== "built" && body.outcome !== "failed")) {
      return await fail(ctx, "finish", token, 400, "outcome must be built or failed");
    }
    const str = (x: unknown) => (typeof x === "string" ? x : undefined);
    return reply(
      await ctx.runMutation(component.chefAgent.finish, {
        token,
        outcome: body.outcome,
        ...(str(body.error) !== undefined ? { error: str(body.error) } : {}),
        ...(body.handoff === true ? { handoff: true } : {}),
        ...(str(body.previewDeploymentName) !== undefined ? { previewDeploymentName: str(body.previewDeploymentName) } : {}),
      }),
    );
  });

  const heartbeat = withToken("heartbeat", async (ctx, _req, token) =>
    reply(await ctx.runMutation(component.chefAgent.heartbeat, { token })),
  );

  // POST <prefix>/artifact: the runner's built frontend, a gzipped tar,
  // with `x-chef-sha256` and `x-chef-commit`. Only in the `guards` phase,
  // at most MAX_ARTIFACT_BYTES; stored in the component's file storage
  // (chefArtifact.store), which checks the credential and the phase before
  // storing anything. The body is never logged or audited, only its hash.
  const artifact = withToken("artifact", async (ctx, req, token) => {
    const sha256 = (req.headers.get("x-chef-sha256") ?? "").toLowerCase();
    const commitSha = (req.headers.get("x-chef-commit") ?? "").toLowerCase();
    if (!isSha256Hex(sha256)) return await fail(ctx, "artifact", token, 400, "x-chef-sha256 must be 64 hex characters");
    if (!isCommitSha(commitSha)) return await fail(ctx, "artifact", token, 400, "x-chef-commit must be a 40 character sha");
    const declared = Number(req.headers.get("content-length") ?? "NaN");
    if (Number.isFinite(declared) && declared > MAX_ARTIFACT_BYTES) {
      return await fail(ctx, "artifact", token, 413, `Artifact over ${MAX_ARTIFACT_BYTES} bytes`);
    }
    const bytes = await req.arrayBuffer();
    if (bytes.byteLength > MAX_ARTIFACT_BYTES) {
      return await fail(ctx, "artifact", token, 413, `Artifact over ${MAX_ARTIFACT_BYTES} bytes`);
    }
    if (bytes.byteLength === 0) return await fail(ctx, "artifact", token, 400, "Empty artifact");
    return reply(await ctx.runAction(component.chefArtifact.store, { token, sha256, commitSha, bytes }));
  });

  // POST <prefix>/release-diff: `git diff <main>..<commit>` (the release
  // diff "Ship it" shows), UTF-8 text, with `x-chef-sha256`, `x-chef-commit`
  // and `x-chef-base`. Only in `guards`, at most RELEASE_DIFF_MAX_BYTES;
  // chefArtifact.recordReleaseDiff checks the credential and the phase,
  // chunks, hashes and scrubs it. Never logged; only its hash is audited.
  const releaseDiff = withToken("releaseDiff", async (ctx, req, token) => {
    const sha256 = (req.headers.get("x-chef-sha256") ?? "").toLowerCase();
    const commitSha = (req.headers.get("x-chef-commit") ?? "").toLowerCase();
    const baseSha = (req.headers.get("x-chef-base") ?? "").toLowerCase();
    if (!isSha256Hex(sha256)) return await fail(ctx, "releaseDiff", token, 400, "x-chef-sha256 must be 64 hex characters");
    if (!isCommitSha(commitSha) || !isCommitSha(baseSha)) {
      return await fail(ctx, "releaseDiff", token, 400, "x-chef-commit and x-chef-base must be 40 character shas");
    }
    const declared = Number(req.headers.get("content-length") ?? "NaN");
    if (Number.isFinite(declared) && declared > RELEASE_DIFF_MAX_BYTES) {
      return await fail(ctx, "releaseDiff", token, 413, `Diff over ${RELEASE_DIFF_MAX_BYTES} bytes`);
    }
    const bytes = new Uint8Array(await req.arrayBuffer());
    if (bytes.byteLength > RELEASE_DIFF_MAX_BYTES) {
      return await fail(ctx, "releaseDiff", token, 413, `Diff over ${RELEASE_DIFF_MAX_BYTES} bytes`);
    }
    if (bytes.byteLength === 0) return await fail(ctx, "releaseDiff", token, 400, "Empty diff");
    let text: string;
    try {
      text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      return await fail(ctx, "releaseDiff", token, 400, "The diff is not UTF-8");
    }
    return reply(
      await ctx.runMutation(component.chefArtifact.recordReleaseDiff, { token, sha256, commitSha, baseSha, text }),
    );
  });

  // POST <prefix>/ai/v1/messages: the inference proxy. Claude Code's
  // ANTHROPIC_BASE_URL is <site>/chef-agent/ai. The run credential is
  // checked and every limit enforced by chefInference.begin before anything
  // is forwarded; the service token is minted here and never leaves this
  // action. The response streams back byte for byte while its usage is read.
  const aiOpts = opts.ai ?? {};
  const aiUpstream = (aiOpts.upstream ?? AI_UPSTREAM).replace(/\/$/, "");
  const mintToken = aiOpts.serviceToken ?? (() => getServiceToken("ai-gateway"));
  const aiFetch = aiOpts.fetch ?? ((url: string, init: RequestInit) => fetch(url, init));

  const ai = httpActionGeneric(async (ctx, req) => {
    const started = Date.now();
    const token = bearer(req);
    const refuseEarly = async (status: number, error: string) => {
      await record(ctx, "ai", token, "refused", status, error);
      return anthropicError(status, error);
    };
    if (!token) return anthropicError(401, "Missing Bearer token");
    if (!RUN_CREDENTIAL.test(token)) return anthropicError(401, "Invalid run credential");
    const bodyText = await req.text();
    const requestBytes = new TextEncoder().encode(bodyText).length;
    if (requestBytes > MAX_AI_BODY) return await refuseEarly(413, "Request too large");
    let body: any;
    try {
      body = JSON.parse(bodyText);
    } catch {
      return await refuseEarly(400, "Body must be JSON");
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return await refuseEarly(400, "Body must be a JSON object");
    }
    const admitted = await ctx.runMutation(component.chefInference.begin, {
      token,
      model: typeof body.model === "string" ? body.model : "",
      maxTokens: typeof body.max_tokens === "number" ? body.max_tokens : null,
      stream: body.stream === true,
      requestBytes,
    });
    if (!admitted.ok) return anthropicError(admitted.status, admitted.error, admitted.retryAfter);

    // From here on the in-flight slot is held; `finish` gives it back exactly
    // once. Every caller gets the same promise, so whoever finishes second
    // still waits for the first one's mutation.
    let finishing: Promise<void> | null = null;
    const finish = (
      outcome: "ok" | "error" | "cancelled",
      httpStatus: number,
      usage: Usage,
      firstByteMs?: number,
      reason?: string,
    ): Promise<void> => {
      finishing ??= (async () => {
        await ctx.runMutation(component.chefInference.end, {
          requestId: admitted.requestId,
          outcome,
          httpStatus,
          usage,
          ...(firstByteMs !== undefined ? { firstByteMs } : {}),
          latencyMs: Date.now() - started,
          ...(reason !== undefined ? { reason } : {}),
        });
      })();
      return finishing;
    };

    let handedOff = false;
    try {
      let serviceToken: string;
      try {
        serviceToken = await mintToken();
      } catch {
        await finish("error", 502, {}, undefined, "could not mint the AI gateway token");
        return anthropicError(502, "Inference is unavailable");
      }
      const headers: Record<string, string> = {
        "content-type": "application/json",
        authorization: `Bearer ${serviceToken}`,
      };
      for (const h of AI_FORWARD_HEADERS) {
        const value = req.headers.get(h);
        if (value !== null) headers[h] = value;
      }
      const search = new URL(req.url).search;
      let res: Response;
      try {
        res = await aiFetch(`${aiUpstream}/v1/messages${search}`, {
          method: "POST",
          headers,
          body: bodyText,
        });
      } catch {
        await finish("error", 502, {}, undefined, "the AI gateway could not be reached");
        return anthropicError(502, "Inference is unavailable");
      }
      const firstByteMs = Date.now() - started;
      const outHeaders = new Headers({ "cache-control": "no-store" });
      for (const h of AI_RESPONSE_HEADERS) {
        const value = res.headers.get(h);
        if (value !== null) outHeaders.set(h, value);
      }
      const status = res.status;
      const isStream = (res.headers.get("content-type") ?? "").includes("text/event-stream");

      if (!isStream || !res.body) {
        const bytes = new Uint8Array(await res.arrayBuffer());
        const text = new TextDecoder().decode(bytes);
        if (text.includes(serviceToken)) {
          await finish("error", 502, usageFromJson(text), firstByteMs, "upstream response held the service token; withheld");
          return anthropicError(502, "Inference response withheld");
        }
        await finish(res.ok ? "ok" : "error", status, usageFromJson(text), firstByteMs);
        return new Response(bytes, { status, headers: outHeaders });
      }

      // Stream: pass every chunk through untouched, parse a decoded copy for
      // usage, and finish the request when the stream ends, breaks, or the
      // client goes away. The last few characters are kept so a token split
      // across two chunks is still caught.
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      const parser = new SseUsageParser();
      let tail = "";
      const out = new ReadableStream<Uint8Array>({
        async pull(controller) {
          try {
            const { done, value } = await reader.read();
            if (done) {
              parser.push(decoder.decode());
              parser.end();
              const complete = parser.sawMessageStop && parser.errorType === null;
              await finish(
                complete ? "ok" : "error",
                status,
                parser.usage,
                firstByteMs,
                complete ? undefined : parser.errorType ? `stream error: ${parser.errorType}` : "stream ended before message_stop",
              );
              controller.close();
              return;
            }
            const text = decoder.decode(value, { stream: true });
            const window = tail + text;
            if (window.includes(serviceToken)) {
              await reader.cancel().catch(() => {});
              await finish("error", 502, parser.usage, firstByteMs, "upstream stream held the service token; cut off");
              controller.error(new Error("Inference response withheld"));
              return;
            }
            tail = window.slice(-serviceToken.length);
            parser.push(text);
            controller.enqueue(value);
          } catch {
            await finish("error", status, parser.usage, firstByteMs, "upstream stream failed");
            controller.error(new Error("Inference stream failed"));
          }
        },
        async cancel() {
          await reader.cancel().catch(() => {});
          await finish("cancelled", status, parser.usage, firstByteMs);
        },
      });
      // A client that hangs up: the deployment aborts the request's signal
      // but keeps pulling the response stream (it doesn't call `cancel`
      // above; docs/local-e2e.md). Without this the upstream would run to
      // the end, spending, while holding the slot. Finishing first makes the
      // pull that sees the cancelled reader end a no-op.
      const clientGone = () => {
        finish("cancelled", status, parser.usage, firstByteMs).catch(() => {});
        reader.cancel().catch(() => {});
      };
      if (req.signal?.aborted) clientGone();
      else req.signal?.addEventListener("abort", clientGone, { once: true });
      handedOff = true;
      return new Response(out, { status, headers: outHeaders });
    } finally {
      if (!handedOff) await finish("error", 500, {}, undefined, "the proxy failed before responding");
    }
  });

  http.route({ path: `${prefix}/ai/v1/messages`, method: "POST", handler: ai });
  http.route({ path: `${prefix}/enroll`, method: "POST", handler: enroll });
  http.route({ path: `${prefix}/run`, method: "GET", handler: run });
  http.route({ pathPrefix: `${prefix}/attachments/`, method: "GET", handler: attachments });
  http.route({ path: `${prefix}/report`, method: "POST", handler: report });
  http.route({ path: `${prefix}/log`, method: "POST", handler: log });
  http.route({ path: `${prefix}/heartbeat`, method: "POST", handler: heartbeat });
  http.route({ path: `${prefix}/finish`, method: "POST", handler: finish });
  http.route({ path: `${prefix}/feedback`, method: "POST", handler: feedback });
  http.route({ path: `${prefix}/approvals`, method: "POST", handler: approvals });
  http.route({ path: `${prefix}/learnings`, method: "POST", handler: learnings });
  http.route({ path: `${prefix}/attempt`, method: "POST", handler: attemptPost });
  http.route({ path: `${prefix}/attempt`, method: "GET", handler: attemptGet });
  http.route({ path: `${prefix}/screenshot`, method: "POST", handler: screenshot });
  http.route({ path: `${prefix}/artifact`, method: "POST", handler: artifact });
  http.route({ path: `${prefix}/release-diff`, method: "POST", handler: releaseDiff });
}
