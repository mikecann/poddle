// Whether the build agent used the Convex plugin (docs/chef-pipeline.md,
// "The Convex plugin"): its skills and agents, counted from the agent's own
// stream-json (the tool calls the runner already streams), and its hooks,
// counted from the log the runner's hook wrapper appends to
// (runner/convex-plugin.ts). One line for the run's log and provenance, so
// we can see whether it pays off. Untrusted input either way: only counts
// and short names come out.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

export type PluginUsage = {
  skills: Record<string, number>;
  agents: Record<string, number>;
  hooks: Record<string, number>;
};

/** In the chef dir: one line per plugin hook run (runner/convex-plugin.ts's wrapper). */
export const PLUGIN_USAGE_LOG = "plugin-usage.log";

const NAME = /^[A-Za-z0-9:_.-]{1,64}$/;
const MAX_NAMES = 30;

export function emptyUsage(): PluginUsage {
  return { skills: {}, agents: {}, hooks: {} };
}

function bump(m: Record<string, number>, name: unknown) {
  if (typeof name !== "string" || !NAME.test(name)) return;
  if (!(name in m) && Object.keys(m).length >= MAX_NAMES) return;
  m[name] = (m[name] ?? 0) + 1;
}

/**
 * One stream-json line of the agent's: a Skill call counts its skill, a
 * Task (or Agent) call its subagent. Anything else, or anything malformed,
 * counts nothing.
 */
export function countStreamLine(usage: PluginUsage, line: string): void {
  if (!line.includes('"tool_use"')) return;
  let m: any;
  try {
    m = JSON.parse(line);
  } catch {
    return;
  }
  if (m?.type !== "assistant" || !Array.isArray(m.message?.content)) return;
  for (const p of m.message.content) {
    if (p?.type !== "tool_use" || !p.input || typeof p.input !== "object") continue;
    if (p.name === "Skill") bump(usage.skills, p.input.skill ?? p.input.command);
    else if (p.name === "Task" || p.name === "Agent") bump(usage.agents, p.input.subagent_type);
  }
}

/** The hook wrapper's log: one hook name per line. */
export function countHookLog(usage: PluginUsage, text: string): void {
  for (const line of text.split("\n").slice(0, 10_000)) bump(usage.hooks, line.trim());
}

/** Only what came from the Convex plugin: its skills (convex:*) and agents, and its hooks. */
export function convexOnly(u: PluginUsage): PluginUsage {
  const pick = (m: Record<string, number>, keep: (k: string) => boolean) => Object.fromEntries(Object.entries(m).filter(([k]) => keep(k)));
  return {
    skills: pick(u.skills, (k) => k.startsWith("convex:")),
    agents: pick(u.agents, (k) => /^(convex:)?convex-(expert|reviewer)$/.test(k)),
    hooks: pick(u.hooks, (k) => k.startsWith("convex-")),
  };
}

/** "plugin used: skills convex:design×2, agents convex:convex-reviewer×1, hooks convex-lint×5" (or "none"). */
export function pluginUsageLine(u: PluginUsage): string {
  const part = (label: string, m: Record<string, number>) => {
    const e = Object.entries(m).sort(([a], [b]) => a.localeCompare(b));
    return `${label} ${e.length ? e.map(([k, n]) => `${k}×${n}`).join(", ") : "none"}`;
  };
  return `plugin used: ${part("skills", u.skills)}; ${part("agents", u.agents)}; ${part("hooks", u.hooks)}`;
}

/** Totals, for the provenance's short string: "skills 2, agents 1, hooks 6". */
export function pluginUsageTotals(u: PluginUsage): string {
  const sum = (m: Record<string, number>) => Object.values(m).reduce((a, b) => a + b, 0);
  return `skills ${sum(u.skills)}, agents ${sum(u.agents)}, hooks ${sum(u.hooks)}`;
}
