// The environment the Chef runner reads, by name. Shared by the runner
// (runner/main.ts) and the launcher (packages/chef-cloud/src/client/chefLauncher.ts), which
// starts it with `sudo --preserve-env=<these>`: Daytona runs commands as
// `daytona`, and sudo's env_reset would drop the mounted placeholders
// (L2 check 4). Names only; no value ever goes in a command line.

/** Set by the launcher as plain envs; neither is secret. */
export const RUNNER_PLAIN_ENV = ["CHEF_API", "CHEF_RUN_ID"] as const;

/** Daytona secret placeholders mounted on the build sandbox. */
export const RUNNER_SECRET_ENV = ["CHEF_RUN_TOKEN", "CHEF_GIT_AUTH", "CHEF_AI_TOKEN"] as const;

/**
 * Kept through sudo but not set by the launcher: the path to the egress
 * proxy's CA bundle that Daytona puts on the toolbox's processes. Without it
 * the runner's own fetches fail TLS behind an allow list (first live run,
 * 2026-10-08). runner/main.ts passes it on to what the runner runs as the
 * agent user (npm ci, the gates, Claude Code): without it npm can't verify
 * the registry (wishbox build #8).
 */
export const RUNNER_TRUST_ENV = ["NODE_EXTRA_CA_CERTS"] as const;

/** Every variable the runner reads from the environment the launcher gives it. */
export const RUNNER_ENV_NAMES: readonly string[] = [...RUNNER_PLAIN_ENV, ...RUNNER_SECRET_ENV, ...RUNNER_TRUST_ENV];
