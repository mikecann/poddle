// The inference proxy's pure parts (docs/chef-pipeline.md, "Inference: a
// per-run proxy now"): the model allowlist, the price table used only when the
// gateway doesn't report a cost, and an incremental parser that reads usage
// out of an Anthropic SSE stream without changing a byte of it.
//
// L1 (docs/l1-contract-test.md) fixed the numbers: the three models below,
// `max_tokens: 64000` from Claude Code, and `cost` in USD on the final
// `message_delta` usage, which is what the spend ceiling uses.

/** The models a run may call: the main model, the Sonnet default for background calls, Haiku. */
export const AI_MODELS = [
  "anthropic/claude-opus-5.5",
  "anthropic/claude-sonnet-5",
  "anthropic/claude-haiku-4.5",
] as const;

export const DEFAULT_AI_MAX_TOKENS = 64_000;
export const DEFAULT_AI_MAX_REQUESTS = 400;
export const MAX_AI_IN_FLIGHT = 2;

/** USD per million tokens. */
type Price = { input: number; cacheWrite: number; cacheRead: number; output: number };

// Opus 5.5 is fitted to the costs the gateway reported in L1 (every fixture
// matches to the cent fraction). The other two are list prices. A model
// missing from the table is priced as the most expensive one.
export const PRICES: Record<string, Price> = {
  "anthropic/claude-opus-5.5": { input: 4, cacheWrite: 5, cacheRead: 0.2, output: 20 },
  "anthropic/claude-sonnet-5": { input: 2, cacheWrite: 2.5, cacheRead: 0.2, output: 10 },
  "anthropic/claude-haiku-4.5": { input: 1, cacheWrite: 1.25, cacheRead: 0.1, output: 5 },
};
const MOST_EXPENSIVE: Price = PRICES["anthropic/claude-opus-5.5"];

export type Usage = {
  inputTokens?: number;
  outputTokens?: number;
  cacheCreationInputTokens?: number;
  cacheReadInputTokens?: number;
  /** USD, as the gateway reported it. */
  costUsd?: number;
};

export function estimateCostUsd(model: string, u: Usage): number {
  const p = PRICES[model] ?? MOST_EXPENSIVE;
  const n = (x: number | undefined) => (typeof x === "number" && Number.isFinite(x) && x > 0 ? x : 0);
  return (
    (n(u.inputTokens) * p.input +
      n(u.cacheCreationInputTokens) * p.cacheWrite +
      n(u.cacheReadInputTokens) * p.cacheRead +
      n(u.outputTokens) * p.output) /
    1_000_000
  );
}

/**
 * When a 200 response carried no usage at all (the stream broke before the
 * final event), charge as if the whole input was uncached and every allowed
 * output token was used. Errs high, on purpose: this only feeds a ceiling.
 */
export function worstCaseCostUsd(model: string, requestBytes: number, maxTokens: number): number {
  return estimateCostUsd(model, { inputTokens: Math.ceil(requestBytes / 3), outputTokens: maxTokens });
}

function num(x: unknown): number | undefined {
  return typeof x === "number" && Number.isFinite(x) && x >= 0 ? x : undefined;
}

/** Read the usage fields we keep from one Anthropic usage object, merging into `into`. */
export function mergeUsage(into: Usage, raw: unknown): Usage {
  if (!raw || typeof raw !== "object") return into;
  const u = raw as Record<string, unknown>;
  const set = (k: keyof Usage, v: number | undefined) => {
    if (v !== undefined) into[k] = v;
  };
  set("inputTokens", num(u.input_tokens));
  set("outputTokens", num(u.output_tokens));
  set("cacheCreationInputTokens", num(u.cache_creation_input_tokens));
  set("cacheReadInputTokens", num(u.cache_read_input_tokens));
  set("costUsd", num(u.cost));
  return into;
}

/**
 * Incremental SSE reader. Feed it the decoded text of each chunk as it
 * passes through; it never alters the stream, only watches it. Events are
 * separated by a blank line; only `data:` lines matter.
 */
export class SseUsageParser {
  usage: Usage = {};
  sawMessageStop = false;
  errorType: string | null = null;
  private buf = "";

  push(text: string) {
    this.buf += text.replace(/\r\n/g, "\n");
    let i: number;
    while ((i = this.buf.indexOf("\n\n")) !== -1) {
      const block = this.buf.slice(0, i);
      this.buf = this.buf.slice(i + 2);
      this.event(block);
    }
    // A pathological stream with no event boundary shouldn't grow this forever.
    if (this.buf.length > 4 * 1024 * 1024) this.buf = "";
  }

  end() {
    if (this.buf.trim()) this.event(this.buf);
    this.buf = "";
  }

  private event(block: string) {
    const data = block
      .split("\n")
      .filter((l) => l.startsWith("data:"))
      .map((l) => l.slice(5).replace(/^ /, ""))
      .join("\n");
    if (!data || data === "[DONE]") return;
    let j: any;
    try {
      j = JSON.parse(data);
    } catch {
      return;
    }
    switch (j?.type) {
      case "message_start":
        mergeUsage(this.usage, j.message?.usage);
        break;
      case "message_delta":
        mergeUsage(this.usage, j.usage);
        break;
      case "message_stop":
        this.sawMessageStop = true;
        break;
      case "error":
        this.errorType = typeof j.error?.type === "string" ? j.error.type.slice(0, 100) : "error";
        break;
    }
  }
}

/** Usage from a non-streaming JSON response (a Message, or an error). */
export function usageFromJson(text: string): Usage {
  try {
    const j = JSON.parse(text);
    return mergeUsage({}, j?.usage);
  } catch {
    return {};
  }
}

const ERROR_TYPES: Record<number, string> = {
  400: "invalid_request_error",
  401: "authentication_error",
  403: "permission_error",
  404: "not_found_error",
  413: "request_too_large",
  429: "rate_limit_error",
  529: "overloaded_error",
};

/** An error in the shape the Anthropic API (and so Claude Code) expects. */
export function anthropicError(status: number, message: string, retryAfterSec?: number): Response {
  const headers: Record<string, string> = {
    "content-type": "application/json",
    "cache-control": "no-store",
  };
  if (retryAfterSec !== undefined) headers["retry-after"] = String(retryAfterSec);
  return new Response(
    JSON.stringify({
      type: "error",
      error: { type: ERROR_TYPES[status] ?? "api_error", message },
    }),
    { status, headers },
  );
}
