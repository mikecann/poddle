// "What's new" lines (items.changelog, whatsNew in the panel and ChefKit):
// what the app's users read once a request ships. Pure; no Convex imports.
//
// A line is for users: one plain sentence about what changed for them. It
// never carries a commit hash, a run or snapshot id, a file path or an
// internal note ("Built by Chef run …", "merged by hand"). When a request is
// completed without one, it is derived from its build's summary: the
// request's own line under "## Each request" (#N: …), else the first bullet
// under "## What changed".

import { parseEachRequest, parseSummaryCard } from "./card.js";

export const MAX_CHANGELOG = 280;
const SENTENCE_MAX = 200;

// A hash or id: 7+ hex characters with a digit in them, or a Convex-style
// id (20+ lowercase letters and digits with a digit in them).
const HEXISH = /\b(?=[0-9a-f]*\d)[0-9a-f]{7,64}\b/gi;
const HEX_ONE = new RegExp(HEXISH.source, "i");
const IDISH = /\b(?=[a-z0-9]*\d)(?=[a-z0-9]*[a-z])[a-z0-9]{20,40}\b/g;
// Lines that are notes for the operator, not for users.
const INTERNAL_LINE =
  /^\s*(?:built by chef|chef (?:run|build)\b|(?:cloud )?build #?\d+\b|run [a-z0-9]{6,}|snapshot\b|commit\b|merged by hand|shipped (?:to|in|with)\b|release #\d+|sha\b)/i;
const INTERNAL_WORDS = /\b(?:by hand|chef run|snapshot|commit(?:ted)?|cherry-pick|rebase|worktree|sha)\b/i;
// A path or a file name: a/b/c, ./x, x.ts.
const PATHISH = /(?:^|\s)\(?(?:\.{0,2}\/)?[\w@.-]+(?:\/[\w@.-]+)+\)?|(?:^|\s)[\w@-]+\.(?:tsx?|jsx?|mjs|cjs|json|css|scss|md|html|swift|py|sh|ya?ml|lock)\b/g;

/** Collapse whitespace and trim. */
const squash = (s: string) => s.replace(/\s+/g, " ").trim();

/** A changelog line with every hash, id and internal note taken out; undefined when nothing for users is left. */
export function userChangelog(text: string | null | undefined): string | undefined {
  if (!text) return undefined;
  const lines = text
    .replace(/\r\n?/g, "\n")
    .split("\n")
    .filter((l) => !INTERNAL_LINE.test(l));
  // And sentences that are notes ("Dark mode. Built by Chef run md70wbj2.").
  let t = squash(
    squash(lines.join(" "))
      .split(/(?<=[.!?])\s+/)
      .filter((x) => !INTERNAL_LINE.test(x))
      .join(" "),
  );
  // Parentheticals that are notes ("(merged by hand, see a594c962)").
  t = t.replace(/\(([^()]*)\)/g, (m, inner: string) => (INTERNAL_WORDS.test(inner) || HEX_ONE.test(inner) ? "" : m));
  t = t.replace(HEXISH, "").replace(IDISH, "");
  // What stripping left dangling: "in .", "( )", " ,".
  t = squash(t.replace(/\(\s*\)/g, "").replace(/\b(?:in|at|from|as|of)\s*([.,;:]|$)/gi, "$1").replace(/\s+([.,;:])/g, "$1"));
  t = t.replace(/[,;:]+\s*([.!?]|$)/g, "$1");
  t = t.replace(/^[\s.,;:-]+/, "");
  if (t.length < 4 || INTERNAL_WORDS.test(t) || /^shipped\b/i.test(t)) return undefined;
  return t.slice(0, MAX_CHANGELOG);
}

/** One plain sentence for users: markdown, code and file paths out, a capital, a full stop. */
export function plainSentence(text: string): string | undefined {
  let t = text.replace(/`[^`]*`/g, (m) => (/[/.]/.test(m) ? "" : m.slice(1, -1)));
  t = t.replace(PATHISH, " ");
  t = squash(t.replace(/\(\s*\)/g, "").replace(/\s+([.,;:])/g, "$1"));
  // The first sentence only.
  const end = /[.!?](\s|$)/.exec(t);
  if (end) t = t.slice(0, end.index + 1);
  t = t.replace(/[\s,;:-]+$/, "");
  if (t.length < 4) return undefined;
  t = t[0].toUpperCase() + t.slice(1);
  if (!/[.!?]$/.test(t)) t += ".";
  return userChangelog(t.length > SENTENCE_MAX ? `${t.slice(0, SENTENCE_MAX - 1).replace(/\s+\S*$/, "")}…` : t);
}

/**
 * A request's changelog line from its build's summary (summary.md, as the
 * runner stored it, scrubbed): its own line under "## Each request" (a
 * batch), else the first "## What changed" bullet. Undefined when there is
 * neither.
 */
export function changelogFromSummary(summary: string | null | undefined, itemNumber: number | null | undefined): string | undefined {
  if (!summary) return undefined;
  const own = typeof itemNumber === "number" ? parseEachRequest(summary, [itemNumber]).get(itemNumber) : undefined;
  const line = own ?? parseSummaryCard(summary).whatChanged[0];
  return line ? plainSentence(line) : undefined;
}
