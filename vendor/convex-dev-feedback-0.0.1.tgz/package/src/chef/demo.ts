// The demo video (docs/chef-pipeline.md, "The demo video"): the agent
// writes a demo script, a list of steps as data in a fixed file
// (`<chefDir>/demo-script.json`), and after the preview deploy a demo
// sandbox plays it against the preview with the image's Playwright,
// recording the screen (runner/demo-record.ts). This module is the part
// both sides share: the script's format, its checks and bounds, and the
// executor that turns steps into calls on a page, so the executor can be
// tested with a fake page.
//
// Steps are data, never code: a fixed set of actions whose arguments are
// plain strings (a path on the preview, an ARIA role and name, visible
// text, a label, a key) and numbers, each checked here. Nothing the agent
// writes is evaluated.
//
// Only erasable TypeScript here, so Node can run it with type stripping. No
// imports: chef-screenshot runs this file under plain Node in tests, and Node
// doesn't map an import's `.js` to `.ts`.

/** In the chef dir, written by the agent. */
export const DEMO_SCRIPT_FILE = "demo-script.json";

export const DEMO_LIMITS = {
  /** Bytes of the script file the runner reads. */
  fileBytes: 16 * 1024,
  /** Steps in a script. */
  steps: 25,
  /** Characters of a string argument. */
  text: 200,
  /** One wait. */
  waitMs: 10_000,
  /** Every wait together. */
  totalWaitMs: 30_000,
  /** One recording, whatever the steps do. */
  recordingMs: 45_000,
  /** One step's own timeout (a click that finds nothing). */
  stepTimeoutMs: 8_000,
  /** A video's bytes. */
  videoBytes: 8 * 1024 * 1024,
};

/** ARIA roles a step may name (Playwright getByRole). */
export const DEMO_ROLES = [
  "button",
  "link",
  "textbox",
  "checkbox",
  "radio",
  "switch",
  "tab",
  "menuitem",
  "option",
  "combobox",
  "heading",
  "listitem",
  "img",
  "dialog",
] as const;

/** Keys a `press` step may send. */
export const DEMO_KEYS = ["Enter", "Escape", "Tab", "Backspace", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"] as const;

export type DemoStep =
  | { do: "goto"; path: string }
  | { do: "click"; role?: (typeof DEMO_ROLES)[number]; name?: string; text?: string }
  | { do: "fill"; label?: string; placeholder?: string; value: string }
  | { do: "press"; key: (typeof DEMO_KEYS)[number] }
  | { do: "waitFor"; text: string }
  | { do: "wait"; ms: number }
  | { do: "scroll"; y: number };

export type DemoScript = { steps: DemoStep[] };

const PATH = /^\/(?!\/)[\x21-\x7e]*$/;
// No control characters (C0 and DEL).
// eslint-disable-next-line no-control-regex
const PRINTABLE = /^[^\x00-\x1f\x7f]*$/;

function str(x: unknown): x is string {
  return typeof x === "string" && x.length > 0 && x.length <= DEMO_LIMITS.text && PRINTABLE.test(x);
}

/**
 * The script from the agent's demo-script.json: `{"steps": [...]}` or a
 * bare list. Bad steps are dropped and named in `problems`; at most 25; the
 * waits together at most 30 seconds. An empty, missing or unusable script
 * is null: no video.
 */
export function parseDemoScript(text: string): { script: DemoScript | null; problems: string[] } {
  const problems: string[] = [];
  if (text.trim() === "") return { script: null, problems };
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    return { script: null, problems: ["the demo script is not JSON"] };
  }
  const list = Array.isArray(raw) ? raw : raw && typeof raw === "object" ? (raw as { steps?: unknown }).steps : undefined;
  if (!Array.isArray(list)) return { script: null, problems: ["the demo script needs a list of steps"] };
  const steps: DemoStep[] = [];
  let waited = 0;
  list.forEach((x, i) => {
    const bad = (why: string) => problems.push(`step ${i}: ${why}`);
    if (steps.length >= DEMO_LIMITS.steps) return bad(`past the limit of ${DEMO_LIMITS.steps} steps`);
    if (!x || typeof x !== "object" || Array.isArray(x)) return bad("not an object");
    const o = x as Record<string, unknown>;
    switch (o.do) {
      case "goto":
        if (typeof o.path !== "string" || o.path.length > 300 || !PATH.test(o.path) || o.path.includes("\\")) {
          return bad("goto needs a path on the app, starting with /");
        }
        return steps.push({ do: "goto", path: o.path });
      case "click": {
        if (o.role !== undefined) {
          if (!(DEMO_ROLES as readonly string[]).includes(o.role as string)) return bad(`role must be one of ${DEMO_ROLES.join(", ")}`);
          if (o.name !== undefined && !str(o.name)) return bad("name must be short visible text");
          return steps.push({ do: "click", role: o.role as (typeof DEMO_ROLES)[number], ...(o.name !== undefined ? { name: o.name as string } : {}) });
        }
        if (!str(o.text)) return bad("click needs a role (and name) or the visible text");
        return steps.push({ do: "click", text: o.text });
      }
      case "fill": {
        if (typeof o.value !== "string" || o.value.length > 500 || !PRINTABLE.test(o.value)) return bad("fill needs a short value");
        if (str(o.label)) return steps.push({ do: "fill", label: o.label, value: o.value });
        if (str(o.placeholder)) return steps.push({ do: "fill", placeholder: o.placeholder, value: o.value });
        return bad("fill needs the field's label or placeholder");
      }
      case "press":
        if (!(DEMO_KEYS as readonly string[]).includes(o.key as string)) return bad(`key must be one of ${DEMO_KEYS.join(", ")}`);
        return steps.push({ do: "press", key: o.key as (typeof DEMO_KEYS)[number] });
      case "waitFor":
        if (!str(o.text)) return bad("waitFor needs the visible text to wait for");
        return steps.push({ do: "waitFor", text: o.text });
      case "wait": {
        const ms = Number(o.ms);
        if (!Number.isInteger(ms) || ms < 0 || ms > DEMO_LIMITS.waitMs) return bad(`wait ms must be 0 to ${DEMO_LIMITS.waitMs}`);
        if (waited + ms > DEMO_LIMITS.totalWaitMs) return bad(`the waits together must stay under ${DEMO_LIMITS.totalWaitMs} ms`);
        waited += ms;
        return steps.push({ do: "wait", ms });
      }
      case "scroll": {
        const y = Number(o.y);
        if (!Number.isInteger(y) || Math.abs(y) > 10_000) return bad("scroll y must be a whole number of pixels");
        return steps.push({ do: "scroll", y });
      }
      default:
        return bad(`unknown action ${JSON.stringify(String(o.do)).slice(0, 40)}`);
    }
  });
  return { script: steps.length ? { steps } : null, problems };
}

/** What the executor needs from a browser page: Playwright's, or a test's fake. */
export interface DemoPage {
  /** Open a URL on the preview (the executor builds it from a checked path). */
  goto(url: string): Promise<void>;
  clickRole(role: string, name: string | undefined, timeoutMs: number): Promise<void>;
  clickText(text: string, timeoutMs: number): Promise<void>;
  fill(by: { label: string } | { placeholder: string }, value: string, timeoutMs: number): Promise<void>;
  press(key: string): Promise<void>;
  waitForText(text: string, timeoutMs: number): Promise<void>;
  wait(ms: number): Promise<void>;
  scroll(y: number): Promise<void>;
}

export type DemoRunResult = {
  /** Steps that ran to the end. */
  done: number;
  /** The step that failed (0-based) and why; absent when every step ran. */
  failed?: { step: number; what: string; reason: string };
  /** The recording's time cap cut it short. */
  timedOut?: boolean;
};

/**
 * Checks a list of steps on its own (a screenshot plan page's `steps`,
 * chef-screenshot's `--steps`) with the demo script's rules: every step must
 * be valid, unlike a whole script, where bad steps are dropped.
 */
export function checkDemoSteps(raw: unknown[]): { steps: DemoStep[] } | { problem: string } {
  const { script, problems } = parseDemoScript(JSON.stringify({ steps: raw }));
  if (!script) return { problem: problems[0] ?? "no steps" };
  if (script.steps.length !== raw.length) return { problem: problems[0] ?? "a step isn't valid" };
  return { steps: script.steps };
}

/** What the page said while a script ran, collected by the browser side (runner/demo-page.ts). */
export type DemoDiagnostics = { consoleErrors: string[]; pageErrors: string[]; failedRequests: string[] };

/** A URL as safe log text: host and path, no query or fragment (they can hold tokens). */
export function urlForLog(u: string): string {
  try {
    const x = new URL(u);
    return `${x.host}${x.pathname}`.slice(0, 120);
  } catch {
    return "a request";
  }
}

/**
 * One short line for a failed step's reason: why the page might not have
 * rendered (build #28 to #32's demos all stopped at their first click on a
 * blank page, with nothing to say why). Empty when the page said nothing.
 */
export function summarizeDiagnostics(d: DemoDiagnostics, clean: (s: string) => string = (s) => s): string {
  const one = (s: string) => s.replace(/\s+/g, " ").trim().slice(0, 160);
  const parts: string[] = [];
  if (d.pageErrors.length) parts.push(`page error: ${one(d.pageErrors[0])}${d.pageErrors.length > 1 ? ` (+${d.pageErrors.length - 1})` : ""}`);
  if (d.failedRequests.length) {
    parts.push(`failed requests: ${[...new Set(d.failedRequests)].slice(0, 3).map(one).join(", ")}${d.failedRequests.length > 3 ? ` (+${d.failedRequests.length - 3})` : ""}`);
  }
  if (d.consoleErrors.length) parts.push(`console: ${one(d.consoleErrors[0])}${d.consoleErrors.length > 1 ? ` (+${d.consoleErrors.length - 1})` : ""}`);
  // Page text can carry anything: the caller's `clean` (scrub) takes secrets
  // out before it is stored on the run or logged.
  return clean(parts.join("; ")).slice(0, 600);
}

/** One line describing a step, for the card ("click the button 'Save'"). */
export function describeStep(s: DemoStep): string {
  switch (s.do) {
    case "goto":
      return `open ${s.path}`;
    case "click":
      return s.role ? `click the ${s.role}${s.name ? ` "${s.name}"` : ""}` : `click "${s.text}"`;
    case "fill":
      return `type into "${s.label ?? s.placeholder}"`;
    case "press":
      return `press ${s.key}`;
    case "waitFor":
      return `wait for "${s.text}"`;
    case "wait":
      return `wait ${s.ms} ms`;
    case "scroll":
      return `scroll ${s.y} px`;
  }
}

/**
 * Plays a checked script on a page, step by step, against `origin` (the
 * preview's https site: a goto is always origin + a checked path). Stops at
 * the first failing step, and at the time cap, and says which; never
 * throws. `now` and the cap are injectable for tests.
 */
export async function runDemoScript(
  page: DemoPage,
  script: DemoScript,
  o: {
    origin: string;
    capMs?: number;
    now?: () => number;
    stepTimeoutMs?: number;
    /** Also allow http://127.0.0.1:<port>: the build sandbox's own app (screenshots, rehearsals). */
    loopback?: boolean;
  },
): Promise<DemoRunResult> {
  const origin = new URL(o.origin);
  const loopback = o.loopback === true && origin.protocol === "http:" && origin.hostname === "127.0.0.1" && origin.port !== "";
  if ((origin.protocol !== "https:" && !loopback) || origin.pathname !== "/" || origin.username || origin.password) {
    return { done: 0, failed: { step: 0, what: "start", reason: "the preview's origin must be a plain https origin" } };
  }
  const now = o.now ?? Date.now;
  const until = now() + (o.capMs ?? DEMO_LIMITS.recordingMs);
  const t = o.stepTimeoutMs ?? DEMO_LIMITS.stepTimeoutMs;
  let done = 0;
  for (let i = 0; i < script.steps.length; i++) {
    if (now() >= until) return { done, timedOut: true };
    const s = script.steps[i];
    try {
      switch (s.do) {
        case "goto": {
          const url = new URL(s.path, origin);
          if (url.origin !== origin.origin) throw new Error("not on the preview");
          await page.goto(url.href);
          break;
        }
        case "click":
          if (s.role) await page.clickRole(s.role, s.name, t);
          else await page.clickText(s.text!, t);
          break;
        case "fill":
          await page.fill(s.label !== undefined ? { label: s.label } : { placeholder: s.placeholder! }, s.value, t);
          break;
        case "press":
          await page.press(s.key);
          break;
        case "waitFor":
          await page.waitForText(s.text, t);
          break;
        case "wait":
          await page.wait(Math.min(s.ms, Math.max(0, until - now())));
          break;
        case "scroll":
          await page.scroll(s.y);
          break;
      }
      done++;
    } catch (e) {
      const reason = String((e as Error)?.message ?? e).split("\n")[0].slice(0, 300);
      return { done, failed: { step: i, what: describeStep(s), reason } };
    }
  }
  return { done };
}
