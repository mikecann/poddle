// The release state machine's shared rules (docs/chef-pipeline.md, "Release:
// one state machine around one sha"). The component (chefReleases.ts) and the
// `chef-release` CLI (release/) both import this module, so the state order,
// the diff chunking and the diff hash have one definition. No Convex imports:
// the CLI loads it in Node.

import { sha256Hex } from "./snapshotHash.js";
import { LOCKFILES } from "./guards.js";

export const RELEASE_STATES = [
  "pinned",
  "diffReady",
  "approved",
  "merged",
  "sourcePushed",
  "gatesPassed",
  "backendDeployed",
  "frontendPublished",
  "verified",
  "live",
  "done",
] as const;

export type ReleaseState = (typeof RELEASE_STATES)[number];
/** Where a release can end other than `done`. */
export type ReleaseEnd = "abandoned" | "rolledBack";
/**
 * `chef`: the laptop CLI merges `chef` into `main`, builds and deploys.
 * `cloud`: "Ship it" in the panel; the host deploys `chef`'s own commit (it
 * already has `main` merged in) with the frontend the build sandbox built,
 * then fast-forwards `main` to it (packages/chef-cloud/src/client/chefShip.ts).
 * `rollback`: an earlier release's mergeSha and artifact, redeployed.
 */
export type ReleaseKind = "chef" | "cloud" | "rollback";

/**
 * The states each kind of release goes through, in order. A rollback
 * redeploys an earlier release's mergeSha and artifact, which were reviewed,
 * merged, pushed and built when that release shipped, so it starts at the
 * backend deploy.
 */
export const RELEASE_SEQUENCE: Record<ReleaseKind, readonly ReleaseState[]> = {
  chef: RELEASE_STATES,
  // Nothing to merge, push or build: the commit is chef's tip, already on
  // Code Storage and descended from main, and the build sandbox already ran
  // the gates and built the frontend.
  cloud: ["pinned", "diffReady", "approved", "backendDeployed", "frontendPublished", "verified", "live", "done"],
  rollback: ["pinned", "backendDeployed", "frontendPublished", "verified", "live", "done"],
};

/** The state after `state` for this kind, or null at the end. */
export function nextReleaseState(kind: ReleaseKind, state: ReleaseState): ReleaseState | null {
  const seq = RELEASE_SEQUENCE[kind];
  const i = seq.indexOf(state);
  if (i < 0 || i === seq.length - 1) return null;
  return seq[i + 1];
}

/** Whether `state` is at or past `than` in this kind's sequence. */
export function releaseReached(kind: ReleaseKind, state: ReleaseState, than: ReleaseState): boolean {
  const seq = RELEASE_SEQUENCE[kind];
  return seq.indexOf(state) >= seq.indexOf(than);
}

/** The two frontend targets; the same artifact goes to both. */
export const FRONTEND_TARGETS = ["convexApp", "staticHosting"] as const;
export type FrontendTarget = (typeof FRONTEND_TARGETS)[number];

/**
 * The frontend targets a release must publish before `frontendPublished`. A
 * cloud ship publishes to the host's static hosting only, and nothing when
 * the app has no frontend (no artifact digest).
 */
export function frontendTargetsFor(kind: ReleaseKind, artifactDigest: string | undefined, cloud = false): readonly FrontendTarget[] {
  // A cloud ship, or a rollback the cloud drives (Chef's automatic one, with a
  // build's kept frontend), publishes to the host's static hosting only.
  if (kind === "cloud" || (kind === "rollback" && cloud)) return artifactDigest ? ["staticHosting"] : [];
  return FRONTEND_TARGETS;
}

export const releaseBranch = (seq: number) => `release/${seq}`;

// ------------------------------------------------------------------ diff

/**
 * Git config and diff options that don't depend on anyone's git config, so
 * the CLI and the build runner produce the same release diff for the same
 * two commits.
 */
export const RELEASE_GIT_CONFIG = [
  "-c", "core.hooksPath=/dev/null",
  "-c", "core.quotePath=true",
  "-c", "diff.noprefix=false",
  "-c", "diff.mnemonicPrefix=false",
  "-c", "diff.relative=false",
] as const;

export const RELEASE_DIFF_ARGS = [
  "diff",
  "--no-color",
  "--no-ext-diff",
  "--no-textconv",
  "--no-renames",
  "--full-index",
  "--diff-algorithm=myers",
  "--indent-heuristic",
  "--src-prefix=a/",
  "--dst-prefix=b/",
] as const;

/** The most diff a release can carry: DIFF_MAX_CHUNKS chunks of DIFF_CHUNK_BYTES. */
export const RELEASE_DIFF_MAX_BYTES = 32 * 128 * 1024;

/**
 * The CLI uploads the release diff through `npx convex run`, whose arguments
 * travel on a command line, so it goes in chunks. 128 KiB of UTF-8 per chunk
 * stays far under the argv limit even after JSON escaping, and 32 chunks
 * (4 MiB) is more than any reviewable release.
 */
export const DIFF_CHUNK_BYTES = 128 * 1024;
export const DIFF_MAX_CHUNKS = 32;

const encoder = new TextEncoder();

/**
 * Split a diff into chunks of at most DIFF_CHUNK_BYTES, at line ends where
 * possible (so a file header or a secret on one line is never cut in two),
 * and inside a line only when the line alone is longer than a chunk.
 * Deterministic: the CLI and any later check chunk the same text the same way.
 */
export function chunkDiff(text: string, maxBytes = DIFF_CHUNK_BYTES): string[] {
  const chunks: string[] = [];
  let cur = "";
  let curBytes = 0;
  const flush = () => {
    if (cur) chunks.push(cur);
    cur = "";
    curBytes = 0;
  };
  for (const line of text.split(/(?<=\n)/)) {
    const bytes = encoder.encode(line).length;
    if (bytes > maxBytes) {
      flush();
      // Cut the long line by code points so no character is split.
      let piece = "";
      let pieceBytes = 0;
      for (const ch of line) {
        const b = encoder.encode(ch).length;
        if (pieceBytes + b > maxBytes) {
          chunks.push(piece);
          piece = "";
          pieceBytes = 0;
        }
        piece += ch;
        pieceBytes += b;
      }
      if (piece) {
        cur = piece;
        curBytes = pieceBytes;
      }
      continue;
    }
    if (curBytes + bytes > maxBytes) flush();
    cur += line;
    curBytes += bytes;
  }
  flush();
  return chunks;
}

/**
 * The release diff's hash: sha256 over the version tag and each chunk's
 * sha256, in order. The server checks every chunk against its hash as it
 * arrives and the whole list against this, so the approval binds every byte
 * the CLI computed, though no single request carries the whole diff.
 */
export async function diffHashFromChunkHashes(chunkHashes: readonly string[]): Promise<string> {
  return await sha256Hex(`chef-release-diff/v1\n${chunkHashes.length}\n${chunkHashes.join("\n")}\n`);
}

export async function releaseDiffHash(text: string): Promise<{ diffHash: string; chunks: string[]; chunkHashes: string[] }> {
  const chunks = chunkDiff(text);
  const chunkHashes: string[] = [];
  for (const c of chunks) chunkHashes.push(await sha256Hex(c));
  return { diffHash: await diffHashFromChunkHashes(chunkHashes), chunks, chunkHashes };
}

/**
 * Paths named by `diff --git a/<x> b/<x>` headers. The CLI diffs with
 * `--no-renames`, so both sides name the same path, which is how a path with
 * spaces is split; git quotes paths with unusual characters.
 */
export function filesInDiff(text: string): string[] {
  const out: string[] = [];
  for (const m of text.matchAll(/^diff --git (.*)$/gm)) {
    const rest = m[1];
    const quoted = rest.match(/^"a\/((?:[^"\\]|\\.)*)" "b\/((?:[^"\\]|\\.)*)"$/);
    if (quoted) {
      out.push(quoted[2]);
      continue;
    }
    const n = (rest.length - 5) / 2;
    if (Number.isInteger(n) && n > 0 && rest.startsWith("a/")) {
      const path = rest.slice(2, 2 + n);
      if (rest.slice(2 + n) === ` b/${path}`) out.push(path);
    }
  }
  return out;
}

/** package.json or a lockfile, anywhere in the tree. Approval needs a second checkbox. */
export function isDependencyFile(path: string): boolean {
  const base = path.slice(path.lastIndexOf("/") + 1).toLowerCase();
  return base === "package.json" || LOCKFILES.has(base);
}

export const GIT_SHA = /^(?:[0-9a-f]{40}|[0-9a-f]{64})$/;
export const SHA256_HEX = /^[0-9a-f]{64}$/;
