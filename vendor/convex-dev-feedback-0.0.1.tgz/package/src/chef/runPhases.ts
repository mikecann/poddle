/**
 * A cloud run's phases in order, with what the panel calls them, and where a
 * run is in that list. Pure, shared by exposeChefApi's `runStatus` and the
 * React build view.
 */
export const RUN_PHASES = [
  ["launched", "Sandbox"],
  ["ready", "Egress checked"],
  ["cloning", "Cloning"],
  ["cloned", "Installed"],
  ["agent", "Building"],
  ["gates", "Checks"],
  ["guards", "Guards"],
  ["committed", "Committed"],
  ["pushing", "Pushing"],
  ["pushed", "Pushed"],
  ["previewing", "Deploying preview"],
  ["done", "Ready"],
] as const;

export type RunPhase = (typeof RUN_PHASES)[number][0];
export type RunStatus = "active" | "reconciling" | "built" | "failed" | "cancelled";

/** done: passed; now: the active run is here; stopped: the run ended here; todo: not reached. */
export type PhaseState = "done" | "now" | "stopped" | "todo";

export type PhaseStep = { phase: RunPhase; label: string; state: PhaseState };

/** Every phase, marked against the run's status and current phase. */
export function phaseSteps(status: RunStatus, phase: string): PhaseStep[] {
  const at = RUN_PHASES.findIndex(([p]) => p === phase);
  const finished = status !== "active" && status !== "reconciling";
  return RUN_PHASES.map(([p, label], i) => ({
    phase: p,
    label,
    state:
      status === "built" || i < at ? "done" : i === at ? (finished ? "stopped" : "now") : "todo",
  }));
}

/**
 * One line for the run's state: the phase while it runs, else how it ended.
 * `fix` is the fix round the agent is in (src/chef/gates.ts): the agent
 * phase after the checks reads "Fixing checks (round 1 of 2)", and the
 * checks after it "Checks (after fix round 1)".
 */
export function runStatusText(
  status: RunStatus,
  phase: string,
  fix?: { round?: number | null; rounds?: number | null },
): string {
  if (status === "built") return "Ready";
  if (status === "reconciling") return "Stopping and cleaning up";
  if (status === "failed") return "Failed";
  if (status === "cancelled") return "Cancelled";
  const round = fix?.round ?? 0;
  if (round > 0 && phase === "agent") return `Fixing (round ${round}${fix?.rounds ? ` of ${fix.rounds}` : ""})`;
  if (round > 0 && (phase === "gates" || phase === "guards")) return `Checking (after fix round ${round})`;
  if (phase === "gates") return "Checking";
  return RUN_PHASES.find(([p]) => p === phase)?.[1] ?? phase;
}
