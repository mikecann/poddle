// What one line of the agent's transcript (agent.jsonl, Claude Code's
// stream-json) was, for a secret scan finding: "in a Write to
// components/x.test.ts", "in a Bash result". Never any of the line's text
// beyond a tool name and a checked file path: the line holds the finding.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

/** A path worth naming: plain characters, not too long. Anything else is "a file". */
const PLAIN_PATH = /^[A-Za-z0-9_./@-]{1,200}$/;
const TOOL = /^[A-Za-z][A-Za-z0-9_:.-]{0,60}$/;

type Block = { type?: unknown; name?: unknown; id?: unknown; tool_use_id?: unknown; input?: unknown };

function blocks(event: unknown): Block[] {
  const content = (event as { message?: { content?: unknown } } | null)?.message?.content;
  return Array.isArray(content) ? (content as Block[]) : [];
}

function toolName(b: Block): string {
  return typeof b.name === "string" && TOOL.test(b.name) ? b.name : "a tool";
}

function pathOf(b: Block, repoDir: string): string | null {
  const p = (b.input as { file_path?: unknown } | null)?.file_path;
  if (typeof p !== "string") return null;
  const rel = p.startsWith(`${repoDir}/`) ? p.slice(repoDir.length + 1) : p;
  return PLAIN_PATH.test(rel) && !rel.split("/").includes("..") ? rel : "a file";
}

/**
 * Describes `lines[index]`. Tool results are named after the tool call they
 * answer, found by id in the lines before. Lines that aren't JSON events
 * (a token split across lines) are "part of a longer line".
 */
export function describeTranscriptLine(lines: string[], index: number, repoDir = ""): string {
  let event: { type?: unknown; subtype?: unknown } | null;
  try {
    event = JSON.parse(lines[index] ?? "");
  } catch {
    return "part of a longer line";
  }
  if (!event || typeof event !== "object") return "an event";
  if (event.type === "assistant") {
    const use = blocks(event).find((b) => b.type === "tool_use");
    if (use) {
      const path = pathOf(use, repoDir);
      return `in a ${toolName(use)} call${path ? ` on ${path}` : ""}`;
    }
    return blocks(event).some((b) => b.type === "thinking") ? "in the agent's thinking" : "in the agent's text";
  }
  if (event.type === "user") {
    const result = blocks(event).find((b) => b.type === "tool_result");
    if (result && typeof result.tool_use_id === "string") {
      for (let i = index - 1; i >= 0 && i >= index - 400; i--) {
        let prior: unknown;
        try {
          prior = JSON.parse(lines[i]);
        } catch {
          continue;
        }
        const use = blocks(prior).find((b) => b.type === "tool_use" && b.id === result.tool_use_id);
        if (use) {
          const path = pathOf(use, repoDir);
          return `in a ${toolName(use)} result${path ? ` from ${path}` : ""}`;
        }
      }
      return "in a tool result";
    }
    return "in a message to the agent";
  }
  if (event.type === "system") return "in a system event";
  if (event.type === "result") return "in the session's result";
  return "in an event";
}
