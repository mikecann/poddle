// Redacting secrets from text before it is stored or shown: runner log
// lines, agent.jsonl, error messages, the agent's summary, diffs.
//
// Patterns start from dangerously-ship's log redaction (provider keys,
// GitHub tokens, `prod:...|...` deploy keys, `NAME=value` env assignments)
// and add what Chef handles: JWTs (service tokens, Code Storage tokens),
// Chef keys and run credentials, Daytona secret placeholders, preview and
// admin keys, Bearer and Basic headers, PEM blocks and URL userinfo.
// Scrubbing errs toward redacting too much.

import { invisibleCharsRegex, revealInvisible } from "./text.js";

/**
 * Prefixes of Chef credentials. Chef agent keys are `chefk_<base32>`, run
 * credentials `chefr_<base32>`; `ship_<48 hex>` is the existing `/agent/*`
 * key format (agentKeys.ts). Steps 4 and 7 mint keys in these formats.
 */
export const CHEF_KEY_PREFIX = "chefk_";
export const CHEF_RUN_CREDENTIAL_PREFIX = "chefr_";

export type SecretKind =
  | "pem"
  | "deployKey"
  | "convexAdminKey"
  | "jwt"
  | "daytonaPlaceholder"
  | "daytonaApiKey"
  | "chefCredential"
  | "providerKey"
  | "bearer"
  | "basicAuth"
  | "urlCredentials"
  | "envAssignment"
  | "knownValue";

type Pattern = {
  kind: SecretKind;
  re: RegExp;
  replace: string | ((match: string, ...groups: string[]) => string);
  /** Strong enough to fail a build when found in a diff. */
  highConfidence: boolean;
};

const R = (kind: SecretKind) => `[REDACTED ${kind}]`;

// A line break inside a wrapped token: a real newline, or an escaped one in
// JSON output, plus indentation or quoting on the next line.
const BRK = String.raw`(?:\r?\n|\\r\\n|\\n)[ \t>]*`;
const B64U = "[A-Za-z0-9_-]";
const seg = (min: string) => `${B64U}${min}(?:${BRK}${B64U}+)*`;
const JWT_SOURCE =
  `eyJ${seg("*")}(?:${BRK})?\\.(?:${BRK})?${seg("+")}(?:${BRK})?\\.(?:${BRK})?(?:${seg("+")})?`;

const PATTERNS: Pattern[] = [
  {
    kind: "pem",
    // Any PEM block; an unterminated one is redacted to the end of the text.
    re: /-----BEGIN ([A-Z0-9 ]+)-----[\s\S]*?(?:-----END \1-----|$(?![\s\S]))/g,
    replace: R("pem"),
    highConfidence: true,
  },
  {
    kind: "deployKey",
    // prod:<deployment>|..., preview:<team>:<project>|..., dev:..., project:...
    re: /\b(?:prod|preview|dev|project):[A-Za-z0-9_.:-]+\|[^\s"'`<>]+/g,
    replace: R("deployKey"),
    highConfidence: true,
  },
  {
    kind: "convexAdminKey",
    // `Convex <admin key>` headers and bare `<deployment>|<key>` admin keys.
    re: /\bConvex\s+[A-Za-z0-9_.:-]+\|[^\s"'`<>]+|\b[a-z]+-[a-z]+-\d+\|[A-Za-z0-9+/=._-]{20,}/g,
    replace: R("convexAdminKey"),
    highConfidence: true,
  },
  {
    kind: "jwt",
    re: new RegExp(JWT_SOURCE, "g"),
    replace: R("jwt"),
    highConfidence: true,
  },
  {
    kind: "daytonaPlaceholder",
    // Matched anywhere, including mid-string (`preview:t:p|dtn_secret_...`).
    re: /dtn_secret_[A-Za-z0-9_-]+/g,
    replace: R("daytonaPlaceholder"),
    highConfidence: true,
  },
  {
    kind: "daytonaApiKey",
    re: /dtn_[0-9a-f]{32,}/g,
    replace: R("daytonaApiKey"),
    highConfidence: true,
  },
  {
    kind: "chefCredential",
    re: /(?:chefk|chefr)_[A-Za-z0-9]{16,}|ship_[0-9a-f]{48}/g,
    replace: R("chefCredential"),
    highConfidence: true,
  },
  {
    kind: "providerKey",
    re: new RegExp(
      [
        "sk-ant-[A-Za-z0-9_-]{10,}",
        "sk-[A-Za-z0-9_-]{20,}",
        "AIza[A-Za-z0-9_-]{35,}",
        "gh[pousr]_[A-Za-z0-9]{36,}",
        "github_pat_[A-Za-z0-9_]{20,}",
        "AKIA[0-9A-Z]{16}",
        "xox[abprs]-[A-Za-z0-9-]{10,}",
        "\\bre_[A-Za-z0-9]{6,}_[A-Za-z0-9]{16,}",
      ].join("|"),
      "g",
    ),
    replace: R("providerKey"),
    highConfidence: true,
  },
  {
    kind: "bearer",
    re: /\b(Bearer)\s+[A-Za-z0-9._~+/=-]{8,}/gi,
    replace: (_m, word: string) => `${word} ${R("bearer")}`,
    highConfidence: false,
  },
  {
    kind: "basicAuth",
    re: /\b(Basic)\s+[A-Za-z0-9+/=]{12,}/gi,
    replace: (_m, word: string) => `${word} ${R("basicAuth")}`,
    highConfidence: false,
  },
  {
    kind: "urlCredentials",
    re: /\b([a-z][a-z0-9+.-]*:\/\/)[^\s/@:"'<>]+(?::[^\s/@"'<>]*)?@/gi,
    replace: (_m, scheme: string) => `${scheme}${R("urlCredentials")}@`,
    highConfidence: false,
  },
  {
    kind: "envAssignment",
    // NAME=value, NAME: value, "NAME": "value" for secret-looking names.
    re: /\b([A-Z0-9_]*(?:TOKEN|SECRET|PASSWORD|PASSWD|API_KEY|DEPLOY_KEY|ADMIN_KEY|PRIVATE_KEY|AUTH)[A-Z0-9_]*)("?[ \t]*[=:][ \t]*)("[^"\n]*"|'[^'\n]*'|[^\s"',}]+)/g,
    replace: (_m, name: string, sep: string, value: string) => {
      if (value.startsWith("[REDACTED")) return `${name}${sep}${value}`;
      const q = value[0] === '"' || value[0] === "'" ? value[0] : "";
      return `${name}${sep}${q}${R("envAssignment")}${q}`;
    },
    highConfidence: false,
  },
];

const TOKEN_CHAR = "[A-Za-z0-9_.|:+\\/=-]";

/**
 * Removes invisible characters wedged inside a token (`eyJ<U+200B>hbG...`),
 * which would otherwise split a secret so no pattern sees it.
 */
function joinSplitTokens(text: string): string {
  const inv = invisibleCharsRegex().source;
  return text.replace(
    new RegExp(`(?<=${TOKEN_CHAR})${inv}+(?=${TOKEN_CHAR})`, "g"),
    "",
  );
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export type ScrubOptions = {
  /** Exact secret values known to the caller (run credentials, etc.). Values under 8 characters are ignored. */
  knownValues?: string[];
  /** Show remaining invisible characters as `<U+XXXX>` markers. Default true. */
  revealInvisible?: boolean;
};

export type ScrubReport = {
  text: string;
  /** How many of each kind were redacted. Never the values. */
  counts: Partial<Record<SecretKind, number>>;
};

/** Redacts secrets and reports what kinds it found. */
export function scrubWithReport(
  input: string,
  opts: ScrubOptions = {},
): ScrubReport {
  const counts: Partial<Record<SecretKind, number>> = {};
  const bump = (k: SecretKind) => (counts[k] = (counts[k] ?? 0) + 1);
  let text = joinSplitTokens(input);

  const known = (opts.knownValues ?? [])
    .filter((v) => v.length >= 8)
    .sort((a, b) => b.length - a.length);
  for (const value of known) {
    text = text.replace(new RegExp(escapeRegExp(value), "g"), () => {
      bump("knownValue");
      return R("knownValue");
    });
  }

  for (const p of PATTERNS) {
    text = text.replace(p.re, (...args: unknown[]) => {
      const match = args[0] as string;
      const groups = args
        .slice(1)
        .filter((g): g is string => typeof g === "string" || g === undefined)
        .map((g) => g ?? "");
      const out =
        typeof p.replace === "string" ? p.replace : p.replace(match, ...groups);
      if (out !== match) bump(p.kind);
      return out;
    });
  }

  if (opts.revealInvisible !== false) text = revealInvisible(text);
  return { text, counts };
}

/** Redacts secrets from `text`. */
export function scrub(text: string, opts: ScrubOptions = {}): string {
  return scrubWithReport(text, opts).text;
}

/**
 * `why`: what the caller's `explain` said (never the value); `where`: what
 * its `describe` said about the line (never the line's text).
 */
export type SecretFinding = { kind: SecretKind; line: number; why?: string; where?: string };

/**
 * The secret scan over a diff or agent.jsonl: high-confidence kinds only,
 * with the 1-based line each starts on. Never returns the value.
 */
export function findSecrets(input: string): SecretFinding[] {
  return scanSecrets(input).findings;
}

export type SecretScan = {
  /** High-confidence secrets not allowed, by kind and line. Never the value. */
  findings: SecretFinding[];
  /** How many matches `allow` let through. */
  allowed: number;
  /** The input with each allowed match redacted (`[REDACTED throwaway <kind>]`). */
  redacted: string;
};

/**
 * findSecrets with an exception: `allow` sees each high-confidence match
 * (kind and value, inside this call only) and may let it through, for
 * values the caller knows are throwaway (src/chef/throwaway.ts). Allowed
 * matches are counted and redacted in `redacted`; the rest are findings.
 * `explain` says why a refused match was refused, and `describe` what the
 * line it is on was (both see the scanned text inside this call only, and
 * must never return a value from it).
 */
export function scanSecrets(
  input: string,
  allow?: (kind: SecretKind, value: string) => boolean,
  opts: { explain?: (kind: SecretKind, value: string) => string; describe?: (lines: string[], index: number) => string } = {},
): SecretScan {
  const text = joinSplitTokens(input);
  const findings: SecretFinding[] = [];
  const allowedRanges: { start: number; end: number; kind: SecretKind }[] = [];
  let lines: string[] | null = null;
  for (const p of PATTERNS) {
    if (!p.highConfidence) continue;
    const re = new RegExp(p.re.source, p.re.flags);
    for (const m of text.matchAll(re)) {
      const start = m.index ?? 0;
      if (allow?.(p.kind, m[0])) {
        allowedRanges.push({ start, end: start + m[0].length, kind: p.kind });
        continue;
      }
      const line = text.slice(0, start).split("\n").length;
      const why = opts.explain?.(p.kind, m[0]);
      let where: string | undefined;
      if (opts.describe) {
        lines ??= text.split("\n");
        where = opts.describe(lines, line - 1);
      }
      findings.push({ kind: p.kind, line, ...(why ? { why } : {}), ...(where ? { where } : {}) });
    }
  }
  let redacted = text;
  // Back to front, so earlier offsets stay valid; overlapping matches once.
  let cut = Infinity;
  for (const r of allowedRanges.sort((a, b) => b.start - a.start)) {
    if (r.end > cut) continue;
    redacted = `${redacted.slice(0, r.start)}[REDACTED throwaway ${r.kind}]${redacted.slice(r.end)}`;
    cut = r.start;
  }
  return { findings: findings.sort((a, b) => a.line - b.line), allowed: allowedRanges.length, redacted };
}
