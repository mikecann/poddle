// The approval snapshot's canonical JSON and content hash. The server
// (chefShared.ts) hashes a snapshot when an admin approves it, and the runner
// recomputes the hash from GET /chef-agent/run before using anything in it.
// Both import this module, so there is one serializer. No Convex imports:
// the runner loads it outside Convex.

const encoder = new TextEncoder();

/**
 * What the hash covers. On the server the ids are Convex `Id`s, which are
 * strings; the runner sees them as plain strings in the /run JSON.
 */
export type SnapshotHashInput = {
  itemId: string;
  title: string;
  description: string;
  transcript: string | null;
  attachments: ReadonlyArray<{
    kind: "screenshot" | "audio";
    storageId: string;
    sha256: string;
    size: number;
    contentType: string;
  }>;
};

export function bytesToHex(bytes: Uint8Array): string {
  let out = "";
  for (const b of bytes) out += b.toString(16).padStart(2, "0");
  return out;
}

/** Hex sha256 of a string (UTF-8) or bytes, via Web Crypto. */
export async function sha256Hex(data: string | ArrayBuffer | Uint8Array): Promise<string> {
  const bytes = typeof data === "string" ? encoder.encode(data) : data;
  const digest = await crypto.subtle.digest("SHA-256", bytes as BufferSource);
  return bytesToHex(new Uint8Array(digest));
}

/**
 * Canonical JSON: fixed key order, attachments in their stored order, and
 * only the fields listed here (the runner's attachments also carry `index`,
 * which isn't hashed). Versioned, since the runner recomputes it.
 */
export function canonicalSnapshotJson(c: SnapshotHashInput): string {
  return JSON.stringify({
    v: 1,
    itemId: c.itemId,
    title: c.title,
    description: c.description,
    transcript: c.transcript,
    attachments: c.attachments.map((a) => ({
      kind: a.kind,
      storageId: a.storageId,
      sha256: a.sha256,
      size: a.size,
      contentType: a.contentType,
    })),
  });
}

export async function snapshotContentHash(c: SnapshotHashInput): Promise<string> {
  return await sha256Hex(canonicalSnapshotJson(c));
}
