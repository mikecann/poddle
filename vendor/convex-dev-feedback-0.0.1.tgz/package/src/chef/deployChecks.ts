/**
 * What the preview and "Ship it" deploy scripts refuse to deploy, checked on
 * the repo itself (docs/chef-pipeline.md, "What the deploy refuses").
 *
 * runner/chef-preview-deploy.sh and runner/chef-ship-deploy.sh refuse a
 * checkout that could steer the pinned Convex CLI, npm or the bundler: a
 * tracked .env, .env.local or .npmrc, any symlink, a convex.json whose
 * functions directory leaves the checkout, git dependencies in
 * package-lock.json. They keep those checks (they are the last line), but
 * by then a build has been paid for. The same checks, here, run first:
 *
 *   - `npx chef init --cloud`'s preflight and `npx chef sync`, on HEAD, before
 *     anything is pushed (cli/preflight.ts, cli/main.ts);
 *   - the runner, right after the clone, before the agent costs anything
 *     (runner/runner.ts);
 *   - the failure classifier, which turns a script's refusal into a reason
 *     and an action (src/chef/failures.ts).
 *
 * Each refusal's `message` is exactly the line the scripts die with, so the
 * two can't drift apart unnoticed: tests/runner/deployChecks.test.ts runs
 * both scripts and this on the same fixtures and compares them.
 *
 * Pure and dependency-free: the callers list the tree and read files their
 * own way (git ls-tree on a commit, git ls-files on a checkout).
 */

/** One tracked path and its git mode ("100644", "120000" for a symlink, ...). */
export type TreeEntry = { mode: string; path: string };

export type DeployRefusalCode = "envFile" | "symlinks" | "convexJson" | "gitDependencies";

export type DeployRefusal = {
  code: DeployRefusalCode;
  /** The deploy scripts' own die line for it, without the script's name. */
  message: string;
  /** What it is about: the file, the symlinks, the git dependencies' names. */
  paths: string[];
  /** What to run or change, line by line. */
  fix: string[];
};

/** The files the scripts refuse at the top of the checkout, in the order they check them. */
export const DEPLOY_ENV_FILES = [".env", ".env.local", ".npmrc"] as const;

/** How many symlinks a message names before "and N more". The scripts' awk uses the same. */
export const SYMLINKS_NAMED = 3;

const SYMLINK_MODE = "120000";
// The scripts' `grep -Eq '"resolved": *"git[+:]' package-lock.json`.
const LOCK_GIT_RESOLVED = /"resolved": *"git[+:]/;

/** `a, b, c, and 2 more`: the scripts' awk join, for the first SYMLINKS_NAMED paths. */
export function nameSome(paths: readonly string[]): string {
  const shown = paths.slice(0, SYMLINKS_NAMED).join(", ");
  return paths.length > SYMLINKS_NAMED ? `${shown}, and ${paths.length - SYMLINKS_NAMED} more` : shown;
}

/** convex.json's functions setting, as the scripts' node one-liner judges it: null when fine. */
function convexJsonProblem(text: string): string | null {
  let c: unknown;
  try {
    c = JSON.parse(text);
  } catch {
    return "convex.json is not valid JSON";
  }
  const f = c && typeof c === "object" ? (c as { functions?: unknown }).functions : undefined;
  if (f === undefined) return null;
  if (typeof f !== "string") return `convex.json's functions is ${JSON.stringify(f)}, not a path`;
  if (f.startsWith("/") || f.split(/[\\/]/).includes("..")) return `convex.json's functions is ${JSON.stringify(f)}`;
  return null;
}

/** The packages package-lock.json resolves from git, by name; [] when it can't tell. */
function lockGitPackages(text: string): string[] {
  let lock: any;
  try {
    lock = JSON.parse(text);
  } catch {
    return [];
  }
  const out = new Set<string>();
  const isGit = (s: unknown) => typeof s === "string" && /^git[+:]/.test(s);
  for (const [path, entry] of Object.entries<any>(lock?.packages ?? {})) {
    if (path && isGit(entry?.resolved)) out.add(path.replace(/^.*node_modules\//, ""));
  }
  const walk = (deps: Record<string, any> | undefined) => {
    for (const [name, entry] of Object.entries<any>(deps ?? {})) {
      if (isGit(entry?.resolved)) out.add(name);
      walk(entry?.dependencies);
    }
  };
  walk(lock?.dependencies);
  return [...out].sort();
}

/**
 * Everything the deploy scripts would refuse in this tree, in the order they
 * check (the first is the one a script dies with). `read` returns a tracked
 * file's text, or null. [] when the deploy would go ahead.
 */
export function deployRefusals(entries: readonly TreeEntry[], read: (path: string) => string | null): DeployRefusal[] {
  const out: DeployRefusal[] = [];
  const byPath = new Map(entries.map((e) => [e.path, e]));
  // `[ -e "$f" ] || [ -L "$f" ]` at the top of a clean checkout: the file
  // itself, a symlink by that name, or a directory with anything in it.
  for (const f of DEPLOY_ENV_FILES) {
    const hit = byPath.has(f) || entries.some((e) => e.path.startsWith(`${f}/`));
    if (!hit) continue;
    out.push({
      code: "envFile",
      message: `the repo has ${f}; refusing to deploy`,
      paths: [f],
      fix: [
        f === ".npmrc"
          ? "npm reads .npmrc, and it can name the programs npm runs; Chef's sandboxes install from registry.npmjs.org without it."
          : "The Convex CLI reads it, so it could point a deploy at another deployment. Keep it on your machine only:",
        `  git rm${byPath.has(f) ? "" : " -r"} --cached ${f}`,
        `  echo ${f} >> .gitignore`,
        `  git add .gitignore && git commit -m "Stop tracking ${f}"`,
        ...(f === ".npmrc" ? [] : ["If it ever held a secret, rotate it: it is still in the git history."]),
      ],
    });
  }
  // `git ls-files -s | awk '$1 == "120000"'`: any symlink, anywhere.
  const links = entries.filter((e) => e.mode === SYMLINK_MODE).map((e) => e.path);
  if (links.length > 0) {
    out.push({
      code: "symlinks",
      message: `the repo has symlinks (${nameSome(links)}); refusing to deploy`,
      paths: links,
      fix: [
        "The Convex bundler follows a symlink to whatever it points at, so the deploy refuses any.",
        "Replace each with a real copy of what it points to, or stop tracking it:",
        ...links.slice(0, 20).map((p) => `  git rm --cached ${p}    # then copy the real file or folder there, or add it to .gitignore`),
        ...(links.length > 20 ? [`  ... and ${links.length - 20} more (git ls-files -s | grep ^120000)`] : []),
        '  git commit -m "Replace symlinks with real files"',
      ],
    });
  }
  // The scripts' node one-liner on convex.json (a JSON error refuses too).
  if (byPath.has("convex.json") && byPath.get("convex.json")!.mode !== SYMLINK_MODE) {
    const why = convexJsonProblem(read("convex.json") ?? "");
    if (why !== null) {
      out.push({
        code: "convexJson",
        message: "convex.json points the functions directory outside the checkout",
        paths: ["convex.json"],
        fix: [`${why}.`, 'Set "functions" to a directory inside the repo (such as "convex/"), or remove it, and commit.'],
      });
    }
  }
  if (byPath.has("package-lock.json") && byPath.get("package-lock.json")!.mode !== SYMLINK_MODE) {
    const text = read("package-lock.json") ?? "";
    if (LOCK_GIT_RESOLVED.test(text)) {
      const names = lockGitPackages(text);
      out.push({
        code: "gitDependencies",
        message: "package-lock.json has git dependencies; refusing to deploy",
        paths: names,
        fix: [
          ...(names.length ? [`From git: ${names.slice(0, 10).join(", ")}${names.length > 10 ? `, and ${names.length - 10} more` : ""}.`] : []),
          "The sandboxes reach only registry.npmjs.org. Vendor each one as a tarball in the repo:",
          "  npm pack <the git spec> --pack-destination vendor",
          '  then in package.json: "<name>": "file:vendor/<name>-<version>.tgz", npm install, and commit vendor/ with the lockfile',
        ],
      });
    }
  }
  return out;
}

/** `git ls-tree -r -z <rev>` output as entries (blobs and symlinks; not submodules). */
export function parseLsTreeZ(out: string): TreeEntry[] {
  const entries: TreeEntry[] = [];
  for (const rec of out.split("\0")) {
    const m = /^(\d{6}) (blob|tree|commit) [0-9a-f]{40,64}\t([\s\S]+)$/.exec(rec);
    if (m && m[2] === "blob") entries.push({ mode: m[1], path: m[3] });
  }
  return entries;
}

/** `git ls-files -s -z` output as entries. */
export function parseLsFilesStageZ(out: string): TreeEntry[] {
  const entries: TreeEntry[] = [];
  for (const rec of out.split("\0")) {
    const m = /^(\d{6}) [0-9a-f]{40,64} \d\t([\s\S]+)$/.exec(rec);
    if (m && m[1] !== "160000") entries.push({ mode: m[1], path: m[2] });
  }
  return entries;
}

/** The one-line failure for a run that stopped on a refusal: the script's message. */
export function deployRefusalError(r: DeployRefusal): string {
  return `deploy refused: ${r.message}`;
}

/** What to do about a refusal, in one line, for a failed run's action. */
export function deployRefusalAction(code: DeployRefusalCode, paths: readonly string[] = []): string {
  const then = "`npx chef sync`, then Try again (`npx chef init --cloud` lists the exact fix).";
  switch (code) {
    case "envFile":
      return `Stop tracking ${paths[0] ?? "the file"} on main (\`git rm --cached ${paths[0] ?? "<file>"}\`, add it to .gitignore), commit, ${then}`;
    case "symlinks":
      return `Replace the symlinks with real files (or \`git rm --cached\` them) on main, commit, ${then}`;
    case "convexJson":
      return `Point convex.json's "functions" at a directory inside the repo on main, commit, ${then}`;
    case "gitDependencies":
      return `Vendor the git dependencies as tarballs on main, commit, ${then}`;
  }
}

/**
 * A deploy script's refusal in an error's text (the runner's "deploy
 * refused: ...", or a deploy script's own die line), or null. Recognises
 * exactly the messages `deployRefusals` writes.
 */
export function findDeployRefusal(text: string): { code: DeployRefusalCode; message: string; paths: string[] } | null {
  let m = /the repo has (\.env|\.env\.local|\.npmrc); refusing to deploy/.exec(text);
  if (m) return { code: "envFile", message: m[0], paths: [m[1]] };
  m = /the repo has symlinks(?: \(([^\n]*?)\))?; refusing to deploy/.exec(text);
  if (m) return { code: "symlinks", message: m[0], paths: m[1] ? m[1].replace(/, and \d+ more$/, "").split(", ") : [] };
  m = /convex\.json points the functions directory outside the checkout/.exec(text);
  if (m) return { code: "convexJson", message: m[0], paths: ["convex.json"] };
  m = /package-lock\.json has git dependencies; refusing to deploy/.exec(text);
  if (m) return { code: "gitDependencies", message: m[0], paths: [] };
  return null;
}
