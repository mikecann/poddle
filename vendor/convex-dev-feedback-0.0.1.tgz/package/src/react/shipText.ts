// Words for "Ship it" (src/react/ShipIt.tsx), apart from the components.

export type ShipRelease = {
  releaseId: string;
  seq: number;
  state: string;
  open: boolean;
  sha: string;
  shipRunId: string | null;
  approvedDiffHash: string | null;
  error: string | null;
  siteUrl: string | null;
  mainSha: string | null;
  updatedAt: number;
};

/**
 * A release following main (docs/chef-pipeline.md, "When main moves under
 * Ship it"), as `shipCandidate` returns it. `text` is the words to show.
 */
export type ShipFollow = {
  releaseSeq: number;
  status: string;
  mainSha: string;
  attempts: number;
  text: string;
  reason: string | null;
  files: string[];
  conflicts: string[];
  repaired: boolean;
  /** needsApproval: approve the merge with this run and hash. */
  runId: string | null;
  diffHash: string | null;
  depsChanged: boolean;
  /** What Chef's agent changed to merge main in: all the re-approval needs reading. */
  resolution: string | null;
  resolutionTruncated: boolean;
  /** failed, stalled: Try again with these. */
  shipRunId: string | null;
  approvedDiffHash: string | null;
};

/** What the admin can do about a release following main: approve the merge, try again, or nothing (Chef is on it). */
export function followAction(f: ShipFollow): "approve" | "retry" | null {
  if (f.status === "needsApproval" && f.runId && f.diffHash) return "approve";
  if ((f.status === "failed" || f.status === "stalled") && f.shipRunId && f.approvedDiffHash) return "retry";
  return null;
}

/** Where a ship is, in words. */
export function shipStateText(r: ShipRelease): string {
  if (r.state === "done") return `Release #${r.seq} is live.`;
  if (r.state === "abandoned") return `Release #${r.seq} didn't ship${r.error ? "" : "."}`;
  if (r.state === "rolledBack") return `Release #${r.seq} was rolled back.`;
  if (r.error) return `Release #${r.seq} stopped (${r.state}). main is where it was.`;
  const doing: Record<string, string> = {
    approved: "deploying",
    backendDeployed: "backend deployed, publishing the frontend",
    frontendPublished: "published, checking the live site",
    verified: "verified, moving main",
    live: "live, finishing",
  };
  return `Release #${r.seq}: ${doing[r.state] ?? r.state}…`;
}


/** What a merge-only build did (main moved before Ship it), in words; null for a normal build. */
export function mergedMainText(run: {
  mergedMain?: { count: number; subjects: string[] } | null;
  refresh?: { releaseSeq: number; sameDiff: boolean } | null;
}): string | null {
  if (!run.refresh || !run.mergedMain) return null;
  const m = run.mergedMain;
  const list = m.subjects.slice(0, 3).join("; ");
  const more = m.subjects.length > 3 ? `; and ${m.count - 3} more` : "";
  return (
    `Main moved since you approved release #${run.refresh.releaseSeq}: Chef merged ${m.count} commit${m.count === 1 ? "" : "s"}` +
    `${list ? ` (${list}${more})` : ""} into this build, and its checks pass again.` +
    (run.refresh.sameDiff ? "" : " What ships changed with the merge, so approve it again.")
  );
}
