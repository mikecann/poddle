/**
 * The approvals view for Chef cloud builds: render the approval snapshot, not
 * the item. Every character of the title, description and transcript, with no
 * truncation, every attachment inline, and hidden characters shown as visible
 * `<U+XXXX>` markers. Approving sends back the snapshot's content hash, so the
 * approval covers exactly what was shown.
 */
import * as React from "react";
import { useMutation, useQuery } from "convex/react";
import type { FunctionReference } from "convex/server";
import { countInvisible, segmentInvisible } from "./revealInvisible.js";

/** What `approvalSnapshot` (exposeChefApi) returns. */
export type ApprovalSnapshot = {
  snapshotId: string;
  itemId: string;
  title: string;
  description: string;
  transcript: string | null;
  contentHash: string;
  approved: boolean;
  attachments: {
    kind: "screenshot" | "audio";
    url: string | null;
    contentType: string;
    size: number;
    sha256: string;
  }[];
};

export type SnapshotApprovalApi = {
  /** exposeChefApi's `prepareApproval`. */
  prepareApproval: FunctionReference<
    "mutation",
    "public",
    { id: string },
    { snapshotId: string; contentHash: string }
  >;
  /** exposeChefApi's `approvalSnapshot`. */
  approvalSnapshot: FunctionReference<"query", "public", { snapshotId: string }, ApprovalSnapshot | null>;
  /** exposeChefApi's `approveSnapshot`. */
  approveSnapshot: FunctionReference<"mutation", "public", { snapshotId: string; contentHash: string }>;
};

const markerStyle: React.CSSProperties = {
  background: "#fde68a",
  color: "#7c2d12",
  border: "1px solid #b45309",
  borderRadius: 3,
  padding: "0 2px",
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
  fontSize: "0.85em",
};

/** Text with hidden characters as visible markers. Never truncates. */
export function RevealedText({ text }: { text: string }) {
  return (
    <>
      {segmentInvisible(text).map((s, i) =>
        s.hidden ? (
          <span key={i} className="ship-hidden-char" style={markerStyle} title="Hidden character">
            {s.text}
          </span>
        ) : (
          <React.Fragment key={i}>{s.text}</React.Fragment>
        ),
      )}
    </>
  );
}

/** One snapshot, in full. Pure rendering; no Convex calls. */
export function SnapshotView({ snapshot }: { snapshot: ApprovalSnapshot }) {
  const hidden =
    countInvisible(snapshot.title) +
    countInvisible(snapshot.description) +
    countInvisible(snapshot.transcript ?? "");
  // Markers replace every bidi control, and isolate keeps what's left from
  // reordering the page around it.
  const block: React.CSSProperties = {
    whiteSpace: "pre-wrap",
    overflowWrap: "anywhere",
    unicodeBidi: "isolate",
    margin: "6px 0 0",
    fontSize: 13,
  };
  return (
    <div className="ship-snapshot" dir="ltr">
      {hidden > 0 && (
        <div
          role="alert"
          className="ship-snapshot-warning"
          style={{ background: "#fef3c7", border: "1px solid #b45309", borderRadius: 6, padding: 8, fontSize: 13 }}
        >
          This request contains {hidden} hidden character{hidden === 1 ? "" : "s"}, shown as{" "}
          <span style={markerStyle}>&lt;U+XXXX&gt;</span> markers.
        </div>
      )}
      <div className="ship-snapshot-title" style={{ ...block, fontWeight: 600, fontSize: 15 }}>
        <RevealedText text={snapshot.title} />
      </div>
      <div className="ship-snapshot-description" style={block}>
        <RevealedText text={snapshot.description} />
      </div>
      {snapshot.transcript !== null && (
        <div style={{ marginTop: 10 }}>
          <div style={{ fontSize: 12, fontWeight: 600, opacity: 0.7 }}>Voice note transcript</div>
          <div className="ship-snapshot-transcript" style={block}>
            <RevealedText text={snapshot.transcript} />
          </div>
        </div>
      )}
      <div className="ship-snapshot-attachments" style={{ fontSize: 12, fontWeight: 600, opacity: 0.7, marginTop: 10 }}>
        {snapshot.attachments.length === 0
          ? "No attachments"
          : `${snapshot.attachments.length} attachment${snapshot.attachments.length === 1 ? "" : "s"}`}
      </div>
      {snapshot.attachments.length > 0 && (
        <div style={{ display: "grid", gap: 8, marginTop: 6 }}>
          {snapshot.attachments.map((a, i) => (
            <figure key={i} style={{ margin: 0 }}>
              {a.kind === "screenshot" && a.url ? (
                <img src={a.url} alt={`Screenshot ${i + 1}`} style={{ maxWidth: "100%", borderRadius: 6 }} />
              ) : a.kind === "audio" && a.url ? (
                <audio src={a.url} controls preload="none" style={{ width: "100%" }} />
              ) : (
                <div>Attachment {i + 1} is unavailable.</div>
              )}
              <figcaption style={{ fontSize: 11, opacity: 0.7, fontFamily: "ui-monospace, monospace" }}>
                {a.contentType} · {a.size} bytes · sha256 {a.sha256.slice(0, 12)}
              </figcaption>
            </figure>
          ))}
        </div>
      )}
      <div style={{ fontSize: 11, opacity: 0.6, marginTop: 8, fontFamily: "ui-monospace, monospace" }}>
        snapshot {snapshot.contentHash.slice(0, 16)}
      </div>
    </div>
  );
}

/**
 * Open a request for approval: snapshot it (`prepareApproval`), show the
 * snapshot in full, and "Approve and build" approves that snapshot's hash
 * (`approveSnapshot`). `onDone` runs after approving or cancelling.
 */
export function SnapshotApproval({
  api,
  itemId,
  onDone,
}: {
  api: SnapshotApprovalApi;
  itemId: string;
  onDone?: () => void;
}) {
  const prepare = useMutation(api.prepareApproval);
  const approve = useMutation(api.approveSnapshot);
  const [prepared, setPrepared] = React.useState<{ snapshotId: string; contentHash: string } | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);
  React.useEffect(() => {
    let live = true;
    prepare({ id: itemId }).then(
      (r) => live && setPrepared(r),
      (e) => live && setError(String(e?.data?.message ?? e?.message ?? e)),
    );
    return () => {
      live = false;
    };
  }, [itemId, prepare]);
  const snapshot = useQuery(api.approvalSnapshot, prepared ? { snapshotId: prepared.snapshotId } : "skip");
  if (error) return <div role="alert">{error}</div>;
  if (!prepared || snapshot === undefined) return <div>Preparing the snapshot…</div>;
  if (snapshot === null) return <div role="alert">Snapshot unavailable.</div>;
  return (
    <div>
      <SnapshotView snapshot={snapshot} />
      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
        <button
          className="ship-btn-primary"
          disabled={busy || snapshot.approved}
          onClick={async () => {
            setBusy(true);
            try {
              // The hash of what was rendered, not of the item as it is now.
              await approve({ snapshotId: snapshot.snapshotId, contentHash: snapshot.contentHash });
              onDone?.();
            } catch (e: any) {
              setError(String(e?.data?.message ?? e?.message ?? e));
            } finally {
              setBusy(false);
            }
          }}
        >
          Approve and build
        </button>
        {onDone && (
          <button className="ship-btn-secondary" disabled={busy} onClick={onDone}>
            Cancel
          </button>
        )}
      </div>
    </div>
  );
}
