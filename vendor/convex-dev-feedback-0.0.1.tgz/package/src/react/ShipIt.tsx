/**
 * "Ship it": the panel's merge button. Shows what shipping the newest built
 * commit on `chef` to the live app changes (the whole diff main..chef, as
 * the build uploaded it, scrubbed), the requests it ships, and "Ship to
 * live", which approves exactly that diff by its hash. The host's shipper
 * then deploys it, publishes the frontend, verifies the live site and only
 * then moves `main`. The last ship's state is shown, with "Try again" when it
 * failed after the backend deploy.
 *
 * The plain-language card (exposeChefApi's `buildCard`, src/react/BuildCard.tsx)
 * comes first: what changed, what to try, the screenshots and the risk
 * flags. The code itself is folded under "Details" and loads only when
 * opened.
 *
 * Talks to exposeChefApi's `shipCandidate`, `shipDiffChunk`, `shipApprove`
 * and, when given, `buildCard`. They return nothing to members, so a member never sees it.
 */
import * as React from "react";
import { useMutation, useQuery } from "convex/react";
import type { FunctionReference } from "convex/server";
import { followAction, mergedMainText, shipStateText, type ShipFollow, type ShipRelease } from "./shipText.js";
import { BuildCard, type BuildCardData } from "./BuildCard.js";

export type { ShipFollow, ShipRelease } from "./shipText.js";

type Q<Args extends Record<string, any>, R> = FunctionReference<"query", "public", Args, R>;
type M<Args extends Record<string, any>, R = any> = FunctionReference<"mutation", "public", Args, R>;

export type ShipDiff = {
  diffHash: string;
  chunkCount: number;
  bytes: number;
  filesChanged: string[];
  filesTruncated: boolean;
  depsChanged: boolean;
  redactions: number;
};


/** What `shipCandidate` (exposeChefApi) returns. */
export type ShipCandidate = {
  run: {
    runId: string;
    seq: number;
    commitSha: string | null;
    baseSha: string | null;
    hasFrontend: boolean;
    finishedAt: number | null;
    /** Main moved before Ship it and Chef merged it in (a merge-only build). */
    mergedMain?: { count: number; subjects: string[] } | null;
    refresh?: { releaseSeq: number; sameDiff: boolean } | null;
    /** Merging main in failed: "Try again" (retryRun) on this request rebuilds it on the new main. */
    retryItemId?: string | null;
    /** A release waiting for a person while it follows main: approving this build ships it in its place. */
    replaces?: number | null;
    diff: ShipDiff | null;
  } | null;
  requests: { runId: string; itemId: string; number: number | null; title: string }[];
  /** Requests whose own build failed after pushing to chef: their code ships with this build. */
  alsoShips?: { runId: string; itemId: string; number: number | null; title: string; seq: number }[];
  release: ShipRelease | null;
  blocked: string | null;
  /** The open release following main: "Merged main in", "Resolving a conflict", "Needs you: conflict in X". */
  follow?: ShipFollow | null;
};

export type ShipDiffChunk = { index: number; count: number; text: string; sha256: string; redactions: number };

export type ShipApproveResult = { approved: boolean; reason?: string; releaseId?: string; seq?: number; started?: boolean };

/** exposeChefApi's functions "Ship it" uses. */
export type ShipItApi = {
  shipCandidate: Q<Record<string, never>, ShipCandidate | null>;
  shipDiffChunk: Q<{ runId: string; index: number }, ShipDiffChunk | null>;
  shipApprove: M<{ runId: string; diffHash: string; depsAcknowledged?: boolean }, ShipApproveResult>;
  /** "Try again" when main moved and merging it failed (exposeChefApi's `retryRun`). */
  retryRun?: M<{ itemId: string }, { outcome: string; reason?: string }>;
  /** The plain-language card shown first (exposeChefApi's `buildCard`); without it, only the diff. */
  buildCard?: Q<{ runId?: string }, BuildCardData | null>;
};

const C = { ink: "#1f2937", muted: "#6b7280", brand: "#9a3412", accent: "#ea580c", line: "#fed7aa", ok: "#15803d", bad: "#b91c1c" };
const mono = "ui-monospace, SFMono-Regular, Menlo, monospace";
const label: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  textTransform: "uppercase",
  letterSpacing: 0.6,
  color: C.brand,
  margin: "0 0 6px",
};
const btn: React.CSSProperties = {
  padding: "6px 10px",
  borderRadius: 6,
  fontSize: 12,
  fontWeight: 600,
  cursor: "pointer",
  border: `1px solid ${C.line}`,
  background: "white",
  color: C.brand,
};
const primary: React.CSSProperties = { ...btn, background: C.accent, color: "white", border: 0 };
const errText = (e: any) => String(e?.data?.message ?? e?.message ?? e);
const short = (s: string | null | undefined) => (s ? s.slice(0, 12) : "?");

function DiffChunkView({ api, runId, index }: { api: ShipItApi; runId: string; index: number }) {
  const c = useQuery(api.shipDiffChunk, { runId, index });
  if (c === undefined) return <div style={{ color: C.muted }}>Loading…</div>;
  if (c === null) return <div style={{ color: C.bad }}>Part {index + 1} is unavailable.</div>;
  return <>{c.text}</>;
}

/** The whole diff, every chunk, scrubbed as stored. */
export function ShipDiffView({ api, runId, diff }: { api: ShipItApi; runId: string; diff: ShipDiff }) {
  return (
    <pre
      className="chef-ship-diff"
      style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", overflowWrap: "anywhere", maxHeight: 320, overflowY: "auto", margin: 0, padding: 8, background: "#fafafa", border: "1px solid #f3f4f6", borderRadius: 6 }}
    >
      {Array.from({ length: diff.chunkCount }, (_, i) => (
        <DiffChunkView key={i} api={api} runId={runId} index={i} />
      ))}
    </pre>
  );
}

/**
 * Pure rendering of "Ship it" from a candidate: the button, then the diff,
 * the requests, the dependency confirmation and "Ship to live". `onShip` is
 * called with the run and the hash shown.
 */
export function ShipItDetails({
  api,
  candidate,
  onShip,
  onRetry,
  card,
}: {
  api: ShipItApi;
  candidate: ShipCandidate;
  onShip: (args: { runId: string; diffHash: string; depsAcknowledged?: boolean }) => Promise<ShipApproveResult>;
  /** Try again on a request whose build Ship it couldn't ship (main moved and didn't merge). */
  onRetry?: (itemId: string) => Promise<{ outcome: string; reason?: string }>;
  /** The Ship card for the candidate, shown first; the diff is under "Details". */
  card?: BuildCardData | null;
}) {
  const [open, setOpen] = React.useState(false);
  const [details, setDetails] = React.useState(false);
  const [deps, setDeps] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const { run, release, blocked, requests } = candidate;
  const diff = run?.diff ?? null;
  const ship = async (args: { runId: string; diffHash: string; depsAcknowledged?: boolean }) => {
    setError(null);
    setBusy(true);
    try {
      const r = await onShip(args);
      if (!r.approved) setError(r.reason ?? "Refused");
      else if (r.started === false) setError("Approved, but the app has no shipper set up (setShipper).");
      else setOpen(false);
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  };
  const follow = candidate.follow ?? null;
  const act = follow ? followAction(follow) : null;
  // A release waiting for a person while it follows main isn't in flight:
  // the newer build may replace it (run.replaces).
  const paused = !!follow && follow.status !== "merged" && follow.status !== "merging";
  const inFlight = release?.open && !release.error && !paused;
  const retry = release?.open && release.error && release.shipRunId && release.approvedDiffHash && !follow;
  return (
    <section className="chef-ship" style={{ display: "grid", gap: 8, fontSize: 13 }}>
      <div style={label}>Ship to the live app</div>
      {follow && (
        <div className="chef-ship-follow" style={{ display: "grid", gap: 6 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: follow.status === "failed" || follow.status === "stalled" ? C.bad : C.accent }}>{follow.text}</div>
          {follow.files.length > 0 && follow.status !== "merging" && (
            <div style={{ fontSize: 11, color: C.muted }}>Files: {follow.files.slice(0, 10).join(", ")}{follow.files.length > 10 ? ", …" : ""}</div>
          )}
          {act === "approve" && follow.resolution && (
            <pre className="chef-ship-resolution" style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", maxHeight: 320, overflowY: "auto", margin: 0, padding: 8, background: "#fafafa", border: "1px solid #f3f4f6", borderRadius: 6 }}>
              {follow.resolution}
              {follow.resolutionTruncated ? "\n[… cut]" : ""}
            </pre>
          )}
          {act === "approve" && follow.depsChanged && (
            <label style={{ fontSize: 12, color: C.bad, display: "flex", gap: 6, alignItems: "center" }}>
              <input type="checkbox" checked={deps} onChange={(e) => setDeps(e.target.checked)} />
              The merged change touches dependencies. I checked them.
            </label>
          )}
          {act && (
            <div>
              <button
                type="button"
                style={primary}
                disabled={busy || (act === "approve" && follow.depsChanged && !deps)}
                onClick={() =>
                  void ship(
                    act === "approve"
                      ? { runId: follow.runId!, diffHash: follow.diffHash!, ...(follow.depsChanged ? { depsAcknowledged: deps } : {}) }
                      : { runId: follow.shipRunId!, diffHash: follow.approvedDiffHash! },
                  )
                }
              >
                {act === "approve" ? (follow.repaired ? "Approve the resolution and ship" : "Approve the merged change and ship") : "Try again"}
              </button>
            </div>
          )}
        </div>
      )}
      {run?.replaces != null && !blocked && (
        <div style={{ fontSize: 12, color: C.muted }}>
          Release #{run.replaces} is waiting for you. Shipping this build ships its requests too, in its place.
        </div>
      )}
      {release && !follow && (
        <div className="chef-ship-status" style={{ fontSize: 12, fontWeight: 600, color: release.state === "done" ? C.ok : release.error || release.state === "abandoned" ? C.bad : C.accent }}>
          {shipStateText(release)}
          {release.state === "done" && release.siteUrl && (
            <>
              {" "}
              <a href={release.siteUrl} target="_blank" rel="noreferrer">
                Open it
              </a>
            </>
          )}
        </div>
      )}
      {release?.error && (release.open || release.state === "abandoned") && (
        <pre style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", color: C.bad, margin: 0 }}>{release.error}</pre>
      )}
      {retry && (
        <div>
          <button
            type="button"
            style={primary}
            disabled={busy}
            onClick={() => void ship({ runId: release.shipRunId!, diffHash: release.approvedDiffHash! })}
          >
            Try again
          </button>
        </div>
      )}
      {!inFlight && !retry && blocked && <div style={{ fontSize: 12, color: C.muted }}>{blocked}</div>}
      {!inFlight && !retry && blocked && run?.retryItemId && onRetry && (
        <div>
          <button
            type="button"
            style={primary}
            disabled={busy}
            onClick={() => {
              setBusy(true);
              setError(null);
              onRetry(run.retryItemId!)
                .then((r) => {
                  if (r.outcome === "refused") setError(r.reason ?? "Refused");
                })
                .catch((e) => setError(errText(e)))
                .finally(() => setBusy(false));
            }}
          >
            Try again
          </button>
        </div>
      )}
      {!inFlight && !retry && !blocked && run && mergedMainText(run) && (
        <div className="chef-ship-merged" style={{ fontSize: 12, color: C.ink, background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 6, padding: 6 }}>
          {mergedMainText(run)}
        </div>
      )}
      {card && run && card.runId === run.runId && !inFlight && !retry && !blocked && <BuildCard card={card} />}
      {!inFlight && !retry && !blocked && run && diff && (
        <>
          {!open ? (
            <div>
              <button type="button" style={primary} onClick={() => setOpen(true)}>
                {card?.runId === run.runId && card.beta?.onBeta ? "Promote to everyone" : "Ship it"}
              </button>{" "}
              <span style={{ fontSize: 12, color: C.muted }}>
                Build #{run.seq}, {short(run.commitSha)}: {requests.length} request{requests.length === 1 ? "" : "s"}
              </span>
            </div>
          ) : (
            <div className="chef-ship-review" style={{ display: "grid", gap: 8 }}>
              <div style={{ fontSize: 12, color: C.ink }}>
                This ships <span style={{ fontFamily: mono }}>{short(run.commitSha)}</span> to the live app, then moves main
                from <span style={{ fontFamily: mono }}>{short(run.baseSha)}</span> to it.
              </div>
              {requests.length > 0 && (
                <ul className="chef-ship-requests" style={{ margin: 0, paddingLeft: 18, fontSize: 12 }}>
                  {requests.map((r) => (
                    <li key={r.itemId}>
                      {r.number !== null && <span style={{ color: C.muted }}>#{r.number} </span>}
                      {r.title}
                    </li>
                  ))}
                </ul>
              )}
              {(candidate.alsoShips ?? []).length > 0 && (
                <div className="chef-ship-also" style={{ fontSize: 12, color: C.ink }}>
                  Also ships (their builds stopped after pushing their change, so it is in this build):
                  <ul style={{ margin: "2px 0 0", paddingLeft: 18 }}>
                    {(candidate.alsoShips ?? []).map((r) => (
                      <li key={r.itemId}>
                        {r.number !== null && <span style={{ color: C.muted }}>#{r.number} </span>}
                        {r.title}
                        <span style={{ color: C.muted }}> (build #{r.seq})</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <div style={{ fontSize: 11, color: C.muted }}>
                {diff.filesChanged.length}
                {diff.filesTruncated ? "+" : ""} files · diff <span style={{ fontFamily: mono }}>{diff.diffHash.slice(0, 12)}</span>
                {diff.redactions > 0 && ` · ${diff.redactions} secret-looking strings hidden`}
              </div>
              <div className="chef-ship-details" style={{ display: "grid", gap: 6 }}>
                <div>
                  <button type="button" style={btn} aria-expanded={details} onClick={() => setDetails((d) => !d)}>
                    {details ? "Hide the details" : "Details: the whole change, as code"}
                  </button>
                </div>
                {details && <ShipDiffView api={api} runId={run.runId} diff={diff} />}
              </div>
              {diff.depsChanged && (
                <label style={{ fontSize: 12, color: C.bad, display: "flex", gap: 6, alignItems: "center" }}>
                  <input type="checkbox" checked={deps} onChange={(e) => setDeps(e.target.checked)} />
                  This changes dependencies (package.json or a lockfile). I checked them.
                </label>
              )}
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  type="button"
                  style={primary}
                  disabled={busy || (diff.depsChanged && !deps)}
                  onClick={() =>
                    void ship({ runId: run.runId, diffHash: diff.diffHash, ...(diff.depsChanged ? { depsAcknowledged: deps } : {}) })
                  }
                >
                  {card?.runId === run.runId && card.beta?.onBeta ? "Promote to everyone" : "Ship to live"}
                </button>
                <button type="button" style={btn} disabled={busy} onClick={() => setOpen(false)}>
                  Cancel
                </button>
              </div>
            </div>
          )}
        </>
      )}
      {error && (
        <div role="alert" style={{ fontSize: 12, color: C.bad }}>
          {error}
        </div>
      )}
    </section>
  );
}

/** "Ship it", live. Renders nothing for members (shipCandidate is null for them). */
export function ShipIt({ api }: { api: ShipItApi }) {
  const candidate = useQuery(api.shipCandidate, {});
  // Hooks can't be conditional: without buildCard, the same query, skipped.
  const card = useQuery(api.buildCard ?? (api.shipCandidate as unknown as NonNullable<ShipItApi["buildCard"]>), api.buildCard ? {} : "skip");
  const approve = useMutation(api.shipApprove);
  // Hooks can't be conditional: without retryRun, a stand-in never called.
  const retry = useMutation(api.retryRun ?? (api.shipApprove as unknown as NonNullable<ShipItApi["retryRun"]>));
  if (!candidate) return null;
  if (!candidate.run && !candidate.release) return null;
  return (
    <ShipItDetails
      api={api}
      candidate={candidate}
      onShip={(a) => approve(a)}
      card={card ?? null}
      {...(api.retryRun ? { onRetry: (itemId: string) => retry({ itemId }) } : {})}
    />
  );
}
