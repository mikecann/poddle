"use client";
/**
 * ChefPanelMount — one line to put the `<chef-panel>` web component (the
 * floating Chef bubble: requests with screenshots + voice notes, build status,
 * Chef's questions, and approvals for admins) on every page of a React app.
 *
 *   // inside your ConvexProvider / client providers component
 *   import { ChefPanelMount } from "@convex-dev/feedback/react";
 *   import { useAuthToken } from "@convex-dev/auth/react";
 *
 *   <ChefPanelMount convexUrl={process.env.NEXT_PUBLIC_CONVEX_URL!} token={useAuthToken()} />
 *
 * Admins (the component's `amAdmin`) see Chef — branding, build status,
 * Chef's questions, the approvals queue (Approve shows the request's snapshot
 * in full, then "Approve and build") and their cloud builds (phases, preview,
 * screenshots, skill notes, spend approvals, the run log). Everyone else sees a neutral
 * lightbulb "Suggest a feature" button (`memberLabel` to rename it) that only
 * files requests and lists their own.
 *
 * The panel talks to the functions `exposeChefApi` creates in `convex/<prefix>.ts`
 * (default "chef"). It runs its own Convex client; this component loads the
 * script once, appends one `<chef-panel>` to `document.body`, and keeps its auth
 * in sync with your app's (pass `token`, or `getToken` for providers like Clerk:
 * `getToken={() => getToken({ template: "convex" })}`). Renders nothing itself.
 *
 * The panel element is intentionally kept across unmounts/hot reloads so a
 * half-typed request survives; drafts also survive full reloads (sessionStorage).
 */
import { useEffect, useRef } from "react";
import { ConvexClient } from "convex/browser";
import { makeFunctionReference } from "convex/server";
import type { ChefAuthTokenFetcher, ChefPanelElement } from "../../panel/chef-panel.browser.js";

export type ChefPanelMountProps = {
  /** Your deployment URL, e.g. process.env.NEXT_PUBLIC_CONVEX_URL. */
  convexUrl: string | undefined;
  /** Module name of your `exposeChefApi` exports (convex/chef.ts → "chef"). */
  prefix?: string;
  /** The signed-in user's Convex auth token (e.g. `useAuthToken()`); null/undefined = signed out. */
  token?: string | null;
  /** Alternative to `token`: a fetcher like ConvexClient.setAuth takes. */
  getToken?: ChefAuthTokenFetcher | (() => Promise<string | null | undefined>);
  /**
   * Load the panel from a URL instead of from this package (e.g. a copy you
   * serve yourself, with a content hash for cache busting).
   */
  src?: string;
  /** Start expanded. */
  defaultOpen?: boolean;
  /** Launcher text for non-admins (default "Suggest a feature"). */
  memberLabel?: string;
  /** Lift the button/panel clear of your own floating controls (px from the bottom / right; default 24). */
  offsetBottom?: number;
  offsetRight?: number;
  /**
   * Pop up a "What's new" card listing changelogs shipped since the visitor's last
   * visit (`<prefix>:whatsNew`). Default true; false sets `whats-new="off"`.
   */
  whatsNew?: boolean;
};

let loaded: Promise<unknown> | null = null;
function loadPanel(src?: string): Promise<unknown> {
  if (loaded) return loaded;
  // The panel uses this app's Convex client (its own bundle's copy) instead of
  // fetching one from esm.sh: no third-party fetch, the app's Convex version, and
  // it works where only the app's hosts are reachable (Chef's demo sandbox).
  const g = globalThis as { __chefConvexLib?: unknown };
  g.__chefConvexLib ??= { ConvexClient, makeFunctionReference };
  if (src) {
    loaded = new Promise<void>((resolve, reject) => {
      const s = document.createElement("script");
      s.type = "module";
      s.src = src;
      s.setAttribute("data-chef-panel", "1");
      s.onload = () => resolve();
      s.onerror = () => reject(new Error(`chef-panel: failed to load ${src}`));
      document.head.appendChild(s);
    });
  } else {
    loaded = import("../../panel/chef-panel.browser.js");
  }
  return loaded;
}

export function ChefPanelMount({ convexUrl, prefix = "chef", token, getToken, src, defaultOpen, memberLabel, offsetBottom, offsetRight, whatsNew = true }: ChefPanelMountProps) {
  // Read through refs so the panel's fetcher always sees the latest auth.
  const auth = useRef({ token, getToken });
  useEffect(() => {
    auth.current = { token, getToken };
  });
  const authKey = getToken !== undefined ? "fetcher" : token;

  // Mount (once per URL/prefix): load the script and add the element.
  useEffect(() => {
    if (!convexUrl) return;
    void loadPanel(src).catch((e) => console.error(e));
    let el = document.querySelector<ChefPanelElement>(`chef-panel[prefix="${prefix}"]`);
    if (!el || el.getAttribute("convex-url") !== convexUrl) {
      el?.remove();
      el = document.createElement("chef-panel") as ChefPanelElement;
      el.setAttribute("convex-url", convexUrl);
      el.setAttribute("prefix", prefix);
      if (defaultOpen) el.setAttribute("open", "1");
      if (!whatsNew) el.setAttribute("whats-new", "off");
      document.body.appendChild(el);
    }
  }, [convexUrl, prefix, src, defaultOpen]);

  useEffect(() => {
    const el = document.querySelector<ChefPanelElement>(`chef-panel[prefix="${prefix}"]`);
    if (!el) return;
    if (memberLabel) el.setAttribute("member-label", memberLabel);
    else el.removeAttribute("member-label");
    if (offsetBottom !== undefined) el.setAttribute("offset-bottom", String(offsetBottom));
    else el.removeAttribute("offset-bottom");
    if (offsetRight !== undefined) el.setAttribute("offset-right", String(offsetRight));
    else el.removeAttribute("offset-right");
    if (!whatsNew) el.setAttribute("whats-new", "off");
    else el.removeAttribute("whats-new");
  }, [convexUrl, prefix, memberLabel, offsetBottom, offsetRight, whatsNew]);

  // Hand the panel our auth; re-hand it whenever the token changes so the
  // panel's client re-authenticates (sign-in, sign-out, refresh).
  useEffect(() => {
    if (!convexUrl) return;
    let cancelled = false;
    void customElements.whenDefined("chef-panel").then(() => {
      const el = document.querySelector<ChefPanelElement>(`chef-panel[prefix="${prefix}"]`);
      if (cancelled || !el?.setAuth) return;
      el.setAuth(async (args) => {
        const a = auth.current;
        if (a.getToken) return (await a.getToken(args)) ?? null;
        return a.token ?? null;
      });
    });
    return () => {
      cancelled = true;
    };
  }, [convexUrl, prefix, authKey]);

  return null;
}
