/// <reference types="vite/client" />
// For hosts' convex-test suites:
//
//   import feedbackTest from "@convex-dev/feedback/test";
//   const t = convexTest(schema, modules);
//   feedbackTest.register(t); // or register(t, "<name in convex.config.ts>")
//
// The feedback component has no child components. An app with cloud builds
// registers @convex-dev/chef-cloud too: `chefCloudTest.register(t)` from
// "@convex-dev/chef-cloud/test", which registers its children.
import type { TestConvex } from "convex-test";
import type { GenericSchema, SchemaDefinition } from "convex/server";
import schema from "./component/schema.js";
const modules = import.meta.glob("./component/**/*.ts");

/**
 * Register the component with the test convex instance.
 * @param t - The test convex instance, e.g. from calling `convexTest`.
 * @param name - The name of the component, as registered in convex.config.ts.
 */
export function register<Schema extends SchemaDefinition<GenericSchema, boolean>>(
  t: TestConvex<Schema>,
  name: string = "feedback",
) {
  t.registerComponent(name, schema, modules);
}
export default { register, schema, modules };
