// How Chef installs an app's dependencies, and what a warm install needs,
// as pure functions over the app's files: no imports, no file system, no
// process. runner/chef-install.mjs runs them on a checkout (the build
// sandbox, the deploy and "Ship it" sandboxes, `npx chef init`), and the
// host (@convex-dev/chef-cloud, as `@convex-dev/feedback/install-plan`) runs
// the very same functions on the files of a commit it read from the app's
// repo, so both sides agree on the plan and on the warm key.
//
//   package-lock.json, npm-shrinkwrap.json   npm ci --ignore-scripts
//   pnpm-lock.yaml                           pnpm install --frozen-lockfile --ignore-scripts
//                                            --ignore-pnpmfile, pnpm from the npm registry
//   yarn.lock, bun.lock, none                refused, with what to do instead
//
// The sandboxes reach only registry.npmjs.org, so pnpm comes from there too,
// through `npm exec`: the version package.json's packageManager names
// ("pnpm@x.y.z"), else a pinned one for the lockfile's version. No corepack:
// its signature keys age out, and the deploy scripts turn its project spec
// off. Nothing from the checkout runs: no lifecycle scripts (npm's for
// fetching pnpm, and the install's), no .pnpmfile.cjs, and no
// configDependencies (pnpm loads their code).
//
// Warm installs (docs/chef-pipeline.md, "Warm snapshots"): an app's own
// Daytona snapshot, built only from committed files, holds npm's cache (and
// for pnpm, pnpm's store) filled by this very install command, under
// /opt/chef/warm/<inputsHash>/ with a marker. In a sandbox made from it the
// install is the same command with `--offline` against a copy of those, so
// npm and pnpm still check every package against the lockfile's integrity;
// anything missing or different fails the offline install, and the normal
// one runs instead.

/** The pnpm Chef runs for a pnpm-lock.yaml without a packageManager field, by the lockfile's major version. */
export const PNPM_FOR_LOCKFILE = { 9: "10.34.6", 6: "8.15.9" };

export const NPM_INSTALL = ["npm", "ci", "--ignore-scripts", "--no-audit", "--no-fund"];

const EXACT_VERSION = /^(\d+)\.(\d+)\.(\d+)(-[0-9A-Za-z.-]+)?$/;
// git and GitHub sources: neither reachable nor inert (git runs, prepare scripts).
const PNPM_GIT_SOURCE = /(git\+ssh|git\+https|git:\/\/|github:|codeload\.github\.com|\btype: git\b)/;
export const MAX_LOCKFILE_BYTES = 64 * 1024 * 1024;
export const MAX_PACKAGE_JSON_BYTES = 1024 * 1024;

/** The files installPlanFrom and warmInputs read, at the checkout's root. */
export const PLAN_FILES = [
  "package.json",
  "package-lock.json",
  "npm-shrinkwrap.json",
  "pnpm-lock.yaml",
  "pnpm-workspace.yaml",
  "yarn.lock",
  "bun.lock",
  "bun.lockb",
  ".npmrc",
];

/** The argv that fetches pnpm <version> from the registry, without its scripts, and installs. */
export function pnpmInstallArgv(version) {
  if (!EXACT_VERSION.test(version)) throw new Error(`not an exact pnpm version: ${JSON.stringify(version)}`);
  return [
    "npm",
    "exec",
    "--yes",
    "--ignore-scripts",
    "--no-audit",
    "--no-fund",
    `--package=pnpm@${version}`,
    "--",
    "pnpm",
    "install",
    "--frozen-lockfile",
    "--ignore-scripts",
    "--ignore-pnpmfile",
    "--reporter=append-only",
  ];
}

/** package.json's text, parsed, or null. */
function parsePackageJson(text) {
  if (text === null || text === undefined) return null;
  try {
    const pkg = JSON.parse(text);
    return pkg && typeof pkg === "object" && !Array.isArray(pkg) ? pkg : null;
  } catch {
    return null;
  }
}

/** A packageManager field's value as {name, version}; version null when it isn't exact. Null if unset. */
export function packageManagerOf(pkgText) {
  const pkg = parsePackageJson(pkgText);
  const pm = pkg ? pkg.packageManager : undefined;
  if (typeof pm !== "string" || pm.trim() === "") return null;
  const m = /^(@?[^@\s]+)@([^+\s]+)(\+\S*)?$/.exec(pm.trim());
  if (!m) return { name: pm.trim(), version: null };
  return { name: m[1], version: EXACT_VERSION.test(m[2]) ? m[2] : null };
}

/** The `lockfileVersion` of a pnpm-lock.yaml's text, as its major number, or null. */
export function pnpmLockfileMajor(text) {
  const m = /^lockfileVersion:\s*['"]?(\d+)(?:\.\d+)?['"]?\s*$/m.exec(text);
  return m ? Number(m[1]) : null;
}

/**
 * How a checkout installs, from its root files: `{ manager, lockfile, argv }`,
 * plus `version` for pnpm; or `{ error, lockfile, help }` when Chef can't
 * install it. `files` is `{ exists(name), read(name, maxBytes) }`; read
 * returns the text, or null when it is missing, unreadable or too big.
 */
export function installPlanFrom(files) {
  for (const lockfile of ["package-lock.json", "npm-shrinkwrap.json"]) {
    if (files.exists(lockfile)) return { manager: "npm", lockfile, argv: [...NPM_INSTALL] };
  }
  if (files.exists("pnpm-lock.yaml")) return pnpmPlan(files);
  for (const [lockfile, name] of [
    ["yarn.lock", "yarn"],
    ["bun.lock", "bun"],
    ["bun.lockb", "bun"],
  ]) {
    if (files.exists(lockfile)) {
      return {
        error: `${lockfile}: Chef's sandboxes install with npm or pnpm, not ${name}`,
        lockfile,
        help: [
          "They reach only registry.npmjs.org. Commit a lockfile npm or pnpm can install from:",
          "  npm install                      # writes package-lock.json",
          name === "yarn" ? "  or: npx pnpm import               # pnpm-lock.yaml from yarn.lock" : "  or: npx pnpm install             # writes pnpm-lock.yaml",
          `  then remove ${lockfile} and commit`,
        ],
      };
    }
  }
  return {
    error: "no lockfile; Chef installs from package-lock.json (npm) or pnpm-lock.yaml (pnpm)",
    lockfile: null,
    help: ["npm install && git add package-lock.json"],
  };
}

function pnpmPlan(files) {
  const lockfile = "pnpm-lock.yaml";
  const text = files.read(lockfile, MAX_LOCKFILE_BYTES);
  if (text === null) return { error: `${lockfile} is unreadable or too big`, lockfile, help: [] };
  const git = text.split("\n").find((l) => PNPM_GIT_SOURCE.test(l));
  if (git) {
    return {
      error: `${lockfile} has git dependencies (${git.trim().slice(0, 120)})`,
      lockfile,
      help: ["Chef's sandboxes reach only registry.npmjs.org; vendor them as tarballs (npx chef init explains)."],
    };
  }
  const ws = files.read("pnpm-workspace.yaml", MAX_PACKAGE_JSON_BYTES);
  if (ws !== null && /^\s*configDependencies\s*:/m.test(ws)) {
    return {
      error: "pnpm-workspace.yaml has configDependencies, which pnpm loads and runs during the install",
      lockfile,
      help: ["Chef installs without running the app's code; remove configDependencies to build in the cloud."],
    };
  }
  const pm = packageManagerOf(files.read("package.json", MAX_PACKAGE_JSON_BYTES));
  if (pm && pm.name !== "pnpm") {
    return {
      error: `package.json's packageManager is ${pm.name}, but the lockfile is ${lockfile}`,
      lockfile,
      help: ['Set "packageManager": "pnpm@<version>", or remove the field.'],
    };
  }
  if (pm && pm.version === null) {
    return {
      error: "package.json's packageManager names no exact pnpm version",
      lockfile,
      help: ['Use "packageManager": "pnpm@<major>.<minor>.<patch>".'],
    };
  }
  let version = pm?.version;
  if (!version) {
    const major = pnpmLockfileMajor(text);
    version = major === null ? undefined : PNPM_FOR_LOCKFILE[major];
    if (!version) {
      return {
        error: `${lockfile} has lockfileVersion ${major ?? "(none)"}; Chef's default pnpm reads 6.x and 9.x`,
        lockfile,
        help: ['Name the pnpm it needs in package.json: "packageManager": "pnpm@<version>".'],
      };
    }
  }
  return { manager: "pnpm", lockfile, version, argv: pnpmInstallArgv(version) };
}

/** One line for logs: what installs, from where. */
export function describePlan(plan) {
  if ("error" in plan) return plan.error;
  return plan.manager === "pnpm" ? `pnpm ${plan.version} from ${plan.lockfile}` : `npm from ${plan.lockfile}`;
}

/**
 * The sandbox's install, as a check that writes nothing, for `npx chef
 * init` and `npx chef sync` to run on the developer's machine before a
 * paid sandbox finds the same problem: npm's `ci --dry-run` (it refuses a
 * package-lock.json out of sync with package.json, EUSAGE) or the very
 * pnpm the sandbox runs, frozen, with `--lockfile-only` (it refuses an
 * outdated pnpm-lock.yaml, ERR_PNPM_OUTDATED_LOCKFILE).
 */
export function lockfileCheckArgv(plan) {
  if ("error" in plan) throw new Error(plan.error);
  if (plan.manager === "npm") return ["npm", "ci", "--dry-run", "--ignore-scripts", "--no-audit", "--no-fund"];
  return [...plan.argv, "--lockfile-only"];
}

/** What to run when the check refuses: the same package manager, then commit the lockfile. */
export function lockfileFix(plan) {
  if ("error" in plan) return plan.help;
  if (plan.manager === "npm") return [`npm install && git add ${plan.lockfile} && git commit -m "Update ${plan.lockfile}"`];
  return [
    `npx pnpm@${plan.version} install --lockfile-only && git add ${plan.lockfile} && git commit -m "Update ${plan.lockfile}"`,
    `(pnpm ${plan.version} is what the sandbox runs; an older pnpm can accept a lockfile it refuses)`,
  ];
}

// ---------------------------------------------------------------- warm installs

/** The marker's format, part of every key: a change here is a new snapshot. */
export const WARM_FORMAT = 1;
/** Where a warm snapshot keeps its caches, one dir per inputsHash. */
export const WARM_ROOT = "/opt/chef/warm";
/** The marker in each warm dir, written last by the snapshot's build. */
export const WARM_MARKER = "WARM.json";
/** At most this many `file:` tarballs in a lockfile, each at most 16 MB (the gateway's per-file limit). */
export const MAX_WARM_TARBALLS = 20;
export const MAX_WARM_TARBALL_BYTES = 16 * 1024 * 1024;

/**
 * The package.json fields that decide what an install fetches. The rest
 * (name, version, scripts, ...) can change without a new warm snapshot.
 */
export const WARM_PACKAGE_FIELDS = [
  "dependencies",
  "devDependencies",
  "optionalDependencies",
  "peerDependencies",
  "peerDependenciesMeta",
  "bundleDependencies",
  "bundledDependencies",
  "overrides",
  "resolutions",
  "pnpm",
  "packageManager",
  "workspaces",
  "engines",
  "os",
  "cpu",
  "libc",
];

/** JSON with every object's keys sorted, so equal values hash the same. */
export function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value)
      .sort()
      .filter((k) => value[k] !== undefined)
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(value[k])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

/** Lowercase hex sha256 of a string (UTF-8) or bytes, with Web Crypto (Node 22, Convex). */
export async function sha256Hex(data) {
  const bytes = typeof data === "string" ? new TextEncoder().encode(data) : data;
  const d = new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bytes));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

/** package.json's install fields only, as an object (the warm snapshot's package.json); null if it doesn't parse. */
export function warmPackageJson(pkgText) {
  const pkg = parsePackageJson(pkgText);
  if (!pkg) return null;
  const out = {};
  for (const k of WARM_PACKAGE_FIELDS) if (pkg[k] !== undefined) out[k] = pkg[k];
  return out;
}

const TARBALL = /\.(tgz|tar\.gz)$/;
const SAFE_PATH = /^[A-Za-z0-9._@+-]+(\/[A-Za-z0-9._@+-]+)*$/;

/**
 * The `file:` tarballs a lockfile installs from the checkout (vendor/*.tgz),
 * as normalized paths; or `{ unsupported }` for what a warm snapshot can't
 * hold: a local directory or `link:` dependency, a path outside the
 * checkout, too many.
 */
export function lockfileTarballs(lockText, manager) {
  const paths = new Set();
  if (manager === "npm" && /"link"\s*:\s*true/.test(lockText)) return { unsupported: "the lockfile links a local directory" };
  if (manager === "pnpm" && /(^|[\s'":])link:/m.test(lockText)) return { unsupported: "the lockfile links a local directory" };
  const re = /(?:^|["'\s:(@])file:([^"'\s,}():]+)/gm;
  let m;
  while ((m = re.exec(lockText))) {
    let p = m[1];
    while (p.startsWith("./")) p = p.slice(2);
    if (!TARBALL.test(p)) return { unsupported: `file:${m[1].slice(0, 80)} is not a tarball` };
    if (!SAFE_PATH.test(p) || p.split("/").some((s) => s === "." || s === "..")) {
      return { unsupported: `file:${m[1].slice(0, 80)} is outside the checkout` };
    }
    paths.add(p);
  }
  if (paths.size > MAX_WARM_TARBALLS) return { unsupported: `the lockfile has more than ${MAX_WARM_TARBALLS} file: tarballs` };
  return { paths: [...paths].sort() };
}

/**
 * Why a checkout can't have a warm install, or null. `files` as for
 * installPlanFrom. Workspaces and local links need more of the checkout
 * than the snapshot holds; an .npmrc would steer npm (the deploy scripts
 * refuse one anyway).
 */
export function warmUnsupported(files, plan) {
  if ("error" in plan) return plan.error;
  if (files.exists(".npmrc")) return "the checkout has .npmrc";
  if (files.exists("pnpm-workspace.yaml")) return "pnpm workspaces";
  const pkg = parsePackageJson(files.read("package.json", MAX_PACKAGE_JSON_BYTES));
  if (!pkg) return "package.json is missing or doesn't parse";
  if (pkg.workspaces !== undefined) return "npm workspaces";
  return null;
}

/**
 * What a warm install depends on, from the checkout's files: the plan
 * (manager, pnpm version, argv), the lockfile's sha256, package.json's
 * install fields' and every `file:` tarball's; and `inputsHash` over all
 * of it. `tarballSha256(path)` gives a tarball's sha256, or null if it is
 * missing. Returns `{ unsupported }` when there can be no warm install.
 */
export async function warmInputs(files, tarballSha256) {
  const plan = installPlanFrom(files);
  const why = warmUnsupported(files, plan);
  if (why) return { unsupported: why };
  const lockText = files.read(plan.lockfile, MAX_LOCKFILE_BYTES);
  if (lockText === null) return { unsupported: `${plan.lockfile} is unreadable or too big` };
  const tb = lockfileTarballs(lockText, plan.manager);
  if (tb.unsupported) return { unsupported: tb.unsupported };
  const tarballs = [];
  for (const path of tb.paths) {
    const sha256 = await tarballSha256(path);
    if (!sha256) return { unsupported: `${path} is missing or too big` };
    tarballs.push({ path, sha256 });
  }
  const pkg = warmPackageJson(files.read("package.json", MAX_PACKAGE_JSON_BYTES));
  const inputs = {
    format: WARM_FORMAT,
    manager: plan.manager,
    ...(plan.manager === "pnpm" ? { version: plan.version } : {}),
    argv: plan.argv,
    lockfile: { name: plan.lockfile, sha256: await sha256Hex(lockText) },
    packageJson: await sha256Hex(canonicalJson(pkg)),
    tarballs,
  };
  return { plan, inputs, inputsHash: await sha256Hex(canonicalJson(inputs)) };
}

/**
 * The warm snapshot's key: its base image (the chef-base recipe it was built
 * from) and the install's inputs. Its name, `chef-warm-<12 hex>`, fits the
 * gateway's snapshot names (a-z, 0-9, '.', '_', '-', up to 63).
 */
export async function warmKey({ base, inputsHash }) {
  if (typeof base !== "string" || !base || !/^[0-9a-f]{64}$/.test(inputsHash)) throw new Error("bad warm key inputs");
  return await sha256Hex(canonicalJson({ format: WARM_FORMAT, base, inputsHash }));
}

export const warmSnapshotName = (key) => {
  if (!/^[0-9a-f]{64}$/.test(key)) throw new Error("bad warm key");
  return `chef-warm-${key.slice(0, 12)}`;
};

/** The warm dir for an inputsHash, under `root`. */
export const warmDirFor = (root, inputsHash) => `${root.replace(/\/$/, "")}/${inputsHash}`;

/**
 * The install argv against a warm dir's caches: npm's cache (`--cache`),
 * and pnpm's store (`--store-dir`) for pnpm. `offline` for the sandbox's
 * install from a copy; without, the snapshot build's install that fills
 * them. Everything else is the plan's argv, flag for flag.
 */
export function warmInstallArgv(plan, dirs, { offline }) {
  if ("error" in plan) throw new Error(plan.error);
  const abs = /^\/[A-Za-z0-9._/-]+$/;
  if (!abs.test(dirs.npmCache) || (plan.manager === "pnpm" && !abs.test(dirs.pnpmStore ?? ""))) {
    throw new Error("warm cache paths must be absolute");
  }
  const npmFlags = [...(offline ? ["--offline"] : []), `--cache=${dirs.npmCache}`];
  if (plan.manager === "npm") return [...plan.argv, ...npmFlags];
  const sep = plan.argv.indexOf("--");
  return [
    ...plan.argv.slice(0, sep),
    ...npmFlags,
    ...plan.argv.slice(sep),
    ...(offline ? ["--offline"] : []),
    `--store-dir=${dirs.pnpmStore}`,
  ];
}

/** The caches inside a warm dir. */
export const warmCaches = (dir) => ({ npmCache: `${dir}/npm-cache`, pnpmStore: `${dir}/pnpm-store` });

/**
 * Whether a warm dir's marker (its WARM.json text) is for exactly these
 * inputs: `{ ok: true, marker }` or `{ ok: false, reason }`.
 */
export function checkWarmMarker(text, want) {
  if (text === null || text === undefined) return { ok: false, reason: "no warm install for this lockfile" };
  let m;
  try {
    m = JSON.parse(text);
  } catch {
    return { ok: false, reason: "the warm marker is not JSON" };
  }
  if (!m || typeof m !== "object") return { ok: false, reason: "the warm marker is not an object" };
  if (m.format !== WARM_FORMAT) return { ok: false, reason: "the warm marker is another format" };
  if (m.inputsHash !== want.inputsHash) return { ok: false, reason: "the warm marker is for other inputs" };
  if (canonicalJson(m.argv) !== canonicalJson(want.plan.argv)) return { ok: false, reason: "the warm marker is for another install command" };
  if (typeof m.key !== "string" || !/^[0-9a-f]{64}$/.test(m.key)) return { ok: false, reason: "the warm marker has no key" };
  return { ok: true, marker: m };
}

/** The marker a warm snapshot's build writes, last, once its install succeeded. */
export function warmMarker({ key, base, inputsHash, inputs }) {
  return {
    format: WARM_FORMAT,
    key,
    name: warmSnapshotName(key),
    base,
    inputsHash,
    manager: inputs.manager,
    ...(inputs.version ? { version: inputs.version } : {}),
    lockfile: inputs.lockfile,
    argv: inputs.argv,
  };
}
