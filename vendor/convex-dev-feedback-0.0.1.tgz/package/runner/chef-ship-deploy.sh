#!/usr/bin/env bash
# Ships one commit to the host's own live deployment: "Ship it" in the Chef
# panel. Runs in a deploy sandbox like the preview's: no agent, the host's
# real deploy key, and no repo code. See "Ship it: a cloud release" and "What
# protects the key" in docs/chef-pipeline.md.
#
# Nothing from the checkout is ever executed here. npm or pnpm installs without
# scripts, the pinned Convex CLI only bundles the functions and sends them to
# Convex, and the frontend arrives already built (the build sandbox built it
# with a placeholder URL, and Chef kept it); this only swaps the placeholder
# for the live deployment's URL and uploads the files.
#
# Usage: chef-ship-deploy.sh <40 character sha>
#
# Environment (set by the host's shipper, packages/chef-cloud/src/client/chefShip.ts; none of it
# is repo-controlled):
#   CHEF_DEPLOY_KEY              the host's deploy key, prod:<deployment>|<secret> or
#                                dev:<deployment>|<secret> (required; passed to this one command)
#   CHEF_DEPLOYMENT_NAME         the host's deployment; the key must be for exactly it (required)
#   CHEF_MAIN_SHA                main now; the sha must descend from it (required)
#   CHEF_REPO_URL                git URL of the app's repo (required)
#   CHEF_GIT_AUTH                optional read-only git placeholder, Basic-encoded
#   CHEF_CONVEX_BIN              the snapshot's pinned Convex CLI (default /opt/chef/bin/convex)
#   CHEF_STATIC_UPLOADER         the pinned static hosting uploader (default: chef-static-upload.mjs
#                                next to this script, run with node)
#   CHEF_FRONTEND_UNPACKER       the pinned unpacker (default: chef-frontend-unpack.mjs next to it)
#   CHEF_INSTALLER               the pinned installer (default: chef-install.mjs next to this
#                                script, run with node): npm or pnpm by the lockfile
#   CHEF_WARM_ROOT               where a warm snapshot keeps its install caches (default
#                                /opt/chef/warm; the installer's). The install is offline from
#                                them only when their marker is for exactly this checkout's
#                                lockfile and install fields; otherwise it is the normal one
#   CHEF_WORKDIR                 where to check out (default /tmp/chef-ship); must not exist
#   CHEF_RESULT_FILE             the result JSON, rewritten after every step
#                                (default /tmp/chef-ship-result.json)
#   CHEF_LOG_FILE                a copy of everything this prints, scrubbed, for the shipper to
#                                read when the ship fails (default /tmp/chef-ship.log)
#   CHEF_MIGRATION               optional function to run once the backend is deployed
#   CHEF_HEALTH_CHECK            optional function that throws unless the app is healthy; run last
#   CHEF_SEED_FUNCTION           optional, the beta channel only: the app's previewSeedFunction,
#                                run once the backend is deployed with CHEF_SEED_ARGS (a JSON
#                                object: the admin's export's one-time URL and sha256). Its
#                                output never reaches this script's output; a failure is
#                                "seed":"failed" in the result, never the deploy's failure
#   CHEF_FRONTEND                0 to skip the frontend
#   CHEF_FRONTEND_PREFIX         where the shipper wrote the built frontend's base64 parts
#   CHEF_FRONTEND_PARTS          how many parts
#   CHEF_FRONTEND_SHA256         the archive's sha256, as Chef recorded it
#
# The result file says what reached production, step by step, since the
# backend deploy and the static upload aren't one atomic step:
#   {"sha","deploymentName","mainIsAncestor","backend","migration","seed","frontend",
#    "frontendSha256","healthCheck","done","error"}
# A failure always leaves its reason in "error": `die`'s message (also
# printed as "chef-ship-deploy: error: <why>"), or what the script was doing
# when anything else failed.
#
# The deploy key is never in an argument list or in the output. It is read
# into a shell variable that is not exported, removed from the environment,
# reaches only the pinned CLI and the pinned uploader through theirs, and is
# scrubbed from everything this script prints.

set -euo pipefail
umask 077

# --- Inputs ------------------------------------------------------------------

result_file="${CHEF_RESULT_FILE:-/tmp/chef-ship-result.json}"
sha="${1:-}"
deployment_name="${CHEF_DEPLOYMENT_NAME:-}"
st_main=false st_backend=false st_migration=skipped st_seed=skipped st_frontend=pending st_fe_sha=null st_health=pending
st_done=false st_error=""
step="starting"

json_str() { node -e 'process.stdout.write(JSON.stringify(process.argv[1]))' -- "$1"; }

# The result so far. Called after each step, and on any exit.
write_result() {
  local err=null
  [ -z "$st_error" ] || err="$(json_str "$st_error")"
  local fe_sha=null
  [ "$st_fe_sha" = null ] || fe_sha="\"$st_fe_sha\""
  printf '{"sha":%s,"deploymentName":%s,"mainIsAncestor":%s,"backend":%s,"migration":"%s","seed":"%s","frontend":"%s","frontendSha256":%s,"healthCheck":"%s","done":%s,"error":%s}\n' \
    "$(json_str "$sha")" "$(json_str "$deployment_name")" "$st_main" "$st_backend" "$st_migration" "$st_seed" \
    "$st_frontend" "$fe_sha" "$st_health" "$st_done" "$err" >"$result_file.tmp"
  mv -f "$result_file.tmp" "$result_file"
}

die() {
  echo "chef-ship-deploy: error: $*" >&2
  st_error="$*"
  write_result 2>/dev/null || true
  exit 1
}
say() {
  step="$*"
  echo "chef-ship-deploy: $*"
}

# Any other failure (set -e) still leaves a result that says so, and what it was doing.
on_exit() {
  local code=$?
  if [ "$code" -ne 0 ] && [ -z "$st_error" ]; then
    st_error="the ship script failed (exit $code) while $step"
    echo "chef-ship-deploy: error: $st_error" >&2
    write_result 2>/dev/null || true
  fi
}
trap on_exit EXIT

re_sha='^[0-9a-f]{40}$'
[[ "$sha" =~ $re_sha ]] || die "usage: chef-ship-deploy.sh <sha>; the sha must be 40 lowercase hex characters"
main_sha="${CHEF_MAIN_SHA:-}"
[[ "$main_sha" =~ $re_sha ]] || die "CHEF_MAIN_SHA must be 40 lowercase hex characters"

# Take the credentials into unexported variables and out of the environment,
# so nothing this script starts inherits them by accident.
deploy_key="${CHEF_DEPLOY_KEY:-}"
deploy_secret="${deploy_key#*|}"
git_auth="${CHEF_GIT_AUTH:-}"
seed_args="${CHEF_SEED_ARGS:-}"
unset CHEF_SEED_ARGS
unset CHEF_DEPLOY_KEY CONVEX_DEPLOY_KEY CHEF_PREVIEW_DEPLOY_KEY CHEF_GIT_AUTH

# Anything that would send the CLI somewhere other than api.convex.dev and the
# host's deployment, select another deployment, or change how node and npm load.
unset CONVEX_PROVISION_HOST CONVEX_SELF_HOSTED_URL CONVEX_SELF_HOSTED_ADMIN_KEY \
  CONVEX_DEPLOYMENT CONVEX_URL CONVEX_SITE_URL CONVEX_OVERRIDE_ACCESS_TOKEN \
  NODE_OPTIONS NODE_PATH
for v in $(env | awk -F= 'tolower($1) ~ /^npm_config_[a-z0-9_]*$/ { print $1 }'); do unset "$v"; done
export COREPACK_ENABLE_PROJECT_SPEC=0 COREPACK_ENABLE_STRICT=0

re_name='^[a-z0-9][a-z0-9-]{0,63}$'
[[ "$deployment_name" =~ $re_name ]] || die "CHEF_DEPLOYMENT_NAME is not a deployment name"
# Only a key for exactly this deployment: never a preview key, never another one.
re_key='^(prod|dev):[a-z0-9][a-z0-9-]{0,63}[|].+$'
[[ "$deploy_key" =~ $re_key ]] || die "need a deploy key for one deployment (prod:<deployment>|... or dev:<deployment>|...)"
key_target="${deploy_key%%|*}"
[ "${key_target#*:}" = "$deployment_name" ] || die "the deploy key is not for $deployment_name"
[ -n "$deploy_secret" ] || die "the deploy key has no secret part"

repo_url="${CHEF_REPO_URL:-}"
[ -n "$repo_url" ] || die "CHEF_REPO_URL is not set"
convex_bin="${CHEF_CONVEX_BIN:-/opt/chef/bin/convex}"
self="${BASH_SOURCE[0]}"
while [ -L "$self" ]; do
  link="$(readlink "$self")"
  case "$link" in /*) self="$link" ;; *) self="$(dirname "$self")/$link" ;; esac
done
self_dir="$(cd "$(dirname "$self")" && pwd -P)"
uploader="${CHEF_STATIC_UPLOADER:-$self_dir/chef-static-upload.mjs}"
unpacker="${CHEF_FRONTEND_UNPACKER:-$self_dir/chef-frontend-unpack.mjs}"
installer="${CHEF_INSTALLER:-$self_dir/chef-install.mjs}"
workdir="${CHEF_WORKDIR:-/tmp/chef-ship}"
log_file="${CHEF_LOG_FILE:-/tmp/chef-ship.log}"
migration="${CHEF_MIGRATION:-}"
health="${CHEF_HEALTH_CHECK:-}"
seed_fn="${CHEF_SEED_FUNCTION:-}"
frontend="${CHEF_FRONTEND:-1}"
fe_prefix="${CHEF_FRONTEND_PREFIX:-/tmp/chef-frontend.}"
fe_parts="${CHEF_FRONTEND_PARTS:-}"
fe_sha256="${CHEF_FRONTEND_SHA256:-}"

case "$convex_bin" in /*) ;; *) die "CHEF_CONVEX_BIN must be an absolute path" ;; esac
case "$uploader" in /*) ;; *) die "CHEF_STATIC_UPLOADER must be an absolute path" ;; esac
case "$unpacker" in /*) ;; *) die "CHEF_FRONTEND_UNPACKER must be an absolute path" ;; esac
case "$installer" in /*) ;; *) die "CHEF_INSTALLER must be an absolute path" ;; esac
case "$workdir" in /*) ;; *) die "CHEF_WORKDIR must be an absolute path" ;; esac
case "$log_file" in /*) ;; *) die "CHEF_LOG_FILE must be an absolute path" ;; esac
re_fn='^[A-Za-z0-9_][A-Za-z0-9_./]*(:[A-Za-z0-9_]+)?$'
if [ -n "$migration" ]; then [[ "$migration" =~ $re_fn ]] || die "CHEF_MIGRATION is not a function name"; fi
if [ -n "$health" ]; then [[ "$health" =~ $re_fn ]] || die "CHEF_HEALTH_CHECK is not a function name"; fi
if [ -n "$seed_fn" ]; then
  [[ "$seed_fn" =~ $re_fn ]] || die "CHEF_SEED_FUNCTION is not a function name"
  case "$seed_args" in "{"*"}") ;; *) die "CHEF_SEED_ARGS must be a JSON object" ;; esac
  [ "${#seed_args}" -le 4096 ] || die "CHEF_SEED_ARGS is too long"
fi
if [ "$frontend" = "1" ]; then
  case "$fe_prefix" in /*) ;; *) die "CHEF_FRONTEND_PREFIX must be an absolute path" ;; esac
  re_parts='^[1-9][0-9]?$'
  [[ "$fe_parts" =~ $re_parts ]] || die "CHEF_FRONTEND_PARTS must be a number from 1 to 99"
  re_sha256='^[0-9a-f]{64}$'
  [[ "$fe_sha256" =~ $re_sha256 ]] || die "CHEF_FRONTEND_SHA256 must be 64 hex characters"
else
  st_frontend=skipped
fi
[ -n "$health" ] || st_health=skipped
[ ! -e "$workdir" ] || die "the work dir already exists"
write_result

# Replaces the key and its secret part in everything piped through it. The
# values reach awk through its environment, not its arguments.
scrub() {
  CHEF_SCRUB_A="$deploy_key" CHEF_SCRUB_B="$deploy_secret" CHEF_SCRUB_C="$git_auth" CHEF_SCRUB_D="$seed_args" awk '
    function cut(s, t,   out, i) {
      if (t == "") return s
      out = ""
      while ((i = index(s, t)) > 0) {
        out = out substr(s, 1, i - 1) "[redacted]"
        s = substr(s, i + length(t))
      }
      return out s
    }
    {
      line = cut($0, ENVIRON["CHEF_SCRUB_A"])
      line = cut(line, ENVIRON["CHEF_SCRUB_B"])
      line = cut(line, ENVIRON["CHEF_SCRUB_C"])
      line = cut(line, ENVIRON["CHEF_SCRUB_D"])
      print line
      fflush()
    }'
}

# A copy of the scrubbed output goes to the log file.
: >"$log_file"
exec > >(scrub | tee -a "$log_file") 2>&1

# The CLI gets a home of its own (a ~/.convex login there would win over the
# key) and runs `run` from an empty project of its own, so nothing in the
# checkout (.env files, convex.json) can steer it.
cli_home="$(mktemp -d)"
cli_proj="$(mktemp -d)"
printf '%s\n' '{"private":true,"dependencies":{"convex":"*"}}' >"$cli_proj/package.json"

convex() {
  HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" "$convex_bin" "$@" 2>&1 | scrub
}
convex_outside() {
  (cd "$cli_proj" && convex "$@")
}

git_() {
  if [ -n "$git_auth" ]; then
    GIT_TERMINAL_PROMPT=0 GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.extraHeader \
      GIT_CONFIG_VALUE_0="Authorization: Basic $git_auth" \
      git -c core.hooksPath=/dev/null "$@"
  else
    GIT_TERMINAL_PROMPT=0 git -c core.hooksPath=/dev/null "$@"
  fi
}

# --- 1. Check out exactly the sha, descended from main -----------------------

say "checking out $sha"
git_ clone --quiet --no-checkout -- "$repo_url" "$workdir" 2>&1 | scrub
cd "$workdir"
git_ -c advice.detachedHead=false checkout --quiet --detach "$sha" 2>&1 | scrub ||
  die "could not check out $sha"
head_sha="$(git rev-parse HEAD)"
[ "$head_sha" = "$sha" ] || die "HEAD is $head_sha, not $sha"
[ -z "$(git status --porcelain)" ] || die "the checkout is not clean"
# main only fast-forwards to the sha, so it must descend from main.
git cat-file -e "$main_sha^{commit}" 2>/dev/null || die "main ($main_sha) is not in the repo"
git merge-base --is-ancestor "$main_sha" "$sha" || die "$sha does not descend from main ($main_sha)"
st_main=true
write_result
# The preview's checks, with its messages (src/chef/deployChecks.ts has them
# too, and tests/runner/deployChecks.test.ts keeps them in step).
for f in .env .env.local .npmrc; do
  if [ -e "$f" ] || [ -L "$f" ]; then die "the repo has $f; refusing to deploy"; fi
done
links="$(git -c core.quotePath=false ls-files -s | awk -F '\t' '
  $1 ~ /^120000 / { n++; if (n <= 3) s = s (n > 1 ? ", " : "") $2 }
  END { if (n > 3) s = s ", and " (n - 3) " more"; print s }')"
[ -z "$links" ] || die "the repo has symlinks ($links); refusing to deploy"
if [ -e convex.json ]; then
  node -e '
    const c = JSON.parse(require("node:fs").readFileSync("convex.json", "utf8"));
    const f = c && c.functions;
    if (f !== undefined && (typeof f !== "string" || f.startsWith("/") || f.split(/[\\/]/).includes(".."))) process.exit(3);
  ' || die "convex.json points the functions directory outside the checkout"
fi
if [ -e package-lock.json ] && grep -Eq '"resolved": *"git[+:]' package-lock.json; then
  die "package-lock.json has git dependencies; refusing to deploy"
fi

# --- 2. Install, without running anything ------------------------------------

# npm ci, or pnpm's frozen install, by the lockfile, with no lifecycle
# scripts and no .pnpmfile (chef-install.mjs, pinned beside this script; it
# refuses what neither can install, such as git dependencies in
# pnpm-lock.yaml). pnpm itself comes from the registry through npm exec.
[ -f "$installer" ] || die "the pinned installer is missing"
case "$(cd "$(dirname "$installer")" && pwd -P)/" in "$(pwd -P)"/*) die "the installer must not come from the checkout" ;; esac
say "installing dependencies"
node "$installer" 2>&1 | scrub

# --- 3. Deploy with the pinned CLI -------------------------------------------

[ -x "$convex_bin" ] || die "the pinned Convex CLI is missing"
work_real="$(pwd -P)"
outside_checkout() {
  local real
  real="$(cd "$(dirname "$1")" && pwd -P)/$(basename "$1")"
  case "$real" in "$work_real"/*) return 1 ;; esac
}
outside_checkout "$convex_bin" || die "the Convex CLI must not come from the checkout"

# No --cmd: the CLI hands its whole environment, key included, to that command.
say "deploying to $deployment_name"
deploy_log="$(mktemp)"
convex deploy --typecheck=disable | tee "$deploy_log"
convex_url="$(sed -n 's#.*Deployed Convex functions to \(https://[a-z0-9-][a-z0-9.-]*\.convex\.cloud\).*#\1#p' "$deploy_log" | head -n 1)"
rm -f "$deploy_log"
[ "$convex_url" = "https://$deployment_name.convex.cloud" ] ||
  die "the deploy didn't report https://$deployment_name.convex.cloud"
st_backend=true
write_result

# --- 4. The post-deploy migration --------------------------------------------

if [ -n "$migration" ]; then
  say "running $migration"
  convex_outside run "$migration" '{}' --typecheck=disable --codegen=disable
  st_migration=ok
  write_result
fi

# --- 4b. The admin's own data, once (the beta channel) ------------------------
# The app's seed function fetches the export by its one-time URL and checks
# its sha256. Its answer and errors could name the admin's data: they go to
# a file that is deleted, never to the output.

if [ -n "$seed_fn" ]; then
  say "copying the admin's own data in with $seed_fn"
  seed_dir="$(mktemp -d)"
  if (cd "$cli_proj" && HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" "$convex_bin" run "$seed_fn" "$seed_args" \
    --typecheck=disable --codegen=disable >"$seed_dir/out" 2>"$seed_dir/err"); then
    st_seed=ok
    say "copied"
  else
    st_seed=failed
    say "$seed_fn failed; the deployment keeps the data it had"
  fi
  rm -rf "$seed_dir"
  write_result
fi

# --- 5. The frontend, built elsewhere, pointed at the deployment and uploaded

if [ "$frontend" = "1" ]; then
  [ -f "$unpacker" ] || die "the pinned frontend unpacker is missing"
  outside_checkout "$unpacker" || die "the frontend unpacker must not come from the checkout"
  case "$uploader" in
    *.mjs) [ -f "$uploader" ] || die "the pinned static hosting uploader is missing"
      upload_cmd=(node "$uploader") ;;
    *) [ -x "$uploader" ] || die "the pinned static hosting uploader is missing"
      upload_cmd=("$uploader") ;;
  esac
  outside_checkout "$uploader" || die "the static hosting uploader must not come from the checkout"
  site_dir="$(mktemp -d)/site"
  say "unpacking the built frontend for $convex_url"
  node "$unpacker" --in-prefix "$fe_prefix" --parts "$fe_parts" --sha256 "$fe_sha256" \
    --out "$site_dir" --url "$convex_url" 2>&1 | scrub
  say "uploading the frontend to $deployment_name"
  (cd "$cli_proj" && HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" CHEF_CONVEX_BIN="$convex_bin" \
    "${upload_cmd[@]}" --deployment-name "$deployment_name" --dist "$site_dir" 2>&1 | scrub)
  st_frontend=ok
  st_fe_sha="$fe_sha256"
  write_result
fi

# --- 6. Health check ---------------------------------------------------------

if [ -n "$health" ]; then
  say "running the health check $health"
  if (cd "$cli_proj" && HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" "$convex_bin" run "$health" '{}' \
    --typecheck=disable --codegen=disable 2>&1 | scrub | tail -n 20); then
    st_health=ok
  else
    st_health=failed
    say "the health check failed"
  fi
fi

st_done=true
write_result
say "shipped $sha to $deployment_name"
