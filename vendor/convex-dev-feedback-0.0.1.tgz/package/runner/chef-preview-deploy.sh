#!/usr/bin/env bash
# Deploys one commit to its request's Convex preview deployment,
# CHEF_PREVIEW_NAME (chef-req-<number>; chef-<sha12> when unset). Deploying
# a request again replaces its preview (`--preview-create` of a name that
# exists deletes and recreates it), so a request holds one preview slot on
# the Convex team, not one per commit (src/chef/preview.ts).
# Runs in the deploy sandbox: no agent, one credential, the real preview
# deploy key, and no repo code. See "The preview" and "What protects the
# key" in docs/chef-pipeline.md.
#
# Nothing from the checkout is ever executed here. npm or pnpm installs without
# scripts, the pinned Convex CLI only bundles the functions and sends them to
# Convex, and the frontend arrives already built (runner/frontend-artifact.ts,
# in the build sandbox, with a placeholder URL); this only swaps the
# placeholder for the preview's URL and uploads the files.
#
# Usage: chef-preview-deploy.sh <40 character sha>
#
# Environment (set by the launcher; none of it is repo-controlled):
#   CHEF_PREVIEW_DEPLOY_KEY      the preview deploy key, preview:<team>:<project>|<secret>
#   CHEF_PREVIEW_NAME            the preview's name: chef-req-<number> or chef-<sha12>
#                                (default chef-<sha12>)
#                                (required; the launcher passes it to this one command)
#   CHEF_REPO_URL                git URL of the app's repo (required)
#   CHEF_GIT_AUTH                optional read-only git placeholder, Basic-encoded
#   CHEF_CONVEX_BIN              the snapshot's pinned Convex CLI (default /opt/chef/bin/convex)
#   CHEF_STATIC_UPLOADER         the pinned static hosting uploader (default: chef-static-upload.mjs
#                                next to this script, run with node)
#   CHEF_FRONTEND_UNPACKER       the pinned unpacker (default: chef-frontend-unpack.mjs next to
#                                this script, run with node)
#   CHEF_INSTALLER               the pinned installer (default: chef-install.mjs next to this
#                                script, run with node): npm or pnpm by the lockfile
#   CHEF_WARM_ROOT               where a warm snapshot keeps its install caches (default
#                                /opt/chef/warm; the installer's). The install is offline from
#                                them only when their marker is for exactly this checkout's
#                                lockfile and install fields; otherwise it is the normal one
#   CHEF_WORKDIR                 where to check out (default /tmp/chef-preview); must not exist
#   CHEF_RESULT_FILE             where to write the result JSON (default /tmp/chef-preview-result.json);
#                                a failure writes {"sha","error"} there instead, with the reason
#   CHEF_LOG_FILE                a copy of everything this prints, scrubbed, for the launcher to
#                                read when the deploy fails (default /tmp/chef-preview.log)
#   CHEF_SEED                    optional function to run once the preview is deployed
#   CHEF_FRONTEND                0 to skip the frontend
#   CHEF_FRONTEND_PREFIX         where the launcher wrote the built frontend's base64 parts,
#                                <prefix>0.b64 ... (default /tmp/chef-frontend.)
#   CHEF_FRONTEND_PARTS          how many parts
#   CHEF_FRONTEND_SHA256         the archive's sha256, as Chef recorded it
#   CHEF_PREVIEW_AUTH_KEYS       0 to skip the throwaway JWT_PRIVATE_KEY and JWKS
#   CHEF_LOGIN_LINK_FUNCTION     optional function that returns {url}, a one-time sign-in link
#                                for the preview; run after the upload, its url goes only into
#                                CHEF_RESULT_FILE as loginUrl, never into the output
#   CHEF_DEMO_LOGIN              1 to ask the function for a second link, for the demo video
#                                (demoLoginUrl in the result file, the same rules)
#   CHEF_PREVIEW_SEED_FUNCTION   optional: the app's previewSeedFunction, run on the preview with
#                                CHEF_PREVIEW_SEED_ARGS (a JSON object: the admin's export's
#                                one-time URL and sha256) to copy the admin's own rows in; it
#                                answers {"userId": "<the copied user on the preview>"}, and the
#                                admin's sign-in link then signs in as that user ({"userId"}).
#                                Never printed: the URL is scrubbed, the answer kept in a file
#
# The deploy key is never in an argument list or in the output. It is read
# into a shell variable that is not exported, removed from the environment,
# reaches only the pinned CLI and the pinned uploader through theirs, and is
# scrubbed from everything this script prints.
#
# A failure always leaves its reason: `die` prints "chef-preview-deploy:
# error: <why>" and writes {"sha","error"} to the result file, and any other
# failure (set -e) writes what it was doing. The launcher reads that, and the
# tail of CHEF_LOG_FILE, into the run's failure and its log.

set -euo pipefail
umask 077

sha="${1:-}"
result_file="${CHEF_RESULT_FILE:-/tmp/chef-preview-result.json}"
deploy_key="" deploy_secret="" git_auth="" pseed_args=""
step="starting"
died=""

# Replaces the key and its secret part in everything piped through it. The
# values reach awk through its environment, not its arguments.
scrub() {
  CHEF_SCRUB_A="$deploy_key" CHEF_SCRUB_B="$deploy_secret" CHEF_SCRUB_C="$git_auth" CHEF_SCRUB_D="${pseed_args:-}" awk '
    function cut(s, t,   out, i) {
      if (t == "") return s
      out = ""
      while ((i = index(s, t)) > 0) {
        out = out substr(s, 1, i - 1) "[redacted]"
        s = substr(s, i + length(t))
      }
      return out s
    }
    {
      line = cut($0, ENVIRON["CHEF_SCRUB_A"])
      line = cut(line, ENVIRON["CHEF_SCRUB_B"])
      line = cut(line, ENVIRON["CHEF_SCRUB_C"])
      line = cut(line, ENVIRON["CHEF_SCRUB_D"])
      print line
      fflush()
    }'
}

# The failure, for the launcher: {"sha","error"} in the result file, scrubbed.
write_failure() {
  case "$result_file" in /*) ;; *) return 0 ;; esac
  node -e 'process.stdout.write(JSON.stringify({ sha: process.argv[1], error: process.argv[2] }) + "\n")' -- "$sha" "$1" |
    scrub >"$result_file.tmp" && mv -f "$result_file.tmp" "$result_file"
}

die() {
  echo "chef-preview-deploy: error: $*" >&2
  died=1
  write_failure "$*" 2>/dev/null || true
  exit 1
}
say() {
  step="$*"
  echo "chef-preview-deploy: $*"
}
# Any other failure (set -e) still says what it was doing.
on_exit() {
  local code=$?
  if [ "$code" -ne 0 ] && [ -z "$died" ]; then
    echo "chef-preview-deploy: error: the deploy script failed (exit $code) while $step" >&2
    write_failure "the deploy script failed (exit $code) while $step" 2>/dev/null || true
  fi
}
trap on_exit EXIT

# --- Inputs ------------------------------------------------------------------

[ $# -eq 1 ] || die "usage: chef-preview-deploy.sh <sha>"
re_sha='^[0-9a-f]{40}$'
[[ "$sha" =~ $re_sha ]] || die "the sha must be 40 lowercase hex characters"
preview="${CHEF_PREVIEW_NAME:-chef-${sha:0:12}}"
re_preview='^chef-(req-[1-9][0-9]{0,8}|[0-9a-f]{12})$'
[[ "$preview" =~ $re_preview ]] || die "CHEF_PREVIEW_NAME must be chef-req-<number> or chef-<sha12>"

# Take the credentials into unexported variables and out of the environment,
# so nothing this script starts inherits them by accident.
deploy_key="${CHEF_PREVIEW_DEPLOY_KEY:-}"
deploy_secret="${deploy_key#*|}"
git_auth="${CHEF_GIT_AUTH:-}"
unset CHEF_PREVIEW_DEPLOY_KEY CONVEX_DEPLOY_KEY CHEF_PREVIEW_DEPLOY_SECRET CHEF_GIT_AUTH

# Anything that would send the CLI somewhere other than api.convex.dev and the
# preview, select another deployment, or change how node and npm load.
unset CONVEX_PROVISION_HOST CONVEX_SELF_HOSTED_URL CONVEX_SELF_HOSTED_ADMIN_KEY \
  CONVEX_DEPLOYMENT CONVEX_URL CONVEX_SITE_URL CONVEX_OVERRIDE_ACCESS_TOKEN \
  NODE_OPTIONS NODE_PATH
for v in $(env | awk -F= 'tolower($1) ~ /^npm_config_[a-z0-9_]*$/ { print $1 }'); do unset "$v"; done
# Corepack must not pick an npm by the repo's packageManager field.
export COREPACK_ENABLE_PROJECT_SPEC=0 COREPACK_ENABLE_STRICT=0

re_key='^preview:[^:|]+:[^:|]+[|].+$'
[[ "$deploy_key" =~ $re_key ]] ||
  die "need a preview deploy key (preview:<team>:<project>|...)"
[ -n "$deploy_secret" ] || die "the deploy key has no secret part"

repo_url="${CHEF_REPO_URL:-}"
[ -n "$repo_url" ] || die "CHEF_REPO_URL is not set"
convex_bin="${CHEF_CONVEX_BIN:-/opt/chef/bin/convex}"
# This script's own directory, through any symlink, for the default uploader
# and unpacker that ship beside it.
self="${BASH_SOURCE[0]}"
while [ -L "$self" ]; do
  link="$(readlink "$self")"
  case "$link" in /*) self="$link" ;; *) self="$(dirname "$self")/$link" ;; esac
done
self_dir="$(cd "$(dirname "$self")" && pwd -P)"
uploader="${CHEF_STATIC_UPLOADER:-$self_dir/chef-static-upload.mjs}"
unpacker="${CHEF_FRONTEND_UNPACKER:-$self_dir/chef-frontend-unpack.mjs}"
installer="${CHEF_INSTALLER:-$self_dir/chef-install.mjs}"
workdir="${CHEF_WORKDIR:-/tmp/chef-preview}"
log_file="${CHEF_LOG_FILE:-/tmp/chef-preview.log}"
seed="${CHEF_SEED:-}"
frontend="${CHEF_FRONTEND:-1}"
fe_prefix="${CHEF_FRONTEND_PREFIX:-/tmp/chef-frontend.}"
fe_parts="${CHEF_FRONTEND_PARTS:-}"
fe_sha256="${CHEF_FRONTEND_SHA256:-}"
auth_keys="${CHEF_PREVIEW_AUTH_KEYS:-1}"
login_fn="${CHEF_LOGIN_LINK_FUNCTION:-}"
demo_login="${CHEF_DEMO_LOGIN:-0}"
pseed_fn="${CHEF_PREVIEW_SEED_FUNCTION:-}"
pseed_args="${CHEF_PREVIEW_SEED_ARGS:-}"
unset CHEF_PREVIEW_SEED_ARGS

case "$convex_bin" in /*) ;; *) die "CHEF_CONVEX_BIN must be an absolute path" ;; esac
case "$uploader" in /*) ;; *) die "CHEF_STATIC_UPLOADER must be an absolute path" ;; esac
case "$unpacker" in /*) ;; *) die "CHEF_FRONTEND_UNPACKER must be an absolute path" ;; esac
case "$installer" in /*) ;; *) die "CHEF_INSTALLER must be an absolute path" ;; esac
case "$workdir" in /*) ;; *) die "CHEF_WORKDIR must be an absolute path" ;; esac
case "$result_file" in /*) ;; *) die "CHEF_RESULT_FILE must be an absolute path" ;; esac
case "$log_file" in /*) ;; *) die "CHEF_LOG_FILE must be an absolute path" ;; esac
re_seed='^[A-Za-z0-9_][A-Za-z0-9_./]*(:[A-Za-z0-9_]+)?$'
if [ -n "$seed" ]; then
  [[ "$seed" =~ $re_seed ]] ||
    die "CHEF_SEED is not a function name"
fi
if [ -n "$login_fn" ]; then
  [[ "$login_fn" =~ $re_seed ]] || die "CHEF_LOGIN_LINK_FUNCTION is not a function name"
fi
if [ -n "$pseed_fn" ]; then
  [[ "$pseed_fn" =~ $re_seed ]] || die "CHEF_PREVIEW_SEED_FUNCTION is not a function name"
  case "$pseed_args" in "{"*"}") ;; *) die "CHEF_PREVIEW_SEED_ARGS must be a JSON object" ;; esac
  [ "${#pseed_args}" -le 4096 ] || die "CHEF_PREVIEW_SEED_ARGS is too long"
fi
if [ "$frontend" = "1" ]; then
  case "$fe_prefix" in /*) ;; *) die "CHEF_FRONTEND_PREFIX must be an absolute path" ;; esac
  re_parts='^[1-9][0-9]?$'
  [[ "$fe_parts" =~ $re_parts ]] || die "CHEF_FRONTEND_PARTS must be a number from 1 to 99"
  re_sha256='^[0-9a-f]{64}$'
  [[ "$fe_sha256" =~ $re_sha256 ]] || die "CHEF_FRONTEND_SHA256 must be 64 hex characters"
fi
[ ! -e "$workdir" ] || die "the work dir already exists"
rm -f "$result_file"

# Everything this script and its children print goes through the scrubber
# as well, whatever printed it, and a copy of that goes to the log file.
: >"$log_file"
exec > >(scrub | tee -a "$log_file") 2>&1

# The CLI gets a home of its own: a ~/.convex login there would win over the
# deploy key, and nothing it writes should land anywhere else.
cli_home="$(mktemp -d)"
# `env set` and `run` work from an empty project of their own, so nothing in
# the checkout (.env files, convex.json) can steer them.
cli_proj="$(mktemp -d)"
printf '%s\n' '{"private":true,"dependencies":{"convex":"*"}}' >"$cli_proj/package.json"

# The pinned CLI with the key in its environment. Never the repo's own
# node_modules/.bin/convex, never whatever `convex` is on PATH.
convex() {
  HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" "$convex_bin" "$@" 2>&1 | scrub
}
convex_outside() {
  (cd "$cli_proj" && convex "$@")
}

git_() {
  if [ -n "$git_auth" ]; then
    GIT_TERMINAL_PROMPT=0 GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.extraHeader \
      GIT_CONFIG_VALUE_0="Authorization: Basic $git_auth" \
      git -c core.hooksPath=/dev/null "$@"
  else
    GIT_TERMINAL_PROMPT=0 git -c core.hooksPath=/dev/null "$@"
  fi
}

# --- 1. Check out exactly the sha --------------------------------------------

say "checking out $sha"
git_ clone --quiet --no-checkout -- "$repo_url" "$workdir" 2>&1 | scrub
cd "$workdir"
git_ -c advice.detachedHead=false checkout --quiet --detach "$sha" 2>&1 | scrub ||
  die "could not check out $sha"
head_sha="$(git rev-parse HEAD)"
[ "$head_sha" = "$sha" ] || die "HEAD is $head_sha, not $sha"
[ -z "$(git status --porcelain)" ] || die "the checkout is not clean"
# These checks, and their messages, are src/chef/deployChecks.ts's too:
# `npx chef init`, `npx chef sync` and the runner make them before a build is
# paid for, and tests/runner/deployChecks.test.ts keeps the two in step.
#
# The CLI reads .env files, and npm and pnpm read .npmrc (which can name the
# programs npm runs, such as `git`). Not even a symlink by that name.
for f in .env .env.local .npmrc; do
  if [ -e "$f" ] || [ -L "$f" ]; then die "the repo has $f; refusing to deploy"; fi
done
# No symlinks anywhere in the tree: the bundler would follow one to any file
# in the sandbox and upload what it reads. The first three are named.
links="$(git -c core.quotePath=false ls-files -s | awk -F '\t' '
  $1 ~ /^120000 / { n++; if (n <= 3) s = s (n > 1 ? ", " : "") $2 }
  END { if (n > 3) s = s ", and " (n - 3) " more"; print s }')"
[ -z "$links" ] || die "the repo has symlinks ($links); refusing to deploy"
# convex.json's functions directory must stay inside the checkout.
if [ -e convex.json ]; then
  node -e '
    const c = JSON.parse(require("node:fs").readFileSync("convex.json", "utf8"));
    const f = c && c.functions;
    if (f !== undefined && (typeof f !== "string" || f.startsWith("/") || f.split(/[\\/]/).includes(".."))) process.exit(3);
  ' || die "convex.json points the functions directory outside the checkout"
fi
# A git dependency makes npm run git, and prepare scripts, outside our control.
if [ -e package-lock.json ] && grep -Eq '"resolved": *"git[+:]' package-lock.json; then
  die "package-lock.json has git dependencies; refusing to deploy"
fi

# --- 2. Install, without running anything ------------------------------------

# npm ci, or pnpm's frozen install, by the lockfile, with no lifecycle
# scripts and no .pnpmfile (chef-install.mjs, pinned beside this script; it
# refuses what neither can install, such as git dependencies in
# pnpm-lock.yaml). pnpm itself comes from the registry through npm exec.
[ -f "$installer" ] || die "the pinned installer is missing"
case "$(cd "$(dirname "$installer")" && pwd -P)/" in "$(pwd -P)"/*) die "the installer must not come from the checkout" ;; esac
say "installing dependencies"
node "$installer" 2>&1 | scrub

# --- 3. Deploy with the pinned CLI -------------------------------------------

[ -x "$convex_bin" ] || die "the pinned Convex CLI is missing"
work_real="$(pwd -P)"
outside_checkout() {
  local real
  real="$(cd "$(dirname "$1")" && pwd -P)/$(basename "$1")"
  case "$real" in "$work_real"/*) return 1 ;; esac
}
outside_checkout "$convex_bin" || die "the Convex CLI must not come from the checkout"

# No --cmd: the CLI hands its whole environment, key included, to that command.
# No --preview-run either: it runs only on a new deployment; the seed runs
# below, after the env vars are set.
say "deploying $preview"
deploy_log="$(mktemp)"
convex deploy --preview-create "$preview" --typecheck=disable | tee "$deploy_log"

# The first "Deployed Convex functions to <url>" line.
convex_url="$(sed -n 's#.*Deployed Convex functions to \(https://[a-z0-9-][a-z0-9.-]*\.convex\.cloud\).*#\1#p' "$deploy_log" | head -n 1)"
rm -f "$deploy_log"
[ -n "$convex_url" ] || die "could not find the preview's URL in the deploy output"
re_url='^https://[a-z0-9][a-z0-9-]*\.convex\.cloud$'
[[ "$convex_url" =~ $re_url ]] || die "the preview's URL is not a convex.cloud URL"
site_url="${convex_url%.convex.cloud}.convex.site"
deployment_name="${convex_url#https://}"
deployment_name="${deployment_name%%.*}"

# --- 4. Throwaway auth keys and SITE_URL -------------------------------------

convex_outside env set --preview-name "$preview" SITE_URL "$site_url"
if [ "$auth_keys" = "1" ]; then
  keys="$(node -e '
    const { generateKeyPairSync } = require("node:crypto");
    const { privateKey, publicKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });
    const pem = privateKey.export({ type: "pkcs8", format: "pem" }).trimEnd().replace(/\n/g, " ");
    const jwk = publicKey.export({ format: "jwk" });
    process.stdout.write(pem + "\n" + JSON.stringify({ keys: [{ use: "sig", ...jwk }] }) + "\n");
  ')"
  jwt_private_key="$(printf '%s\n' "$keys" | sed -n 1p)"
  jwks="$(printf '%s\n' "$keys" | sed -n 2p)"
  convex_outside env set --preview-name "$preview" -- JWT_PRIVATE_KEY "$jwt_private_key" >/dev/null
  convex_outside env set --preview-name "$preview" -- JWKS "$jwks" >/dev/null
  say "set throwaway JWT_PRIVATE_KEY and JWKS"
fi

# --- 5. Seed -----------------------------------------------------------------

if [ -n "$seed" ]; then
  say "running $seed"
  convex_outside run "$seed" '{}' --preview-name "$preview" --typecheck=disable --codegen=disable
fi

# --- 6. The frontend, built elsewhere, pointed at the preview and uploaded ---

if [ "$frontend" = "1" ]; then
  [ -f "$unpacker" ] || die "the pinned frontend unpacker is missing"
  outside_checkout "$unpacker" || die "the frontend unpacker must not come from the checkout"
  # A .mjs uploader runs with node, so it needs no execute bit.
  case "$uploader" in
    *.mjs) [ -f "$uploader" ] || die "the pinned static hosting uploader is missing"
      upload_cmd=(node "$uploader") ;;
    *) [ -x "$uploader" ] || die "the pinned static hosting uploader is missing"
      upload_cmd=("$uploader") ;;
  esac
  outside_checkout "$uploader" || die "the static hosting uploader must not come from the checkout"
  site_dir="$(mktemp -d)/site"
  say "unpacking the built frontend for $convex_url"
  node "$unpacker" --in-prefix "$fe_prefix" --parts "$fe_parts" --sha256 "$fe_sha256" \
    --out "$site_dir" --url "$convex_url" 2>&1 | scrub
  say "uploading the frontend to $preview"
  (cd "$cli_proj" && HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" CHEF_CONVEX_BIN="$convex_bin" \
    "${upload_cmd[@]}" --preview-name "$preview" --dist "$site_dir" 2>&1 | scrub)
fi

# --- 7. A one-time sign-in link ----------------------------------------------

# The app's own function, run on the preview (not here) with the pinned CLI,
# from the empty project, like the seed. Its answer is a sign-in token, so it
# goes only into the result file: never printed, never in the output Daytona
# stores. A link that isn't https on exactly the preview's own .convex.site,
# or that carries credentials or a port, is dropped. None of this fails the
# deploy: the preview works without it.
# One sign-in link from the app's function, checked; empty when there is none.
# Its answer is a sign-in token: it goes only into the result file.
login_link() {
  local login_dir out="" args="${1:-"{}"}"
  login_dir="$(mktemp -d)"
  if (cd "$cli_proj" && HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" "$convex_bin" run "$login_fn" "$args" \
    --preview-name "$preview" --typecheck=disable --codegen=disable >"$login_dir/out" 2>"$login_dir/err"); then
    if out="$(CHEF_LOGIN_HOST="${site_url#https://}" node -e '
      const fail = (why) => { process.stderr.write("chef-preview-deploy: the sign-in link was refused: " + why + "\n"); process.exit(3); };
      let r;
      try { r = JSON.parse(require("node:fs").readFileSync(0, "utf8")); } catch { fail("the answer is not JSON"); }
      if (!r || typeof r !== "object" || typeof r.url !== "string") fail("the answer has no url");
      const s = r.url;
      if (s.length > 4096 || /[\s\x00-\x1f\x7f]/.test(s)) fail("the url is malformed");
      let u;
      try { u = new URL(s); } catch { fail("the url does not parse"); }
      if (u.protocol !== "https:") fail("the url is not https");
      if (u.username !== "" || u.password !== "") fail("the url carries credentials");
      if (u.port !== "") fail("the url names a port");
      if (u.hostname !== process.env.CHEF_LOGIN_HOST) fail("the url is not on the preview site");
      process.stdout.write(JSON.stringify(u.href));
    ' <"$login_dir/out")"; then
      :
    else
      out=""
    fi
  else
    # The error, with anything that looks like a link taken out.
    say "$login_fn failed; the preview has no sign-in link" >&2
    tail -c 2000 "$login_dir/err" | sed -E 's#[A-Za-z][A-Za-z0-9+.-]*://[^[:space:]"]*#[link]#g' >&2
  fi
  rm -rf "$login_dir"
  printf '%s' "$out"
}

# The admin's own rows, copied in (chefCloud's previewData, "admin-copy"):
# the app's previewSeedFunction fetches the export by its one-time URL on
# the preview, checks its sha256 and inserts it, answering {"userId"}: the
# copied admin on the preview. Its answer and its errors never reach the
# output (they could name the admin's data); a failure leaves the preview
# with its demo data.
seeded_user=""
admin_copy=false
if [ -n "$pseed_fn" ]; then
  say "copying the admin's own data into $preview with $pseed_fn"
  pseed_dir="$(mktemp -d)"
  if (cd "$cli_proj" && HOME="$cli_home" CONVEX_DEPLOY_KEY="$deploy_key" "$convex_bin" run "$pseed_fn" "$pseed_args" \
    --preview-name "$preview" --typecheck=disable --codegen=disable >"$pseed_dir/out" 2>"$pseed_dir/err"); then
    if seeded_user="$(node -e '
      let r;
      try { r = JSON.parse(require("node:fs").readFileSync(0, "utf8")); } catch { process.exit(3); }
      const id = r && typeof r === "object" ? r.userId : null;
      if (typeof id !== "string" || !/^[A-Za-z0-9_|:.-]{1,128}$/.test(id)) process.exit(3);
      process.stdout.write(id);
    ' <"$pseed_dir/out")"; then
      admin_copy=true
      say "copied; the admin's sign-in link signs in as the copied user"
    else
      seeded_user=""
      say "$pseed_fn didn't answer {userId}; the preview keeps its demo data"
    fi
  else
    say "$pseed_fn failed; the preview keeps its demo data"
  fi
  rm -rf "$pseed_dir"
fi

login_json=""
demo_json=""
if [ -n "$login_fn" ]; then
  say "asking $login_fn for a sign-in link"
  if [ -n "$seeded_user" ]; then
    login_json="$(login_link "{\"userId\":\"$seeded_user\"}")"
    # An app whose function takes no userId: the demo user's link.
    if [ -z "$login_json" ]; then login_json="$(login_link)"; fi
  else
    login_json="$(login_link)"
  fi
  if [ -n "$login_json" ]; then say "got a sign-in link for $site_url (kept out of this output)"; fi
  if [ "$demo_login" = "1" ]; then
    say "asking $login_fn for a second sign-in link, for the demo video"
    demo_json="$(login_link)"
  fi
fi

# --- 8. Report ---------------------------------------------------------------

result="{\"sha\":\"$sha\",\"previewName\":\"$preview\",\"deploymentName\":\"$deployment_name\",\"convexUrl\":\"$convex_url\",\"siteUrl\":\"$site_url\",\"frontend\":$([ "$frontend" = 1 ] && echo true || echo false)}"
if [ -n "$pseed_fn" ]; then result="${result%\}},\"adminCopy\":$admin_copy}"; fi
# The file gets the sign-in links; the output never does.
full="$result"
if [ -n "$login_json" ]; then full="${full%\}},\"loginUrl\":$login_json}"; fi
if [ -n "$demo_json" ]; then full="${full%\}},\"demoLoginUrl\":$demo_json}"; fi
printf '%s\n' "$full" >"$result_file"
echo "chef-preview-result $result"
