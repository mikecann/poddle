// The demo recorder (docs/chef-pipeline.md, "The demo video"), delivered
// into a demo sandbox as chef-demo.mjs and run by chef-demo.sh: plays the
// agent's demo script (src/chef/demo.ts, data only) against the preview
// with the image's pinned Playwright and Chromium, recording the screen, a
// phone first and then a desktop, each at most 45 seconds, and writes each
// video as base64 parts and a result file for the launcher to read through
// Daytona.
//
// The sandbox holds no credential but the throwaway demo session's
// one-time link (CHEF_DEMO_LOGIN_URL, signed in as the preview's demo user,
// never printed). Its egress is the preview's two hosts, and the browser
// itself aborts any request to another host. Nothing the agent wrote runs
// here but the preview's own frontend, in the browser.
//
// Environment:
//   CHEF_DEMO_ORIGIN      https://<preview>.convex.site
//   CHEF_DEMO_HOSTS       the hosts the browser may reach, comma-separated
//   CHEF_DEMO_SCRIPT      the checked demo script, JSON (src/chef/demo.ts)
//   CHEF_DEMO_LOGIN_URL   optional one-time sign-in link, on the origin
//   CHEF_DEMO_OUT         where the parts and result.json go (default /tmp/chef-demo)
//   CHEF_DEMO_VIEWPORTS   phone,desktop (default)
//   CHEF_PLAYWRIGHT_DIR   the image's Playwright (default /opt/chef/playwright)
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { join } from "node:path";
import {
  DEMO_LIMITS,
  parseDemoScript,
  runDemoScript,
  summarizeDiagnostics,
  type DemoDiagnostics,
  type DemoPage,
  type DemoRunResult,
} from "../src/chef/demo.ts";
import { demoPageFor, watchDiagnostics } from "./demo-page.ts";
import { scrub } from "../src/chef/scrub.ts";

export const DEMO_RESULT_FILE = "result.json";
/** Raw bytes per base64 part: a multiple of 3, so the parts join cleanly. */
export const DEMO_PART_BYTES = 3 * 1024 * 1024;

export const VIEWPORTS = {
  phone: { width: 390, height: 844, isMobile: true, hasTouch: true },
  desktop: { width: 1280, height: 800, isMobile: false, hasTouch: false },
} as const;
export type ViewportName = keyof typeof VIEWPORTS;

export type DemoVideo = {
  viewport: ViewportName;
  parts: number;
  bytes: number;
  sha256: string;
  durationMs: number;
  done: number;
  steps: number;
  failed?: DemoRunResult["failed"];
  timedOut?: boolean;
};

export type DemoResult = { ok: true; videos: DemoVideo[]; problems: string[] } | { ok: false; error: string };

/**
 * One recording: a page to play the script on, `finish`, which closes it and
 * says where the video is, and what the page said so far (for a failed step).
 */
export type Recording = { page: DemoPage; finish: () => Promise<string | null>; diagnostics?: () => DemoDiagnostics };

export type RecorderDeps = {
  open: (viewport: ViewportName) => Promise<Recording>;
  close: () => Promise<void>;
  now?: () => number;
  log?: (line: string) => void;
};

/** The parts of a video as base64 strings, DEMO_PART_BYTES of raw bytes each. */
export function videoParts(bytes: Uint8Array): string[] {
  const out: string[] = [];
  for (let i = 0; i < bytes.length; i += DEMO_PART_BYTES) out.push(Buffer.from(bytes.subarray(i, i + DEMO_PART_BYTES)).toString("base64"));
  return out;
}

/** Reads and checks the environment; throws with what's wrong. */
export function demoConfig(env: Record<string, string | undefined>) {
  const origin = new URL(env.CHEF_DEMO_ORIGIN ?? "");
  if (origin.protocol !== "https:" || origin.pathname !== "/" || origin.username || origin.password || origin.port) {
    throw new Error("CHEF_DEMO_ORIGIN must be a plain https origin");
  }
  const hosts = (env.CHEF_DEMO_HOSTS ?? "").split(",").map((h) => h.trim()).filter(Boolean);
  if (!hosts.includes(origin.hostname)) throw new Error("CHEF_DEMO_HOSTS must include the origin's host");
  const parsed = parseDemoScript(env.CHEF_DEMO_SCRIPT ?? "");
  if (!parsed.script) throw new Error(`no demo script: ${parsed.problems[0] ?? "empty"}`);
  let login: string | null = null;
  if (env.CHEF_DEMO_LOGIN_URL) {
    const u = new URL(env.CHEF_DEMO_LOGIN_URL);
    if (u.origin !== origin.origin) throw new Error("the demo's sign-in link isn't on the preview");
    login = u.href;
  }
  const viewports = (env.CHEF_DEMO_VIEWPORTS ?? "phone,desktop").split(",").map((v) => v.trim()) as ViewportName[];
  if (viewports.length === 0 || viewports.some((v) => !(v in VIEWPORTS))) throw new Error("CHEF_DEMO_VIEWPORTS must be phone and/or desktop");
  return { origin: origin.origin + "/", hosts, script: parsed.script, problems: parsed.problems, login, viewports, out: env.CHEF_DEMO_OUT || "/tmp/chef-demo" };
}

/**
 * Records every viewport, writes the parts and the result file. A step that
 * fails keeps the partial video and says which step. Never throws; a
 * failure to start writes {ok: false, error}.
 */
export async function recordDemos(env: Record<string, string | undefined>, deps: RecorderDeps): Promise<DemoResult> {
  const log = deps.log ?? (() => {});
  const now = deps.now ?? Date.now;
  let cfg: ReturnType<typeof demoConfig>;
  try {
    cfg = demoConfig(env);
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
  rmSync(cfg.out, { recursive: true, force: true });
  mkdirSync(cfg.out, { recursive: true, mode: 0o755 });
  const write = (r: DemoResult) => {
    const tmp = join(cfg.out, `${DEMO_RESULT_FILE}.tmp`);
    writeFileSync(tmp, JSON.stringify(r) + "\n", { mode: 0o644 });
    renameSync(tmp, join(cfg.out, DEMO_RESULT_FILE));
    return r;
  };
  const videos: DemoVideo[] = [];
  try {
    for (const viewport of cfg.viewports) {
      const started = now();
      const rec = await deps.open(viewport);
      let run: DemoRunResult;
      try {
        if (cfg.login) {
          await rec.page.goto(cfg.login);
          log(`chef-demo: ${viewport}: signed in with the demo link`);
        }
        run = await runDemoScript(rec.page, cfg.script, { origin: cfg.origin, capMs: DEMO_LIMITS.recordingMs - (now() - started), now });
      } catch (e) {
        run = { done: 0, failed: { step: 0, what: "sign in", reason: String((e as Error)?.message ?? e).split("\n")[0].slice(0, 300) } };
      }
      // Why the page might not have been there (every Makeabook demo stopped
      // at its first click on a blank page, with nothing to say why).
      const said = run.failed && rec.diagnostics ? summarizeDiagnostics(rec.diagnostics(), (s) => scrub(s)) : "";
      if (run.failed && said) run = { ...run, failed: { ...run.failed, reason: `${run.failed.reason} | ${said}`.slice(0, 700) } };
      const path = await rec.finish();
      const durationMs = now() - started;
      if (!path) {
        log(`chef-demo: ${viewport}: no video`);
        continue;
      }
      const size = statSync(path).size;
      if (size > DEMO_LIMITS.videoBytes) {
        log(`chef-demo: ${viewport}: the video is ${size} bytes, over the cap; dropped`);
        continue;
      }
      const bytes = new Uint8Array(readFileSync(path));
      const parts = videoParts(bytes);
      parts.forEach((p, i) => writeFileSync(join(cfg.out, `${viewport}.${i}.b64`), p, { mode: 0o644 }));
      videos.push({
        viewport,
        parts: parts.length,
        bytes: bytes.length,
        sha256: createHash("sha256").update(bytes).digest("hex"),
        durationMs,
        done: run.done,
        steps: cfg.script.steps.length,
        ...(run.failed ? { failed: run.failed } : {}),
        ...(run.timedOut ? { timedOut: true } : {}),
      });
      log(`chef-demo: ${viewport}: ${run.done} of ${cfg.script.steps.length} steps, ${bytes.length} bytes${run.failed ? `; step ${run.failed.step + 1} failed (${run.failed.what})` : ""}`);
      // A desktop video only if the phone's went: a failing script fails the same way.
      if (run.failed) break;
    }
  } catch (e) {
    return write({ ok: false, error: String((e as Error)?.message ?? e).split("\n")[0].slice(0, 500) });
  } finally {
    await deps.close().catch(() => {});
  }
  return write({ ok: true, videos, problems: cfg.problems.slice(0, 10) });
}

/** The real recorder: the image's Playwright and Chromium, recording each page. */
export async function playwrightRecorder(env: Record<string, string | undefined>, hosts: string[]): Promise<RecorderDeps> {
  const dir = env.CHEF_PLAYWRIGHT_DIR || "/opt/chef/playwright";
  const req = createRequire(join(dir, "package.json"));
  const { chromium } = req("playwright") as { chromium: any };
  const browser = await chromium.launch({ headless: true });
  // With an egress allow list, Daytona's proxy re-signs HTTPS with its own CA.
  // Chromium reads neither NODE_EXTRA_CA_CERTS nor the system store (it has
  // its own NSS db), so every page fails with ERR_CERT_AUTHORITY_INVALID.
  // The proxy is the only way out and allows the preview's hosts only.
  const behindProxy = existsSync(env.CHEF_PROXY_CA || "/etc/daytona/netleash/ca.crt");
  const videoDir = join(env.CHEF_DEMO_OUT || "/tmp/chef-demo", "raw");
  const allowed = new Set(hosts);
  return {
    async open(viewport) {
      const vp = VIEWPORTS[viewport];
      mkdirSync(videoDir, { recursive: true });
      const context = await browser.newContext({
        viewport: { width: vp.width, height: vp.height },
        isMobile: vp.isMobile,
        hasTouch: vp.hasTouch,
        recordVideo: { dir: videoDir, size: { width: vp.width, height: vp.height } },
        ...(behindProxy ? { ignoreHTTPSErrors: true } : {}),
      });
      // Nothing but the preview's own hosts, whatever the page asks for.
      await context.route("**/*", (route: any) => {
        let host = "";
        try {
          host = new URL(route.request().url()).hostname;
        } catch {
          host = "";
        }
        return allowed.has(host) ? route.continue() : route.abort();
      });
      const p = await context.newPage();
      const diagnostics = watchDiagnostics(p);
      return {
        page: demoPageFor(p),
        diagnostics,
        finish: async () => {
          const video = p.video();
          await context.close();
          return video ? await video.path() : null;
        },
      };
    },
    close: async () => {
      await browser.close();
    },
  };
}

export async function demoMain(env: Record<string, string | undefined>, out: (s: string) => void): Promise<number> {
  let hosts: string[] = [];
  try {
    hosts = demoConfig(env).hosts;
  } catch (e) {
    const outDir = env.CHEF_DEMO_OUT || "/tmp/chef-demo";
    mkdirSync(outDir, { recursive: true });
    writeFileSync(join(outDir, DEMO_RESULT_FILE), JSON.stringify({ ok: false, error: (e as Error).message }) + "\n");
    out(`chef-demo: error: ${(e as Error).message}\n`);
    return 1;
  }
  let deps: RecorderDeps;
  try {
    deps = await playwrightRecorder(env, hosts);
  } catch (e) {
    const outDir = env.CHEF_DEMO_OUT || "/tmp/chef-demo";
    mkdirSync(outDir, { recursive: true });
    writeFileSync(join(outDir, DEMO_RESULT_FILE), JSON.stringify({ ok: false, error: `the browser didn't start: ${(e as Error).message}` }) + "\n");
    out(`chef-demo: error: the browser didn't start\n`);
    return 1;
  }
  const r = await recordDemos(env, { ...deps, log: (l) => out(l + "\n") });
  if (!r.ok) out(`chef-demo: error: ${r.error}\n`);
  return r.ok ? 0 : 1;
}
