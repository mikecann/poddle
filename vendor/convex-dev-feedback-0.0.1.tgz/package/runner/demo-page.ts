// A Playwright page as a DemoPage (src/chef/demo.ts), and what the page said
// while a script ran. Shared by the demo recorder (runner/demo-record.ts, on
// the preview) and chef-screenshot (runner/screenshot-helper.ts: steps before
// a screenshot, and rehearsing the demo on the build's own app).
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { DEMO_LIMITS, type DemoDiagnostics, type DemoPage, urlForLog } from "../src/chef/demo.ts";

const MAX_LINES = 20;

/** `p` is a Playwright Page. */
export function demoPageFor(p: any): DemoPage {
  return {
    goto: async (url) => {
      await p.goto(url, { waitUntil: "load", timeout: DEMO_LIMITS.stepTimeoutMs * 2 });
    },
    clickRole: async (role, name, timeout) => {
      await p.getByRole(role, name ? { name } : {}).first().click({ timeout });
    },
    clickText: async (text, timeout) => {
      await p.getByText(text).first().click({ timeout });
    },
    fill: async (by, value, timeout) => {
      const loc = "label" in by ? p.getByLabel(by.label) : p.getByPlaceholder(by.placeholder);
      await loc.first().fill(value, { timeout });
    },
    press: async (key) => {
      await p.keyboard.press(key === "Space" ? " " : key);
    },
    waitForText: async (text, timeout) => {
      await p.getByText(text).first().waitFor({ timeout });
    },
    wait: async (ms) => {
      await p.waitForTimeout(ms);
    },
    scroll: async (y) => {
      await p.mouse.wheel(0, y);
    },
  };
}

/**
 * Collects console errors, uncaught page errors and failed requests from the
 * moment it is called. Request URLs keep only host and path. Bounded.
 */
export function watchDiagnostics(p: any): () => DemoDiagnostics {
  const d: DemoDiagnostics = { consoleErrors: [], pageErrors: [], failedRequests: [] };
  const push = (list: string[], s: string) => {
    if (list.length < MAX_LINES) list.push(s.slice(0, 300));
  };
  p.on("console", (m: any) => {
    if (m.type() === "error") push(d.consoleErrors, String(m.text()));
  });
  p.on("pageerror", (e: any) => push(d.pageErrors, String(e?.message ?? e)));
  p.on("requestfailed", (r: any) => push(d.failedRequests, `${urlForLog(r.url())} (${r.failure()?.errorText ?? "failed"})`));
  return () => d;
}
