// `chef-screenshot`: a screenshot of the app the agent is serving, with the
// image's pinned Playwright and Chromium (docs/chef-pipeline.md,
// "Screenshots"). Root-owned in the image; the agent runs it to look at its
// own work, and the runner runs it, as the agent user, for the final
// screenshots after the gates.
//
//   chef-screenshot <path-or-url> [--out <file.png>] [--viewport WxH]
//     [--wait-for <selector>] [--port <n>] [--full-page] [--timeout <ms>]
//     [--signed-in [--login-function <module:function>]]
//     [--steps '<json list of demo steps>'] [--rehearse <demo-script.json>]
//     [--playwright-bin <path>] [--browsers-path <dir>]
//
// `<path-or-url>` is a path on the app (`/settings`, on 127.0.0.1 and
// `--port`, default 5173) or a full `http://127.0.0.1:<port>/...` URL.
// Nothing else is opened: not localhost, not another host, not https.
//
// `--signed-in` screenshots the page as the app's demo user: the helper runs
// the app's sign-in link function (CHEF_LOGIN_FUNCTION, chefCloud's
// `previewLoginFunction`) on the local backend with `npx convex run`, opens
// the link's path on the same 127.0.0.1 origin, waits for the app to sign in,
// then opens the page in the same browser. The link is a one-time token for
// the throwaway local backend; it is never printed.
//
// `--steps` plays demo-script steps (src/chef/demo.ts: click, fill, press,
// waitFor, ...) on the page before the screenshot, to show what is behind a
// click. `--rehearse` plays the agent's whole demo script the way the preview's
// demo video will (a phone, signed in when the app can be), says which step
// stopped it and what the page said, and screenshots where it ended: exit 0
// when every step ran, 1 when one failed.
//
// Chromium runs without its own sandbox. Playwright launches it that way by
// default (`chromiumSandbox: false`), and its sandbox would need unprivileged
// user namespaces or a setuid `chrome-sandbox`, which the Daytona container
// doesn't give `chefagent`. What it renders is the agent's own app from
// 127.0.0.1, as the agent user, in a sandbox whose egress is the app's own
// host: a renderer that escapes gets what the agent user already has.
//
// Exit codes: 0 written, 1 failed, 2 refused or bad usage.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync, statSync } from "node:fs";
import http from "node:http";
import { createRequire } from "node:module";
import { dirname, isAbsolute, join, resolve } from "node:path";
import {
  LOGIN_FUNCTION,
  SCREENSHOT_LIMITS,
  checkLoopbackUrl,
  isWaitForSelector,
  pngInfo,
  signInPath,
} from "../src/chef/screenshots.ts";
import {
  DEMO_LIMITS,
  checkDemoSteps,
  parseDemoScript,
  runDemoScript,
  summarizeDiagnostics,
  type DemoRunResult,
  type DemoStep,
} from "../src/chef/demo.ts";
import { demoPageFor, watchDiagnostics } from "./demo-page.ts";

/** Where the image puts the pinned Playwright CLI and its browsers. */
export const DEFAULT_PLAYWRIGHT_BINS = ["/opt/chef/bin/playwright", "/opt/chef/playwright/node_modules/.bin/playwright"];
export const DEFAULT_BROWSERS_PATH = "/opt/chef/ms-playwright";
export const DEFAULT_APP_PORT = 5173;
export const DEFAULT_VIEWPORT = { width: 1280, height: 800 };
/** The image's Playwright package, for --signed-in (the CLI can't open two pages in one browser). */
export const DEFAULT_PLAYWRIGHT_DIR = "/opt/chef/playwright";

export type HelperArgs = {
  url: string;
  out: string;
  viewport: { width: number; height: number };
  waitFor?: string;
  fullPage: boolean;
  timeoutMs: number;
  /** Sign in first, through this login function (the flag, else CHEF_LOGIN_FUNCTION). */
  signedIn?: { loginFunction?: string };
  /** Demo steps played before the screenshot (`--steps`). */
  steps?: DemoStep[];
  /** The demo script to rehearse (`--rehearse`), an absolute path. */
  rehearse?: string;
  playwrightBin?: string;
  browsersPath?: string;
};

export class UsageError extends Error {}

const ABS = /^\/[A-Za-z0-9._/-]+$/;

/** Parses and checks the command line. Throws UsageError on anything off. */
export function parseHelperArgs(argv: string[], cwd: string): HelperArgs {
  let target: string | undefined;
  let out: string | undefined;
  let port = DEFAULT_APP_PORT;
  let viewport = { ...DEFAULT_VIEWPORT };
  let waitFor: string | undefined;
  let fullPage = false;
  let timeoutMs = 30_000;
  let playwrightBin: string | undefined;
  let browsersPath: string | undefined;
  let signedIn = false;
  let loginFunction: string | undefined;
  let steps: DemoStep[] | undefined;
  let rehearse: string | undefined;
  let viewportGiven = false;
  const value = (i: number, flag: string) => {
    const v = argv[i + 1];
    if (v === undefined) throw new UsageError(`${flag} needs a value`);
    return v;
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    switch (a) {
      case "--out":
        out = value(i++, a);
        break;
      case "--port": {
        const v = value(i++, a);
        port = Number(v);
        if (!/^\d{1,5}$/.test(v) || port < 1 || port > 65535) throw new UsageError("--port must be 1 to 65535");
        break;
      }
      case "--viewport": {
        const m = /^(\d{2,5})x(\d{2,5})$/.exec(value(i++, a));
        if (!m) throw new UsageError("--viewport must be WIDTHxHEIGHT, as in 1280x800");
        viewport = { width: Number(m[1]), height: Number(m[2]) };
        viewportGiven = true;
        if (viewport.width < 200 || viewport.height < 200 || viewport.width > 3840 || viewport.height > 4320) {
          throw new UsageError("--viewport must be between 200x200 and 3840x4320");
        }
        break;
      }
      case "--steps": {
        let raw: unknown;
        try {
          raw = JSON.parse(value(i++, a));
        } catch {
          throw new UsageError("--steps must be a JSON list of demo steps");
        }
        if (!Array.isArray(raw) || raw.length === 0 || raw.length > 10) throw new UsageError("--steps must be a list of 1 to 10 demo steps");
        const c = checkDemoSteps(raw);
        if ("problem" in c) throw new UsageError(`--steps: ${c.problem}`);
        steps = c.steps;
        break;
      }
      case "--rehearse":
        rehearse = value(i++, a);
        rehearse = isAbsolute(rehearse) ? rehearse : resolve(cwd, rehearse);
        if (!rehearse.endsWith(".json")) throw new UsageError("--rehearse takes the demo script's .json file");
        break;
      case "--wait-for":
        waitFor = value(i++, a);
        if (!isWaitForSelector(waitFor)) throw new UsageError("--wait-for must be a plain selector of printable ASCII");
        break;
      case "--full-page":
        fullPage = true;
        break;
      case "--signed-in":
        signedIn = true;
        break;
      case "--login-function":
        loginFunction = value(i++, a);
        if (!LOGIN_FUNCTION.test(loginFunction)) throw new UsageError("--login-function must be module:function");
        break;
      case "--timeout": {
        const v = value(i++, a);
        timeoutMs = Number(v);
        if (!/^\d{1,6}$/.test(v) || timeoutMs < 1000 || timeoutMs > 120_000) {
          throw new UsageError("--timeout must be 1000 to 120000 ms");
        }
        break;
      }
      case "--playwright-bin":
        playwrightBin = value(i++, a);
        if (!ABS.test(playwrightBin)) throw new UsageError("--playwright-bin must be an absolute path");
        break;
      case "--browsers-path":
        browsersPath = value(i++, a);
        if (!ABS.test(browsersPath)) throw new UsageError("--browsers-path must be an absolute path");
        break;
      default:
        if (a.startsWith("--")) throw new UsageError(`unknown option ${a}`);
        if (target !== undefined) throw new UsageError("one page at a time");
        target = a;
    }
  }
  if (target === undefined) throw new UsageError("which page? Give a path such as / or a http://127.0.0.1:<port>/ URL");
  let url: URL;
  try {
    if (target.startsWith("/") && !target.startsWith("//")) url = checkLoopbackUrl(`http://127.0.0.1:${port}${target}`);
    else url = checkLoopbackUrl(target);
  } catch (e) {
    throw new UsageError((e as Error).message);
  }
  if (out === undefined) {
    const slug = (url.pathname.replace(/[^A-Za-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "home").slice(0, 40);
    out = `/tmp/chef-screenshots/${slug}.png`;
  }
  out = isAbsolute(out) ? out : resolve(cwd, out);
  if (!out.endsWith(".png")) throw new UsageError("--out must end in .png");
  if (loginFunction !== undefined && !signedIn) throw new UsageError("--login-function goes with --signed-in");
  if (rehearse !== undefined && steps !== undefined) throw new UsageError("--rehearse plays the demo script; give --steps or --rehearse, not both");
  // The preview's demo video starts on a phone; a rehearsal does too unless told otherwise.
  if (rehearse !== undefined && !viewportGiven) viewport = { width: 390, height: 844 };
  return {
    url: url.toString(),
    out,
    viewport,
    ...(waitFor !== undefined ? { waitFor } : {}),
    fullPage,
    timeoutMs,
    ...(signedIn ? { signedIn: loginFunction !== undefined ? { loginFunction } : {} } : {}),
    ...(steps !== undefined ? { steps } : {}),
    ...(rehearse !== undefined ? { rehearse } : {}),
    ...(playwrightBin !== undefined ? { playwrightBin } : {}),
    ...(browsersPath !== undefined ? { browsersPath } : {}),
  };
}

/** The Playwright CLI: the flag, CHEF_PLAYWRIGHT_BIN, the image's, or `playwright` on PATH. */
export function resolvePlaywrightBin(a: HelperArgs, env: Record<string, string | undefined>): string {
  if (a.playwrightBin) return a.playwrightBin;
  const fromEnv = env.CHEF_PLAYWRIGHT_BIN;
  if (fromEnv && ABS.test(fromEnv)) return fromEnv;
  for (const p of DEFAULT_PLAYWRIGHT_BINS) if (existsSync(p)) return p;
  return "playwright";
}

/** `playwright screenshot`'s argv. Every value is checked above; no shell is involved. */
export function playwrightArgs(a: HelperArgs): string[] {
  return [
    "screenshot",
    "--browser",
    "chromium",
    "--viewport-size",
    `${a.viewport.width},${a.viewport.height}`,
    "--timeout",
    String(a.timeoutMs),
    ...(a.waitFor !== undefined ? ["--wait-for-selector", a.waitFor] : []),
    ...(a.fullPage ? ["--full-page"] : []),
    a.url,
    a.out,
  ];
}

/** True once something answers HTTP at the URL (any status), within `ms`. */
export async function waitForServer(url: string, ms: number): Promise<boolean> {
  const until = Date.now() + ms;
  for (;;) {
    const up = await new Promise<boolean>((done) => {
      const req = http.get(url, { timeout: 2000 }, (res) => {
        res.resume();
        done(true);
      });
      req.on("timeout", () => {
        req.destroy();
        done(false);
      });
      req.on("error", () => done(false));
    });
    if (up) return true;
    if (Date.now() > until) return false;
    await new Promise((r) => setTimeout(r, 250));
  }
}

/**
 * The `url` from what `npx convex run <login function>` printed: the
 * function's return value as JSON (the CLI's logs go to stderr). Null when
 * there is none.
 */
export function loginLinkFromOutput(stdout: string): string | null {
  const text = stdout.trim();
  const start = text.indexOf("{");
  if (start < 0) return null;
  try {
    const v = JSON.parse(text.slice(start)) as { url?: unknown };
    return typeof v?.url === "string" ? v.url : null;
  } catch {
    return null;
  }
}

/** Runs `npx convex run <fn> {}` on the local backend (the env's CONVEX_SELF_HOSTED_*), as this user. */
function runLoginFunction(fn: string, env: Record<string, string>, cwd: string, timeoutMs: number): Promise<string> {
  return new Promise((done, fail) => {
    const child = spawn("npx", ["convex", "run", fn, "{}"], { cwd, env, stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    let err = "";
    child.stdout.on("data", (d: Buffer) => (out = (out + d.toString("utf8")).slice(-64_000)));
    child.stderr.on("data", (d: Buffer) => (err = (err + d.toString("utf8")).slice(-4000)));
    const timer = setTimeout(() => child.kill("SIGKILL"), timeoutMs);
    child.on("error", (e) => {
      clearTimeout(timer);
      fail(new Error(`couldn't run npx convex run: ${e.message}`));
    });
    child.on("close", (c) => {
      clearTimeout(timer);
      // stderr may name the function's error; stdout holds the token, so it is never echoed.
      if (c !== 0) return fail(new Error(`${fn} failed: ${err.trim().split("\n").slice(-3).join(" ").slice(0, 500)}`));
      done(out);
    });
  });
}

/** What a rehearsal did: how far the script got, and what the page said when it stopped. */
export type Rehearsal = DemoRunResult & { steps: number; said: string };

/** One line for the agent and the runner's log. */
export function rehearsalLine(r: Rehearsal): string {
  if (!r.failed && !r.timedOut) return `chef-screenshot: rehearsal: all ${r.steps} steps ran`;
  const where = r.failed ? `stopped at step ${r.failed.step + 1} (${r.failed.what}): ${r.failed.reason}` : "ran out of time";
  return `chef-screenshot: rehearsal: ${r.done} of ${r.steps} steps ran; ${where}${r.said ? ` | the page said: ${r.said}` : ""}`;
}

/**
 * In the image's Playwright package (the CLI opens one page and can't click):
 * signs in through `signInUrl` when given, opens `a.url`, then plays
 * `a.steps` before the screenshot, or rehearses `a.rehearse`'s script and
 * screenshots where it ended. Throws when a step of `a.steps` fails.
 */
async function shootInBrowser(a: HelperArgs, signInUrl: string | null, env: Record<string, string>): Promise<Rehearsal | null> {
  process.env.PLAYWRIGHT_BROWSERS_PATH = env.PLAYWRIGHT_BROWSERS_PATH;
  process.env.PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = "1";
  const req = createRequire(join(env.CHEF_PLAYWRIGHT_DIR || DEFAULT_PLAYWRIGHT_DIR, "package.json"));
  const { chromium } = req("playwright") as { chromium: any };
  const browser = await chromium.launch({ headless: true });
  try {
    const phone = a.viewport.width < 600;
    const context = await browser.newContext({ viewport: a.viewport, ...(phone ? { isMobile: true, hasTouch: true } : {}) });
    const page = await context.newPage();
    const said = watchDiagnostics(page);
    const origin = new URL(a.url).origin;
    if (signInUrl) {
      await page.goto(signInUrl, { waitUntil: "load", timeout: a.timeoutMs });
      // The app consumes the link and moves on (or clears the fragment): wait for that, then settle.
      await page
        .waitForURL((u: URL) => u.origin === origin && !u.hash.includes("token"), { timeout: Math.min(15_000, a.timeoutMs) })
        .catch(() => {});
      await page.waitForLoadState("networkidle", { timeout: 5000 }).catch(() => {});
    }
    await page.goto(a.url, { waitUntil: "load", timeout: a.timeoutMs });
    let rehearsal: Rehearsal | null = null;
    if (a.rehearse !== undefined) {
      const parsed = parseDemoScript(readFileSync(a.rehearse, "utf8").slice(0, DEMO_LIMITS.fileBytes));
      if (!parsed.script) throw new Error(`no demo script to rehearse: ${parsed.problems[0] ?? "empty"}`);
      const r = await runDemoScript(demoPageFor(page), parsed.script, { origin: `${origin}/`, loopback: true });
      rehearsal = { ...r, steps: parsed.script.steps.length, said: r.failed || r.timedOut ? summarizeDiagnostics(said()) : "" };
    } else if (a.steps !== undefined) {
      const r = await runDemoScript(demoPageFor(page), { steps: a.steps }, { origin: `${origin}/`, loopback: true });
      if (r.failed) {
        const s = summarizeDiagnostics(said());
        throw new Error(`step ${r.failed.step + 1} (${r.failed.what}): ${r.failed.reason}${s ? ` | the page said: ${s}` : ""}`);
      }
    }
    if (a.waitFor !== undefined && a.rehearse === undefined) await page.locator(a.waitFor).first().waitFor({ timeout: a.timeoutMs });
    else await page.waitForLoadState("networkidle", { timeout: 5000 }).catch(() => {});
    await page.screenshot({ path: a.out, fullPage: a.fullPage, timeout: a.timeoutMs });
    return rehearsal;
  } finally {
    await browser.close().catch(() => {});
  }
}

export async function helperMain(
  argv: string[],
  env: Record<string, string | undefined>,
  io: { out: (s: string) => void; err: (s: string) => void; cwd: string },
): Promise<number> {
  let a: HelperArgs;
  try {
    a = parseHelperArgs(argv, io.cwd);
  } catch (e) {
    if (!(e instanceof UsageError)) throw e;
    io.err(`chef-screenshot: ${e.message}\n`);
    io.err(
      "usage: chef-screenshot <path-or-url> [--out <file.png>] [--viewport WxH] [--wait-for <selector>] [--port <n>] [--full-page] [--signed-in] [--steps '<json>'] [--rehearse <demo-script.json>]\n",
    );
    return 2;
  }
  // A rehearsal signs in whenever the app can, as the preview's demo does.
  const appLogin = env.CHEF_LOGIN_FUNCTION && LOGIN_FUNCTION.test(env.CHEF_LOGIN_FUNCTION) ? env.CHEF_LOGIN_FUNCTION : undefined;
  const loginFunction = a.signedIn ? (a.signedIn.loginFunction ?? env.CHEF_LOGIN_FUNCTION) : a.rehearse !== undefined ? appLogin : undefined;
  if (a.signedIn && (!loginFunction || !LOGIN_FUNCTION.test(loginFunction))) {
    io.err("chef-screenshot: --signed-in needs the app's sign-in link function (CHEF_LOGIN_FUNCTION); this app has none, so screenshot signed out\n");
    return 2;
  }
  if (a.rehearse !== undefined && !existsSync(a.rehearse)) {
    io.err(`chef-screenshot: no demo script at ${a.rehearse}\n`);
    return 2;
  }
  if (!(await waitForServer(a.url, 15_000))) {
    io.err(`chef-screenshot: nothing answers at ${a.url}; start the app on 127.0.0.1 first\n`);
    return 1;
  }
  mkdirSync(dirname(a.out), { recursive: true });
  rmSync(a.out, { force: true });
  const bin = resolvePlaywrightBin(a, env);
  const childEnv: Record<string, string> = {};
  for (const [k, v] of Object.entries(env)) if (v !== undefined) childEnv[k] = v;
  childEnv.PLAYWRIGHT_BROWSERS_PATH = a.browsersPath ?? (env.PLAYWRIGHT_BROWSERS_PATH || DEFAULT_BROWSERS_PATH);
  // Never download anything: the browsers are in the image or nowhere.
  childEnv.PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = "1";
  if (loginFunction || a.steps !== undefined || a.rehearse !== undefined) {
    let rehearsal: Rehearsal | null;
    try {
      let signInUrl: string | null = null;
      if (loginFunction) {
        const link = loginLinkFromOutput(await runLoginFunction(loginFunction, childEnv, io.cwd, 60_000));
        signInUrl = checkLoopbackUrl(`${new URL(a.url).origin}${signInPath(link)}`).toString();
      }
      rehearsal = await shootInBrowser(a, signInUrl, childEnv);
    } catch (e) {
      io.err(`chef-screenshot: ${a.rehearse !== undefined ? "rehearsal" : "screenshot"} failed: ${String((e as Error)?.message ?? e).split("\n")[0].slice(0, 700)}\n`);
      return 1;
    }
    const how = `${loginFunction ? " (signed in)" : ""}${a.steps ? ` after ${a.steps.length} step${a.steps.length === 1 ? "" : "s"}` : ""}`;
    const code = reportShot(a, io, how);
    if (rehearsal) {
      io.out(`${rehearsalLine(rehearsal)}\n`);
      return rehearsal.failed || rehearsal.timedOut ? 1 : code;
    }
    return code;
  }
  const code = await new Promise<number | string>((done) => {
    const child = spawn(bin, playwrightArgs(a), { env: childEnv, stdio: ["ignore", "pipe", "pipe"] });
    let output = "";
    const keep = (d: Buffer) => (output = (output + d.toString("utf8")).slice(-8000));
    child.stdout.on("data", keep);
    child.stderr.on("data", keep);
    const timer = setTimeout(() => child.kill("SIGKILL"), a.timeoutMs + 15_000);
    child.on("error", (e) => {
      clearTimeout(timer);
      done(`couldn't start ${bin}: ${e.message}`);
    });
    child.on("close", (c, signal) => {
      clearTimeout(timer);
      if (c === 0) return done(0);
      done(`playwright exited (${c ?? signal}): ${output.trim().slice(-2000)}`);
    });
  });
  if (code !== 0) {
    io.err(`chef-screenshot: ${code}\n`);
    return 1;
  }
  return reportShot(a, io, "");
}

/** Checks the PNG the shot wrote and says so. */
function reportShot(a: HelperArgs, io: { out: (s: string) => void; err: (s: string) => void }, how: string): number {
  if (!existsSync(a.out)) {
    io.err(`chef-screenshot: playwright wrote nothing to ${a.out}\n`);
    return 1;
  }
  const size = statSync(a.out).size;
  const info = pngInfo(new Uint8Array(readFileSync(a.out).subarray(0, 64)));
  if (!info) {
    io.err(`chef-screenshot: ${a.out} is not a PNG\n`);
    return 1;
  }
  const big = size > SCREENSHOT_LIMITS.fileBytes ? ` (over ${SCREENSHOT_LIMITS.fileBytes} bytes: too big to upload)` : "";
  io.out(`chef-screenshot: wrote ${a.out} (${info.width}x${info.height}, ${size} bytes) from ${a.url}${how}${big}\n`);
  return 0;
}
