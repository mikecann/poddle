// The Chef runner: one run, inside the build sandbox (docs/chef-pipeline.md,
// "One run, step by step", steps 4 to 10). It is root-owned code started by
// the orchestrator with CHEF_API and CHEF_RUN_ID; its secrets arrive as
// Daytona placeholders (CHEF_RUN_TOKEN, CHEF_GIT_AUTH, CHEF_AI_TOKEN) that
// carry a real value only when the orchestrator sets one.
//
// In order:
//  1. refuse to start twice (a marker file created with O_EXCL);
//  2. the egress self-test, before any credential is live; on failure stop,
//     and say so in the status file the orchestrator reads;
//  3. write `ready` to the status file and wait until the run credential works;
//  4. fetch the run, verify the snapshot hash, fetch and verify attachments;
//  5. clone into a git dir only the runner can write (the agent's checkout
//     has no .git at all), create the request branch from chef and merge
//     main in (conflicts are left in progress for the agent to resolve,
//     listed in merge-conflicts.md; protected paths take main's side),
//     refuse at once what the preview deploy would refuse
//     (src/chef/deployChecks.ts), install, start the local backend from the snapshot's binary
//     (runner/local-backend.ts), report `cloned` and wait until the
//     orchestration grants `agent` (git dead, egress narrowed);
//  6. Claude Code as the agent user with a clean environment, its stream-json
//     parsed, scrubbed and batched to /log, heartbeats throughout;
//  7. kill every agent process, run the gates as the agent user, kill again;
//  8. guards on the diff and a secret scan of agent.jsonl; then, best
//     effort, the final screenshots of the app as built
//     (runner/screenshots.ts);
//  9. commit (hooks off), report `committed` with the sha and wait until the
//     orchestration grants `pushing` (the write credential set, the git host
//     added to egress);
// 10. wait until the git host answers with the credential (widening egress
//     takes 1 to 3 minutes, L2), bounded; then, with no agent process alive,
//     push the request branch, then fast-forward chef (never forced, hooks
//     off), read the refs back, report.
//
// The contract with the launcher is written out at the top of
// packages/chef-cloud/src/client/chefLauncher.ts. Both waits are bounded; a run that never gets its
// grant fails. Any failure writes `ok: false` and the error to status.json.
//
// A failure anywhere before step 10 pushes nothing. The git credential only
// ever travels in a header set through GIT_CONFIG_* environment variables of
// the runner's own git processes: never argv, never a URL, never a file.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawn } from "node:child_process";
import { createHash, randomBytes } from "node:crypto";
import {
  appendFileSync,
  chmodSync,
  closeSync,
  constants as fsConstants,
  existsSync,
  fstatSync,
  mkdirSync,
  openSync,
  readFileSync,
  readSync,
  realpathSync,
  renameSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from "node:fs";
import { dirname, join } from "node:path";
import {
  MERGE_CONFLICTS_FILE,
  MERGE_MAIN_DIR,
  attachmentFileName,
  assertInertArgs,
  planAgentRun,
  planCommit,
  planFixRound,
  planMergeCommit,
  planMergeRepair,
  planResumeRound,
  EARLIER_ATTEMPT_DIFF_FILE,
  EARLIER_ATTEMPT_FILE,
  PREVIOUS_FAILURE_FILE,
  previousFailureFile,
  REBASED_MAX_TURNS,
  earlierAttemptFile,
  requestBranchName,
  validateSnapshot,
  type AgentRunPlan,
  type ApprovedRun,
  type SnapshotAttachment,
} from "../src/chef/prompt.ts";
import {
  CONFLICT_MARKER_GREP,
  checkGuards,
  mergeTakesMain,
  parseGrepZ,
  parseRawDiffZ,
  type GuardResult,
} from "../src/chef/guards.ts";
import { findSecrets, scanSecrets, scrub } from "../src/chef/scrub.ts";
import { deployRefusalError, deployRefusals, parseLsTreeZ, type DeployRefusal } from "../src/chef/deployChecks.ts";
import { throwawayAllow, throwawayExplain } from "../src/chef/throwaway.ts";
import { describeTranscriptLine } from "../src/chef/transcriptContext.ts";
import { RELEASE_DIFF_ARGS, RELEASE_DIFF_MAX_BYTES, RELEASE_GIT_CONFIG } from "../src/chef/release.ts";
import { revealInvisible } from "../src/chef/text.ts";
import { MERGE_REPAIR_ROUNDS, RESOLUTION_DIFF_MAX_BYTES } from "../src/chef/follow.ts";
import {
  APPROVAL_REQUESTS_FILE,
  NOTE_LIMITS,
  SKILL_FEEDBACK_FILE,
  approvalRequestEntry,
  parseJsonLines,
  skillFeedbackEntry,
} from "../src/chef/notes.ts";
import { buildAgentEnv, AGENT_HOME, AGENT_PATH, type LocalBackendEnv } from "./agent-env.ts";
import {
  CHECK_FAILURE_FILE,
  GATE_OUTPUT_BYTES,
  TAMPER_VIOLATIONS,
  checkFailureFile,
  clampFixRounds,
  compareWithBaseline,
  gateBlocks,
  gateFailureFile,
  gateSummary,
  redBaselineNote,
  tailOutput,
  type GateResult,
} from "../src/chef/gates.ts";
import {
  APP_NOTES_FILE,
  REPO_NOTES_FILE,
  TIMING_KEYS,
  matchBaseline,
  repoNoteEntry,
  type ObservedFacts,
  type PhaseTimings,
  type RepoNote,
} from "../src/chef/learnings.ts";
import { DEFAULT_CONVEX_PLUGIN_DIR, DEFAULT_CONVEX_PLUGIN_SOURCE, buildConvexPlugin } from "./convex-plugin.ts";
import { CHEF_MODEL, claudeSettingsJson } from "./claude-settings.ts";
import type { AgentUser } from "./agent-user.ts";
import { collectPnpmErrorCodes, newestNpmLogSummary } from "./npm-log.ts";
import { describePlan, installPlan, prepareWarm, warmLookup } from "./chef-install.mjs";
import { WARM_ROOT } from "./chef-install-plan.mjs";
import {
  buildSkillsPlugin,
  prepareClaudeConfigDir,
  DEFAULT_CLAUDE_CONFIG_DIR,
  DEFAULT_PLUGIN_DIR,
  DEFAULT_SKILLS_DIR,
  PLUGIN_NAME,
} from "./skills.ts";
import { VISUAL_CHECK_AGENT, VISUAL_CHECK_AGENT_MD } from "./visual-check.ts";
import type { EgressCheck, EgressResult } from "./egress.ts";
import { finalScreenshots, resolveScreenshotConfig, type ScreenshotConfig } from "./screenshots.ts";
import { LOGIN_FUNCTION, SCREENSHOT_LIMITS, SCREENSHOT_PLAN_FILE } from "../src/chef/screenshots.ts";
import { DEMO_LIMITS, DEMO_SCRIPT_FILE, parseDemoScript, type DemoScript } from "../src/chef/demo.ts";
import { PLUGIN_USAGE_LOG, convexOnly, countHookLog, countStreamLine, emptyUsage, pluginUsageLine, pluginUsageTotals } from "../src/chef/pluginUsage.ts";
import { buildFrontendArtifact, pickFrontend, type FrontendConfig } from "./frontend-artifact.ts";
import {
  backendUp,
  keygenArgs,
  localBackendUrl,
  parseAdminKey,
  resolveLocalBackend,
  serveArgs,
  type LocalBackendConfig,
} from "./local-backend.ts";

export type Timing = {
  /** How long to wait for the orchestrator to make the run credential live. */
  credentialWaitMs: number;
  /** Poll interval while waiting for a credential or a grant. */
  pollMs: number;
  heartbeatMs: number;
  logFlushMs: number;
  /**
   * How long to wait for the orchestration to grant `agent` after `cloned`,
   * or `pushing` after `committed`. It grants once the sandbox is in the
   * state the phase allows, about 20 seconds after it sees the request.
   */
  grantWaitMs: number;
  agentTimeoutMs: number;
  commandTimeoutMs: number;
  /**
   * How long to wait for the git host to answer with the credential, before
   * the clone and after `pushing` is granted. Widening egress on a running
   * sandbox took 1 to 3 minutes in L2, and a secret's new value up to 20 s.
   */
  gitReachWaitMs: number;
  /** The `localEnv` command, each time it runs. */
  localEnvTimeoutMs: number;
  /**
   * What a fix round leaves of the run's deadline for the gates, the
   * guards and the push: no round starts with less than this left, and a
   * round's agent stops this long before the deadline.
   */
  fixReserveMs: number;
};

export const DEFAULT_TIMING: Timing = {
  credentialWaitMs: 10 * 60_000,
  pollMs: 2_000,
  heartbeatMs: 60_000,
  logFlushMs: 2_000,
  grantWaitMs: 10 * 60_000,
  agentTimeoutMs: 30 * 60_000,
  commandTimeoutMs: 15 * 60_000,
  gitReachWaitMs: 5 * 60_000,
  localEnvTimeoutMs: 2 * 60_000,
  fixReserveMs: 12 * 60_000,
};

/** Where the runner keeps its state; the launcher reads `status.json` here. */
export const DEFAULT_STATE_DIR = "/opt/chef/state";

/**
 * The state dir's mode. Root owns it (the runner is root). Others may only
 * traverse it: Daytona's toolbox reads files as `daytona`, so the launcher's
 * `readFile` of `status.json` and `started` needs the x bit, and nothing more
 * (L2 check 7). The agent user can't list it or write in it.
 */
export const STATE_DIR_MODE = 0o711;
/** `status.json` and `started`: readable by the launcher, and nothing secret in them. */
export const PUBLIC_FILE_MODE = 0o644;

/** What `status.json` holds. Nothing else is ever written to it. */
export type RunnerStatusFile = {
  runId: string;
  at: number;
  phase: string;
  ok: boolean;
  error?: string;
  selfTest?: EgressResult;
};

/** Time for the runner's bounded waits. Injectable, so tests can run a long wait at once. */
export type Clock = {
  now: () => number;
  sleep: (ms: number) => Promise<void>;
};

export type RunnerConfig = {
  runId: string;
  /** Base URL of the Chef agent API's host, e.g. https://x.convex.site. */
  api: string;
  /** The app's https origin, for the settings file. Defaults to `api`. */
  siteOrigin?: string;
  /** Route prefix. Default /chef-agent. */
  routePrefix?: string;
  /** The Code Storage git URL, no credentials in it. Default: the run's `config.repoUrl`. */
  repoUrl?: string;
  /**
   * The runner's own dir: marker, status, agent.jsonl, commit message, git's
   * HOME. Default /opt/chef/state, where the launcher reads status.json.
   * Made 0711 (see STATE_DIR_MODE): nobody else can list or write it, and
   * Daytona's toolbox, which reads as `daytona`, can open the two files it
   * knows by name, `status.json` and `started` (0644, nothing secret).
   */
  stateDir?: string;
  /** The git dir, runner-owned. The agent's checkout never has a .git. */
  gitDir: string;
  /** The checkout the agent works in. */
  workDir: string;
  /** prompt.md, request.md, attachments/, summary.md. Agent-readable. */
  chefDir: string;
  /** Where the Claude Code settings file is written. */
  settingsPath: string;
  /**
   * The image's skills, `<skillsDir>/<name>/SKILL.md`, root-owned. Default
   * /opt/chef/skills. A missing dir, or `false`, means no skills.
   */
  skillsDir?: string | false;
  /**
   * Where the runner builds the read-only skills plugin it passes with
   * `--plugin-dir` (runner/skills.ts). Default /opt/chef-agent/plugin. It
   * and every dir above it must be owned by root and writable by no one else.
   */
  pluginDir?: string;
  /**
   * The agent's CLAUDE_CONFIG_DIR, made fresh by the runner before the agent
   * (runner/skills.ts prepareClaudeConfigDir). Default
   * /opt/chef-agent/claude; the same ownership rule as pluginDir.
   */
  claudeConfigDir?: string;
  claudeBin?: string;
  maxTurns?: number;
  /**
   * Run as the agent user before the agent, with no credential. Default
   * "auto": by the checkout's lockfile (runner/chef-install.mjs), `npm ci
   * --ignore-scripts` or pnpm's frozen install without scripts; a checkout
   * neither can install fails the clone with what to do.
   */
  install?: string[][] | "auto";
  /**
   * Where a warm snapshot keeps its install caches (docs/chef-pipeline.md,
   * "Warm snapshots"; runner/chef-install-plan.mjs). With `install: "auto"`,
   * a warm dir whose marker is for exactly this checkout's inputs makes the
   * install the same command, offline, against a copy of its caches; any
   * mismatch, or a failed offline install, installs normally. Default
   * /opt/chef/warm; `false` never looks.
   */
  warmRoot?: string | false;
  /**
   * The local backend, started from the snapshot's binary as the agent user
   * before the agent and again, fresh, before the gates. `false` for none.
   */
  localBackend?: LocalBackendConfig | false;
  /**
   * Sets the environment variables the app's convex.config requires on the
   * local backend, with throwaway values, so a push isn't refused with
   * MissingEnvironmentVariables. The argv of a command in the repo (for
   * example `node scripts/local-env.mjs`), run as the agent user in the
   * checkout with CONVEX_SELF_HOSTED_URL and CONVEX_SELF_HOSTED_ADMIN_KEY,
   * right after every start of the local backend (the agent's, the gates'
   * and the screenshots') and before anything pushes to it. Bounded by
   * `timing.localEnvTimeoutMs`, its output logged; a failure is a log line,
   * never the run's. The run's `config.localEnv` wins if it is an argv,
   * `false` or "auto". "auto" runs `npm run --silent chef:local-env` if the
   * checkout's package.json (as cloned, before the agent) has that script,
   * else nothing. Default none.
   */
  localEnv?: string[] | false | "auto";
  /** Run as the agent user after the local backend is up, with its env. Default none. */
  prepare?: string[][];
  /**
   * The final screenshots after the guards (runner/screenshots.ts), and
   * PLAYWRIGHT_BROWSERS_PATH for the agent. `false` for none; they also
   * need the local backend.
   */
  screenshots?: ScreenshotConfig | false;
  /**
   * The official Convex plugin, loaded read-only next to the skills
   * (runner/convex-plugin.ts): built from `source` (default
   * /opt/chef/runner/convex-plugin, where the launcher installs the
   * vendored copy) into `dir` (default /opt/chef-agent/convex-plugin).
   * Absent source: no plugin. `false`: never.
   */
  convexPlugin?: { source?: string; dir?: string } | false;
  /**
   * `chef-check` (runner/check.ts), which the agent runs to see what the
   * runner will verify: its path on the agent's PATH (default chef-check,
   * which the start script links into /usr/local/bin), or `false` for none.
   * Local runs get none.
   */
  checkBin?: string | false;
  /**
   * Fix rounds after the agent's first session when a gate that passed on
   * the base fails (src/chef/gates.ts). The run's `config.fixRounds` wins;
   * default 2, at most 5. Local runs (`npx chef work`) get none.
   */
  fixRounds?: number;
  /**
   * Default `npm test` and `npm run typecheck`. The run's `config.gates` wins
   * if valid. "auto" runs `npm run typecheck`, `npm run lint` and `npm test`,
   * each only if the checkout's package.json (as cloned, before the agent)
   * has that script.
   */
  gates?: string[][] | "auto";
  /**
   * The frontend build (runner/frontend-artifact.ts), after the gates and
   * the commit; `false` for none. The run's `config.frontend` wins.
   */
  frontend?: FrontendConfig | false;
  authorEmail?: string;
  /** PATH for the runner's own commands (git). */
  runnerPath?: string;
  /** PATH and HOME the agent user gets. */
  agentPath?: string;
  agentHome?: string;
  gitBin?: string;
  timing?: Partial<Timing>;
  /**
   * The runner's environment: CHEF_RUN_TOKEN, CHEF_GIT_AUTH, CHEF_AI_TOKEN.
   * Read from here and nothing else; never handed on wholesale.
   */
  env: Record<string, string | undefined>;
};

export type SpawnRecord = {
  file: string;
  args: string[];
  cwd: string;
  asAgent: boolean;
  /** Names only, never values. */
  envKeys: string[];
};

/**
 * A local run (`npx chef work`, runner/local/): on a developer's machine,
 * with their own Claude Code or Codex login. These replace the pieces that
 * only make sense in the build sandbox. There is no inference placeholder
 * and no proxy settings; the git credential is fetched fresh before the
 * clone and again before the push.
 */
export type LocalMode = {
  /** The environment for the agent (`agent`) or for code it wrote (`gates`), in place of buildAgentEnv. */
  agentEnv: (o: {
    purpose: "agent" | "gates";
    localBackend?: LocalBackendEnv;
    playwrightBrowsersPath?: string;
  }) => Record<string, string>;
  /** The settings file, in place of claudeSettingsJson. */
  settingsJson: (o: { localEnv?: string[] }) => string;
  /** The agent's command, from the planned one; the prompt and request files may be added to. */
  agentPlan: (plan: AgentRunPlan) => AgentRunPlan;
  /** A log line from one line of the agent's stdout. Default summarizeStreamJson. */
  summarize?: (line: string) => string | null;
  /** After the agent is killed, before the gates: take away what only the agent needed. */
  afterAgent?: () => Promise<void>;
  /** A fresh Basic credential (base64 of user:password) for the runner's git. */
  gitAuth: (purpose: "clone" | "push") => Promise<string>;
  /** Merged into the provenance reported at `ready`. */
  provenance: Record<string, string>;
};

export type RunnerDeps = {
  agentUser: AgentUser;
  egressCheck: EgressCheck;
  fetch?: typeof fetch;
  /** Sees every process the runner starts. For audit and tests. */
  onSpawn?: (r: SpawnRecord) => void;
  /** Where scrubbed log lines go locally. Default stdout. */
  print?: (line: string) => void;
  /** For the credential and grant waits. Default the real clock. */
  clock?: Clock;
  /** Set for a local run (runner/local/); absent in the build sandbox. */
  local?: LocalMode;
};

export type Stage =
  | "start"
  | "selfTest"
  | "credentials"
  | "run"
  | "clone"
  | "baseline"
  | "agent"
  | "gates"
  | "guards"
  | "commit"
  | "frontend"
  | "push"
  | "done";

export type RunnerResult = {
  ok: boolean;
  stage: Stage;
  error?: string;
  branch?: string;
  commitSha?: string;
  pushedBranch?: boolean;
  pushedChef?: boolean;
  /** Set when main moved under the run: an alert, not a failure. */
  mainMoved?: boolean;
  violations?: GuardResult["violations"];
};

class Failure extends Error {
  stage: Stage;
  violations?: GuardResult["violations"];
  constructor(stage: Stage, message: string, violations?: GuardResult["violations"]) {
    super(message);
    this.stage = stage;
    this.violations = violations;
  }
}

const realClock: Clock = {
  now: () => Date.now(),
  sleep: (ms: number) => new Promise((r) => setTimeout(r, ms)),
};

function sha256(data: string | Uint8Array): string {
  return createHash("sha256").update(data).digest("hex");
}

/** Writes a file atomically (tmp then rename) with exactly this mode, whatever the umask. */
function writeAtomic(path: string, content: string, mode: number) {
  mkdirSync(dirname(path), { recursive: true });
  const tmp = `${path}.tmp-${process.pid}`;
  writeFileSync(tmp, content, { mode });
  chmodSync(tmp, mode);
  renameSync(tmp, path);
}

// ---------------------------------------------------------------- processes

type ExecOpts = {
  cwd: string;
  env: Record<string, string>;
  asAgent?: boolean;
  timeoutMs: number;
  /** A file to connect to stdin. */
  stdinPath?: string;
  onStdoutLine?: (line: string) => void;
  onStderrLine?: (line: string) => void;
};

type ExecResult = { code: number | null; signal: string | null; stdout: string; stderr: string; timedOut: boolean };

const KEEP_OUTPUT = 256 * 1024;

function lineSplitter(onLine: (l: string) => void) {
  let buf = "";
  return {
    push(chunk: string) {
      buf += chunk;
      let i: number;
      while ((i = buf.indexOf("\n")) >= 0) {
        onLine(buf.slice(0, i));
        buf = buf.slice(i + 1);
      }
      // A runaway line without newlines: hand it on in pieces.
      if (buf.length > 64 * 1024) {
        onLine(buf);
        buf = "";
      }
    },
    end() {
      if (buf) onLine(buf);
      buf = "";
    },
  };
}

// --------------------------------------------------------------- the runner

export async function runChef(cfg: RunnerConfig, deps: RunnerDeps): Promise<RunnerResult> {
  const timing: Timing = { ...DEFAULT_TIMING, ...cfg.timing };
  const doFetch = deps.fetch ?? fetch;
  const print = deps.print ?? ((l: string) => process.stdout.write(l + "\n"));
  const prefix = cfg.routePrefix ?? "/chef-agent";
  const apiBase = cfg.api.replace(/\/$/, "") + prefix;
  const gitBin = cfg.gitBin ?? "git";
  const runnerPath = cfg.runnerPath ?? "/usr/local/bin:/usr/bin:/bin";
  const authorEmail = cfg.authorEmail ?? "chef@chef.invalid";
  const agentUser = deps.agentUser;
  const clock = deps.clock ?? realClock;
  const stateDir = cfg.stateDir ?? DEFAULT_STATE_DIR;
  const claudeConfigDir = cfg.claudeConfigDir ?? DEFAULT_CLAUDE_CONFIG_DIR;

  const runToken = cfg.env.CHEF_RUN_TOKEN ?? "";
  let gitAuth = cfg.env.CHEF_GIT_AUTH ?? "";
  const aiToken = cfg.env.CHEF_AI_TOKEN ?? "";
  const known = [runToken, gitAuth, aiToken].filter((v) => v.length >= 8);
  const clean = (s: string) => scrub(s, { knownValues: known });

  mkdirSync(stateDir, { recursive: true, mode: STATE_DIR_MODE });
  // The mode on mkdir is masked by the umask and ignored for a dir that
  // already exists, so set it outright.
  chmodSync(stateDir, STATE_DIR_MODE);
  const statusPath = join(stateDir, "status.json");
  const markerPath = join(stateDir, "started");
  const agentLogPath = join(stateDir, "agent.jsonl");

  // status.json is readable by `daytona`, so it holds a fixed set of fields
  // and every string in it is scrubbed: the error, and each probe's text.
  const writeStatus = (s: { phase: string; ok: boolean; error?: string; selfTest?: EgressResult }) =>
    writeAtomic(statusPath, JSON.stringify(statusRecord(cfg.runId, s, clean)) + "\n", PUBLIC_FILE_MODE);

  // 1. Never twice. The orchestrator never restarts a runner; it reconciles.
  // Readable (nothing secret in it): the launcher reads it through Daytona
  // to adopt this runner after a lost start response.
  try {
    writeFileSync(markerPath, JSON.stringify({ pid: process.pid, runId: cfg.runId, at: Date.now() }) + "\n", {
      flag: "wx",
      mode: PUBLIC_FILE_MODE,
    });
    chmodSync(markerPath, PUBLIC_FILE_MODE);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "EEXIST") {
      const error = "a runner already started in this sandbox; refusing to start again";
      print(`chef-runner: ${error}`);
      return { ok: false, stage: "start", error };
    }
    throw e;
  }

  // ------------------------------------------------------------ helpers

  const record = (r: SpawnRecord) => deps.onSpawn?.(r);

  const exec = (file: string, args: string[], o: ExecOpts): Promise<ExecResult> =>
    new Promise((resolve, reject) => {
      let cmd = { file, args } as { file: string; args: string[]; uid?: number; gid?: number };
      if (o.asAgent) cmd = agentUser.command(file, args);
      record({ file: cmd.file, args: [...cmd.args], cwd: o.cwd, asAgent: !!o.asAgent, envKeys: Object.keys(o.env) });
      let stdinFd: number | undefined;
      if (o.stdinPath) stdinFd = openSync(o.stdinPath, "r");
      const child = spawn(cmd.file, cmd.args, {
        cwd: o.cwd,
        env: o.env,
        // Agent processes get their own process group so the whole tree can
        // be killed; the runner's own git commands don't need one.
        detached: !!o.asAgent,
        stdio: [stdinFd ?? "ignore", "pipe", "pipe"],
        ...(cmd.uid !== undefined ? { uid: cmd.uid } : {}),
        ...(cmd.gid !== undefined ? { gid: cmd.gid } : {}),
      });
      if (stdinFd !== undefined) closeSync(stdinFd);
      if (o.asAgent && child.pid) agentUser.spawned(child.pid);
      let stdout = "";
      let stderr = "";
      let timedOut = false;
      const outLines = o.onStdoutLine ? lineSplitter(o.onStdoutLine) : null;
      const errLines = o.onStderrLine ? lineSplitter(o.onStderrLine) : null;
      child.stdout!.setEncoding("utf8");
      child.stderr!.setEncoding("utf8");
      child.stdout!.on("data", (d: string) => {
        stdout = (stdout + d).slice(-KEEP_OUTPUT);
        outLines?.push(d);
      });
      child.stderr!.on("data", (d: string) => {
        stderr = (stderr + d).slice(-KEEP_OUTPUT);
        errLines?.push(d);
      });
      const timer = setTimeout(() => {
        timedOut = true;
        try {
          if (o.asAgent && child.pid) process.kill(-child.pid, "SIGKILL");
          else child.kill("SIGKILL");
        } catch {
          // Gone already.
        }
      }, o.timeoutMs);
      child.on("error", (e) => {
        clearTimeout(timer);
        reject(e);
      });
      let settled = false;
      const finish = (code: number | null, signal: string | null) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        outLines?.end();
        errLines?.end();
        resolve({ code, signal, stdout, stderr, timedOut });
      };
      child.on("close", (code, signal) => finish(code, signal));
      child.on("exit", (code, signal) => {
        if (!o.asAgent || !child.pid) return;
        // The command is done, so whatever it left in its process group goes
        // too. Something that escaped the group can still hold the pipes
        // open; don't wait on it longer than a moment (killAll gets it).
        try {
          process.kill(-child.pid, "SIGKILL");
        } catch {
          // Nothing left.
        }
        setTimeout(() => {
          child.stdout?.destroy();
          child.stderr?.destroy();
          finish(code, signal);
        }, 2000).unref();
      });
    });

  // The runner's git: a fixed environment, no global or system config, no
  // credential helpers, no prompts, hooks off on every command.
  const gitEnv = (withAuth: boolean): Record<string, string> => {
    const env: Record<string, string> = {
      PATH: runnerPath,
      HOME: join(stateDir, "home"),
      LANG: "C",
      GIT_CONFIG_NOSYSTEM: "1",
      GIT_CONFIG_GLOBAL: "/dev/null",
      GIT_TERMINAL_PROMPT: "0",
      GIT_ASKPASS: "/bin/false",
      SSH_ASKPASS: "/bin/false",
    };
    const extra: [string, string][] = [["credential.helper", ""]];
    if (withAuth && gitAuth) {
      // Daytona swaps the placeholder inside this header, toward the Code
      // Storage host only. The value is in this process's environment, which
      // only the runner's user can read.
      extra.push(["http.extraHeader", `Authorization: Basic ${gitAuth}`]);
    }
    env.GIT_CONFIG_COUNT = String(extra.length);
    extra.forEach(([k, v], i) => {
      env[`GIT_CONFIG_KEY_${i}`] = k;
      env[`GIT_CONFIG_VALUE_${i}`] = v;
    });
    return env;
  };

  // Set from the config, or from the run's config once it's fetched.
  let repoUrl = "";
  let repoScheme = "https";
  const setRepoUrl = (url: unknown) => {
    if (typeof url !== "string") throw new Failure("run", "no repo URL");
    let u: URL;
    try {
      u = new URL(url);
    } catch {
      throw new Failure("run", "the repo URL is not a URL");
    }
    if (u.username || u.password) throw new Failure("run", "the repo URL must not carry credentials");
    if (u.protocol !== "https:" && u.protocol !== "http:") throw new Failure("run", "the repo URL must be http(s)");
    repoUrl = url;
    repoScheme = u.protocol.slice(0, -1);
  };

  const gitSafety = () => [
    "-c", "core.hooksPath=/dev/null",
    "-c", "commit.gpgSign=false",
    "-c", "core.fsmonitor=false",
    "-c", "protocol.allow=never",
    "-c", `protocol.${repoScheme}.allow=always`,
    "-c", "http.followRedirects=false",
    "-c", "safe.directory=*",
    "-c", "user.name=Chef",
    "-c", `user.email=${authorEmail}`,
  ];

  /** git with the runner's git dir and the agent's checkout, given explicitly. */
  const git = async (
    args: string[],
    o: { auth?: boolean; allowFail?: boolean; worktree?: boolean; timeoutMs?: number } = {},
  ) => {
    const base = [...gitSafety(), `--git-dir=${cfg.gitDir}`];
    if (o.worktree !== false) base.push(`--work-tree=${cfg.workDir}`);
    const r = await exec(gitBin, [...base, ...args], {
      cwd: existsSync(cfg.workDir) ? cfg.workDir : stateDir,
      env: gitEnv(!!o.auth),
      timeoutMs: o.timeoutMs ?? timing.commandTimeoutMs,
    });
    if (r.code !== 0 && !o.allowFail) {
      throw new Error(`git ${args[0]} failed: ${clean(r.stderr.trim()).slice(-1500)}`);
    }
    return r;
  };

  /** A commit's sha, or null. */
  async function rev(ref: string) {
    const x = await git(["rev-parse", "--verify", "--quiet", `${ref}^{commit}`], { allowFail: true, worktree: false });
    return x.code === 0 ? x.stdout.trim() : null;
  }

  // ---------------------------------------------------------------- log

  let seq = 0;
  const pending: string[] = [];
  let inFlight: { seq: number; lines: string[] } | null = null;
  let credentialLive = false;
  let flushing: Promise<void> = Promise.resolve();

  const logLine = (line: string) => {
    const l = clean(line).slice(0, 4000);
    print(l);
    pending.push(l);
    if (pending.length >= 200) void flush();
  };

  const flushOnce = async () => {
    if (!credentialLive) return;
    while (inFlight || pending.length > 0) {
      if (!inFlight) {
        inFlight = { seq, lines: pending.splice(0, 200) };
        seq++;
      }
      const res = await api("POST", "/log", inFlight).catch(() => null);
      // A failed batch is kept and retried later under the same seq, so a
      // retry of one that did land is not stored twice.
      if (!res || !res.ok) return;
      inFlight = null;
    }
  };
  const flush = () => (flushing = flushing.then(flushOnce, flushOnce));

  // ---------------------------------------------------------------- API

  async function api(method: "GET" | "POST", path: string, body?: unknown) {
    return await doFetch(apiBase + path, {
      method,
      headers: {
        authorization: `Bearer ${runToken}`,
        ...(body !== undefined ? { "content-type": "application/json" } : {}),
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
    });
  }

  async function getRun(): Promise<{ status: number; body: any }> {
    const res = await api("GET", "/run");
    const text = await res.text();
    let body: any = null;
    try {
      body = JSON.parse(text);
    } catch {
      // Not JSON.
    }
    return { status: res.status, body };
  }

  let phase = "launched";
  async function report(to: string, facts?: Record<string, unknown>) {
    const res = await api("POST", "/report", { fromPhase: phase, toPhase: to, ...(facts ? { facts } : {}) });
    const body: any = await res.json().catch(() => null);
    if (!res.ok || !body) {
      throw new Error(`report ${phase} -> ${to} refused: ${res.status} ${clean(String(body?.error ?? ""))}`);
    }
    // The server's phase: for a request it may already be the grant (an
    // enrolled run's requests are granted at once).
    phase = typeof body.phase === "string" ? body.phase : to;
    logLine(`chef-runner: phase ${to}${phase !== to ? `, granted ${phase}` : ""}`);
  }

  /**
   * After a request (`cloned`, `committed`), wait until the orchestration
   * grants the next phase. Polls the heartbeat, which returns the run's
   * phase. Bounded: no grant within grantWaitMs fails the run, and so does
   * the run moving anywhere else or its credential being revoked.
   */
  async function waitForGrant(want: string, stageNow: Stage) {
    const requested = phase;
    const until = clock.now() + timing.grantWaitMs;
    for (;;) {
      if (phase === want) {
        logLine(`chef-runner: ${want} granted`);
        return;
      }
      if (phase !== requested) throw new Failure(stageNow, `the run moved to ${phase} while waiting for ${want}`);
      if (clock.now() > until) throw new Failure(stageNow, `${want} was not granted in time`);
      await clock.sleep(timing.pollMs);
      const res = await api("POST", "/heartbeat").catch(() => null);
      if (!res) continue;
      const body: any = await res.json().catch(() => null);
      if (res.status === 401 || res.status === 403) throw new Failure(stageNow, "the run was stopped");
      if (res.ok && typeof body?.phase === "string") phase = body.phase;
    }
  }

  // ---------------------------------------------------------- the run

  let heartbeat: ReturnType<typeof setInterval> | undefined;
  let logTimer: ReturnType<typeof setInterval> | undefined;
  let stage: Stage = "selfTest";
  const result: RunnerResult = { ok: false, stage };
  // What this run learned, for the next one (src/chef/learnings.ts):
  // reported once, at the end, whether the run built or not.
  const startedAt = clock.now();
  const timings: PhaseTimings = {};
  const observed: ObservedFacts = {};
  let learningsSent = false;
  // Values the runner made for this sandbox alone (the local backends' admin
  // keys and instance secrets): throwaway to the transcript scan.
  const sandboxLocal: string[] = [];
  let readRepoNotes: (() => { entries: RepoNote[]; invalid: number; dropped: number }) | null = null;
  // What the agent tried (its summary and the diff stat), for the run's
  // record when it fails; set once the agent has run.
  let describeAttempt: (() => Promise<{ summary: string; diffStat: string }>) | null = null;
  // The agent's Claude Code session, from its stream-json `init`, to resume
  // for a fix round; null when it never said (another agent, an old CLI).
  let sessionId: string | null = null;
  // Keeps a failed run's work for "Try again" (chefAttempts); set once the agent has run.
  let uploadAttempt: (() => Promise<void>) | null = null;

  try {
    // 2. Self-test. Nothing is live yet, and no request has been made.
    writeStatus({ phase: "selfTest", ok: true });
    let st: EgressResult;
    try {
      st = await deps.egressCheck();
    } catch (e) {
      st = { ok: false, probes: [{ probe: "self-test", blocked: false, detail: String((e as Error).message) }] };
    }
    if (!st.ok) {
      const failed = st.probes.filter((p) => !p.blocked).map((p) => `${p.probe}: ${p.detail}`);
      throw Object.assign(new Failure("selfTest", `egress self-test failed: ${failed.join("; ")}`), { selfTest: st });
    }

    // 3. Ready: the orchestrator reads this and makes the credentials live.
    writeStatus({ phase: "ready", ok: true, selfTest: st });
    print("chef-runner: self-test passed, waiting for credentials");
    stage = "credentials";
    const deadline = clock.now() + timing.credentialWaitMs;
    let run: { status: number; body: any };
    for (;;) {
      run = await getRun().catch((e: unknown) => {
        // A dead credential is a 401; a network error means the proxy hasn't
        // let us through yet. A TLS error never fixes itself: fail now
        // instead of waiting out the deadline.
        const code = String((e as { cause?: { code?: unknown } })?.cause?.code ?? "");
        if (/CERT|UNABLE_TO_VERIFY|SELF_SIGNED|ERR_TLS/i.test(code)) {
          throw new Failure("credentials", `TLS to the Chef API failed (${code}); is NODE_EXTRA_CA_CERTS set?`);
        }
        return { status: 0, body: null };
      });
      if (run.status === 200 && run.body) break;
      if (run.status !== 0 && run.status !== 401) {
        throw new Failure("credentials", `GET /run refused: ${run.status} ${clean(String(run.body?.error ?? ""))}`);
      }
      if (clock.now() > deadline) throw new Failure("credentials", "the run credential never went live");
      await clock.sleep(timing.pollMs);
    }
    credentialLive = true;
    heartbeat = setInterval(() => {
      void api("POST", "/heartbeat").catch(() => {});
    }, timing.heartbeatMs);
    logTimer = setInterval(() => void flush(), timing.logFlushMs);

    // 4. The run and its snapshot.
    stage = "run";
    const r = run.body as ApprovedRun & {
      runId: string;
      phase: string;
      deadline?: number;
      config?: Record<string, unknown>;
      /** What earlier builds learned (chefLearnings.forRun): the agent's brief and cached baselines. */
      learnings?: { brief?: unknown; baselines?: unknown };
      /** "Try again" on a failed build that left its work: GET /attempt has it. */
      continues?: boolean;
      /**
       * "merge": main moved after this request was built and approved for
       * Ship it. No agent: merge the current main into chef, check it
       * exactly as a build is checked (gates, guards, deploy checks, the
       * frontend), and push the merge (docs/chef-pipeline.md, "When main
       * moves before Ship it").
       */
      mode?: string;
      /**
       * A release merge (contract 13): main moved under release `seq`, so
       * merge it into the release's approved commit `fromSha` (not chef's
       * tip), let the agent resolve conflicts and fix the checks when
       * `repair`, and push the request branch only (docs/chef-pipeline.md,
       * "When main moves under Ship it").
       */
      release?: { seq?: unknown; fromSha?: unknown; repair?: unknown };
      /** A follow-up build: why the last build's preview failed on its own code. */
      followUp?: { reason?: unknown };
    };
    if (r.runId !== cfg.runId) throw new Failure("run", "the credential belongs to another run");
    await validateSnapshot(r);
    setRepoUrl(cfg.repoUrl ?? r.config?.repoUrl);
    const branch = requestBranchName(r.itemNumber, cfg.runId);
    result.branch = branch;
    const mergeOnly = r.mode === "merge";
    const follow =
      mergeOnly && r.release && typeof r.release.fromSha === "string" && /^[0-9a-f]{40}$/.test(r.release.fromSha)
        ? { seq: Number(r.release.seq) || 0, fromSha: r.release.fromSha, repair: r.release.repair === true }
        : null;
    if (follow) {
      logLine(
        `chef-runner: main moved under release #${follow.seq}: merging it into the approved commit ${follow.fromSha.slice(0, 12)} and checking again` +
          (follow.repair ? "; the agent resolves conflicts and fixes the checks if it must" : ", with no agent"),
      );
    } else if (mergeOnly) logLine("chef-runner: main moved since this request was built: merging it in and checking again, with no agent");
    phase = r.phase;
    const provenance = {
      nodeVersion: process.version,
      model: CHEF_MODEL,
      runnerSha256: sha256(readFileSync(new URL(import.meta.url))),
      ...deps.local?.provenance,
    };
    if (phase === "launched") await report("ready", { provenance });
    if (phase !== "ready") throw new Failure("run", `the run is in ${phase}, not ready`);
    await report("cloning");

    mkdirSync(join(cfg.chefDir, "attachments"), { recursive: true, mode: 0o755 });
    for (const a of r.snapshot.attachments) await fetchAttachment(a);
    // A batch's other requests' files (docs/chef-pipeline.md, "Batching").
    for (const [k, m] of (r.batch ?? []).entries()) {
      for (const a of m.snapshot.attachments) await fetchAttachment(a, k + 1);
    }

    // 5. Clone into the runner's git dir.
    stage = "clone";
    if (deps.local) await refreshGitAuth("clone");
    await waitForGitHost("clone");
    await git(["clone", "--bare", "--quiet", repoUrl, cfg.gitDir], { auth: true, worktree: false });
    const chefBefore = await rev("refs/heads/chef");
    const mainBefore = await rev("refs/heads/main");
    // A release merge starts from the release's own commit: newer builds on
    // chef aren't part of what was approved.
    const fromSha = follow ? await rev(follow.fromSha) : null;
    if (follow && fromSha !== follow.fromSha) throw new Failure("clone", `the release's commit ${follow.fromSha.slice(0, 12)} isn't in the repo`);
    const start = fromSha ?? chefBefore ?? mainBefore;
    if (!start) throw new Failure("clone", "the repo has neither chef nor main");
    mkdirSync(cfg.workDir, { recursive: true });
    await git(["checkout", "--quiet", "--force", "-B", branch, start]);
    // main merged in. A clean merge is committed here, and the agent starts
    // from it. A conflicting one stays in progress (MERGE_HEAD) and the
    // agent resolves it (startMergeWithConflicts); the run's own commit is
    // then the merge.
    let conflicts: MergeConflict[] = [];
    let baseSha = start;
    // What main brought that chef lacked: for a merge-only run's card.
    let mergedMain: { count: number; subjects: string[] } | null = null;
    if (mergeOnly && (!start || !mainBefore || (!follow && !chefBefore))) throw new Failure("clone", "nothing to merge: the repo needs both chef and main");
    if (mergeOnly) {
      const count = Number((await git(["rev-list", "--count", `${start}..${mainBefore}`], { worktree: false })).stdout.trim()) || 0;
      const subjects = (await git(["log", "--no-merges", "--format=%s", "-n", "20", `${start}..${mainBefore}`], { worktree: false })).stdout
        .split("\n")
        .map((l) => clean(revealInvisible(l)).slice(0, 200))
        .filter(Boolean);
      mergedMain = { count, subjects };
      logLine(`chef-runner: main has ${count} commit${count === 1 ? "" : "s"} chef lacks${subjects.length ? `: ${subjects.slice(0, 5).join("; ")}` : ""}`);
    }
    // The merge's starting side: chef, or a release merge's approved commit.
    const ours = follow ? start : chefBefore;
    if (ours && mainBefore) {
      const m = await git(["-c", "merge.conflictStyle=diff3", "merge", "--no-edit", "--quiet", "refs/heads/main"], {
        allowFail: true,
      });
      if (m.code !== 0 && follow?.repair) {
        // The agent resolves them, keeping both sides' intent; what it
        // changes is shown for one approval (the resolution diff).
        conflicts = await startMergeWithConflicts(ours, mainBefore);
        baseSha = await mergeBaseline(ours, mainBefore);
        logLine(`chef-runner: main conflicts with release #${follow.seq} in ${conflicts.length} file${conflicts.length === 1 ? "" : "s"}: resolving them`);
      } else if (m.code !== 0 && mergeOnly) {
        // No agent to resolve anything: say which files, and that Try again
        // rebuilds the request on the new main (its agent resolves them).
        const ls = await git(["ls-files", "--unmerged", "-z"], { allowFail: true });
        const files = ls.code === 0 ? parseUnmergedZ(ls.stdout).map((c) => revealInvisible(clean(c.path))) : [];
        await git(["merge", "--abort"], { allowFail: true });
        throw new Failure(
          "clone",
          `main doesn't merge cleanly into this build${files.length ? ` (${files.slice(0, 5).join(", ")}${files.length > 5 ? `, and ${files.length - 5} more` : ""})` : ""}: Try again rebuilds it on the new main`,
        );
      }
      else if (m.code !== 0) {
        conflicts = await startMergeWithConflicts(ours, mainBefore);
        baseSha = await mergeBaseline(ours, mainBefore);
      } else baseSha = (await rev("HEAD"))!;
    }
    // What the preview deploy would refuse (src/chef/deployChecks.ts, the
    // deploy scripts' own checks): on what this build deploys, main merged
    // into chef (and main's side too while they conflict). Before the
    // install, the grant and the agent, so a repo the deploy refuses costs
    // nothing but this clone, and the run says exactly what to fix.
    const refusals = await deployRefusalsAt("HEAD", conflicts.length === 0);
    if (conflicts.length > 0 && mainBefore) {
      for (const x of await deployRefusalsAt(mainBefore, false)) {
        if (!refusals.some((y) => y.message === x.message)) refusals.push(x);
      }
    }
    if (refusals.length > 0) {
      for (const x of refusals) {
        logLine(`chef-runner: deploy check: ${x.message}`);
        for (const l of x.fix) logLine(`chef-runner: deploy check:   ${l}`);
      }
      throw new Failure("clone", deployRefusalError(refusals[0]));
    }
    logLine("chef-runner: deploy check: nothing here the preview deploy refuses");
    await agentUser.own(cfg.workDir);

    // Set once the local backend is up; the agent and gates get its URL and key.
    let backend: LocalBackendEnv | undefined;
    const shots = cfg.screenshots === false ? null : resolveScreenshotConfig(cfg.screenshots ?? {});
    // The app's sign-in link function (chefRunnerConfig.loginFunction): with
    // it, `chef-screenshot --signed-in` and the final screenshots sign in as
    // the app's demo user on the local backend. A function name, never a link.
    const loginFunction =
      shots && typeof r.config?.loginFunction === "string" && LOGIN_FUNCTION.test(r.config.loginFunction)
        ? (r.config.loginFunction as string)
        : null;
    if (shots && r.config?.loginFunction !== undefined && !loginFunction) {
      logLine("chef-runner: screenshots: the login function isn't module:function; screenshots won't sign in");
    }
    const agentEnvFor = (purpose: "agent" | "gates" = "agent"): Record<string, string> => {
      const env = deps.local
        ? deps.local.agentEnv({
            purpose,
            ...(backend ? { localBackend: backend } : {}),
            ...(shots ? { playwrightBrowsersPath: shots.browsersPath } : {}),
          })
        : buildAgentEnv(cfg.env, {
            home: cfg.agentHome ?? AGENT_HOME,
            path: cfg.agentPath ?? AGENT_PATH,
            claudeConfigDir,
            ...(backend ? { localBackend: backend } : {}),
            ...(shots ? { playwrightBrowsersPath: shots.browsersPath } : {}),
          });
      return loginFunction ? { ...env, CHEF_LOGIN_FUNCTION: loginFunction } : env;
    };
    const gateEnv = () => {
      const env = agentEnvFor("gates");
      // Install, backend and gates never call inference.
      delete (env as Record<string, string | undefined>).ANTHROPIC_AUTH_TOKEN;
      return env;
    };
    const runAsAgent = async (
      what: string,
      argv: string[],
      env: Record<string, string> = gateEnv(),
      onLine?: (line: string) => void,
      cwd: string = cfg.workDir,
    ) => {
      assertInertArgs(argv);
      const line = (l: string) => {
        onLine?.(l);
        logLine(`${what}: ${l}`);
      };
      const x = await exec(argv[0], argv.slice(1), {
        cwd,
        env,
        asAgent: true,
        timeoutMs: timing.commandTimeoutMs,
        onStdoutLine: line,
        onStderrLine: line,
      });
      return x;
    };
    // The app's required env vars on a backend that just started: its own
    // command, bounded, logged with the backend's key scrubbed. Never fatal:
    // a push it didn't help says so in the log.
    const runLocalEnv = async (argv: string[], b: LocalBackendEnv) => {
      const hide = (l: string) => (b.adminKey ? l.split(b.adminKey).join("[redacted]") : l);
      const t0 = clock.now();
      try {
        const x = await exec(argv[0], argv.slice(1), {
          cwd: cfg.workDir,
          env: gateEnv(),
          asAgent: true,
          timeoutMs: timing.localEnvTimeoutMs,
          onStdoutLine: (l) => logLine(`local-env: ${hide(l)}`),
          onStderrLine: (l) => logLine(`local-env: ${hide(l)}`),
        });
        const took = `${Math.round((clock.now() - t0) / 100) / 10} s`;
        if (x.code === 0) logLine(`chef-runner: local env: ${argv.join(" ")} set the local backend's env vars (${took})`);
        else {
          logLine(
            `chef-runner: local env: ${argv.join(" ")} ${x.timedOut ? `timed out after ${took}` : `failed (${x.code ?? x.signal})`}; going on without it`,
          );
        }
      } catch (e) {
        logLine(`chef-runner: local env: ${argv.join(" ")} didn't run: ${hide((e as Error).message)}; going on without it`);
      }
    };
    // The install, by the lockfile unless the config names commands.
    const installStarted = clock.now();
    let installs: string[][];
    let lockfile: string | null = "package-lock.json";
    let warmInstalled = false;
    // How the install went, for the run's provenance: "warm <key12>", or "normal: <why not>".
    const installProvenance: { warmInstall?: string } = {};
    const runInstall = async (argv: string[], quiet = false) => {
      const env = gateEnv();
      const pnpmCodes: string[] = [];
      const x = await runAsAgent("install", argv, env, (l) => collectPnpmErrorCodes(l, pnpmCodes));
      if (x.code === 0) return null;
      // npm can fail with only "Exit handler never called!"; its debug
      // log has the error codes (runner/npm-log.ts). pnpm (run through
      // npm exec) prints its ERR_PNPM_* codes; npm's log still has why
      // fetching pnpm itself failed.
      const npmWhy = argv[0] === "npm" && env.HOME ? newestNpmLogSummary(env.HOME) : null;
      if (npmWhy && !quiet) logLine(`chef-runner: install: npm's log: ${npmWhy}`);
      return [pnpmCodes.length ? `pnpm error ${pnpmCodes.join(", ")}` : null, npmWhy].filter(Boolean).join("; ") || `exit ${x.code}`;
    };
    if (cfg.install === undefined || cfg.install === "auto") {
      const plan = installPlan(cfg.workDir);
      if ("error" in plan) {
        for (const l of plan.help) logLine(`chef-runner: install: ${l}`);
        throw new Failure("clone", `install failed: ${plan.error}`);
      }
      logLine(`chef-runner: install: ${describePlan(plan)}`);
      observed.install = describePlan(plan);
      installs = [plan.argv];
      lockfile = plan.lockfile;
      // A warm snapshot's caches, when they are for exactly this checkout.
      const warmRoot = cfg.warmRoot === undefined ? WARM_ROOT : cfg.warmRoot;
      const warm = warmRoot ? await warmLookup(cfg.workDir, warmRoot).catch((e: Error) => ({ ok: false as const, reason: clean(e.message) })) : null;
      if (warm?.ok) {
        const key12 = warm.marker.key.slice(0, 12);
        let prepared: { argv: string[]; dir: string } | null = null;
        try {
          prepared = prepareWarm(warm);
          await agentUser.own(prepared.dir);
        } catch (e) {
          logLine(`chef-runner: install: the warm caches couldn't be copied (${clean((e as Error).message)}); installing normally`);
        }
        if (prepared) {
          logLine(`chef-runner: install: warm, from ${warm.marker.name} (key ${key12}), offline`);
          const why = await runInstall(prepared.argv, true);
          if (why === null) {
            warmInstalled = true;
            installProvenance.warmInstall = `warm ${key12}`;
          } else {
            logLine(`chef-runner: install: the warm install failed (${clean(why)}); installing normally`);
            installProvenance.warmInstall = `normal: the warm install from ${key12} failed`;
            rmSync(join(cfg.workDir, "node_modules"), { recursive: true, force: true });
          }
        } else installProvenance.warmInstall = `normal: the warm caches couldn't be copied`;
      } else if (warm && warm.reason !== "not a warm snapshot") {
        logLine(`chef-runner: install: no warm install: ${clean(warm.reason)}`);
        installProvenance.warmInstall = `normal: ${clean(warm.reason)}`.slice(0, 200);
      }
      if (warmInstalled) installs = [];
    } else installs = cfg.install;
    for (const argv of installs) {
      const why = await runInstall(argv);
      if (why !== null) {
        throw new Failure("clone", `install failed: ${argv.join(" ")}${/^exit \d+$/.test(why) ? "" : ` (${why})`}`);
      }
    }
    await agentUser.killAll();
    // "install (warm)" in the run's phase times, or "install".
    if (warmInstalled) timings.installWarm = clock.now() - installStarted;
    else timings.install = clock.now() - installStarted;
    const lockPath = lockfile ? join(cfg.workDir, lockfile) : null;
    const lockfileHash = lockPath && existsSync(lockPath) ? sha256(readFileSync(lockPath)) : undefined;
    const lb = cfg.localBackend === false ? null : resolveLocalBackend(cfg.localBackend ?? {});
    // The scripts "auto" picks gates and the local env command from, read
    // now, as cloned: the agent can't add or drop a gate.
    const scripts = packageScripts(cfg.workDir);
    observed.scripts = [...scripts].sort().slice(0, 40);
    const localEnv = lb ? pickLocalEnv(r.config, cfg.localEnv, scripts) : null;
    // The gates, from the scripts as cloned too, and their results so far.
    const gates = pickGates(r.config, cfg.gates, scripts);
    const gateResults: GateResult[] = gates.map((argv) => ({ command: argv.join(" "), baseline: "none" }));
    // Each gate's output on the baseline, to tell its old failures from new ones.
    const baselineOutputs: (string | undefined)[] = gates.map(() => undefined);
    // Where a merge's baseline (main's own tree) was checked out.
    const mainDir = join(dirname(cfg.workDir), "chef-main-baseline");
    const configuredRounds = clampFixRounds(typeof r.config?.fixRounds === "number" ? r.config.fixRounds : (cfg.fixRounds ?? undefined));
    // A release merge's agent gets a few rounds to fix what the merge broke;
    // a plain merge-only build gets none.
    const fixRounds = deps.local ? 0 : follow?.repair ? Math.min(MERGE_REPAIR_ROUNDS, configuredRounds) : mergeOnly ? 0 : configuredRounds;
    // A release merge's agent: whether it ran, and the checks it was asked to fix.
    let repairRan = false;
    const repairedGates = new Set<string>();
    const startBackend = async () => {
      if (lb) {
        backend = await startLocalBackend(lb);
        if (localEnv) await runLocalEnv(localEnv, backend);
      }
      for (const argv of cfg.prepare ?? []) {
        const x = await runAsAgent("backend", argv);
        if (x.code !== 0) throw new Failure("clone", `local backend failed: ${argv.join(" ")}`);
      }
    };
    await startBackend();
    // A request: the orchestrator kills the git credential and narrows
    // egress, then grants `agent`. Nothing of the agent's starts before.
    await report("cloned", {
      // The run's base, as the host uses it, is where main was: the beta,
      // preview and ship scripts require the build to descend from it, and
      // "main moved" compares it with main. With main merged in, `baseSha`
      // here is a merge commit made in this sandbox; after a conflicting
      // merge it is never pushed at all (mergeBaseline), so the beta deploy
      // refused "main (...) is not in the repo". Main itself is always there.
      baseSha: mainBefore ?? baseSha,
      branch,
      ...(chefBefore ? { chefBefore } : {}),
      ...(lockfileHash || installProvenance.warmInstall
        ? { provenance: { ...(lockfileHash ? { lockfileHash } : {}), ...installProvenance } }
        : {}),
    });
    await waitForGrant("agent", "clone");

    const runBaseline = async () => {
      stage = "baseline";
      const t0 = clock.now();
      // After a conflicting merge the checkout holds conflict markers, so a
      // baseline there would say nothing: every gate blocks, as before.
      if (conflicts.length > 0) {
        logLine("chef-runner: baseline: skipped (main and chef conflict); every gate that fails after the agent blocks");
        return;
      }
      const tree = (await git(["rev-parse", "HEAD^{tree}"], { worktree: false })).stdout.trim();
      const commands = gateResults.map((g) => g.command);
      const cached = matchBaseline(r.learnings?.baselines, tree, lockfileHash, commands);
      if (cached) {
        cached.forEach((o, i) => {
          gateResults[i].baseline = o;
          gateResults[i].baselineCached = true;
        });
        for (const g of gateResults) logLine(`chef-runner: baseline: ${gateSummary(g)}`);
        logLine(`chef-runner: baseline: from an earlier run on the same tree ${tree.slice(0, 12)} and lockfile; not run again`);
      } else {
        // The local backend started before `cloned` is fresh: nothing has
        // run on it yet. The baseline uses it; the agent gets another.
        for (let i = 0; i < gates.length; i++) {
          const out = { text: "" };
          const x = await runAsAgent("baseline", gates[i], gateEnv(), (l) => {
            out.text = (out.text + l + "\n").slice(-4 * GATE_OUTPUT_BYTES);
          });
          gateResults[i].baseline = x.code === 0 ? "pass" : "fail";
          if (x.code !== 0) baselineOutputs[i] = out.text;
        }
        await agentUser.killAll();
        if ((await agentUser.list()).length > 0) throw new Failure("baseline", "agent processes still alive after the baseline");
        for (const g of gateResults) logLine(`chef-runner: baseline: ${gateSummary(g)}`);
        // What the gates wrote goes, so the agent starts from the base and
        // none of it lands in the diff: tracked files back to HEAD, new
        // files that aren't ignored removed. Ignored ones (node_modules)
        // stay. git never follows a symlink in the checkout for either.
        const st = await git(["status", "--porcelain", "--untracked-files=all"]);
        if (st.stdout.trim() !== "") {
          await git(["reset", "--quiet", "--hard", "HEAD"]);
          await git(["clean", "-fdq", "-e", "node_modules"]);
          await agentUser.own(cfg.workDir);
          logLine("chef-runner: baseline: put back what the gates changed in the checkout");
        }
        // A fresh backend for the agent, like the gates get.
        await startBackend();
      }
      observed.baseline = {
        tree,
        ...(lockfileHash ? { lockfileHash } : {}),
        gates: gateResults.filter((g) => g.baseline !== "none").map((g) => ({ command: g.command, outcome: g.baseline as "pass" | "fail" })),
      };
      timings.baseline = clock.now() - t0;
    };

    /**
     * A merge's baseline: every gate on main's own tree, so a check main
     * already fails (a lint error that has been on main for weeks) doesn't
     * fail the merge; only problems the merge adds do. main is checked out
     * (git archive, no hooks, no credential) next to the checkout with the
     * checkout's node_modules linked in, which is right only when main's
     * lockfile is the merged one; otherwise there is no baseline and every
     * gate must pass, as before.
     */
    const runMainBaseline = async () => {
      stage = "baseline";
      const t0 = clock.now();
      if (!mainBefore || gates.length === 0) return;
      const lockOf = async (rev: string) => (lockfile ? (await git(["rev-parse", "--verify", "--quiet", `${rev}:${lockfile}`], { allowFail: true, worktree: false })).stdout.trim() : "");
      const merged = lockfile && existsSync(join(cfg.workDir, lockfile))
        ? (await git(["hash-object", "--", join(cfg.workDir, lockfile)], { worktree: false })).stdout.trim()
        : "";
      if ((await lockOf(mainBefore)) !== merged) {
        logLine("chef-runner: baseline on main: skipped (main's lockfile isn't the merged one); every gate must pass on the merged code");
        return;
      }
      rmSync(mainDir, { recursive: true, force: true });
      mkdirSync(mainDir, { recursive: true });
      const tar = join(stateDir, "main-baseline.tar");
      await git(["archive", "--format=tar", `--output=${tar}`, mainBefore], { worktree: false });
      const x = await exec("tar", ["-xf", tar, "-C", mainDir], { cwd: stateDir, env: { PATH: process.env.PATH ?? "/usr/bin:/bin" }, timeoutMs: timing.commandTimeoutMs });
      rmSync(tar, { force: true });
      if (x.code !== 0) {
        logLine("chef-runner: baseline on main: skipped (main's tree couldn't be checked out); every gate must pass on the merged code");
        return;
      }
      if (existsSync(join(cfg.workDir, "node_modules")) && !existsSync(join(mainDir, "node_modules"))) {
        symlinkSync(join(cfg.workDir, "node_modules"), join(mainDir, "node_modules"));
      }
      await agentUser.own(mainDir);
      for (let i = 0; i < gates.length; i++) {
        const out = { text: "" };
        const r = await runAsAgent("baseline (main)", gates[i], gateEnv(), (l) => {
          out.text = (out.text + l + "\n").slice(-4 * GATE_OUTPUT_BYTES);
        }, mainDir);
        gateResults[i].baseline = r.code === 0 ? "pass" : "fail";
        gateResults[i].baselineOn = "main";
        if (r.code !== 0) baselineOutputs[i] = out.text;
      }
      await agentUser.killAll();
      if ((await agentUser.list()).length > 0) throw new Failure("baseline", "agent processes still alive after the baseline");
      rmSync(mainDir, { recursive: true, force: true });
      for (const g of gateResults) logLine(`chef-runner: baseline: ${gateSummary(g)}`);
      for (const g of gateResults) {
        if (g.baseline === "fail") logLine(`chef-runner: main already fails \`${g.command}\`; only what the merge adds blocks it`);
      }
      await startBackend();
      timings.baseline = clock.now() - t0;
    };

    /**
     * check.json for `chef-check` (runner/check.ts): the gates and how each
     * did on the base, the frontend build, and the base's file list (git
     * blob hashes) and package.json files, for the guards' dry run. Nothing
     * secret: it is the app's own config and tree.
     */
    const writeCheckConfig = async (path: string) => {
      const ls = await git(["ls-tree", "-r", "-z", "--full-tree", baseSha], { worktree: false });
      const base: Record<string, [string, string]> = {};
      const packageJson: Record<string, string> = {};
      for (const entry of ls.stdout.split("\0")) {
        const m = /^(\d{6}) blob ([0-9a-f]{40,64})\t([\s\S]+)$/.exec(entry);
        if (!m) continue;
        base[m[3]] = [m[1], m[2]];
        if (/(^|\/)package\.json$/i.test(m[3]) && Object.keys(packageJson).length < 20) {
          const x = await git(["show", `${baseSha}:${m[3]}`], { allowFail: true, worktree: false });
          if (x.code === 0 && x.stdout.length < 1024 * 1024) packageJson[m[3]] = x.stdout;
        }
      }
      const fe = pickFrontend(r.config, cfg.frontend);
      const baseline: Record<string, "pass" | "fail"> = {};
      for (const g of gateResults) if (g.baseline !== "none") baseline[g.command] = g.baseline;
      const config = {
        gates,
        baseline,
        frontend: fe ? { command: fe.command, urlEnvVar: fe.urlEnvVar, distDir: fe.distDir } : null,
        base,
        packageJson,
        timeoutMs: timing.commandTimeoutMs,
      };
      writeAtomic(path, JSON.stringify(config) + "\n", 0o644);
    };

    // 5b. The baseline: every gate on the untouched checkout, as the agent
    // user with the gates' environment, after the grant (git dead, egress
    // the app's own host) and before the agent exists, so nothing the agent
    // writes can touch it. A gate that fails here doesn't fail the build.
    // A merge-only run has no baseline: what ships is this very tree, so
    // every gate must pass on it.
    if (gates.length > 0 && !mergeOnly) await runBaseline();
    // A merge is judged against main: what main already fails isn't the merge's.
    else if (mergeOnly) await runMainBaseline();

    // 5c. "Try again" on a failed build that left its work (chefAttempts):
    // start from it, after the baseline. On the same base it applies as is.
    // When main moved since, it is applied three-way onto the new base (the
    // runner's git, no credential, hooks off; the blobs it names are in the
    // clone's history), and if that is clean the agent only verifies and
    // adjusts it, in a shorter session, instead of building it again. A diff
    // that doesn't apply cleanly is dropped and the agent starts fresh, and
    // the run's provenance says which happened. The work is untrusted either
    // way: the gates and guards check everything against the base, applied
    // diff included, exactly as they check the agent's own.
    let continued = "";
    const applyEarlierAttempt = async (): Promise<false | "same" | "rebased"> => {
      const fresh = (why: string, line: string) => {
        continued = `fresh: ${why}`.slice(0, 200);
        logLine(line);
        return false as const;
      };
      const res = await api("GET", "/attempt").catch(() => null);
      const body: any = res ? await res.json().catch(() => null) : null;
      if (!res?.ok || !body || typeof body.diff !== "string" || typeof body.baseTree !== "string") {
        return fresh("not fetched", `chef-runner: the earlier attempt wasn't fetched (${res ? res.status : "no answer"}); starting fresh`);
      }
      if (sha256(body.diff) !== body.sha256) {
        return fresh("hash mismatch", "chef-runner: the earlier attempt doesn't match its hash; starting fresh");
      }
      const tree = (await git(["rev-parse", "HEAD^{tree}"], { worktree: false })).stdout.trim();
      const moved = body.baseTree !== tree;
      const patch = join(stateDir, "earlier-attempt.patch");
      writeFileSync(patch, body.diff, { mode: 0o600 });
      const x = await git(
        moved ? ["apply", "--3way", "--whitespace=nowarn", patch] : ["apply", "--index", "--binary", "--whitespace=nowarn", patch],
        { allowFail: true },
      );
      rmSync(patch, { force: true });
      const unmerged = moved
        ? (await git(["diff", "--name-only", "--diff-filter=U", "-z"], { allowFail: true })).stdout.split("\0").filter(Boolean)
        : [];
      if (x.code !== 0 || unmerged.length > 0) {
        await git(["reset", "--quiet", "--hard", "HEAD"]);
        await agentUser.own(cfg.workDir);
        if (!moved) {
          return fresh("doesn't apply", `chef-runner: the earlier attempt doesn't apply (${clean(x.stderr.trim()).slice(-300)}); starting fresh`);
        }
        const why = unmerged.length
          ? `it conflicts with main's changes in ${unmerged.slice(0, 5).map(clean).join(", ")}${unmerged.length > 5 ? `, and ${unmerged.length - 5} more` : ""}`
          : clean(x.stderr.trim()).split("\n").slice(-3).join(" ").slice(-300);
        return fresh(
          "conflicts with the new base",
          `chef-runner: the earlier attempt was on an older base and doesn't apply cleanly to the new one (${why}); starting fresh`,
        );
      }
      await agentUser.own(cfg.workDir);
      // What was applied, against this run's base, for the agent to read: it
      // has no git in its checkout.
      const applied = await git(["diff", "--cached", "--binary", "--no-color", "--no-ext-diff", "--no-textconv", "HEAD"], { allowFail: true });
      writeAtomic(join(cfg.chefDir, EARLIER_ATTEMPT_DIFF_FILE), clean(applied.stdout).slice(0, MAX_ATTEMPT_BYTES), 0o644);
      writeAtomic(
        join(cfg.chefDir, EARLIER_ATTEMPT_FILE),
        earlierAttemptFile(clean(String(body.reason ?? "")), {
          summary: clean(typeof body.summary === "string" ? body.summary : ""),
          rebased: moved,
        }),
        0o644,
      );
      continued = moved ? "rebased onto the new base" : "same base";
      logLine(
        moved
          ? "chef-runner: main moved since the earlier attempt; its work applied cleanly onto the new base, so the agent verifies and adjusts it"
          : "chef-runner: continuing from the earlier attempt's work",
      );
      return moved ? "rebased" : "same";
    };
    const earlierAttempt = r.continues === true && conflicts.length === 0 && !mergeOnly ? await applyEarlierAttempt() : false;
    if (r.continues === true && conflicts.length > 0) {
      continued = "fresh: main and chef conflict";
      logLine("chef-runner: main and chef conflict, so the earlier attempt's work isn't applied; starting fresh");
    }

    // 6. The agent.
    stage = "agent";
    const settingsJson = deps.local
      ? deps.local.settingsJson(localEnv ? { localEnv } : {})
      : claudeSettingsJson({
          siteOrigin: cfg.siteOrigin ?? cfg.api,
          ...(localEnv ? { localEnv } : {}),
        });
    // `chef-check`, the agent's own run of what the runner verifies: its
    // config from the base (written by the runner, read-only to the agent),
    // and the one command the settings allow for it.
    const checkCommand = deps.local || cfg.checkBin === false ? null : [cfg.checkBin ?? "chef-check", "--config", join(cfg.chefDir, "check.json")];
    let settingsText = settingsJson;
    if (checkCommand) {
      assertInertArgs(checkCommand);
      await writeCheckConfig(join(cfg.chefDir, "check.json"));
      try {
        const st = JSON.parse(settingsJson) as { permissions?: { allow?: unknown } };
        if (st.permissions && Array.isArray(st.permissions.allow)) {
          st.permissions.allow.push(`Bash(${checkCommand.join(" ")})`);
          settingsText = JSON.stringify(st, null, 2) + "\n";
        }
      } catch {
        logLine("chef-runner: chef-check not allowed: the settings aren't JSON");
      }
    }
    writeAtomic(cfg.settingsPath, settingsText, 0o644);
    // Skills and the config dir: root-owned where Claude Code discovers
    // skills and settings, so the agent can't add or change either mid-run.
    const pluginDir = cfg.pluginDir ?? DEFAULT_PLUGIN_DIR;
    // With screenshots, the plugin also carries the visual check, an agent on
    // the small model that takes and reads them (runner/visual-check.ts).
    // `skillsDir: false` (the cloud default for an app with no skills of its
    // own) means no image skills, not no plugin: the agent still gets the
    // runner's own agents.
    const skills = buildSkillsPlugin(cfg.skillsDir === false ? null : (cfg.skillsDir ?? DEFAULT_SKILLS_DIR), pluginDir, {
      agents: shots ? { [VISUAL_CHECK_AGENT]: VISUAL_CHECK_AGENT_MD } : {},
    });
    const pluginLoaded = !!skills && (skills.skills.length > 0 || skills.agents.length > 0);
    if (skills && skills.skills.length > 0) {
      logLine(`chef-runner: skills: ${skills.skills.join(", ")}`);
      for (const x of skills.stripped) logLine(`chef-runner: skill ${x.skill}: dropped ${x.keys.join(", ")} from its frontmatter`);
    }
    if (skills && skills.agents.length > 0) logLine(`chef-runner: agents: ${skills.agents.map((a) => `${PLUGIN_NAME}:${a}`).join(", ")}`);
    for (const why of skills?.skipped ?? []) logLine(`chef-runner: skill skipped: ${why}`);
    // The official Convex plugin, the same way: root-owned, read-only, with
    // no MCP server, monitors or telemetry (runner/convex-plugin.ts).
    const convexPluginDir = cfg.convexPlugin === false ? null : (cfg.convexPlugin?.dir ?? DEFAULT_CONVEX_PLUGIN_DIR);
    // The plugin's hooks append to this log when they run (counted at the end).
    const pluginUsagePath = join(cfg.chefDir, PLUGIN_USAGE_LOG);
    const convexPlugin =
      cfg.convexPlugin === false || deps.local
        ? null
        : buildConvexPlugin(cfg.convexPlugin?.source ?? DEFAULT_CONVEX_PLUGIN_SOURCE, convexPluginDir!, { usageLog: pluginUsagePath });
    if (convexPlugin) {
      logLine(
        `chef-runner: convex plugin ${convexPlugin.version}: ${convexPlugin.skills.length} skills, agents ${convexPlugin.agents.join(", ") || "none"}, hooks ${convexPlugin.hooks.join(", ") || "none"}; no MCP server, monitors or telemetry`,
      );
      for (const why of convexPlugin.skipped) logLine(`chef-runner: convex plugin: skipped ${why}`);
    }
    await prepareClaudeConfigDir(claudeConfigDir, (p) => agentUser.shareDir(p));
    // What earlier builds learned (src/chef/learnings.ts), read-only for the agent.
    const brief = typeof r.learnings?.brief === "string" ? r.learnings.brief.slice(0, 16_000) : "";
    // A follow-up build: why the last build's preview failed, read-only for the agent.
    const previousFailure = !mergeOnly && typeof r.followUp?.reason === "string" ? clean(r.followUp.reason).slice(0, 4000) : "";
    if (previousFailure) {
      writeAtomic(join(cfg.chefDir, PREVIOUS_FAILURE_FILE), previousFailureFile(previousFailure), 0o644);
      logLine("chef-runner: a follow-up build: the agent is told why the last preview deploy failed");
    }
    if (brief.trim() !== "") {
      writeAtomic(join(cfg.chefDir, APP_NOTES_FILE), brief, 0o644);
      logLine(`chef-runner: app notes from earlier builds: ${brief.length} characters`);
    }
    const planned = await planAgentRun(r, {
      repoDir: cfg.workDir,
      chefDir: cfg.chefDir,
      settingsPath: cfg.settingsPath,
      ...(cfg.claudeBin ? { claudeBin: cfg.claudeBin } : {}),
      // Verifying an earlier attempt's rebased work is a shorter job than building it.
      ...(earlierAttempt === "rebased"
        ? { maxTurns: Math.min(cfg.maxTurns ?? REBASED_MAX_TURNS, REBASED_MAX_TURNS) }
        : cfg.maxTurns
          ? { maxTurns: cfg.maxTurns }
          : {}),
      ...(pluginLoaded ? { pluginDir } : {}),
      ...(convexPlugin ? { extraPluginDirs: [convexPluginDir!] } : {}),
      ...(skills?.agents.includes(VISUAL_CHECK_AGENT) ? { visualCheckAgent: `${PLUGIN_NAME}:${VISUAL_CHECK_AGENT}` } : {}),
      ...(loginFunction ? { signedInScreenshots: true } : {}),
      ...(localEnv ? { localEnv } : {}),
      ...(conflicts.length > 0 ? { mergeConflicts: true } : {}),
      ...(brief.trim() !== "" ? { appNotes: true } : {}),
      ...(convexPlugin ? { convexPlugin: true } : {}),
      ...(checkCommand ? { checkCommand } : {}),
      ...(earlierAttempt ? { earlierAttempt: earlierAttempt === "rebased" ? "rebased" : true } : {}),
      ...(previousFailure ? { previousFailure: true } : {}),
    });
    const plan = deps.local ? deps.local.agentPlan(planned) : planned;
    // The files the agent writes: empty, its own, in a dir it can't write.
    const skillFeedbackPath = join(cfg.chefDir, SKILL_FEEDBACK_FILE);
    const approvalsPath = join(cfg.chefDir, APPROVAL_REQUESTS_FILE);
    const screenshotPlanPath = join(cfg.chefDir, SCREENSHOT_PLAN_FILE);
    const demoScriptPath = join(cfg.chefDir, DEMO_SCRIPT_FILE);
    /** The agent wrote a demo script with at least one valid step (the final screenshots rehearse it). */
    const hasDemoScript = () => {
      try {
        return parseDemoScript(readAgentFile(demoScriptPath, DEMO_LIMITS.fileBytes)).script !== null;
      } catch {
        return false;
      }
    };
    const repoNotesPath = join(cfg.chefDir, REPO_NOTES_FILE);
    for (const path of [plan.summaryPath, skillFeedbackPath, approvalsPath, screenshotPlanPath, demoScriptPath, repoNotesPath, pluginUsagePath]) {
      rmSync(path, { force: true });
      writeFileSync(path, "", { mode: 0o644 });
      await agentUser.own(path);
    }
    readRepoNotes = () => parseJsonLines(readAgentFile(repoNotesPath, NOTE_LIMITS.fileBytes), (x) => repoNoteEntry(x, clean));
    writeFileSync(agentLogPath, "", { mode: 0o600 });
    const agentEnv = agentEnvFor();
    // Which plugin skills and agents the agent called, from its own stream.
    const usage = emptyUsage();
    // One session of the agent: its plan's files, then Claude Code as the
    // agent user, bounded, every process of the agent user's killed after.
    const session = async (p: AgentRunPlan, timeoutMs: number) => {
      for (const f of p.files) writeAtomic(f.path, f.content, 0o644);
      const t0 = clock.now();
      const x = await exec(p.command.file, p.command.args, {
        cwd: p.command.cwd,
        env: agentEnv,
        asAgent: true,
        stdinPath: p.stdinPath,
        timeoutMs,
        onStdoutLine: (l) => {
          appendFileSync(agentLogPath, l + "\n");
          countStreamLine(usage, l);
          const id = streamJsonSessionId(l);
          if (id) sessionId = id;
          const s = (deps.local?.summarize ?? summarizeStreamJson)(l);
          if (s) logLine(`agent: ${s}`);
        },
        onStderrLine: (l) => logLine(`agent stderr: ${l}`),
      });
      await agentUser.killAll();
      await deps.local?.afterAgent?.();
      logLine(
        x.timedOut
          ? "chef-runner: the agent hit its time limit and was killed"
          : `chef-runner: the agent exited (${x.code ?? x.signal})`,
      );
      return clock.now() - t0;
    };
    if (follow?.repair && conflicts.length > 0) {
      // A release merge that conflicts: one session, only to resolve the merge.
      repairRan = true;
      timings.agent = await session(
        planMergeRepair(plan, cfg.chefDir, { releaseSeq: follow.seq, conflicts: true, ...(checkCommand ? { checkCommand } : {}) }),
        timing.agentTimeoutMs,
      );
    } else if (!mergeOnly) {
      timings.agent = await session(plan, timing.agentTimeoutMs);
      // What the agent left besides its diff, read now that it is dead and
      // reported whatever the gates say.
      await reportNotes("skill feedback", "/feedback", "skillFeedback", skillFeedbackPath, skillFeedbackEntry);
      await reportNotes("approval requests", "/approvals", "approvalRequests", approvalsPath, approvalRequestEntry);
    }
    // What it tried, for the run's record even if the run fails.
    describeAttempt = async () => {
      let summary = "";
      try {
        summary = readAgentFile(plan.summaryPath, 8 * 1024);
      } catch {
        // Best effort, like every agent file.
      }
      let diffStat = "";
      try {
        await git(["add", "--all", "--", "."]);
        diffStat = (await git(["diff", "--cached", "--stat=100", "--no-color", "--no-ext-diff", baseSha], { allowFail: true })).stdout;
      } catch {
        // Nothing to say.
      }
      return { summary: clean(summary).slice(0, 4000), diffStat: clean(diffStat).slice(-4000) };
    };
    uploadAttempt = async () => {
      await git(["add", "--all", "--", "."]);
      const d = await git(["diff", "--cached", "--binary", "--no-color", "--no-ext-diff", "--no-textconv", baseSha], { allowFail: true });
      const text = d.stdout;
      if (d.code !== 0 || text === "") return;
      if (Buffer.byteLength(text) > MAX_ATTEMPT_BYTES) {
        logLine("chef-runner: the attempt's diff is too large to keep for Try again");
        return;
      }
      // Never kept with anything secret-looking in it: it would be applied elsewhere.
      if (findSecrets(text).length > 0) {
        logLine("chef-runner: the attempt's diff holds something secret-looking; not kept for Try again");
        return;
      }
      const tree = (await git(["rev-parse", `${baseSha}^{tree}`], { worktree: false })).stdout.trim();
      const res = await api("POST", "/attempt", { baseTree: tree, diff: text }).catch(() => null);
      logLine(res?.ok ? "chef-runner: kept this attempt's work for Try again" : `chef-runner: this attempt's work wasn't kept: ${res ? res.status : "no answer"}`);
    };

    // 7 to 9b. Verification: the gates, the guards, the commit and the
    // frontend build, with the agent dead, as today. They run code the agent
    // wrote, so as the agent user, and everything it leaves is killed after.
    // What fails here and the agent can fix (a gate that passed on the base
    // and fails now, a guard on the diff it can undo, the frontend build)
    // doesn't end the run: the agent's same Claude Code session is resumed
    // with what failed, in the same checkout, and then everything is
    // verified again, fresh. Up to `fixRounds` times, within the run's spend
    // ceiling and deadline. What it can't fix (the platform's failures) or
    // must not get another go at (a protected path, a secret: tampering)
    // ends the run as before.
    const gatesProvenance = {
      ...(convexPlugin ? { convexPlugin: convexPlugin.version } : {}),
      ...(continued ? { earlierAttempt: continued } : {}),
    };
    await report("gates", { gateResults, ...(Object.keys(gatesProvenance).length ? { provenance: gatesProvenance } : {}) });
    stage = "gates";
    timings.gates = 0;
    timings.guards = 0;
    timings.frontend = 0;
    const frontend = pickFrontend(r.config, cfg.frontend);
    if (frontend) observed.frontend = `${frontend.command.join(" ")} -> ${frontend.distDir} (${frontend.urlEnvVar})`;
    const hide = (t: string) => {
      let x = clean(t);
      if (backend?.adminKey) x = x.split(backend.adminKey).join("[redacted]");
      return x;
    };
    type Verified = { ok: true; commitSha: string; files: ReturnType<typeof parseRawDiffZ>; depsChanged: boolean; diffText: string };
    type NotVerified = {
      ok: false;
      failure: Failure;
      /** One line, for the log, the round's record and the panel. */
      reason: string;
      /** What the agent gets in check-failure.md (scrubbed). */
      detail: string;
      /** Whether a fix round may follow. */
      addressable: boolean;
    };
    /** Undo the verification's commit after a later step failed: the checkout and index stay. */
    const undoCommit = async () => {
      if (follow && result.commitSha) {
        // A release merge's own commit (a resolution, or a fix on top of the
        // clean merge): back to the merge as git left it, its changes staged.
        if (conflicts.length > 0) {
          await git(["reset", "--quiet", "--soft", start!]);
          await git(["update-ref", "MERGE_HEAD", mainBefore!], { worktree: false });
        } else await git(["reset", "--quiet", "--soft", baseSha]);
        delete result.commitSha;
        return;
      }
      if (mergeOnly) return;
      if (conflicts.length > 0) {
        await git(["reset", "--quiet", "--soft", chefBefore!]);
        await git(["update-ref", "MERGE_HEAD", mainBefore!], { worktree: false });
      } else await git(["reset", "--quiet", "--soft", baseSha]);
      delete result.commitSha;
    };
    const verify = async (round: number): Promise<Verified | NotVerified> => {
      // The gates.
      stage = "gates";
      const g0 = clock.now();
      await agentUser.killAll();
      if ((await agentUser.list()).length > 0) throw new Failure("gates", "agent processes still alive");
      await startBackend();
      const outputs: string[] = [];
      for (let i = 0; i < gates.length; i++) {
        const out = { text: "" };
        const x = await runAsAgent("gate", gates[i], gateEnv(), (l) => {
          out.text = (out.text + l + "\n").slice(-2 * GATE_OUTPUT_BYTES);
        });
        gateResults[i].result = x.code === 0 ? "pass" : "fail";
        outputs.push(out.text + (x.timedOut ? "\n[timed out]\n" : ""));
        if (gateBlocks(gateResults[i])) await agentUser.killAll();
      }
      await agentUser.killAll();
      if ((await agentUser.list()).length > 0) throw new Failure("gates", "agent processes still alive after gates");
      timings.gates! += clock.now() - g0;
      // A gate that failed on the baseline too blocks only for what is new.
      for (let i = 0; i < gateResults.length; i++) {
        const { newProblems: _n, baselineFiles: _f, ...plain } = gateResults[i];
        gateResults[i] = compareWithBaseline(plain, baselineOutputs[i], outputs[i], [cfg.workDir, mainDir]);
      }
      for (const g of gateResults) logLine(`chef-runner: gate ${gateSummary(g)}`);
      for (const g of gateResults) {
        const note = redBaselineNote(g);
        if (note && g.result === "fail") logLine(`chef-runner: ${note}`);
      }
      const blocking = gateResults.map((g, i) => ({ gate: g, output: outputs[i] })).filter((x) => gateBlocks(x.gate));
      if (blocking.length > 0) {
        const cmds = blocking.map((b) => b.gate.command).join(", ");
        return {
          ok: false,
          failure: new Failure(
            "gates",
            `${mergeOnly ? "gate failed after merging main" : "gate failed"}: ${blocking[0].gate.command}${
              blocking[0].gate.newProblems?.length
                ? ` (new problems in ${[...new Set(blocking[0].gate.newProblems.map((p) => p.split(": ")[0]))].slice(0, 5).join(", ")})`
                : ""
            }`,
          ),
          reason: `${cmds} ${blocking.length === 1 ? "fails" : "fail"} (${
            blocking.some((b) => b.gate.newProblems?.length)
              ? `new problems: ${blocking.flatMap((b) => b.gate.newProblems ?? []).slice(0, 3).join("; ")}`
              : `passed ${mergeOnly ? "on main" : "before this build"}`
          })`,
          detail: gateFailureFile({
            round: round + 1,
            rounds: fixRounds,
            failing: blocking.map((b) => ({ gate: b.gate, output: hide(tailOutput(b.output)) })),
          }),
          addressable: true,
        };
      }

      // 8. The guards.
      const u0 = clock.now();
      await report("guards", { gateResults });
      stage = "guards";
      await git(["add", "--all", "--", "."]);
      // Against baseSha, the tree the agent started from. After a conflicting
      // merge that's the baseline (mergeBaseline): main's own changes, a
      // protected file included, are in it and never count as the agent's.
      // A merge-only run checks what ships: the merged tree against the new main.
      const guardBase = mergeOnly ? mainBefore! : baseSha;
      const raw = await git(["diff", "--cached", "--raw", "-z", "--find-renames", "--no-ext-diff", guardBase]);
      const files = parseRawDiffZ(raw.stdout);
      // Conflict markers: in every changed file, and in every file the merge
      // left conflicted, changed or not.
      const scanPaths = [...new Set([...files.filter((f) => f.status !== "D").map((f) => f.path), ...conflicts.map((c) => c.path)])];
      const conflictScan = await scanConflictMarkers(scanPaths);
      if (files.length === 0) {
        timings.guards! += clock.now() - u0;
        if (mergeOnly) {
          return { ok: false, failure: new Failure("guards", "nothing to ship: main already has everything chef has"), reason: "nothing to ship", detail: "", addressable: false };
        }
        return {
          ok: false,
          failure: new Failure("guards", "the agent changed nothing"),
          reason: "nothing changed",
          detail: checkFailureFile(round + 1, fixRounds, "Nothing changed", "Your session ended without changing any file. Build the request."),
          addressable: true,
        };
      }
      const diff = await git(["diff", "--cached", "--no-color", "--no-ext-diff", "--no-textconv", "--binary", guardBase]);
      const contents: Record<string, { before?: string; after?: string }> = {};
      for (const f of files) {
        for (const p of f.oldPath !== undefined ? [f.oldPath, f.path] : [f.path]) {
          if (!/(^|\/)package\.json$/i.test(p)) continue;
          const before = await git(["show", `${guardBase}:${p}`], { allowFail: true, worktree: false });
          const after = await git(["show", `:${p}`], { allowFail: true });
          contents[p] = {
            ...(before.code === 0 ? { before: before.stdout } : {}),
            ...(after.code === 0 ? { after: after.stdout } : {}),
          };
        }
      }
      const guard = checkGuards({ files, contents, diffText: diff.stdout, conflictScan });
      const violations = [...guard.violations];
      // The agent's transcript: any high-confidence secret fails the run,
      // except the sandbox's own throwaway tokens (src/chef/throwaway.ts): the
      // local backend's admin key and the sign-in JWTs it issues, which the
      // agent sees while testing and nothing outside the sandbox accepts.
      // Those are redacted from the transcript and counted. The diff above
      // has no such exception.
      // Each finding says why it wasn't let through and where it was (a tool
      // call, a result), never the value or the line: build #30 failed on
      // five "jwt in agent.jsonl line N" and the transcript went with the
      // sandbox, so nobody could tell what they were.
      const transcript = scanSecrets(readFileSync(agentLogPath, "utf8"), throwawayAllow(sandboxLocal), {
        explain: throwawayExplain(sandboxLocal),
        describe: (lines, i) => describeTranscriptLine(lines, i, cfg.workDir),
      });
      for (const s of transcript.findings) {
        const more = [s.why, s.where].filter(Boolean).join(", ");
        violations.push({ kind: "secretInDiff", detail: `${s.kind} in agent.jsonl line ${s.line}${more ? ` (${more})` : ""}` });
      }
      if (transcript.allowed > 0) {
        writeFileSync(agentLogPath, transcript.redacted, { mode: 0o600 });
        logLine(
          `chef-runner: ${transcript.allowed} sandbox-local token${transcript.allowed === 1 ? "" : "s"} in the agent's transcript (the local backend's key, its sign-in JWTs, or JWT-shaped text that isn't a token): throwaway, redacted, not a leak`,
        );
      }
      timings.guards! += clock.now() - u0;
      if (violations.length > 0) {
        const text = violations
          .map((v) => `${v.kind}${v.path ? ` ${revealInvisible(v.path)}` : ""}: ${v.detail}`)
          .join("; ");
        const tamper = violations.some((v) => TAMPER_VIOLATIONS.includes(v.kind));
        return {
          ok: false,
          failure: new Failure("guards", `guards failed: ${text}`, violations),
          reason: `guards: ${clean(text).slice(0, 200)}`,
          detail: checkFailureFile(
            round + 1,
            fixRounds,
            "The runner's guards refuse the change",
            violations.map((v) => `- ${v.kind}${v.path ? ` ${revealInvisible(v.path)}` : ""}: ${v.detail}`).join("\n"),
          ),
          addressable: !tamper,
        };
      }

      // 9. Commit. A merge-only run's commit is the merge itself, made at
      // the clone (parents chef and main); nothing else changed since.
      stage = "commit";
      if (mergeOnly) {
        const st = await git(["status", "--porcelain", "--untracked-files=all"]);
        const changed = st.stdout.trim() !== "";
        if (changed && !follow?.repair) throw new Failure("commit", "the checkout changed during the checks");
        if (follow && (changed || conflicts.length > 0)) {
          // The agent's resolution (the merge itself, mid-merge) or its fix
          // on top of the clean merge, with a fixed message and author.
          if (conflicts.length > 0 && (await rev("MERGE_HEAD")) !== mainBefore) throw new Failure("commit", "the merge in progress isn't main's");
          const mc = planMergeCommit({
            releaseSeq: follow.seq,
            mainSha: mainBefore!,
            conflicts: conflicts.length > 0,
            messagePath: join(stateDir, "commit-message.txt"),
            authorEmail,
          });
          writeAtomic(mc.messageFile.path, mc.messageFile.content, 0o600);
          await git(mc.args);
        }
        const head = (await rev("HEAD"))!;
        const parents = (await git(["show", "-s", "--format=%P", "HEAD"], { worktree: false })).stdout.trim().split(" ");
        const want = follow && changed && conflicts.length === 0 ? [baseSha] : [ours!, mainBefore!];
        if (parents.join(" ") !== want.join(" ")) {
          throw new Failure("commit", want.length === 1 ? "the fix isn't on top of the merge" : `the merge isn't of ${follow ? "the release" : "chef"} and main`);
        }
        result.commitSha = head;
      }
      const commit = mergeOnly ? null : await planCommit({
        run: r,
        runId: cfg.runId,
        messagePath: join(stateDir, "commit-message.txt"),
        authorEmail,
      });
      if (commit) {
        writeAtomic(commit.messageFile.path, commit.messageFile.content, 0o600);
        // Mid-merge (MERGE_HEAD is main), this commit is the merge: chef, then
        // main, with the planned message.
        if (conflicts.length > 0 && (await rev("MERGE_HEAD")) !== mainBefore) {
          throw new Failure("commit", "the merge in progress isn't main's");
        }
        await git(commit.args);
        const parents = (await git(["show", "-s", "--format=%P", "HEAD"], { worktree: false })).stdout.trim().split(" ");
        const wantParents = conflicts.length > 0 ? [chefBefore!, mainBefore!] : [baseSha];
        if (parents.join(" ") !== wantParents.join(" ")) {
          throw new Failure("commit", conflicts.length > 0 ? "the commit isn't a merge of chef and main" : "the commit's parent isn't the base");
        }
      }
      const commitSha = (await rev("HEAD"))!;
      result.commitSha = commitSha;

      // 9b. The frontend, built here with a placeholder URL, because the
      // deploy sandbox runs no repo code (runner/frontend-artifact.ts).
      if (frontend) {
        stage = "frontend";
        const f0 = clock.now();
        const feOut = { text: "" };
        try {
          await buildFrontendArtifact(
            { workDir: cfg.workDir, frontend, commitSha },
            {
              build: (argv, extra) => {
                const env: Record<string, string | undefined> = { ...gateEnv(), ...extra };
                // The build needs no backend; its admin key stays out of the output.
                delete env.CONVEX_SELF_HOSTED_URL;
                delete env.CONVEX_SELF_HOSTED_ADMIN_KEY;
                return runAsAgent("frontend", argv, env as Record<string, string>, (l) => {
                  feOut.text = (feOut.text + l + "\n").slice(-2 * GATE_OUTPUT_BYTES);
                });
              },
              killAgents: async () => {
                await agentUser.killAll();
                if ((await agentUser.list()).length > 0) throw new Failure("frontend", "agent processes still alive after the frontend build");
              },
              upload: uploadArtifact,
              log: logLine,
            },
          );
        } catch (e) {
          timings.frontend! += clock.now() - f0;
          // The platform's (an upload refused, a process left alive): not the agent's to fix.
          if (e instanceof Failure) throw e;
          const message = clean((e as Error).message ?? String(e));
          await undoCommit();
          return {
            ok: false,
            failure: new Failure("frontend", message),
            reason: `frontend: ${message.slice(0, 200)}`,
            detail: checkFailureFile(round + 1, fixRounds, `The frontend build: ${message}`, hide(tailOutput(feOut.text))),
            // Which variable the app reads is the host's config, not the agent's to change.
            addressable: !/never uses/.test(message),
          };
        }
        timings.frontend! += clock.now() - f0;
      }
      return { ok: true, commitSha, files, depsChanged: guard.depsChanged, diffText: diff.stdout };
    };

    let verified: Verified | null = null;
    for (let round = 0; ; round++) {
      const v = await verify(round);
      if (v.ok) {
        verified = v;
        break;
      }
      const left = r.deadline ? Number(r.deadline) - Date.now() : Infinity;
      if (!v.addressable || round >= fixRounds || left < timing.fixReserveMs + 60_000) {
        const f = v.failure;
        if (v.addressable && fixRounds > 0) {
          f.message += round >= fixRounds
            ? ` (${f.stage === "gates" ? "passed before this build; " : ""}still failing after ${fixRounds} fix round${fixRounds === 1 ? "" : "s"})`
            : ` (${f.stage === "gates" ? "passed before this build; " : ""}no time left for a fix round)`;
        }
        throw f;
      }
      // A fix round: what failed, scrubbed, for the agent's same session.
      const n = round + 1;
      writeAtomic(join(cfg.chefDir, CHECK_FAILURE_FILE), v.detail, 0o644);
      logLine(`chef-runner: fixing (round ${n} of ${fixRounds}): ${v.reason}`);
      await report("agent", { fixRound: n, fixReason: v.reason.slice(0, 300), gateResults });
      stage = "agent";
      await startBackend();
      if (follow) {
        repairRan = true;
        for (const g of gateResults) if (gateBlocks(g)) repairedGates.add(g.command);
      }
      const fixPlan = follow
        ? planMergeRepair(plan, cfg.chefDir, { releaseSeq: follow.seq, conflicts: false, round: n, rounds: fixRounds, ...(checkCommand ? { checkCommand } : {}) })
        : sessionId
          ? planResumeRound(plan, sessionId, r.itemNumber, cfg.chefDir, { round: n, rounds: fixRounds, ...(checkCommand ? { checkCommand } : {}) })
          : planFixRound(plan, r.itemNumber, cfg.chefDir, { round: n, rounds: fixRounds });
      logLine(sessionId ? `chef-runner: resuming the agent's session for round ${n}` : `chef-runner: a new session for round ${n} (no session id to resume)`);
      timings.fix = (timings.fix ?? 0) + (await session(fixPlan, Math.min(timing.agentTimeoutMs, left - timing.fixReserveMs)));
      observed.fixRounds = n;
      await report("gates", { fixRound: n, gateResults });
      stage = "gates";
    }
    observed.gates = gateResults.map((g) => ({ command: g.command, baseline: g.baseline, ...(g.result ? { result: g.result } : {}) }));
    const { commitSha, files } = verified;
    const filesChanged = files.map((f) => f.path);
    observed.filesChanged = filesChanged.slice(0, 50);

    // The final screenshots: the app as built, for people. After the
    // commit, so nothing it writes reaches it; before `committed`, so no
    // agent code runs while git can write. Never fails the run.
    // A release merge has no card of its own to show: no screenshots.
    if (shots && lb && !follow) {
      let planText = "";
      try {
        planText = readAgentFile(screenshotPlanPath, SCREENSHOT_LIMITS.planBytes);
      } catch (e) {
        logLine(`chef-runner: screenshots: plan not read: ${clean((e as Error).message)}`);
      }
      await finalScreenshots(
        {
          log: logLine,
          freshBackend: async () => {
            await startBackend();
            return backend?.url ?? null;
          },
          // Argv from the runner's config, a checked seed function name and
          // the helper's checked page arguments (src/chef/screenshots.ts);
          // a selector may hold spaces, and no shell is involved.
          runAsAgent: (what, argv, timeoutMs) =>
            exec(argv[0], argv.slice(1), {
              cwd: cfg.workDir,
              env: gateEnv(),
              asAgent: true,
              timeoutMs,
              onStdoutLine: (l) => logLine(`${what}: ${l}`),
              onStderrLine: (l) => logLine(`${what}: ${l}`),
            }),
          own: (path) => agentUser.own(path),
          killAll: () => agentUser.killAll(),
          upload: async (query, bytes, sha) => {
            const res = await doFetch(`${apiBase}/screenshot?${new URLSearchParams(query)}`, {
              method: "POST",
              headers: { authorization: `Bearer ${runToken}`, "content-type": "image/png", "x-chef-sha256": sha },
              body: bytes as BodyInit,
            });
            return { status: res.status, body: await res.json().catch(() => null) };
          },
          sleep: (ms) => clock.sleep(ms),
          now: () => clock.now(),
        },
        {
          ...shots,
          ...(loginFunction ? { loginFunction } : {}),
          ...(frontend ? { distDir: frontend.distDir } : {}),
          ...(!mergeOnly && hasDemoScript() ? { demoScript: demoScriptPath } : {}),
        },
        planText,
      );
    }

    // Whether the Convex plugin was used (src/chef/pluginUsage.ts): its skills
    // and agents from the stream, its hooks from their log, for the run's
    // provenance and what builds learn.
    let pluginUsage: string | null = null;
    if (convexPlugin) {
      try {
        countHookLog(usage, readAgentFile(pluginUsagePath, 256 * 1024));
      } catch (e) {
        logLine(`chef-runner: plugin usage log not read: ${clean((e as Error).message)}`);
      }
      const convex = convexOnly(usage);
      logLine(`chef-runner: ${clean(pluginUsageLine(convex))}`);
      pluginUsage = pluginUsageTotals(convex);
      observed.pluginUsage = clean(pluginUsageLine(convex)).slice(0, 300);
    }

    // The demo script (src/chef/demo.ts): data the demo sandbox plays against
    // the preview after the deploy, read now that every agent process is dead.
    let demoScript: DemoScript | null = null;
    if (!mergeOnly) {
      try {
        const parsed = parseDemoScript(readAgentFile(demoScriptPath, DEMO_LIMITS.fileBytes));
        demoScript = parsed.script;
        for (const p of parsed.problems.slice(0, 10)) logLine(`chef-runner: demo script: ${clean(p)}`);
        logLine(demoScript ? `chef-runner: demo script: ${demoScript.steps.length} steps` : "chef-runner: no demo script");
      } catch (e) {
        logLine(`chef-runner: demo script not read: ${clean((e as Error).message)}`);
      }
    }

    // The release diff, `git diff main..commit` with the release's fixed
    // options, for "Ship it" in the panel: the commit has main merged in, so
    // this is exactly what shipping it changes on main. Best effort: without
    // it the build still previews, and "Ship it" refuses to ship it.
    if (mainBefore) {
      try {
        const rd = await git([...RELEASE_GIT_CONFIG, ...RELEASE_DIFF_ARGS, mainBefore, commitSha], { worktree: false });
        const bytes = Buffer.byteLength(rd.stdout);
        if (bytes === 0) logLine("chef-runner: the release diff is empty; not uploaded");
        else if (bytes > RELEASE_DIFF_MAX_BYTES) logLine(`chef-runner: the release diff is ${bytes} bytes, over the cap; not uploaded`);
        else await uploadReleaseDiff(rd.stdout, { baseSha: mainBefore, commitSha });
      } catch (e) {
        logLine(`chef-runner: release diff not uploaded: ${clean((e as Error).message ?? String(e)).slice(0, 300)}`);
      }
    }
    // A release merge whose agent changed anything: what it changed, from
    // the merge as git left it (conflict markers and all) to the commit. The
    // re-approval card shows only this.
    let mergeRepair: { conflicts: string[]; gates: string[]; files: string[]; diff: string; truncated: boolean } | null = null;
    if (follow && (repairRan || conflicts.length > 0) && baseSha !== commitSha) {
      try {
        const rd = await git([...RELEASE_GIT_CONFIG, ...RELEASE_DIFF_ARGS, baseSha, commitSha], { worktree: false });
        const names = await git(["diff", "--name-only", "-z", "--no-renames", baseSha, commitSha], { worktree: false });
        const text = rd.stdout;
        const cap = RESOLUTION_DIFF_MAX_BYTES;
        mergeRepair = {
          conflicts: conflicts.map((c) => revealInvisible(clean(c.path))).slice(0, 200),
          gates: [...repairedGates].map(clean).slice(0, 20),
          files: names.stdout.split("\0").filter(Boolean).map((f) => revealInvisible(clean(f))).slice(0, 500),
          diff: Buffer.byteLength(text) > cap ? Buffer.from(text).subarray(0, cap).toString("utf8") : text,
          truncated: Buffer.byteLength(text) > cap,
        };
        logLine(`chef-runner: the merge's resolution changes ${mergeRepair.files.length} file${mergeRepair.files.length === 1 ? "" : "s"}: ${mergeRepair.files.slice(0, 5).join(", ")}`);
      } catch (e) {
        logLine(`chef-runner: the merge's resolution diff wasn't read: ${clean((e as Error).message ?? String(e)).slice(0, 300)}`);
      }
    }
    stage = "commit";
    // A request: the orchestrator makes the git credential writable and
    // opens the git host, then grants `pushing`. No push before that.
    await report("committed", {
      commitSha,
      branch,
      filesChanged,
      depsChanged: verified.depsChanged,
      diffHash: sha256(verified.diffText),
      ...(mergedMain ? { mergedMain } : {}),
      ...(mergeRepair ? { mergeRepair } : {}),
      ...(demoScript ? { demoScript } : {}),
      ...(pluginUsage ? { provenance: { pluginUsage } } : {}),
    });
    await waitForGrant("pushing", "commit");

    // 10. Push: request branch, then chef. No agent process may be alive.
    // The grant means the write credential is set and the git host added to
    // egress, not that either has reached the sandbox: widening takes
    // minutes. So wait until the host answers with the credential.
    stage = "push";
    const pushStarted = clock.now();
    if (deps.local) await refreshGitAuth("push");
    await waitForGitHost("push");
    await agentUser.killAll();
    if ((await agentUser.list()).length > 0) throw new Failure("push", "agent processes alive at push");
    if (ours) {
      const anc = await git(["merge-base", "--is-ancestor", ours, commitSha], { allowFail: true, worktree: false });
      if (anc.code !== 0) throw new Failure("push", follow ? "the commit doesn't descend from the release" : "the commit doesn't descend from chef");
    }
    await push(commitSha, branch);
    result.pushedBranch = true;
    // A release merge ships through its release: chef keeps the newer builds.
    if (!follow) {
      await push(commitSha, "chef");
      result.pushedChef = true;
    }

    const refs = await lsRemote();
    if (refs.get(`refs/heads/${branch}`) !== commitSha) throw new Failure("push", "the request branch didn't land");
    if (!follow && refs.get("refs/heads/chef") !== commitSha) throw new Failure("push", "chef didn't land");
    if ((refs.get("refs/heads/main") ?? null) !== mainBefore) {
      result.mainMoved = true;
      logLine("chef-runner: ALERT: main moved during the run");
    }
    await report("pushed", follow ? {} : { chefAfter: commitSha });
    timings.push = clock.now() - pushStarted;
    await sendLearnings();
    stage = "done";
    result.ok = true;
    result.stage = "done";
    writeStatus({ phase: "pushed", ok: true });
    return result;
  } catch (e) {
    const f = e instanceof Failure ? e : new Failure(stage, (e as Error).message ?? String(e));
    const error = clean(f.message);
    result.ok = false;
    result.stage = f.stage;
    result.error = error;
    if (f.violations) result.violations = f.violations;
    if (credentialLive) logLine(`chef-runner: failed in ${f.stage}: ${error}`);
    else print(`chef-runner: failed in ${f.stage}: ${error}`);
    // Before status.json says it failed: the orchestration ends the run, and
    // the run's credential with it, once it reads that.
    if (credentialLive) await sendLearnings().catch(() => {});
    // The work, for "Try again", when the agent's work failed verification
    // in a way it could fix; never after tampering.
    const tampered = (f.violations ?? []).some((v) => TAMPER_VIOLATIONS.includes(v.kind));
    if (credentialLive && uploadAttempt && !tampered && ["gates", "guards", "frontend"].includes(f.stage)) {
      await uploadAttempt().catch(() => {});
    }
    writeStatus({
      phase: f.stage,
      ok: false,
      error,
      ...((e as { selfTest?: EgressResult }).selfTest ? { selfTest: (e as { selfTest: EgressResult }).selfTest } : {}),
    });
    return result;
  } finally {
    if (heartbeat) clearInterval(heartbeat);
    if (logTimer) clearInterval(logTimer);
    await agentUser.killAll().catch(() => {});
    await flush();
  }

  // ------------------------------------------------------------ pieces

  /**
   * What the deploy scripts would refuse in `rev`'s tree
   * (src/chef/deployChecks.ts). `fromCheckout`: the checkout holds exactly
   * `rev`, so files are read from it (whole, refusing a symlink); else
   * through git.
   */
  async function deployRefusalsAt(rev: string, fromCheckout: boolean): Promise<DeployRefusal[]> {
    const ls = await git(["ls-tree", "-r", "-z", "--full-tree", rev], { worktree: false });
    const entries = parseLsTreeZ(ls.stdout);
    const texts = new Map<string, string | null>();
    for (const p of ["convex.json", "package-lock.json"]) {
      if (!entries.some((e) => e.path === p)) continue;
      let text: string | null = null;
      if (fromCheckout) {
        try {
          text = readAgentFile(join(cfg.workDir, p), 64 * 1024 * 1024);
        } catch {
          text = null;
        }
      }
      if (text === null) {
        const x = await git(["show", `${rev}:${p}`], { allowFail: true, worktree: false });
        text = x.code === 0 ? x.stdout : null;
      }
      texts.set(p, text);
    }
    return deployRefusals(entries, (p) => texts.get(p) ?? null);
  }

  /**
   * main conflicts with chef. Leaves the merge in progress and the conflicts
   * in the checkout for the agent, except at paths the guards protect (and
   * package.json and lockfiles): those take main's side, the
   * human-maintained base, since the agent may not touch them. Writes
   * `<chefDir>/merge-conflicts.md` for the prompt. More than
   * MAX_MERGE_CONFLICTS files, or a merge that failed without conflicts,
   * aborts it and fails the run as before.
   */
  async function startMergeWithConflicts(chefSha: string, mainSha: string): Promise<MergeConflict[]> {
    const fail = async (why: string) => {
      await git(["merge", "--abort"], { allowFail: true });
      return new Failure("clone", `needs_attention: chef doesn't merge main cleanly: ${why}`);
    };
    const ls = await git(["ls-files", "--unmerged", "-z"], { allowFail: true });
    const conflicts = ls.code === 0 ? parseUnmergedZ(ls.stdout) : [];
    if (conflicts.length === 0) throw await fail("the merge failed without conflicts");
    if (conflicts.length > MAX_MERGE_CONFLICTS) {
      throw await fail(`${conflicts.length} files conflict, more than ${MAX_MERGE_CONFLICTS}`);
    }
    if ((await rev("MERGE_HEAD")) !== mainSha || (await rev("HEAD")) !== chefSha) throw await fail("unexpected merge state");
    const mainDir = join(cfg.chefDir, MERGE_MAIN_DIR);
    rmSync(mainDir, { recursive: true, force: true });
    for (const c of conflicts) {
      const takesMain = mergeTakesMain(c.path);
      if (takesMain) {
        c.resolution = `main's side taken (${takesMain})`;
        if (c.stages.has(3)) await git(["--literal-pathspecs", "checkout", "--theirs", "--", c.path]);
        else await git(["--literal-pathspecs", "rm", "--quiet", "--force", "--", c.path]);
        continue;
      }
      if ([...c.modes.values()].some((m) => m === "120000" || m === "160000")) {
        c.kind = "a symlink or submodule on one side";
      } else if (c.stages.has(2) && c.stages.has(3) && !hasConflictMarkers(join(cfg.workDir, c.path))) {
        // Git couldn't merge it by lines: the checkout has chef's side.
        // Main's goes where the agent can read it.
        await git(["--literal-pathspecs", "checkout-index", "--stage=3", `--prefix=${mainDir}/`, "--", c.path]);
        c.kind = `binary: the checkout has chef's version, main's is at ${MERGE_MAIN_DIR}/${c.path}`;
      }
    }
    writeAtomic(join(cfg.chefDir, MERGE_CONFLICTS_FILE), mergeConflictsFile(conflicts, clean), 0o644);
    const left = conflicts.filter((c) => !c.resolution).length;
    logLine(
      `chef-runner: main doesn't merge cleanly into chef: ${conflicts.length} file(s) conflict, ` +
        `${left} left to the agent, ${conflicts.length - left} took main's side (protected)`,
    );
    return conflicts;
  }

  /**
   * The state the agent starts from after a conflicting merge, as a commit
   * the runner keeps to itself (never pushed): the auto-merged tree with
   * the agent's conflicts as git left them and the protected ones on
   * main's side, parents chef and main. The guards diff against it, so only
   * what the agent changed counts, and main's changes, protected files
   * included, never do. Comparing the result with either parent instead
   * would flag every protected file main changed (or let the agent revert
   * one to chef's side unnoticed).
   */
  async function mergeBaseline(chefSha: string, mainSha: string): Promise<string> {
    await git(["add", "--all", "--", "."]);
    const tree = (await git(["write-tree"], { worktree: false })).stdout.trim();
    const c = await git(
      ["commit-tree", tree, "-p", chefSha, "-p", mainSha, "-m", "Chef: main merged into chef, conflicts left for the agent"],
      { worktree: false },
    );
    return c.stdout.trim();
  }

  /** Lines that may be conflict markers in the index's text files at these paths, for the guards. */
  async function scanConflictMarkers(paths: string[]): Promise<Record<string, { line: number; text: string }[]>> {
    if (paths.length === 0) return {};
    const x = await git(
      ["--literal-pathspecs", "grep", "--cached", "-I", "-n", "-z", "--no-color", "--no-textconv", "-E", "-e", CONFLICT_MARKER_GREP, "--", ...paths],
      { allowFail: true },
    );
    if (x.code === 1) return {};
    if (x.code !== 0) throw new Failure("guards", `couldn't scan for conflict markers: ${clean(x.stderr.trim()).slice(-500)}`);
    return parseGrepZ(x.stdout);
  }

  /**
   * The local backend from the snapshot's binary (runner/local-backend.ts):
   * a fresh data dir and instance secret, the admin key from `keygen`, then
   * the binary detached in its own session as the agent user, and a bounded
   * wait for `/version`. Nothing here touches the network beyond 127.0.0.1.
   * killAll stops it like any other agent process.
   */
  async function startLocalBackend(lb: ReturnType<typeof resolveLocalBackend>): Promise<LocalBackendEnv> {
    const fail = (m: string) => new Failure(stage, `local backend: ${m}`);
    // Fresh each time: the gates get a clean backend, whatever the agent left.
    rmSync(lb.dataDir, { recursive: true, force: true });
    mkdirSync(lb.dataDir, { recursive: true, mode: 0o700 });
    const logPath = join(lb.dataDir, "backend.log");
    writeFileSync(logPath, "", { mode: 0o600 });
    await agentUser.own(lb.dataDir);
    const env = deps.local
      ? deps.local.agentEnv({ purpose: "gates" })
      : buildAgentEnv(cfg.env, { home: cfg.agentHome ?? AGENT_HOME, path: cfg.agentPath ?? AGENT_PATH });
    delete (env as Record<string, string | undefined>).ANTHROPIC_AUTH_TOKEN;
    delete (env as Record<string, string | undefined>).CONVEX_AGENT_MODE;
    const instanceSecret = randomBytes(32).toString("hex");

    // stdout is the admin key: kept here, never logged.
    const kg = await exec(lb.binary, keygenArgs(lb, instanceSecret), {
      cwd: lb.dataDir,
      env,
      asAgent: true,
      timeoutMs: lb.startTimeoutMs,
    }).catch((e: Error) => {
      throw fail(`keygen didn't run: ${clean(e.message)}`);
    });
    if (kg.code !== 0) {
      throw fail(`keygen failed (${kg.code ?? kg.signal}): ${clean(kg.stderr.trim()).slice(-1000)}`);
    }
    let adminKey: string;
    try {
      adminKey = parseAdminKey(kg.stdout);
    } catch (e) {
      throw fail((e as Error).message);
    }
    // Sandbox-local, made here: the transcript scan knows them as throwaway.
    sandboxLocal.push(adminKey, instanceSecret);

    const cmd = agentUser.command(lb.binary, serveArgs(lb, instanceSecret));
    record({ file: cmd.file, args: [...cmd.args], cwd: lb.dataDir, asAgent: true, envKeys: Object.keys(env) });
    const logFd = openSync(logPath, "a");
    let exited: string | null = null;
    try {
      const child = spawn(cmd.file, cmd.args, {
        cwd: lb.dataDir,
        env,
        // Its own session and process group: it outlives this spawn, and
        // killAll still finds it (by uid, or by its group in tests).
        detached: true,
        stdio: ["ignore", logFd, logFd],
        ...(cmd.uid !== undefined ? { uid: cmd.uid } : {}),
        ...(cmd.gid !== undefined ? { gid: cmd.gid } : {}),
      });
      child.on("error", (e) => (exited = `didn't start: ${e.message}`));
      child.on("exit", (code, signal) => (exited = `exited (${code ?? signal})`));
      if (child.pid) agentUser.spawned(child.pid);
      child.unref();
    } finally {
      closeSync(logFd);
    }

    const until = clock.now() + lb.startTimeoutMs;
    for (;;) {
      if (exited) throw fail(exited);
      if (await backendUp(lb.port)) break;
      if (clock.now() > until) throw fail(`/version didn't answer within ${lb.startTimeoutMs} ms`);
      await clock.sleep(250);
    }
    const url = localBackendUrl(lb);
    logLine(`chef-runner: local backend up at ${url}`);
    return { url, adminKey };
  }

  /**
   * Reads a JSON-lines file the agent wrote (after it is dead, so nothing can
   * swap it while it's read), parses, bounds and scrubs it, and reports the
   * entries. Best effort: a failure is logged, never the run's.
   */
  async function reportNotes<T>(
    what: string,
    route: string,
    field: string,
    path: string,
    entry: (x: unknown, clean: (s: string) => string) => T | null,
  ) {
    let content: string;
    try {
      content = readAgentFile(path, NOTE_LIMITS.fileBytes);
    } catch (e) {
      logLine(`chef-runner: ${what} not read: ${clean((e as Error).message)}`);
      return;
    }
    const parsed = parseJsonLines(content, (x) => entry(x, clean));
    if (parsed.invalid > 0) logLine(`chef-runner: ${what}: ${parsed.invalid} invalid line(s) skipped`);
    if (parsed.dropped > 0) logLine(`chef-runner: ${what}: ${parsed.dropped} entr(ies) past the limit dropped`);
    if (parsed.entries.length === 0) return;
    for (let attempt = 1; ; attempt++) {
      const res = await api("POST", route, { [field]: parsed.entries }).catch(() => null);
      if (res?.ok) {
        logLine(`chef-runner: ${what}: ${parsed.entries.length} reported`);
        return;
      }
      if (attempt >= 3 || (res && res.status >= 400 && res.status < 500)) {
        logLine(`chef-runner: ${what} not reported: ${res ? res.status : "no answer"}`);
        return;
      }
      await clock.sleep(timing.pollMs);
    }
  }

  /**
   * What this run learned (src/chef/learnings.ts), once: the runner's own
   * observations, the timings, and the agent's notes about the repo, read
   * after it is dead, bounded and scrubbed. Best effort and bounded in
   * time: a refusal or no answer is a log line.
   */
  async function sendLearnings() {
    if (learningsSent || !credentialLive) return;
    learningsSent = true;
    timings.total = clock.now() - startedAt;
    const t: Record<string, number> = {};
    for (const k of TIMING_KEYS) {
      const v = timings[k];
      if (typeof v === "number" && Number.isFinite(v) && v >= 0) t[k] = Math.round(v);
    }
    let notes: RepoNote[] = [];
    if (readRepoNotes) {
      try {
        const parsed = readRepoNotes();
        notes = parsed.entries;
        if (parsed.invalid > 0) logLine(`chef-runner: repo notes: ${parsed.invalid} invalid line(s) skipped`);
      } catch (e) {
        logLine(`chef-runner: repo notes not read: ${clean((e as Error).message)}`);
      }
    }
    const attempt = describeAttempt ? await describeAttempt().catch(() => null) : null;
    const res = await Promise.race([
      api("POST", "/learnings", { observed, timings: t, notes, ...(attempt ? { attempt } : {}) }).catch(() => null),
      new Promise<null>((r) => setTimeout(() => r(null), 15_000).unref()),
    ]);
    logLine(
      res?.ok
        ? `chef-runner: learnings reported (${notes.length} note${notes.length === 1 ? "" : "s"} from the agent)`
        : `chef-runner: learnings not reported: ${res ? res.status : "no answer"}`,
    );
  }

  /** POST the frontend archive (runner/frontend-artifact.ts) with the run credential. */
  async function uploadArtifact(bytes: Uint8Array, meta: { sha256: string; commitSha: string }) {
    const res = await doFetch(apiBase + "/artifact", {
      method: "POST",
      headers: {
        authorization: `Bearer ${runToken}`,
        "content-type": "application/gzip",
        "x-chef-sha256": meta.sha256,
        "x-chef-commit": meta.commitSha,
      },
      body: bytes as BodyInit,
    });
    if (!res.ok) {
      const body: any = await res.json().catch(() => null);
      throw new Failure("frontend", `artifact upload refused: ${res.status} ${clean(String(body?.error ?? ""))}`);
    }
  }

  async function uploadReleaseDiff(text: string, meta: { baseSha: string; commitSha: string }) {
    const res = await doFetch(apiBase + "/release-diff", {
      method: "POST",
      headers: {
        authorization: `Bearer ${runToken}`,
        "content-type": "text/plain; charset=utf-8",
        "x-chef-sha256": sha256(text),
        "x-chef-commit": meta.commitSha,
        "x-chef-base": meta.baseSha,
      },
      body: text,
    });
    if (!res.ok) {
      const body: any = await res.json().catch(() => null);
      throw new Error(`refused: ${res.status} ${clean(String(body?.error ?? ""))}`);
    }
  }

  async function fetchAttachment(a: SnapshotAttachment, member?: number) {
    const name = member !== undefined ? `${member}/${a.index}` : `${a.index}`;
    const res = await api("GET", `/attachments/${name}`);
    if (!res.ok) throw new Failure("run", `attachment ${name}: ${res.status}`);
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length !== a.size || sha256(bytes) !== a.sha256) {
      throw new Failure("run", `attachment ${name} doesn't match the snapshot`);
    }
    writeFileSync(join(cfg.chefDir, "attachments", attachmentFileName(a, member)), bytes, { mode: 0o644 });
  }

  /** A local run's git credential, fetched fresh (runner/local/git-auth.ts) and scrubbed from then on. */
  async function refreshGitAuth(purpose: "clone" | "push") {
    try {
      gitAuth = await deps.local!.gitAuth(purpose);
    } catch (e) {
      throw new Failure(purpose === "clone" ? "clone" : "push", `no git credential: ${clean((e as Error).message)}`);
    }
    if (gitAuth.length >= 8) known.push(gitAuth);
  }

  /**
   * Waits until the git host answers `ls-remote` with the credential:
   * egress lets it through and the secret's current value is live. The git
   * secret is dead before a clone or push phase, so an answer means the new
   * value arrived. Bounded by gitReachWaitMs; each try by 30 seconds.
   */
  async function waitForGitHost(stageNow: Stage) {
    const started = clock.now();
    const until = started + timing.gitReachWaitMs;
    for (let tries = 1; ; tries++) {
      const x = await git(["ls-remote", "--heads", repoUrl], {
        auth: true,
        allowFail: true,
        worktree: false,
        timeoutMs: 30_000,
      });
      if (x.code === 0) {
        logLine(
          tries === 1
            ? "chef-runner: git host reachable"
            : `chef-runner: git host reachable after ${tries} tries, ${Math.round((clock.now() - started) / 1000)} s`,
        );
        return;
      }
      if (clock.now() >= until) {
        const why = clean(x.stderr.trim()).slice(-500);
        throw new Failure(stageNow, `the git host wasn't reachable within ${Math.round(timing.gitReachWaitMs / 1000)} s: ${why}`);
      }
      await clock.sleep(timing.pollMs);
    }
  }

  async function push(sha: string, ref: string) {
    // Never forced: no --force, no `+` on the refspec. The server refuses
    // anything that isn't a fast-forward. One attempt: the host already
    // answered with the credential (waitForGitHost), so a failure is real.
    const refspec = `${sha}:refs/heads/${ref}`;
    const x = await git(["push", "--no-verify", "--porcelain", repoUrl, refspec], {
      auth: true,
      allowFail: true,
      worktree: false,
    });
    if (x.code !== 0) {
      const out = clean(`${x.stdout}\n${x.stderr}`);
      throw new Failure("push", `push of ${ref} failed: ${out.trim().slice(-1500)}`);
    }
    logLine(`chef-runner: pushed ${ref}`);
  }

  async function lsRemote(): Promise<Map<string, string>> {
    const x = await git(["ls-remote", repoUrl], { auth: true, allowFail: true, worktree: false });
    if (x.code !== 0) throw new Failure("push", "couldn't read the refs back");
    const m = new Map<string, string>();
    for (const line of x.stdout.split("\n")) {
      const [sha, ref] = line.split("\t");
      if (sha && ref) m.set(ref.trim(), sha.trim());
    }
    return m;
  }
}

/** More conflicting files than this and the merge is left to people (needs_attention). */
export const MAX_MERGE_CONFLICTS = 40;

export type MergeConflict = {
  path: string;
  /** Index stages present: 1 base, 2 chef (ours), 3 main (theirs). */
  stages: Set<number>;
  modes: Map<number, string>;
  /** What the agent finds, for merge-conflicts.md. */
  kind: string;
  /** Set when the runner resolved it (main's side); the agent leaves it alone. */
  resolution?: string;
};

/** `git ls-files --unmerged -z`: `<mode> <sha> <stage>\t<path>\0`, grouped by path. */
export function parseUnmergedZ(out: string): MergeConflict[] {
  const byPath = new Map<string, MergeConflict>();
  for (const entry of out.split("\0")) {
    if (entry === "") continue;
    const m = /^(\d{6}) [0-9a-f]+ ([123])\t([\s\S]+)$/.exec(entry);
    if (!m) throw new Error("unparseable ls-files entry");
    const stage = Number(m[2]);
    const c = byPath.get(m[3]) ?? { path: m[3], stages: new Set<number>(), modes: new Map<number, string>(), kind: "" };
    c.stages.add(stage);
    c.modes.set(stage, m[1]);
    byPath.set(m[3], c);
  }
  for (const c of byPath.values()) {
    const chef = c.stages.has(2);
    const main = c.stages.has(3);
    c.kind =
      chef && main
        ? c.stages.has(1)
          ? "changed on both sides: conflict markers in the file"
          : "added on both sides: conflict markers in the file"
        : chef
          ? "deleted on main, changed on chef: the checkout has chef's version; keep it or delete it"
          : "deleted on chef, changed on main: the checkout has main's version; keep it or delete it";
  }
  return [...byPath.values()];
}

/** Whether a file the merge just wrote has a conflict block. A plain file only; never follows a link. */
function hasConflictMarkers(path: string): boolean {
  try {
    const fd = openSync(path, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW | fsConstants.O_NONBLOCK);
    try {
      if (!fstatSync(fd).isFile()) return false;
      return /^<{7} /m.test(readFileSync(fd, "utf8"));
    } finally {
      closeSync(fd);
    }
  } catch {
    return false;
  }
}

/** `merge-conflicts.md`: the conflicted paths, scrubbed and quoted, at most MAX_MERGE_CONFLICTS. */
export function mergeConflictsFile(conflicts: MergeConflict[], clean: (s: string) => string): string {
  const show = (p: string) => JSON.stringify(revealInvisible(clean(p)).slice(0, 300));
  const forAgent = conflicts.filter((c) => !c.resolution).slice(0, MAX_MERGE_CONFLICTS);
  const taken = conflicts.filter((c) => c.resolution).slice(0, MAX_MERGE_CONFLICTS);
  const lines = [
    "# Merge conflicts",
    "",
    "main was merged into chef for this build and these files conflict.",
    "Resolve each one before the request (see the prompt).",
    "",
  ];
  if (forAgent.length > 0) {
    lines.push("## For you to resolve", "");
    for (const c of forAgent) lines.push(`- ${show(c.path)}: ${c.kind}`);
    lines.push("");
  }
  if (taken.length > 0) {
    lines.push(
      "## Resolved by the runner: main's version taken",
      "",
      "Paths the build may not change (protected files, package.json,",
      "lockfiles) take main's side, the human-maintained base. They're",
      "already resolved; leave them as they are.",
      "",
    );
    for (const c of taken) lines.push(`- ${show(c.path)}: ${c.resolution}`);
    lines.push("");
  }
  return lines.join("\n");
}

/**
 * A file the agent wrote, read by the runner: a regular file at exactly this
 * path (no symlink in it, the last component included), at most `max` bytes.
 */
export function readAgentFile(path: string, max: number): string {
  if (realpathSync(dirname(path)) !== dirname(path)) throw new Error("its directory is not a plain path");
  const fd = openSync(path, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW | fsConstants.O_NONBLOCK);
  try {
    if (!fstatSync(fd).isFile()) throw new Error("not a regular file");
    const buf = Buffer.alloc(max);
    let n = 0;
    while (n < max) {
      const r = readSync(fd, buf, n, max - n, null);
      if (r === 0) break;
      n += r;
    }
    return buf.subarray(0, n).toString("utf8");
  } finally {
    closeSync(fd);
  }
}

/**
 * The status file's content: only the known fields, every string scrubbed.
 * The runner never puts a credential here, and this makes sure a probe's
 * detail or an error that quotes one can't either.
 */
export function statusRecord(
  runId: string,
  s: { phase: string; ok: boolean; error?: string; selfTest?: EgressResult },
  clean: (s: string) => string,
  at: number = Date.now(),
): RunnerStatusFile {
  const out: RunnerStatusFile = { runId, at, phase: clean(s.phase), ok: s.ok };
  if (s.error !== undefined) out.error = clean(s.error);
  if (s.selfTest) {
    out.selfTest = {
      ok: s.selfTest.ok,
      probes: s.selfTest.probes.map((p) => ({ probe: clean(p.probe), blocked: p.blocked, detail: clean(p.detail) })),
    };
  }
  return out;
}

/** The npm script "auto" runs as the local env command. */
export const AUTO_LOCAL_ENV_SCRIPT = "chef:local-env";
/** What the runner keeps of a failed attempt's diff for "Try again" (src/component/chefAttempts.ts MAX_ATTEMPT_BYTES). */
export const MAX_ATTEMPT_BYTES = 512 * 1024;
/** The gates "auto" runs, in order, each if its script exists. */
export const AUTO_GATES: ReadonlyArray<readonly [string, string[]]> = [
  ["typecheck", ["npm", "run", "typecheck"]],
  ["lint", ["npm", "run", "lint"]],
  ["test", ["npm", "test"]],
];

/** The script names in `<dir>/package.json`; none if it is missing, too big or not JSON. */
export function packageScripts(dir: string): Set<string> {
  try {
    const raw = readFileSync(join(dir, "package.json"));
    if (raw.length > 1024 * 1024) return new Set();
    const scripts = (JSON.parse(raw.toString("utf8")) as { scripts?: unknown }).scripts;
    if (!scripts || typeof scripts !== "object" || Array.isArray(scripts)) return new Set();
    return new Set(Object.entries(scripts).filter(([, v]) => typeof v === "string" && v.trim() !== "").map(([k]) => k));
  } catch {
    return new Set();
  }
}

/**
 * The `localEnv` command: the run's `config.localEnv` if it is an argv,
 * `false` (for none) or "auto", else the runner's. Null for none.
 */
export function pickLocalEnv(
  config: Record<string, unknown> | undefined,
  fallback?: string[] | false | "auto",
  scripts: ReadonlySet<string> = new Set(),
): string[] | null {
  const fromRun = config?.localEnv;
  if (fromRun === false) return null;
  const isArgv = (x: unknown): x is string[] =>
    Array.isArray(x) && x.length > 0 && x.every((s) => typeof s === "string" && s !== "");
  if (fromRun === "auto" || (!isArgv(fromRun) && fallback === "auto")) {
    return scripts.has(AUTO_LOCAL_ENV_SCRIPT) ? ["npm", "run", "--silent", AUTO_LOCAL_ENV_SCRIPT] : null;
  }
  const argv = isArgv(fromRun) ? fromRun : fallback === false || fallback === undefined ? null : fallback;
  if (argv === null) return null;
  if (!isArgv(argv)) throw new Error("localEnv must be an argv");
  assertInertArgs(argv);
  return [...argv];
}

/** Gates from the run's config if it holds a valid list or "auto", else the runner's. */
export function pickGates(
  config: Record<string, unknown> | undefined,
  fallback?: string[][] | "auto",
  scripts: ReadonlySet<string> = new Set(),
): string[][] {
  const g = config?.gates;
  const auto = () => AUTO_GATES.filter(([name]) => scripts.has(name)).map(([, argv]) => [...argv]);
  if (g === "auto") return auto();
  if (Array.isArray(g) && g.length > 0 && g.every((x) => Array.isArray(x) && x.length > 0 && x.every((s) => typeof s === "string"))) {
    const gates = g as string[][];
    gates.forEach((argv) => assertInertArgs(argv));
    return gates;
  }
  if (fallback === "auto") return auto();
  return fallback ?? [["npm", "test"], ["npm", "run", "typecheck"]];
}

/** The session id in Claude Code's stream-json `init` line, or null. Checked: it goes into argv (`--resume`). */
export function streamJsonSessionId(line: string): string | null {
  if (!line.includes('"init"') || !line.includes("session_id")) return null;
  try {
    const m = JSON.parse(line) as { type?: unknown; subtype?: unknown; session_id?: unknown };
    if (m.type !== "system" || m.subtype !== "init" || typeof m.session_id !== "string") return null;
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(m.session_id) ? m.session_id : null;
  } catch {
    return null;
  }
}

/**
 * One readable log line from a Claude Code stream-json line, or null for
 * lines not worth a log entry. Never trusted: it's the agent's output.
 */
export function summarizeStreamJson(line: string): string | null {
  if (line.trim() === "") return null;
  let m: any;
  try {
    m = JSON.parse(line);
  } catch {
    return line;
  }
  if (!m || typeof m !== "object") return null;
  const cut = (s: unknown, n = 300) => {
    const t = typeof s === "string" ? s : JSON.stringify(s ?? "");
    return t.length > n ? t.slice(0, n) + "..." : t;
  };
  switch (m.type) {
    case "system":
      return m.subtype === "init" ? `init model=${cut(m.model, 80)}` : `system ${cut(m.subtype, 40)}`;
    case "assistant": {
      const parts = Array.isArray(m.message?.content) ? m.message.content : [];
      const out: string[] = [];
      for (const p of parts) {
        if (p?.type === "text") out.push(cut(p.text));
        else if (p?.type === "tool_use") out.push(`tool ${cut(p.name, 40)} ${cut(p.input, 200)}`);
      }
      return out.length ? out.join(" | ") : null;
    }
    case "user":
      return null;
    case "result":
      return `result ${cut(m.subtype, 40)} turns=${Number(m.num_turns) || 0} cost=${Number(m.total_cost_usd) || 0}`;
    default:
      return `${cut(m.type, 40)}`;
  }
}
