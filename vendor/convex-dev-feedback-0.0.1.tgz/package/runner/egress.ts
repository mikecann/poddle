// The egress self-test ("Egress, per sandbox, fail-closed"). The runner's
// first act, before the orchestrator gives any secret a real value: every
// probe here must FAIL to connect. Any success fails the run.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import http from "node:http";
import https from "node:https";
import net from "node:net";

export type ProbeResult = {
  probe: string;
  /** True when the probe was blocked, which is what we want. */
  blocked: boolean;
  detail: string;
};

export type EgressResult = { ok: boolean; probes: ProbeResult[] };

export type EgressCheck = () => Promise<EgressResult>;

const TIMEOUT_MS = 5000;

/** Resolves with what happened; "connected" means egress let it through. */
function tryRequest(
  url: string,
  extra: { host?: string } = {},
): Promise<{ connected: boolean; detail: string }> {
  return new Promise((resolve) => {
    const u = new URL(url);
    const mod = u.protocol === "https:" ? https : http;
    const req = mod.request(
      url,
      {
        method: "HEAD",
        timeout: TIMEOUT_MS,
        headers: extra.host ? { host: extra.host } : {},
        // A denied host might still present a certificate; any TLS session
        // at all means the packets got out.
        rejectUnauthorized: false,
      },
      (res) => {
        res.resume();
        resolve({ connected: true, detail: `HTTP ${res.statusCode}` });
      },
    );
    req.on("timeout", () => {
      req.destroy();
      resolve({ connected: false, detail: "timed out" });
    });
    req.on("error", (e: NodeJS.ErrnoException) => {
      // A TLS failure after the TCP connect still means we got out.
      const tls = /certificate|SSL|TLS|EPROTO/i.test(String(e.code ?? e.message));
      resolve({ connected: tls, detail: String(e.code ?? "error") });
    });
    req.end();
  });
}

/** An HTTP CONNECT through the configured proxy to a denied host. */
function tryConnect(proxy: string, target: string): Promise<{ connected: boolean; detail: string }> {
  return new Promise((resolve) => {
    const p = new URL(proxy);
    const sock = net.connect({ host: p.hostname, port: Number(p.port || 80) });
    const done = (connected: boolean, detail: string) => {
      sock.destroy();
      resolve({ connected, detail });
    };
    sock.setTimeout(TIMEOUT_MS, () => done(false, "timed out"));
    sock.on("error", (e: NodeJS.ErrnoException) => done(false, String(e.code ?? "error")));
    sock.on("connect", () => sock.write(`CONNECT ${target} HTTP/1.1\r\nHost: ${target}\r\n\r\n`));
    sock.once("data", (d) => {
      const status = /^HTTP\/1\.[01] (\d{3})/.exec(d.toString("latin1"))?.[1] ?? "?";
      done(status === "200", `proxy said ${status}`);
    });
  });
}

/**
 * The default check: a denied hostname over HTTPS, a direct IPv4 and IPv6
 * address, plain HTTP, and a CONNECT to a denied host through the sandbox's
 * proxy if one is configured.
 */
export function defaultEgressCheck(env: Record<string, string | undefined> = process.env): EgressCheck {
  return async () => {
    const probes: ProbeResult[] = [];
    const add = (probe: string, r: { connected: boolean; detail: string }) =>
      probes.push({ probe, blocked: !r.connected, detail: r.detail });
    add("denied hostname (https://example.com)", await tryRequest("https://example.com/"));
    add("direct IPv4 (https://1.1.1.1)", await tryRequest("https://1.1.1.1/"));
    add("direct IPv6 (https://[2606:4700:4700::1111])", await tryRequest("https://[2606:4700:4700::1111]/"));
    add("plain HTTP (http://example.com)", await tryRequest("http://example.com/"));
    const proxy = env.HTTPS_PROXY ?? env.https_proxy ?? env.HTTP_PROXY ?? env.http_proxy;
    if (proxy) {
      add("CONNECT example.com:443 through the proxy", await tryConnect(proxy, "example.com:443"));
    } else {
      probes.push({ probe: "CONNECT through a proxy", blocked: true, detail: "no proxy configured" });
    }
    return { ok: probes.every((p) => p.blocked), probes };
  };
}

/** A check that runs a command; exit 0 means egress is closed. For tests and L2. */
export function commandEgressCheck(
  run: () => Promise<{ code: number | null; output: string }>,
): EgressCheck {
  return async () => {
    const r = await run();
    return {
      ok: r.code === 0,
      probes: [{ probe: "egress check command", blocked: r.code === 0, detail: r.output.slice(0, 500) }],
    };
  };
}
