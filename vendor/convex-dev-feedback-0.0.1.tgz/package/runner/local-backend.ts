// The local Convex backend the agent tests against, started from the binary
// the `chef-runner` snapshot carries. Not through `convex dev --once`: on a
// first run that asks version.convex.dev for the latest backend version
// (blocked by egress), and it SIGTERMs the backend it started when it exits
// (L2 check 5). Instead the runner:
//
//  1. makes a fresh instance secret and has the binary's `keygen admin-key`
//     derive the admin key from it (read from stdout, never logged);
//  2. starts the binary detached, in its own session, so it outlives the
//     spawn that started it, as the agent user, on 127.0.0.1;
//  3. waits until `/version` answers, bounded;
//  4. hands the agent and the gates CONVEX_SELF_HOSTED_URL and
//     CONVEX_SELF_HOSTED_ADMIN_KEY, so the CLI drives it as a self-hosted
//     deployment and never sets anything up over the network.
//
// The instance secret is in the backend's argv, which every user in the
// sandbox can see through /proc. It only protects this throwaway backend,
// which runs as the agent user anyway.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import http from "node:http";
import { join } from "node:path";

export type LocalBackendConfig = {
  /** The prebaked binary. Default /opt/chef/bin/convex-local-backend. */
  binary?: string;
  /** The backend's port on 127.0.0.1. Default 3210. */
  port?: number;
  /** Its HTTP actions port. Default port + 1. */
  sitePort?: number;
  instanceName?: string;
  /** Recreated empty on every start, then handed to the agent user. Default /opt/chef/backend. */
  dataDir?: string;
  /** How long to wait for `/version` to answer. Default 60 s. */
  startTimeoutMs?: number;
};

export const DEFAULT_LOCAL_BACKEND_BINARY = "/opt/chef/bin/convex-local-backend";
export const DEFAULT_LOCAL_BACKEND_PORT = 3210;
export const DEFAULT_LOCAL_BACKEND_DATA_DIR = "/opt/chef/backend";

export type ResolvedLocalBackend = Required<LocalBackendConfig>;

const NAME = /^[a-z][a-z0-9-]{0,62}$/;
const ABS = /^\/[A-Za-z0-9_./-]+$/;

export function resolveLocalBackend(c: LocalBackendConfig = {}): ResolvedLocalBackend {
  const port = c.port ?? DEFAULT_LOCAL_BACKEND_PORT;
  const r: ResolvedLocalBackend = {
    binary: c.binary ?? DEFAULT_LOCAL_BACKEND_BINARY,
    port,
    sitePort: c.sitePort ?? port + 1,
    instanceName: c.instanceName ?? "chef-local",
    dataDir: c.dataDir ?? DEFAULT_LOCAL_BACKEND_DATA_DIR,
    startTimeoutMs: c.startTimeoutMs ?? 60_000,
  };
  for (const p of [r.port, r.sitePort]) {
    if (!Number.isInteger(p) || p < 1 || p > 65535) throw new Error("local backend ports must be 1 to 65535");
  }
  if (r.port === r.sitePort) throw new Error("the local backend's two ports must differ");
  if (!NAME.test(r.instanceName)) throw new Error("bad local backend instance name");
  if (!ABS.test(r.binary) || !ABS.test(r.dataDir)) throw new Error("local backend paths must be absolute");
  return r;
}

export function localBackendUrl(r: ResolvedLocalBackend): string {
  return `http://127.0.0.1:${r.port}`;
}

export function keygenArgs(r: ResolvedLocalBackend, instanceSecret: string): string[] {
  return ["keygen", "admin-key", "--instance-name", r.instanceName, "--instance-secret", instanceSecret];
}

export function serveArgs(r: ResolvedLocalBackend, instanceSecret: string): string[] {
  return [
    "--port", String(r.port),
    "--site-proxy-port", String(r.sitePort),
    "--instance-name", r.instanceName,
    "--instance-secret", instanceSecret,
    "--local-storage", join(r.dataDir, "storage"),
    join(r.dataDir, "convex_local_backend.sqlite3"),
  ];
}

/** The admin key from keygen's output: one line, one token. */
export function parseAdminKey(stdout: string): string {
  const lines = stdout.split("\n").map((l) => l.trim()).filter(Boolean);
  const key = lines[lines.length - 1] ?? "";
  if (!/^[A-Za-z0-9_|:.-]{1,2000}$/.test(key)) throw new Error("keygen didn't print an admin key");
  return key;
}

/** True when the backend's `/version` answers 200. Never through a proxy. */
export function backendUp(port: number, timeoutMs = 1000): Promise<boolean> {
  return new Promise((resolve) => {
    const req = http.get({ host: "127.0.0.1", port, path: "/version", timeout: timeoutMs }, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
    req.on("error", () => resolve(false));
  });
}
