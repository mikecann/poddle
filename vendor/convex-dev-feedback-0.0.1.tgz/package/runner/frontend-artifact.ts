// The frontend artifact, built in the build sandbox (docs/chef-pipeline.md,
// "The preview"). The deploy sandbox holds the real preview deploy key and
// runs no repo code, so the app's frontend is built here instead, where repo
// code runs anyway:
//
//  1. the build command (default `npm run build`) as the agent user, in the
//     checkout, after the gates and the commit, with the Convex URL variable
//     (default VITE_CONVEX_URL) set to CONVEX_URL_PLACEHOLDER. Egress then is
//     the app's own host and the git secret is dead, as for the gates;
//  2. every agent process killed;
//  3. the output directory (default dist) read by the runner: regular files
//     only, no symlinks, no hard links, nothing outside the checkout;
//  4. packed as a deterministic gzipped ustar archive, checked to hold the
//     placeholder somewhere, and uploaded with its sha256 and the commit to
//     POST /chef-agent/artifact.
//
// The deploy sandbox unpacks it (runner/chef-frontend-unpack.mjs), swaps the
// placeholder for the preview's URL and uploads the files.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { createHash } from "node:crypto";
import { closeSync, constants, fstatSync, lstatSync, openSync, readSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { gzipSync } from "node:zlib";
import {
  CONVEX_URL_PLACEHOLDER,
  MAX_ARTIFACT_BYTES,
  MAX_ARTIFACT_FILES,
  MAX_ARTIFACT_UNPACKED_BYTES,
  resolveFrontendConfig,
  type FrontendConfig,
  type ResolvedFrontend,
} from "../src/chef/frontend.ts";

export type { FrontendConfig };

/**
 * The frontend settings for a run: the run's `config.frontend` from the host
 * (`false` for none) wins over the runner's file config, as gates do. Null
 * means no frontend. Throws on a malformed config.
 */
export function pickFrontend(
  runConfig: Record<string, unknown> | undefined,
  fileConfig: FrontendConfig | false | undefined,
): ResolvedFrontend | null {
  const fromRun = runConfig?.frontend;
  if (fromRun === false) return null;
  if (fromRun !== undefined && fromRun !== null) {
    if (typeof fromRun !== "object" || Array.isArray(fromRun)) throw new Error("config.frontend must be an object or false");
    return resolveFrontendConfig(fromRun as FrontendConfig);
  }
  if (fileConfig === false) return null;
  return resolveFrontendConfig(fileConfig);
}

export type PackedFile = { path: string; bytes: Uint8Array };

// No control characters, no slashes or backslashes.
// eslint-disable-next-line no-control-regex
const NAME_PART = /^[^\x00-\x1f\x7f/\\]+$/;

/** Every regular file under `dir`, sorted, read without following links. */
export function collectDist(workDir: string, distDir: string): PackedFile[] {
  // Every component from the checkout down must be a real directory.
  let at = workDir;
  for (const part of distDir.split("/")) {
    at = join(at, part);
    let st;
    try {
      st = lstatSync(at);
    } catch {
      throw new Error(`the build did not produce ${distDir}`);
    }
    if (st.isSymbolicLink()) throw new Error(`${distDir} goes through a symlink`);
    if (!st.isDirectory()) throw new Error(`${distDir} is not a directory`);
  }
  const out: PackedFile[] = [];
  let total = 0;
  const walk = (dir: string, rel: string) => {
    const names = readdirSync(dir).sort();
    for (const name of names) {
      if (!NAME_PART.test(name) || name === "." || name === "..") throw new Error(`bad file name in ${distDir}: ${JSON.stringify(name)}`);
      const full = join(dir, name);
      const path = rel ? `${rel}/${name}` : name;
      const st = lstatSync(full);
      if (st.isSymbolicLink()) throw new Error(`${distDir}/${path} is a symlink`);
      if (st.isDirectory()) {
        walk(full, path);
        continue;
      }
      if (!st.isFile()) throw new Error(`${distDir}/${path} is not a regular file`);
      if (st.nlink > 1) throw new Error(`${distDir}/${path} is a hard link`);
      if (out.length >= MAX_ARTIFACT_FILES) throw new Error(`${distDir} has more than ${MAX_ARTIFACT_FILES} files`);
      total += st.size;
      if (total > MAX_ARTIFACT_UNPACKED_BYTES) throw new Error(`${distDir} is over ${MAX_ARTIFACT_UNPACKED_BYTES} bytes`);
      out.push({ path, bytes: readNoFollow(full) });
    }
  };
  walk(at, "");
  if (out.length === 0) throw new Error(`${distDir} is empty`);
  return out;
}

function readNoFollow(path: string): Uint8Array {
  const fd = openSync(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
  try {
    const st = fstatSync(fd);
    if (!st.isFile()) throw new Error(`${path} is not a regular file`);
    const buf = Buffer.alloc(st.size);
    let off = 0;
    while (off < buf.length) {
      const n = readSync(fd, buf, off, buf.length - off, off);
      if (n === 0) break;
      off += n;
    }
    return new Uint8Array(buf.buffer, buf.byteOffset, off);
  } finally {
    closeSync(fd);
  }
}

// ---------------------------------------------------------------- ustar

function octal(n: number, width: number): string {
  // width includes the trailing NUL.
  const s = n.toString(8);
  if (s.length > width - 1) throw new Error("tar field overflow");
  return s.padStart(width - 1, "0") + "\0";
}

function splitName(path: string): { name: string; prefix: string } {
  if (Buffer.byteLength(path) <= 100) return { name: path, prefix: "" };
  for (let i = path.indexOf("/"); i > 0; i = path.indexOf("/", i + 1)) {
    const prefix = path.slice(0, i);
    const name = path.slice(i + 1);
    if (Buffer.byteLength(prefix) <= 155 && Buffer.byteLength(name) <= 100) return { name, prefix };
  }
  throw new Error(`path too long for the archive: ${path}`);
}

function header(path: string, size: number): Uint8Array {
  const h = Buffer.alloc(512);
  const { name, prefix } = splitName(path);
  h.write(name, 0, "utf8");
  h.write(octal(0o644, 8), 100, "ascii");
  h.write(octal(0, 8), 108, "ascii");
  h.write(octal(0, 8), 116, "ascii");
  h.write(octal(size, 12), 124, "ascii");
  h.write(octal(0, 12), 136, "ascii");
  h.write("        ", 148, "ascii");
  h.write("0", 156, "ascii");
  h.write("ustar\0", 257, "ascii");
  h.write("00", 263, "ascii");
  h.write(prefix, 345, "utf8");
  let sum = 0;
  for (const b of h) sum += b;
  h.write(octal(sum, 7) + " ", 148, "ascii");
  return h;
}

/** A deterministic ustar archive of regular files: mode 0644, uid 0, mtime 0. */
export function packTar(files: PackedFile[]): Uint8Array {
  const parts: Uint8Array[] = [];
  for (const f of files) {
    parts.push(header(f.path, f.bytes.length));
    parts.push(f.bytes);
    const pad = (512 - (f.bytes.length % 512)) % 512;
    if (pad) parts.push(new Uint8Array(pad));
  }
  parts.push(new Uint8Array(1024));
  return Buffer.concat(parts);
}

// ---------------------------------------------------------------- the step

export type FrontendDeps = {
  /** The build command as the agent user, in the checkout, with these extra envs. */
  build: (argv: string[], env: Record<string, string>) => Promise<{ code: number | null; timedOut: boolean }>;
  /** Kill every agent process and throw if any is left. */
  killAgents: () => Promise<void>;
  /** POST the archive to /chef-agent/artifact. Throws on refusal. */
  upload: (bytes: Uint8Array, meta: { sha256: string; commitSha: string }) => Promise<void>;
  log: (line: string) => void;
};

export type FrontendResult = { sha256: string; size: number; files: number };

/**
 * The names frameworks read a Convex URL from at build time. The build gets
 * the placeholder under each of them as well as the configured one, so a
 * Next app (NEXT_PUBLIC_CONVEX_URL) builds with the Vite default config,
 * and the other way round; the deploy replaces the placeholder whatever
 * name carried it.
 */
export const CONVEX_URL_ENV_ALIASES = [
  "VITE_CONVEX_URL",
  "NEXT_PUBLIC_CONVEX_URL",
  "REACT_APP_CONVEX_URL",
  "EXPO_PUBLIC_CONVEX_URL",
  "PUBLIC_CONVEX_URL",
] as const;

const includes = (hay: Uint8Array, needle: Buffer) => Buffer.from(hay.buffer, hay.byteOffset, hay.length).includes(needle);

export async function buildFrontendArtifact(
  args: { workDir: string; frontend: ResolvedFrontend; commitSha: string },
  deps: FrontendDeps,
): Promise<FrontendResult> {
  const fe = args.frontend;
  deps.log(`chef-runner: building the frontend (${fe.command.join(" ")}) with ${fe.urlEnvVar} as a placeholder`);
  let built: { code: number | null; timedOut: boolean };
  try {
    const env: Record<string, string> = Object.fromEntries(CONVEX_URL_ENV_ALIASES.map((n) => [n, CONVEX_URL_PLACEHOLDER]));
    env[fe.urlEnvVar] = CONVEX_URL_PLACEHOLDER;
    built = await deps.build(fe.command, env);
  } finally {
    await deps.killAgents();
  }
  if (built.code !== 0) {
    throw new Error(`frontend build failed: ${fe.command.join(" ")}${built.timedOut ? " (timed out)" : ""}`);
  }
  const files = collectDist(args.workDir, fe.distDir);
  const needle = Buffer.from(CONVEX_URL_PLACEHOLDER);
  if (!files.some((f) => includes(f.bytes, needle))) {
    throw new Error(
      `the built frontend never uses ${fe.urlEnvVar} (nor ${CONVEX_URL_ENV_ALIASES.filter((n) => n !== fe.urlEnvVar).join(", ")}); set the run config's frontend.urlEnvVar to the variable the app reads`,
    );
  }
  const gz = gzipSync(packTar(files), { level: 9 });
  if (gz.length > MAX_ARTIFACT_BYTES) {
    throw new Error(`the built frontend is ${gz.length} bytes gzipped; at most ${MAX_ARTIFACT_BYTES}`);
  }
  const sha256 = createHash("sha256").update(gz).digest("hex");
  await deps.upload(new Uint8Array(gz.buffer, gz.byteOffset, gz.length), { sha256, commitSha: args.commitSha });
  deps.log(`chef-runner: uploaded the frontend, ${files.length} files, ${gz.length} bytes, sha256 ${sha256}`);
  return { sha256, size: gz.length, files: files.length };
}
