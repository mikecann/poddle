#!/bin/sh
# Starts the delivered Chef runner. The launcher (packages/chef-cloud/src/client/chefLauncher.ts,
# delivered mode) writes the runner, its config and this script into the
# build sandbox through Daytona's file API, then its one command, as root
# through sudo, installs them root-owned into /opt/chef/runner, checks every
# file against the sha256 manifest whose own hash is in that command, and
# runs this. So the sandbox image needs no Chef code: the runner is exactly
# the version the host's @convex-dev/feedback has.
#
# sudo keeps only the variables the runner reads (src/chef/runnerEnv.ts);
# they are names and placeholders, never a value on a command line.
set -eu
d=/opt/chef/runner
ca=/etc/daytona/netleash/ca.crt

# With an egress allow list, Daytona's proxy re-signs HTTPS with its own CA.
# Trust it system-wide for git and curl (the base image's helper when it has
# one), and give Node (this runner, npm and the agent through it)
# NODE_EXTRA_CA_CERTS.
if [ -r "$ca" ]; then
  if [ -x /opt/chef/bin/trust-daytona-proxy-ca ]; then
    /opt/chef/bin/trust-daytona-proxy-ca >/dev/null
  else
    install -m 0644 "$ca" /usr/local/share/ca-certificates/daytona-netleash.crt
    update-ca-certificates >/dev/null 2>&1
  fi
  export NODE_EXTRA_CA_CERTS="$ca"
fi

# The screenshot helper and chef-check the agent runs, on its PATH, root's:
# it can't change them.
chmod 0755 "$d/chef-screenshot.mjs" "$d/chef-check.mjs"
ln -sf "$d/chef-screenshot.mjs" /usr/local/bin/chef-screenshot
ln -sf "$d/chef-check.mjs" /usr/local/bin/chef-check

# Where the runner builds the agent's read-only skills plugin and config.
# It and every dir above it must be root's and writable by no one else.
install -d -o root -g root -m 0755 /opt/chef-agent

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
exec node "$d/chef-runner.mjs" --config "$d/runner.json"
