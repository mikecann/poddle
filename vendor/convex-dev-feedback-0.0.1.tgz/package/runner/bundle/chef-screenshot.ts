// The bundled `chef-screenshot` helper's entry point (scripts/build-runner.mjs).
// The same as runner/chef-screenshot.mjs.
import { helperMain } from "../screenshot-helper.ts";

process.exitCode = await helperMain(process.argv.slice(2), process.env, {
  out: (s) => process.stdout.write(s),
  err: (s) => process.stderr.write(s),
  cwd: process.cwd(),
});
