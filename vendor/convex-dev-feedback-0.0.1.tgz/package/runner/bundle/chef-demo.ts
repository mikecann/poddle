// The bundled demo recorder's entry point (scripts/build-runner.mjs): runs
// in a demo sandbox, started by chef-demo.sh (runner/demo-record.ts).
import { demoMain } from "../demo-record.ts";

process.exitCode = await demoMain(process.env, (s) => process.stdout.write(s));
