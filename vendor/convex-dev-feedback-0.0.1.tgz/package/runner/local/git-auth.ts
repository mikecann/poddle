// The git credential for a local run: asked of the credential helper that
// `npx chef init` set for the `chef` remote (`npx chef git-credential`, a
// short-lived Code Storage token), through `git credential fill`, and handed
// to the runner as a Basic value. The runner puts it in an http.extraHeader
// of its own git processes only (runner/runner.ts gitEnv); it never touches
// a file, an argv or the agent.
//
// Only the remote's own helper answers: `credential.helper=` empties the
// list git built from the developer's config (a keychain helper could hold
// an expired token from an earlier push) and the remote's helper is added
// back, so nothing else is asked and nothing is stored.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawn } from "node:child_process";

export type GitAuthOpts = {
  /** The app's checkout, where the `chef` remote and its helper are configured. */
  appDir: string;
  /** The remote's URL, with no credentials in it. */
  remoteUrl: string;
  gitBin?: string;
  /** The helper's environment: the developer's (it runs their `npx chef` and Convex login). */
  env: Record<string, string | undefined>;
  timeoutMs?: number;
};

type Run = { code: number | null; stdout: string; stderr: string };

function run(bin: string, args: string[], o: { cwd: string; env: Record<string, string | undefined>; input?: string; timeoutMs: number }): Promise<Run> {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { cwd: o.cwd, env: o.env as NodeJS.ProcessEnv, stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (d: string) => (stdout += d));
    child.stderr.on("data", (d: string) => (stderr = (stderr + d).slice(-4000)));
    const timer = setTimeout(() => child.kill("SIGKILL"), o.timeoutMs);
    child.on("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code, stdout, stderr });
    });
    child.stdin.end(o.input ?? "");
  });
}

/** The `chef` remote's URL from the app's git config. Refuses one with credentials in it. */
export async function chefRemoteUrl(appDir: string, opts: { gitBin?: string; env: Record<string, string | undefined>; remote?: string }): Promise<string> {
  const r = await run(opts.gitBin ?? "git", ["remote", "get-url", opts.remote ?? "chef"], { cwd: appDir, env: opts.env, timeoutMs: 10_000 });
  if (r.code !== 0) throw new Error(`no git remote "${opts.remote ?? "chef"}" here; run \`npx chef init\` first`);
  const url = r.stdout.trim();
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    throw new Error("the chef remote is not an http(s) URL");
  }
  if (u.protocol !== "https:" && u.protocol !== "http:") throw new Error("the chef remote is not an http(s) URL");
  if (u.username || u.password) throw new Error("the chef remote's URL carries credentials; run `npx chef init` again");
  return url;
}

/** `username=...` and `password=...` from `git credential fill`'s answer. */
export function parseCredentialAnswer(text: string): { username: string; password: string } | null {
  const get = (k: string) => {
    for (const line of text.split("\n")) {
      if (line.startsWith(`${k}=`)) return line.slice(k.length + 1).replace(/\r$/, "");
    }
    return null;
  };
  const username = get("username");
  const password = get("password");
  if (!username || !password) return null;
  return { username, password };
}

/** Asks the remote's helper for a credential; returns base64(user:password). Never prints it. */
export async function fillGitAuth(o: GitAuthOpts): Promise<string> {
  const git = o.gitBin ?? "git";
  const u = new URL(o.remoteUrl);
  const helpers = await run(git, ["config", "--get-all", `credential.${o.remoteUrl}.helper`], {
    cwd: o.appDir,
    env: o.env,
    timeoutMs: 10_000,
  });
  const helper = helpers.stdout.split("\n").map((s) => s.trim()).filter(Boolean).pop();
  if (helpers.code !== 0 || !helper) {
    throw new Error("the chef remote has no credential helper; run `npx chef init` first");
  }
  const input =
    [`protocol=${u.protocol.replace(/:$/, "")}`, `host=${u.host}`, `path=${u.pathname.replace(/^\//, "")}`].join("\n") + "\n\n";
  const r = await run(
    git,
    ["-c", "credential.helper=", "-c", `credential.${o.remoteUrl}.helper=${helper}`, "-c", "credential.interactive=false", "credential", "fill"],
    {
      cwd: o.appDir,
      env: { ...o.env, GIT_TERMINAL_PROMPT: "0", GIT_ASKPASS: "/bin/false", SSH_ASKPASS: "/bin/false" },
      input,
      timeoutMs: o.timeoutMs ?? 120_000,
    },
  );
  const cred = r.code === 0 ? parseCredentialAnswer(r.stdout) : null;
  // The helper's own message, never git's answer (which holds the password).
  if (!cred) throw new Error(`the credential helper gave no credential${r.stderr.trim() ? `: ${r.stderr.trim().split("\n").pop()}` : ""}`);
  return Buffer.from(`${cred.username}:${cred.password}`, "utf8").toString("base64");
}
