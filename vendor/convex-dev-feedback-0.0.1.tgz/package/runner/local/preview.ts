// `npx chef work --preview local`: the pushed commit deployed to its
// request's preview deployment, chef-req-<number> (src/chef/preview.ts;
// chef-<sha12> without a request number), from the developer's machine, by the
// same fixed script the cloud deploy sandbox runs (runner/chef-preview-deploy.sh):
// a fresh checkout of the sha, npm or pnpm by the lockfile without scripts
// (runner/chef-install.mjs), the developer's
// own Convex CLI from the app, `convex deploy --preview-create`.
//
// `--preview-create` only works with a preview deploy key (`npx convex
// deploy --help`), so the CLI login alone can't make one; the developer's
// key comes from CHEF_PREVIEW_DEPLOY_KEY in their environment and goes to
// the script's environment only. The frontend isn't uploaded (the runner's
// build went to Chef for the cloud path); the preview is the backend.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, realpathSync, rmSync } from "node:fs";
import { randomBytes } from "node:crypto";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { scrub } from "../../src/chef/scrub.ts";
import { isRunPreviewName, previewNameFor } from "../../src/chef/preview.ts";

export const PREVIEW_KEY_ENV = "CHEF_PREVIEW_DEPLOY_KEY";

export type LocalPreviewOpts = {
  sha: string;
  /** The run's request number, for its preview's name; null or absent: chef-<sha12>. */
  itemNumber?: number | null;
  appDir: string;
  remoteUrl: string;
  baseDir: string;
  hostEnv: Record<string, string | undefined>;
  gitAuth: () => Promise<string>;
  /** The deploy script; default the one next to the runner. */
  script?: string;
  /** The Convex CLI; default the app's node_modules/.bin/convex. */
  convexBin?: string;
  print?: (line: string) => void;
  timeoutMs?: number;
};

export type LocalPreview = { ok: true; deploymentName: string } | { ok: false; error: string };

const DEPLOYMENT_NAME = /^[a-z0-9-]{1,64}$/;

/** The script's result file: only the deployment name, and only if the rest agrees with it. */
export function parseLocalPreviewResult(raw: string, sha: string, itemNumber: number | null = null): LocalPreview {
  let r: any;
  try {
    r = JSON.parse(raw.trim().replace(/^chef-preview-result /, ""));
  } catch {
    return { ok: false, error: "the preview result is not JSON" };
  }
  if (!r || r.sha !== sha) return { ok: false, error: "the preview result is for another commit" };
  if (!isRunPreviewName(r.previewName, { itemNumber, sha })) return { ok: false, error: "the preview name is not the request's" };
  if (typeof r.deploymentName !== "string" || !DEPLOYMENT_NAME.test(r.deploymentName)) return { ok: false, error: "bad deployment name" };
  if (r.convexUrl !== `https://${r.deploymentName}.convex.cloud`) return { ok: false, error: "the URL doesn't match the deployment name" };
  return { ok: true, deploymentName: r.deploymentName };
}

export async function deployLocalPreview(o: LocalPreviewOpts): Promise<LocalPreview> {
  if (!/^[0-9a-f]{40}$/.test(o.sha)) return { ok: false, error: "the sha must be 40 hex characters" };
  const key = o.hostEnv[PREVIEW_KEY_ENV];
  if (!key) return { ok: false, error: `${PREVIEW_KEY_ENV} is not set; a local preview needs the project's preview deploy key` };
  const convexBin = o.convexBin ?? join(o.appDir, "node_modules", ".bin", "convex");
  if (!existsSync(convexBin)) return { ok: false, error: `no Convex CLI at ${convexBin}; install the app's dependencies` };
  const script = o.script ?? fileURLToPath(new URL("../chef-preview-deploy.sh", import.meta.url));
  const print = o.print ?? ((l: string) => process.stdout.write(l + "\n"));
  mkdirSync(o.baseDir, { recursive: true, mode: 0o700 });
  const dir = join(realpathSync(o.baseDir), `preview-${o.sha.slice(0, 12)}-${randomBytes(3).toString("hex")}`);
  mkdirSync(dir, { mode: 0o700 });
  let gitAuth = "";
  try {
    gitAuth = await o.gitAuth();
    const resultFile = join(dir, "result.json");
    const env: Record<string, string> = {
      PATH: o.hostEnv.PATH ?? "/usr/local/bin:/usr/bin:/bin",
      HOME: join(dir, "home"),
      LANG: "C",
      [PREVIEW_KEY_ENV]: key,
      CHEF_PREVIEW_NAME: previewNameFor({ itemNumber: o.itemNumber ?? null, sha: o.sha }),
      CHEF_REPO_URL: o.remoteUrl,
      CHEF_GIT_AUTH: gitAuth,
      CHEF_CONVEX_BIN: realpathSync(convexBin),
      CHEF_WORKDIR: join(dir, "checkout"),
      CHEF_RESULT_FILE: resultFile,
      CHEF_FRONTEND: "0",
    };
    mkdirSync(env.HOME, { mode: 0o700 });
    const clean = (s: string) => scrub(s, { knownValues: [key, key.split("|").pop() ?? "", gitAuth] });
    const code = await new Promise<number | null>((resolve, reject) => {
      const child = spawn("bash", [script, o.sha], { env, stdio: ["ignore", "pipe", "pipe"] });
      const out = (d: Buffer) => {
        for (const l of d.toString("utf8").split("\n")) if (l.trim()) print(`preview: ${clean(l)}`);
      };
      child.stdout.on("data", out);
      child.stderr.on("data", out);
      const timer = setTimeout(() => child.kill("SIGKILL"), o.timeoutMs ?? 20 * 60_000);
      child.on("error", (e) => {
        clearTimeout(timer);
        reject(e);
      });
      child.on("close", (c) => {
        clearTimeout(timer);
        resolve(c);
      });
    });
    if (code !== 0) return { ok: false, error: `the preview deploy failed (${code})` };
    if (!existsSync(resultFile)) return { ok: false, error: "the preview deploy wrote no result" };
    return parseLocalPreviewResult(readFileSync(resultFile, "utf8"), o.sha, o.itemNumber ?? null);
  } catch (e) {
    return { ok: false, error: scrub((e as Error).message, { knownValues: [key, gitAuth] }) };
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
