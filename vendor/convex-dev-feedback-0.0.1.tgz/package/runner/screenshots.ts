// The final screenshots (docs/chef-pipeline.md, "Screenshots"): after the
// gates and guards pass, with the agent dead, the runner starts the app as
// the agent user against a fresh local backend, seeds it with the agent's
// seed function if its plan names one, screenshots the pages the agent's
// `screenshot-plan.json` lists (the home page by default) with the fixed
// `chef-screenshot` helper, signed in as the app's demo user when the app has
// a sign-in link function, kills everything the agent user has, and uploads
// each PNG to POST /chef-agent/screenshot.
//
// It runs after the guards' `git add`, so nothing the build or the app
// writes into the checkout reaches the commit, and before `committed`, so no
// agent code runs while the git credential can write.
//
// Best effort: nothing here fails the run. Every problem is a log line.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { createHash } from "node:crypto";
import {
  closeSync,
  constants as fsConstants,
  existsSync,
  fstatSync,
  mkdirSync,
  openSync,
  readSync,
  realpathSync,
  rmSync,
} from "node:fs";
import http from "node:http";
import { dirname, join } from "node:path";
import { SCREENSHOT_LIMITS, parseScreenshotPlan, pngInfo, type ScreenshotPage } from "../src/chef/screenshots.ts";
import { checkDemoSteps } from "../src/chef/demo.ts";

export type ScreenshotConfig = {
  /** The helper, root-owned. Default /opt/chef/runner/chef-screenshot.mjs, run with `node`. */
  helper?: string;
  /** Runs the helper. Default `node` from the agent's PATH. */
  nodeBin?: string;
  /** Passed to the helper as --playwright-bin. Default: the helper's own (/opt/chef/bin/playwright). */
  playwrightBin?: string;
  /** PLAYWRIGHT_BROWSERS_PATH for the agent and the helper. Default /opt/chef/ms-playwright. */
  browsersPath?: string;
  /** Where the helper writes the PNGs: made fresh, handed to the agent user. Default /opt/chef-agent/screenshots. */
  outDir?: string;
  /** Pushes the app's functions to the local backend. Default `npx convex dev --once --typecheck=disable`. */
  push?: string[][];
  /** Runs the plan's seed function, which is appended. Default `npx convex run`. */
  seed?: string[];
  /** Builds the frontend; VITE_CONVEX_URL is the local backend. Default `npm run build`. */
  build?: string[][];
  /** Serves the build on 127.0.0.1:<port>, in the background. Default `npx vite preview` on 4173. */
  serve?: string[];
  port?: number;
  /** WxH. Default 1280x800. */
  viewport?: string;
  /** Each of push, seed and build. Default 5 minutes. */
  stepTimeoutMs?: number;
  /** For the server to answer. Default 60 s. */
  serveTimeoutMs?: number;
  /** One page. Default 60 s. */
  shotTimeoutMs?: number;
};

export const DEFAULT_SCREENSHOT_HELPER = "/opt/chef/runner/chef-screenshot.mjs";
export const DEFAULT_BROWSERS_PATH = "/opt/chef/ms-playwright";
export const DEFAULT_SCREENSHOT_DIR = "/opt/chef-agent/screenshots";
export const DEFAULT_PREVIEW_PORT = 4173;

export type ResolvedScreenshotConfig = Required<Omit<ScreenshotConfig, "playwrightBin">> & {
  playwrightBin?: string;
  /**
   * The app's sign-in link function (the run's config.loginFunction): pages
   * are screenshotted signed in through it, unless the plan says
   * `"signedIn": false`.
   */
  loginFunction?: string;
  /**
   * Where the app's frontend build writes (the run's config.frontend.distDir,
   * `out` for a Next.js static export). The default server is `vite preview`,
   * which serves `dist` unless told otherwise.
   */
  distDir?: string;
  /**
   * The agent's demo script (its absolute path, written by the agent): after
   * the screenshots, it is rehearsed once on this app the way the preview's
   * demo video will play it. A failure is logged with the step and what the
   * page said, and where it stopped goes up as the `demo-stopped` screenshot.
   */
  demoScript?: string;
};

/** The screenshot the rehearsal leaves when it fails: where the demo would stop. */
export const DEMO_STOPPED = "demo-stopped";

const ABS = /^\/[A-Za-z0-9_./-]+$/;
/** A build directory in the checkout: plain relative segments. */
const DIST_DIR = /^[A-Za-z0-9_.-]+(\/[A-Za-z0-9_.-]+)*$/;

function defaultServe(port: number): string[] {
  return ["npx", "vite", "preview", "--port", String(port), "--strictPort", "--host", "127.0.0.1"];
}

/**
 * The server's argv: the configured one, with the build directory added when
 * it is the default `vite preview` and the app builds somewhere else. Before
 * this, every Makeabook build's final screenshots failed with `The directory
 * "dist" does not exist` (its build writes `out`).
 */
export function serveArgv(cfg: ResolvedScreenshotConfig): string[] {
  const isDefault = cfg.serve.join("\0") === defaultServe(cfg.port).join("\0");
  if (!isDefault || cfg.distDir === undefined || cfg.distDir === "dist") return cfg.serve;
  if (!DIST_DIR.test(cfg.distDir) || cfg.distDir.split("/").includes("..")) throw new Error("the build directory must be a plain relative path");
  return [...cfg.serve, "--outDir", cfg.distDir];
}

export function resolveScreenshotConfig(c: ScreenshotConfig = {}): ResolvedScreenshotConfig {
  const port = c.port ?? DEFAULT_PREVIEW_PORT;
  const r: ResolvedScreenshotConfig = {
    helper: c.helper ?? DEFAULT_SCREENSHOT_HELPER,
    nodeBin: c.nodeBin ?? "node",
    browsersPath: c.browsersPath ?? DEFAULT_BROWSERS_PATH,
    outDir: c.outDir ?? DEFAULT_SCREENSHOT_DIR,
    push: c.push ?? [["npx", "convex", "dev", "--once", "--typecheck=disable"]],
    seed: c.seed ?? ["npx", "convex", "run"],
    build: c.build ?? [["npm", "run", "build"]],
    serve: c.serve ?? defaultServe(port),
    port,
    viewport: c.viewport ?? "1280x800",
    stepTimeoutMs: c.stepTimeoutMs ?? 5 * 60_000,
    serveTimeoutMs: c.serveTimeoutMs ?? 60_000,
    shotTimeoutMs: c.shotTimeoutMs ?? 60_000,
    ...(c.playwrightBin !== undefined ? { playwrightBin: c.playwrightBin } : {}),
  };
  for (const p of [r.helper, r.browsersPath, r.outDir, ...(r.playwrightBin ? [r.playwrightBin] : [])]) {
    if (!ABS.test(p) || p.split("/").includes("..")) throw new Error("screenshot paths must be absolute plain paths");
  }
  if (!Number.isInteger(r.port) || r.port < 1 || r.port > 65535) throw new Error("the screenshot port must be 1 to 65535");
  if (!/^\d{2,5}x\d{2,5}$/.test(r.viewport)) throw new Error("the screenshot viewport must be WxH");
  if (r.serve.length === 0 || r.seed.length === 0) throw new Error("serve and seed must be commands");
  return r;
}

/** What the runner lends this step. Everything runs as the agent user. */
export type ScreenshotIO = {
  log: (line: string) => void;
  /** Starts the local backend fresh (empty data). Its URL, or null without one. */
  freshBackend: () => Promise<string | null>;
  /**
   * Runs argv as the agent user in the checkout, with the agent's env minus
   * inference. No shell: argv is the runner's config plus values checked by
   * src/chef/screenshots.ts (a selector may hold spaces).
   */
  runAsAgent: (
    what: string,
    argv: string[],
    timeoutMs: number,
  ) => Promise<{ code: number | null; timedOut: boolean }>;
  /** Hands a path to the agent user. */
  own: (path: string) => Promise<void>;
  killAll: () => Promise<void>;
  /** POSTs one PNG to /chef-agent/screenshot. */
  upload: (query: Record<string, string>, bytes: Uint8Array, sha256: string) => Promise<{ status: number; body: any } | null>;
  sleep: (ms: number) => Promise<void>;
  now: () => number;
};

export type ScreenshotOutcome = {
  pages: number;
  taken: string[];
  uploaded: string[];
  skipped: string[];
  /** The demo script's rehearsal, when there was one. */
  rehearsal?: "passed" | "failed";
};

/** True once something answers HTTP on 127.0.0.1:port. Never through a proxy. */
function answers(port: number): Promise<boolean> {
  return new Promise((done) => {
    const req = http.get({ host: "127.0.0.1", port, path: "/", timeout: 1000 }, (res) => {
      res.resume();
      done(true);
    });
    req.on("timeout", () => {
      req.destroy();
      done(false);
    });
    req.on("error", () => done(false));
  });
}

/**
 * Up to `max` bytes of a file the agent user wrote: a regular file at
 * exactly this path, no symlink in it. Null when it isn't there. Returns
 * max + 1 bytes when the file is larger, so the caller can tell.
 */
export function readAgentBytes(path: string, max: number): Uint8Array | null {
  if (realpathSync(dirname(path)) !== dirname(path)) throw new Error("its directory is not a plain path");
  let fd: number;
  try {
    fd = openSync(path, fsConstants.O_RDONLY | fsConstants.O_NOFOLLOW | fsConstants.O_NONBLOCK);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw e;
  }
  try {
    if (!fstatSync(fd).isFile()) throw new Error("not a regular file");
    const buf = Buffer.alloc(max + 1);
    let n = 0;
    while (n < buf.length) {
      const r = readSync(fd, buf, n, buf.length - n, null);
      if (r === 0) break;
      n += r;
    }
    return new Uint8Array(buf.subarray(0, n));
  } finally {
    closeSync(fd);
  }
}

/**
 * The whole step. `planText` is the agent's plan file, already read with
 * the runner's checks (empty for none). Never throws.
 */
export async function finalScreenshots(
  io: ScreenshotIO,
  cfg: ResolvedScreenshotConfig,
  planText: string,
): Promise<ScreenshotOutcome> {
  const outcome: ScreenshotOutcome = { pages: 0, taken: [], uploaded: [], skipped: [] };
  const extra: ScreenshotPage[] = [];
  const log = (s: string) => io.log(`chef-runner: screenshots: ${s}`);
  const { plan, problems } = parseScreenshotPlan(planText, checkDemoSteps);
  for (const p of problems.slice(0, 10)) log(`plan: ${p}`);
  outcome.pages = plan.pages.length;
  try {
    await io.killAll();
    const url = await io.freshBackend();
    if (!url) {
      log("no local backend, so no app to screenshot");
      return outcome;
    }
    for (const argv of cfg.push) {
      const x = await io.runAsAgent("screenshots", argv, cfg.stepTimeoutMs);
      if (x.code !== 0) {
        log(`pushing the functions failed (${argv.join(" ")}${x.timedOut ? ", timed out" : ""}); no screenshots`);
        return outcome;
      }
    }
    if (plan.seed) {
      const x = await io.runAsAgent("screenshots", [...cfg.seed, plan.seed], cfg.stepTimeoutMs);
      if (x.code !== 0) log(`the seed function ${plan.seed} failed; screenshotting the app unseeded`);
      else log(`seeded with ${plan.seed}`);
    }
    for (const argv of cfg.build) {
      const x = await io.runAsAgent("screenshots", argv, cfg.stepTimeoutMs);
      if (x.code !== 0) {
        log(`the frontend build failed (${argv.join(" ")}${x.timedOut ? ", timed out" : ""}); no screenshots`);
        return outcome;
      }
    }

    // The server runs until killAll. Its promise settles when it exits.
    let serverExit: string | null = null;
    void io
      .runAsAgent("app", serveArgv(cfg), cfg.stepTimeoutMs + cfg.shotTimeoutMs * plan.pages.length)
      .then(
        (x) => (serverExit = `exited (${x.code}${x.timedOut ? ", timed out" : ""})`),
        (e: Error) => (serverExit = `didn't start: ${e.message}`),
      );
    const until = io.now() + cfg.serveTimeoutMs;
    for (;;) {
      if (await answers(cfg.port)) break;
      if (serverExit) {
        log(`the app server ${serverExit}; no screenshots`);
        return outcome;
      }
      if (io.now() > until) {
        log(`nothing answered on 127.0.0.1:${cfg.port} within ${Math.round(cfg.serveTimeoutMs / 1000)} s; no screenshots`);
        return outcome;
      }
      await io.sleep(250);
    }

    rmSync(cfg.outDir, { recursive: true, force: true });
    mkdirSync(cfg.outDir, { recursive: true, mode: 0o700 });
    await io.own(cfg.outDir);
    for (const page of plan.pages) {
      const x = await io.runAsAgent("screenshot", helperArgv(cfg, page), cfg.shotTimeoutMs + 20_000);
      if (x.code === 0) outcome.taken.push(page.name);
      else log(`${page.name} (${page.path}) failed${x.timedOut ? ": timed out" : ""}`);
    }
    if (cfg.demoScript) {
      // Its result line ("rehearsal: N of M steps ran; stopped at ...") is the helper's own output.
      const x = await io.runAsAgent("rehearsal", rehearseArgv(cfg, cfg.demoScript), DEMO_REHEARSAL_MS + 20_000);
      outcome.rehearsal = x.code === 0 ? "passed" : "failed";
      if (x.code !== 0 && !plan.pages.some((p) => p.name === DEMO_STOPPED)) {
        extra.push({ path: "/", name: DEMO_STOPPED });
        outcome.pages++;
        outcome.taken.push(DEMO_STOPPED);
      }
    }
  } catch (e) {
    log(`stopped: ${(e as Error).message}`);
  } finally {
    // The app, the backend and anything they left: gone before the files
    // are read, so nothing can swap them while they are.
    try {
      await io.killAll();
    } catch (e) {
      log(`couldn't kill the app: ${(e as Error).message}`);
    }
  }

  await uploadAll(io, cfg, [...plan.pages, ...extra], outcome, log);
  log(`${outcome.uploaded.length} of ${outcome.pages} uploaded`);
  return outcome;
}

/** The demo's whole run, with its own cap: the preview's recording is at most 45 s. */
export const DEMO_REHEARSAL_MS = 60_000;

/** The helper's argv for rehearsing `script` on the served app; the PNG is where it ended. */
export function rehearseArgv(cfg: ResolvedScreenshotConfig, script: string): string[] {
  return [
    cfg.nodeBin,
    cfg.helper,
    "/",
    "--port",
    String(cfg.port),
    "--out",
    join(cfg.outDir, `${DEMO_STOPPED}.png`),
    "--rehearse",
    script,
    "--timeout",
    String(Math.min(120_000, cfg.shotTimeoutMs)),
    "--browsers-path",
    cfg.browsersPath,
    ...(cfg.playwrightBin ? ["--playwright-bin", cfg.playwrightBin] : []),
    ...(cfg.loginFunction ? ["--signed-in", "--login-function", cfg.loginFunction] : []),
  ];
}

export function helperArgv(cfg: ResolvedScreenshotConfig, page: ScreenshotPage): string[] {
  return [
    cfg.nodeBin,
    cfg.helper,
    page.path,
    "--port",
    String(cfg.port),
    "--out",
    join(cfg.outDir, `${page.name}.png`),
    "--viewport",
    cfg.viewport,
    "--timeout",
    String(Math.min(120_000, cfg.shotTimeoutMs)),
    "--browsers-path",
    cfg.browsersPath,
    ...(cfg.playwrightBin ? ["--playwright-bin", cfg.playwrightBin] : []),
    ...(page.waitFor !== undefined ? ["--wait-for", page.waitFor] : []),
    ...(cfg.loginFunction && page.signedIn !== false ? ["--signed-in", "--login-function", cfg.loginFunction] : []),
    // Checked by parseScreenshotPlan, and again by the helper. One argv element, no shell.
    ...(page.steps ? ["--steps", JSON.stringify(page.steps)] : []),
  ];
}

async function uploadAll(
  io: ScreenshotIO,
  cfg: ResolvedScreenshotConfig,
  pages: ScreenshotPage[],
  outcome: ScreenshotOutcome,
  log: (s: string) => void,
) {
  if (outcome.taken.length === 0) return;
  let total = 0;
  for (const page of pages) {
    if (!outcome.taken.includes(page.name)) continue;
    const skip = (why: string) => {
      outcome.skipped.push(page.name);
      log(`${page.name}: ${why}`);
    };
    let bytes: Uint8Array | null;
    try {
      bytes = existsSync(cfg.outDir) ? readAgentBytes(join(cfg.outDir, `${page.name}.png`), SCREENSHOT_LIMITS.fileBytes) : null;
    } catch (e) {
      skip(`not read: ${(e as Error).message}`);
      continue;
    }
    if (!bytes) {
      skip("no file");
      continue;
    }
    if (bytes.length > SCREENSHOT_LIMITS.fileBytes) {
      skip(`over ${SCREENSHOT_LIMITS.fileBytes} bytes`);
      continue;
    }
    if (!pngInfo(bytes)) {
      skip("not a PNG");
      continue;
    }
    if (total + bytes.length > SCREENSHOT_LIMITS.totalBytes) {
      skip(`past the run's ${SCREENSHOT_LIMITS.totalBytes} bytes`);
      continue;
    }
    total += bytes.length;
    const sha256 = createHash("sha256").update(bytes).digest("hex");
    for (let attempt = 1; ; attempt++) {
      const res = await io.upload({ name: page.name, path: page.path }, bytes, sha256).catch(() => null);
      if (res && res.status === 200) {
        outcome.uploaded.push(page.name);
        break;
      }
      if (attempt >= 3 || (res && res.status >= 400 && res.status < 500)) {
        const why = res ? `${res.status} ${String(res.body?.error ?? "").slice(0, 200)}` : "no answer";
        skip(`not uploaded: ${why}`);
        break;
      }
      await io.sleep(1000);
    }
  }
}
