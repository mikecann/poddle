#!/usr/bin/env node
// Uploads a built frontend to a Convex deployment's static hosting: a
// PREVIEW (after runner/chef-preview-deploy.sh, "The preview" in
// docs/chef-pipeline.md), or the host's own live deployment, named
// explicitly (after runner/chef-ship-deploy.sh, "Ship it").
//
// Usage: chef-static-upload.mjs (--preview-name <name> | --deployment-name <name>) --dist <dir>
//          [--component <name>] [--module <name>] [--api auto|0.2|0.1] [--no-spa]
//
// Environment:
//   CONVEX_DEPLOY_KEY   with --preview-name: a preview deploy key, preview:<team>:<project>|<secret>;
//                       with --deployment-name: that deployment's own key,
//                       prod:<name>|<secret> or dev:<name>|<secret>, and nothing else (required)
//   CHEF_CONVEX_BIN     the pinned Convex CLI, an absolute path (default /opt/chef/bin/convex)
//
// Why this exists: `@convex-dev/static-hosting`'s own `upload` only targets
// dev or --prod. This does what its upload does, through `convex run
// --preview-name <name>`, with Node's built-ins and the pinned CLI only:
//
//   static-hosting 0.2 (component-owned storage; the app exposes nothing):
//     --component staticHosting lib:getUrls             (selfHosting is tried too)
//     --component staticHosting lib:generateUploadUrls  (batches of 100)
//     POST each file to its upload URL
//     --component staticHosting lib:stageAssets         (chunks under 20 KiB of JSON)
//     --component staticHosting lib:publishDeployment   (the atomic switch)
//     --component staticHosting lib:cleanupPendingStorage
//   static-hosting 0.1 (the app re-exports exposeUploadApi from convex/<module>.ts):
//     <module>:listAssets, <module>:generateUploadUrls, POST, <module>:recordAssets,
//     <module>:gcOldAssets
//
// Files are hashed (sha256) and identical files with the same content type
// are uploaded once and share a storage id.
//
// The deploy key reaches the CLI only through its environment: never an
// argument, never printed (everything the CLI says is scrubbed of the key and
// its secret part). The CLI runs in an empty directory of our own, so the
// checkout's .env.local, convex.json and node_modules can't redirect it.

import { execFile } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { lstatSync, mkdtempSync, readFileSync, readdirSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { extname, isAbsolute, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".webp": "image/webp",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".txt": "text/plain; charset=utf-8",
  ".map": "application/json",
  ".webmanifest": "application/manifest+json",
  ".xml": "application/xml",
};

// The same limits as static-hosting 0.2's own upload.
const MAX_FILES = 1800;
const MAX_ARGUMENT_BYTES = 20 * 1024;
const UPLOAD_URL_BATCH = 100;
const CONCURRENCY = 5;
const MAINTENANCE_PAGES = 20;
const MAINTENANCE_PAGE_SIZE = 256;

const PREVIEW_KEY = /^preview:[^:|]+:[^:|]+\|.+$/;
const DEPLOYMENT_KEY = /^(prod|dev):([a-z0-9][a-z0-9-]{0,63})\|.+$/;
const DEPLOYMENT_NAME = /^[a-z0-9][a-z0-9-]{0,63}$/;
const PREVIEW_NAME = /^[a-z0-9][a-z0-9-]{0,62}$/;
const NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;
const MODULE = /^[A-Za-z_][A-Za-z0-9_]*(\/[A-Za-z_][A-Za-z0-9_]*)*$/;

// Variables that would point the CLI at some other deployment or host.
const REDIRECTS = [
  "CONVEX_DEPLOYMENT",
  "CONVEX_URL",
  "CONVEX_SITE_URL",
  "CONVEX_PROVISION_HOST",
  "CONVEX_SELF_HOSTED_URL",
  "CONVEX_SELF_HOSTED_ADMIN_KEY",
  "CONVEX_OVERRIDE_ACCESS_TOKEN",
];

class Refusal extends Error {}

function say(msg) {
  process.stdout.write(`chef-static-upload: ${msg}\n`);
}

export function mimeType(path) {
  return MIME_TYPES[extname(path).toLowerCase()] ?? "application/octet-stream";
}

export function parseArgs(argv) {
  const out = { previewName: null, deploymentName: null, dist: null, component: null, module: "staticHosting", api: "auto", spa: true };
  const value = (i, flag) => {
    const v = argv[i + 1];
    if (v === undefined || v.startsWith("--")) throw new Refusal(`${flag} needs a value`);
    return v;
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    switch (a) {
      case "--preview-name":
        out.previewName = value(i++, a);
        break;
      case "--deployment-name":
        out.deploymentName = value(i++, a);
        break;
      case "--dist":
        out.dist = value(i++, a);
        break;
      case "--component":
        out.component = value(i++, a);
        break;
      case "--module":
        out.module = value(i++, a);
        break;
      case "--api":
        out.api = value(i++, a);
        break;
      case "--no-spa":
        out.spa = false;
        break;
      case "--spa":
        out.spa = true;
        break;
      default:
        // Includes --prod, --deployment, --url and --admin-key: this only
        // ever targets a preview, or one deployment named explicitly.
        throw new Refusal(
          `unknown argument ${JSON.stringify(a)}; this uploader only targets a preview (--preview-name) or one named deployment (--deployment-name)`,
        );
    }
  }
  if (out.previewName && out.deploymentName) throw new Refusal("give --preview-name or --deployment-name, not both");
  if (!out.previewName && !out.deploymentName) {
    throw new Refusal("--preview-name or --deployment-name is required; this uploader targets nothing by default");
  }
  if (out.previewName && !PREVIEW_NAME.test(out.previewName)) throw new Refusal("--preview-name is not a preview name");
  if (out.deploymentName && !DEPLOYMENT_NAME.test(out.deploymentName)) {
    throw new Refusal("--deployment-name is not a deployment name");
  }
  if (!out.dist) throw new Refusal("--dist is required");
  if (out.component !== null && !NAME.test(out.component)) throw new Refusal("--component is not a component name");
  if (!MODULE.test(out.module)) throw new Refusal("--module is not a module name");
  if (!["auto", "0.2", "0.1"].includes(out.api)) throw new Refusal("--api must be auto, 0.2 or 0.1");
  return out;
}

/** Splits items so each call's JSON argument stays under the CLI-safe size. */
export function chunkByBytes(items, makeArgs, maxBytes = MAX_ARGUMENT_BYTES) {
  const chunks = [];
  let current = [];
  for (const item of items) {
    const candidate = [...current, item];
    if (Buffer.byteLength(JSON.stringify(makeArgs(candidate))) <= maxBytes) {
      current = candidate;
      continue;
    }
    if (current.length === 0 || Buffer.byteLength(JSON.stringify(makeArgs([item]))) > maxBytes) {
      throw new Error("one upload record is larger than the CLI argument limit; shorten the asset path");
    }
    chunks.push(current);
    current = [item];
  }
  if (current.length > 0) chunks.push(current);
  return chunks;
}

/** Every regular file under dist. Symlinks and other special files are refused, not followed. */
export function collectFiles(distDir) {
  const files = [];
  const walk = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const full = join(dir, entry.name);
      const rel = relative(distDir, full).split("\\").join("/");
      if (entry.isSymbolicLink()) throw new Refusal(`${rel} is a symlink; refusing to follow it`);
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile()) {
        const bytes = readFileSync(full);
        files.push({
          path: "/" + rel,
          localPath: full,
          contentType: mimeType(full),
          size: bytes.length,
          sha256: createHash("sha256").update(bytes).digest("hex"),
        });
      } else throw new Refusal(`${rel} is not a regular file`);
    }
  };
  walk(distDir);
  files.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  return files;
}

/** Groups files by (sha256, content type): one upload per group. */
export function dedupe(files) {
  const blobs = new Map();
  for (const f of files) {
    const key = `${f.sha256}\0${f.contentType}`;
    let blob = blobs.get(key);
    if (!blob) {
      blob = { key, localPath: f.localPath, contentType: f.contentType, sha256: f.sha256, paths: [] };
      blobs.set(key, blob);
    }
    blob.paths.push(f.path);
  }
  return [...blobs.values()];
}

async function forEachLimit(items, limit, worker) {
  let next = 0;
  let failed;
  const run = async () => {
    while (failed === undefined && next < items.length) {
      const i = next++;
      try {
        await worker(items[i], i);
      } catch (e) {
        failed ??= e;
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
  if (failed !== undefined) throw failed;
}

function makeScrubber(secrets) {
  const live = secrets.filter((s) => s && s.length >= 4).sort((a, b) => b.length - a.length);
  return (text) => {
    let out = String(text);
    for (const s of live) out = out.split(s).join("[redacted]");
    return out;
  };
}

function makeConvex({ bin, key, previewName, cwd, scrub }) {
  const env = { ...process.env };
  for (const name of REDIRECTS) delete env[name];
  env.CONVEX_DEPLOY_KEY = key;
  return (functionPath, args, { component, quiet } = {}) => {
    const json = JSON.stringify(args);
    if (Buffer.byteLength(json) > MAX_ARGUMENT_BYTES) {
      return Promise.reject(new Error(`internal: the argument to ${functionPath} is too large`));
    }
    const argv = [
      "run",
      ...(component ? ["--component", component] : []),
      functionPath,
      json,
      "--typecheck=disable",
      "--codegen=disable",
      // A preview by name; otherwise the deployment the key is for, which
      // main() checked is exactly the one named.
      ...(previewName ? ["--preview-name", previewName] : []),
    ];
    return new Promise((resolvePromise, reject) => {
      execFile(bin, argv, { cwd, env, encoding: "utf8", maxBuffer: 16 * 1024 * 1024 }, (error, stdout, stderr) => {
        if (error) {
          const detail = scrub(`${stderr || ""}${stdout || ""}`.trim()).split("\n").slice(-20).join("\n");
          if (!quiet) process.stderr.write(`chef-static-upload: convex run ${functionPath} failed:\n${detail}\n`);
          reject(new Error(`convex run ${functionPath} failed`));
          return;
        }
        const text = stdout.trim();
        try {
          resolvePromise(text === "" ? null : JSON.parse(text));
        } catch {
          reject(new Error(`convex run ${functionPath} printed something that isn't JSON`));
        }
      });
    });
  };
}

function checkUploadUrl(url, origin) {
  let u;
  try {
    u = new URL(url);
  } catch {
    throw new Error("the deployment returned an upload URL that isn't a URL");
  }
  if (u.protocol !== "https:" && u.protocol !== "http:") throw new Error("upload URL is not http(s)");
  if (origin !== null && u.origin !== origin) {
    throw new Error(`upload URL is on ${u.origin}, not the deployment's ${origin}`);
  }
}

async function uploadBlobs(blobs, urls, origin, uploaded = []) {
  const storageIds = new Array(blobs.length);
  let done = 0;
  await forEachLimit(blobs, CONCURRENCY, async (blob, i) => {
    checkUploadUrl(urls[i], origin);
    const res = await fetch(urls[i], {
      method: "POST",
      headers: { "Content-Type": blob.contentType },
      body: readFileSync(blob.localPath),
    });
    if (!res.ok) throw new Error(`storage upload failed for ${blob.paths[0]}: ${res.status}`);
    const body = await res.json().catch(() => ({}));
    if (typeof body.storageId !== "string") throw new Error(`storage upload returned no storageId for ${blob.paths[0]}`);
    storageIds[i] = body.storageId;
    uploaded.push(body.storageId);
    done++;
    say(`[${done}/${blobs.length}] ${blob.paths.join(", ")} ${blob.contentType} sha256:${blob.sha256.slice(0, 12)}`);
  });
  return storageIds;
}

async function uploadUrls(convex, fn, count, component) {
  const urls = [];
  for (let offset = 0; offset < count; offset += UPLOAD_URL_BATCH) {
    const n = Math.min(UPLOAD_URL_BATCH, count - offset);
    const batch = await convex(fn, { count: n }, { component });
    if (!Array.isArray(batch) || batch.length !== n || !batch.every((u) => typeof u === "string")) {
      throw new Error("the deployment returned invalid upload URLs");
    }
    urls.push(...batch);
  }
  return urls;
}

function manifest(blobs, storageIds, deploymentId) {
  const assets = [];
  blobs.forEach((blob, i) => {
    for (const path of blob.paths) {
      assets.push({ path, storageId: storageIds[i], contentType: blob.contentType, deploymentId });
    }
  });
  assets.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  return assets;
}

async function detect(convex, opts) {
  if (opts.api !== "0.1") {
    const names = opts.component ? [opts.component] : ["staticHosting", "selfHosting"];
    for (const name of names) {
      try {
        const urls = await convex("lib:getUrls", {}, { component: name, quiet: true });
        if (urls && typeof urls.cloudUrl === "string" && typeof urls.siteUrl === "string") {
          return { api: "0.2", component: name, urls };
        }
      } catch {
        // Not this name, or not 0.2.
      }
    }
    if (opts.api === "0.2") throw new Error(`no static-hosting 0.2 component (${names.join(" or ")}) answered on the preview`);
  }
  try {
    const rows = await convex(`${opts.module}:listAssets`, { limit: 1 }, { quiet: true });
    if (Array.isArray(rows)) return { api: "0.1", module: opts.module };
  } catch {
    // Fall through.
  }
  throw new Error(
    "found no static hosting on the preview: no 0.2 component (lib:getUrls) and no 0.1 " +
      `${opts.module}:listAssets; is the app deployed, and is --component or --module right?`,
  );
}

async function publish02(convex, component, blobs, deploymentId, spa, origin) {
  const c = { component };
  const uploaded = [];
  let publishAttempted = false;
  try {
    say(`getting ${blobs.length} upload URLs`);
    const urls = await uploadUrls(convex, "lib:generateUploadUrls", blobs.length, component);
    const storageIds = await uploadBlobs(blobs, urls, origin, uploaded);
    const assets = manifest(blobs, storageIds, deploymentId);
    const chunks = chunkByBytes(assets, (a) => ({ assets: a }));
    for (let i = 0; i < chunks.length; i++) {
      say(`staging manifest chunk ${i + 1}/${chunks.length}`);
      await convex("lib:stageAssets", { assets: chunks[i] }, c);
    }
    say("publishing");
    publishAttempted = true;
    const result = await convex(
      "lib:publishDeployment",
      { currentDeploymentId: deploymentId, expectedAssetCount: assets.length, spaFallback: spa },
      c,
    );
    if (!result || typeof result.deleted !== "number") throw new Error("the deployment returned an invalid publish result");
    return assets;
  } catch (error) {
    if (publishAttempted) {
      // The publish may have committed even though its response was lost.
      try {
        const current = await convex("lib:getCurrentDeployment", {}, { ...c, quiet: true });
        if (current && current.currentDeploymentId === deploymentId) {
          say("the publish committed although its response was lost; the new files are live");
          return null;
        }
      } catch {
        // Can't tell; clean up conservatively below.
      }
    }
    let discarded = false;
    try {
      await convex("lib:discardStagedDeployment", { deploymentId }, c);
      discarded = true;
    } catch {
      say("could not discard the staged manifest");
    }
    // deleteUploadedFiles keeps anything the live manifest references, so
    // this is safe even if a lost publish won the race.
    if (uploaded.length > 0 && (!publishAttempted || discarded)) {
      try {
        for (const ids of chunkByBytes(uploaded, (s) => ({ storageIds: s }))) {
          await convex("lib:deleteUploadedFiles", { storageIds: ids }, c);
        }
      } catch {
        say("could not remove the files from the failed upload");
      }
    }
    throw error;
  }
}

async function cleanupOldStorage02(convex, component) {
  try {
    for (let page = 0; page < MAINTENANCE_PAGES; page++) {
      const r = await convex("lib:cleanupPendingStorage", { limit: MAINTENANCE_PAGE_SIZE }, { component });
      if (!r || r.needsAnotherPass !== true) return;
    }
  } catch {
    say("the new files are live, but old storage could not be fully removed");
  }
}

async function publish01(convex, mod, blobs, deploymentId) {
  say(`getting ${blobs.length} upload URLs`);
  const urls = await uploadUrls(convex, `${mod}:generateUploadUrls`, blobs.length, undefined);
  const storageIds = await uploadBlobs(blobs, urls, null);
  const assets = manifest(blobs, storageIds, deploymentId);
  const chunks = chunkByBytes(assets, (a) => ({ assets: a }));
  for (let i = 0; i < chunks.length; i++) {
    say(`recording assets ${i + 1}/${chunks.length}`);
    await convex(`${mod}:recordAssets`, { assets: chunks[i] });
  }
  say("removing the previous deployment's files");
  await convex(`${mod}:gcOldAssets`, { currentDeploymentId: deploymentId });
  return assets;
}

export async function main(argv, env) {
  const opts = parseArgs(argv);

  const key = env.CONVEX_DEPLOY_KEY ?? "";
  if (opts.previewName) {
    if (!PREVIEW_KEY.test(key)) {
      throw new Refusal("CONVEX_DEPLOY_KEY must be a preview deploy key (preview:<team>:<project>|...)");
    }
  } else {
    const m = DEPLOYMENT_KEY.exec(key);
    if (!m || m[2] !== opts.deploymentName) {
      throw new Refusal(
        `CONVEX_DEPLOY_KEY must be the deploy key of ${opts.deploymentName} (prod:${opts.deploymentName}|... or dev:${opts.deploymentName}|...)`,
      );
    }
  }
  const target = opts.previewName ? `preview ${opts.previewName}` : `deployment ${opts.deploymentName}`;
  const secret = key.slice(key.indexOf("|") + 1);
  const scrub = makeScrubber([key, secret]);

  const bin = env.CHEF_CONVEX_BIN || "/opt/chef/bin/convex";
  if (!isAbsolute(bin)) throw new Refusal("CHEF_CONVEX_BIN must be an absolute path");

  let distDir;
  try {
    distDir = realpathSync(resolve(opts.dist));
  } catch {
    throw new Refusal(`dist directory not found: ${opts.dist}`);
  }
  if (!lstatSync(distDir).isDirectory()) throw new Refusal(`${opts.dist} is not a directory`);
  const files = collectFiles(distDir);
  if (files.length === 0) throw new Refusal("the dist directory is empty");
  if (!files.some((f) => f.path === "/index.html")) throw new Refusal("the dist directory has no index.html");
  if (files.length > MAX_FILES) throw new Refusal(`the dist directory has ${files.length} files; at most ${MAX_FILES}`);
  const blobs = dedupe(files);

  // An empty project directory for the CLI: `convex run` wants a package.json
  // that depends on convex, and nothing else of the checkout's.
  const cwd = mkdtempSync(join(tmpdir(), "chef-static-upload-"));
  writeFileSync(join(cwd, "package.json"), '{"private":true,"dependencies":{"convex":"*"}}\n');
  try {
    const convex = makeConvex({ bin, key, previewName: opts.previewName, cwd, scrub });
    const found = await detect(convex, opts);
    const deploymentId = randomUUID();
    say(
      `uploading ${files.length} files (${blobs.length} distinct) to ${target}, ` +
        (found.api === "0.2"
          ? `static-hosting 0.2, component ${found.component}`
          : `static-hosting 0.1, module ${found.module}`),
    );
    if (found.api === "0.2") {
      const origin = new URL(found.urls.cloudUrl).origin;
      await publish02(convex, found.component, blobs, deploymentId, opts.spa, origin);
      await cleanupOldStorage02(convex, found.component);
    } else {
      await publish01(convex, found.module, blobs, deploymentId);
    }
    const result = {
      ...(opts.previewName ? { previewName: opts.previewName } : { deploymentName: opts.deploymentName }),
      api: found.api,
      ...(found.api === "0.2" ? { component: found.component, siteUrl: found.urls.siteUrl } : { module: found.module }),
      deploymentId,
      files: files.length,
      uploads: blobs.length,
    };
    process.stdout.write(`chef-static-upload-result ${scrub(JSON.stringify(result))}\n`);
    return 0;
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
}

const invoked = process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url));
if (invoked) {
  main(process.argv.slice(2), process.env).then(
    (code) => {
      process.exitCode = code;
    },
    (e) => {
      const key = process.env.CONVEX_DEPLOY_KEY ?? "";
      const scrub = makeScrubber([key, key.includes("|") ? key.slice(key.indexOf("|") + 1) : ""]);
      process.stderr.write(`chef-static-upload: ${scrub(e instanceof Error ? e.message : String(e))}\n`);
      process.exitCode = e instanceof Refusal ? 2 : 1;
    },
  );
}
