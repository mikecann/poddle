// Types for runner/chef-install-plan.mjs.
export type InstallPlan =
  | { manager: "npm"; lockfile: string; argv: string[] }
  | { manager: "pnpm"; lockfile: string; version: string; argv: string[] };
export type InstallRefusal = { error: string; lockfile: string | null; help: string[] };
/** A checkout's root files: whether one exists, and its text (null if missing, unreadable or over maxBytes). */
export type PlanFiles = { exists(name: string): boolean; read(name: string, maxBytes: number): string | null };
export type WarmInputs = {
  format: number;
  manager: "npm" | "pnpm";
  version?: string;
  argv: string[];
  lockfile: { name: string; sha256: string };
  packageJson: string;
  tarballs: { path: string; sha256: string }[];
};
export type WarmMarker = {
  format: number;
  key: string;
  name: string;
  base: string;
  inputsHash: string;
  manager: "npm" | "pnpm";
  version?: string;
  lockfile: { name: string; sha256: string };
  argv: string[];
};
export const PNPM_FOR_LOCKFILE: Readonly<Record<number, string>>;
export const NPM_INSTALL: readonly string[];
export const MAX_LOCKFILE_BYTES: number;
export const MAX_PACKAGE_JSON_BYTES: number;
export const PLAN_FILES: readonly string[];
export function pnpmInstallArgv(version: string): string[];
export function packageManagerOf(pkgText: string | null): { name: string; version: string | null } | null;
export function pnpmLockfileMajor(text: string): number | null;
export function installPlanFrom(files: PlanFiles): InstallPlan | InstallRefusal;
export function describePlan(plan: InstallPlan | InstallRefusal): string;
export function lockfileCheckArgv(plan: InstallPlan | InstallRefusal): string[];
export function lockfileFix(plan: InstallPlan | InstallRefusal): string[];
export const WARM_FORMAT: number;
export const WARM_ROOT: string;
export const WARM_MARKER: string;
export const MAX_WARM_TARBALLS: number;
export const MAX_WARM_TARBALL_BYTES: number;
export const WARM_PACKAGE_FIELDS: readonly string[];
export function canonicalJson(value: unknown): string;
export function sha256Hex(data: string | Uint8Array): Promise<string>;
export function warmPackageJson(pkgText: string | null): Record<string, unknown> | null;
export function lockfileTarballs(lockText: string, manager: "npm" | "pnpm"): { paths: string[]; unsupported?: undefined } | { unsupported: string; paths?: undefined };
export function warmUnsupported(files: PlanFiles, plan: InstallPlan | InstallRefusal): string | null;
export function warmInputs(
  files: PlanFiles,
  tarballSha256: (path: string) => Promise<string | null>,
): Promise<{ plan: InstallPlan; inputs: WarmInputs; inputsHash: string; unsupported?: undefined } | { unsupported: string }>;
export function warmKey(args: { base: string; inputsHash: string }): Promise<string>;
export function warmSnapshotName(key: string): string;
export function warmDirFor(root: string, inputsHash: string): string;
export function warmCaches(dir: string): { npmCache: string; pnpmStore: string };
export function warmInstallArgv(plan: InstallPlan, dirs: { npmCache: string; pnpmStore?: string }, opts: { offline: boolean }): string[];
export function checkWarmMarker(
  text: string | null | undefined,
  want: { inputsHash: string; plan: InstallPlan },
): { ok: true; marker: WarmMarker } | { ok: false; reason: string };
export function warmMarker(args: { key: string; base: string; inputsHash: string; inputs: WarmInputs }): WarmMarker;
