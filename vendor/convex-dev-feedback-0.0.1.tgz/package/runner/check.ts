// `chef-check`: the agent's own run of what the runner verifies after it
// (docs/chef-pipeline.md, "Iterating inside the session"). The agent runs
// it as itself, in its checkout, as often as it likes, and fixes what it
// reports before it finishes. Advisory only: the runner never reads its
// result, and verifies everything again, fresh, after the agent is dead.
//
// It runs, from `check.json` (written by the runner into the chef dir,
// read-only to the agent):
//   1. the gates, each noted with how it did on the base (a gate failing
//      there too doesn't block);
//   2. the frontend build with the URL placeholder, and that the build uses it;
//   3. the guards in dry run over the working tree: what changed against
//      the base's file list (git blob hashes, no git needed), package.json
//      scripts and dependencies, lockfiles, protected paths, conflict
//      markers, and the secret scan over the changed files.
// It prints each step's result with the end of its output, scrubbed, and
// exits 0 only if everything the runner would refuse passes.
//
// No credentials, no network: it only runs the app's own commands, as the
// agent already can.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, lstatSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import {
  CONFLICT_MARKER_GREP,
  checkGuards,
  type ChangedFile,
  type Violation,
} from "../src/chef/guards.ts";
import { scrub } from "../src/chef/scrub.ts";
import { CONVEX_URL_PLACEHOLDER } from "../src/chef/frontend.ts";
import { tailOutput } from "../src/chef/gates.ts";
import { collectDist } from "./frontend-artifact.ts";

/** What the runner writes for chef-check. */
export type CheckConfig = {
  /** The gates' argv, as the runner runs them. */
  gates: string[][];
  /** Each gate's outcome on the base, by command; absent when there was no baseline. */
  baseline?: Record<string, "pass" | "fail">;
  frontend: { command: string[]; urlEnvVar: string; distDir: string } | null;
  /** The base's tracked files: path -> [mode, blob sha1]. */
  base: Record<string, [string, string]>;
  /** The base's package.json files' text, by path. */
  packageJson: Record<string, string>;
  /** Commands time out after this many ms. Default 10 minutes. */
  timeoutMs?: number;
};

export type CheckStep = { name: string; ok: boolean; blocking: boolean; detail: string; output?: string };

export type CheckDeps = {
  run: (argv: string[], env: Record<string, string | undefined>) => Promise<{ code: number | null; output: string; timedOut: boolean }>;
  cwd: string;
  env: Record<string, string | undefined>;
};

// Never walked for new files: dependencies, VCS data and build outputs.
const SKIP_DIRS = new Set(["node_modules", ".git", "dist", "build", ".next", ".turbo", "coverage", "out", ".convex", ".cache", ".vercel"]);
const MAX_FILE = 2 * 1024 * 1024;

function blobSha(bytes: Buffer): string {
  return createHash("sha1").update(`blob ${bytes.length}\0`).update(bytes).digest("hex");
}

/** The root .gitignore's simple patterns: names, dir/ names and *.ext. Good enough for advice. */
function ignoreMatcher(root: string): (rel: string, name: string, isDir: boolean) => boolean {
  let lines: string[] = [];
  try {
    lines = readFileSync(join(root, ".gitignore"), "utf8").split("\n");
  } catch {
    // none
  }
  const names = new Set<string>();
  const dirs = new Set<string>();
  const exts: string[] = [];
  for (const raw of lines) {
    const l = raw.trim();
    if (!l || l.startsWith("#") || l.startsWith("!")) continue;
    const p = l.replace(/^\//, "");
    if (/^\*\.[A-Za-z0-9._-]+$/.test(p)) exts.push(p.slice(1));
    else if (/^[^*?[\]]+\/$/.test(p)) dirs.add(p.slice(0, -1));
    else if (/^[^*?[\]/]+$/.test(p)) names.add(p);
  }
  return (rel, name, isDir) =>
    names.has(name) || names.has(rel) || (isDir && (dirs.has(name) || dirs.has(rel))) || exts.some((e) => name.endsWith(e));
}

/** What changed in `root` against the base's file list. */
export function changedFiles(root: string, base: CheckConfig["base"]): { files: ChangedFile[]; read: (p: string) => string | null } {
  const ignored = ignoreMatcher(root);
  const trackedDirs = new Set<string>();
  for (const k of Object.keys(base)) {
    const parts = k.split("/");
    for (let i = 1; i < parts.length; i++) trackedDirs.add(parts.slice(0, i).join("/"));
  }
  const seen = new Set<string>();
  const files: ChangedFile[] = [];
  const walk = (dir: string, rel: string) => {
    let entries: string[];
    try {
      entries = readdirSync(dir);
    } catch {
      return;
    }
    for (const name of entries.sort()) {
      const r = rel ? `${rel}/${name}` : name;
      const p = join(dir, name);
      const st = lstatSync(p);
      const tracked = Object.prototype.hasOwnProperty.call(base, r);
      if (st.isDirectory()) {
        if (SKIP_DIRS.has(name) || (!trackedDirs.has(r) && ignored(r, name, true))) continue;
        walk(p, r);
        continue;
      }
      if (!tracked && ignored(r, name, false)) continue;
      seen.add(r);
      const mode = st.isSymbolicLink() ? "120000" : st.mode & 0o111 ? "100755" : "100644";
      if (st.isSymbolicLink() || !st.isFile()) {
        files.push({ status: tracked ? "M" : "A", path: r, newMode: mode, ...(tracked ? { oldMode: base[r][0] } : {}) });
        continue;
      }
      if (st.size > MAX_FILE * 8) {
        files.push({ status: tracked ? "M" : "A", path: r, newMode: mode });
        continue;
      }
      const sha = blobSha(readFileSync(p));
      if (!tracked) files.push({ status: "A", path: r, newMode: mode });
      else if (base[r][1] !== sha || base[r][0] !== mode) files.push({ status: "M", path: r, oldMode: base[r][0], newMode: mode });
    }
  };
  walk(root, "");
  for (const [path, [mode]] of Object.entries(base)) {
    if (!seen.has(path) && !existsSync(join(root, path))) files.push({ status: "D", path, oldMode: mode });
  }
  const read = (p: string) => {
    try {
      const st = lstatSync(join(root, p));
      if (!st.isFile() || st.size > MAX_FILE) return null;
      const b = readFileSync(join(root, p));
      return b.includes(0) ? null : b.toString("utf8");
    } catch {
      return null;
    }
  };
  return { files, read };
}

/** The guards in dry run over the working tree. */
export function guardsDryRun(root: string, cfg: Pick<CheckConfig, "base" | "packageJson">): { violations: Violation[]; changed: number } {
  const { files, read } = changedFiles(root, cfg.base);
  const contents: Record<string, { before?: string; after?: string }> = {};
  for (const f of files) {
    if (!/(^|\/)package\.json$/i.test(f.path)) continue;
    const before = cfg.packageJson[f.path];
    const after = f.status === "D" ? null : read(f.path);
    contents[f.path] = { ...(before !== undefined ? { before } : {}), ...(after !== null ? { after } : {}) };
  }
  // A diff of the changed files as all-added lines: the secret scan and the size limit see them.
  const diff: string[] = [];
  const conflictScan: Record<string, { line: number; text: string }[]> = {};
  const marker = new RegExp(CONFLICT_MARKER_GREP);
  for (const f of files) {
    if (f.status === "D") continue;
    const text = read(f.path);
    if (text === null) continue;
    diff.push(`diff --git a/${f.path} b/${f.path}`, `+++ b/${f.path}`);
    text.split("\n").forEach((line, i) => {
      diff.push(`+${line}`);
      if (marker.test(line)) (conflictScan[f.path] ??= []).push({ line: i + 1, text: line });
    });
  }
  const r = checkGuards({ files, contents, diffText: diff.join("\n"), conflictScan });
  return { violations: r.violations, changed: files.length };
}

/** Every step, in the runner's order. */
export async function runCheck(cfg: CheckConfig, deps: CheckDeps): Promise<CheckStep[]> {
  const steps: CheckStep[] = [];
  const hideKey = (t: string) => {
    let x = scrub(t);
    const k = deps.env.CONVEX_SELF_HOSTED_ADMIN_KEY;
    if (k && k.length >= 8) x = x.split(k).join("[redacted]");
    return x;
  };
  for (const argv of cfg.gates) {
    const command = argv.join(" ");
    const r = await deps.run(argv, deps.env);
    const ok = r.code === 0;
    const before = cfg.baseline?.[command];
    const blocking = !ok && before !== "fail";
    steps.push({
      name: `gate ${command}`,
      ok,
      blocking,
      detail: ok ? "passes" : before === "fail" ? "fails, as it did before this build (doesn't block)" : `fails${r.timedOut ? " (timed out)" : ""}`,
      ...(ok ? {} : { output: hideKey(tailOutput(r.output, 4000)) }),
    });
  }
  if (cfg.frontend) {
    const fe = cfg.frontend;
    const r = await deps.run(fe.command, { ...deps.env, [fe.urlEnvVar]: CONVEX_URL_PLACEHOLDER });
    let ok = r.code === 0;
    let detail = ok ? "builds" : `the build fails${r.timedOut ? " (timed out)" : ""}`;
    if (ok) {
      try {
        const files = collectDist(deps.cwd, fe.distDir);
        if (!files.some((f) => Buffer.from(f.bytes).includes(Buffer.from(CONVEX_URL_PLACEHOLDER)))) {
          ok = false;
          detail = `the build never uses ${fe.urlEnvVar}`;
        }
      } catch (e) {
        ok = false;
        detail = hideKey((e as Error).message);
      }
    }
    steps.push({ name: `frontend ${fe.command.join(" ")}`, ok, blocking: !ok, detail, ...(ok || r.code === 0 ? {} : { output: hideKey(tailOutput(r.output, 4000)) }) });
  }
  const g = guardsDryRun(deps.cwd, cfg);
  steps.push({
    name: "guards",
    ok: g.violations.length === 0 && g.changed > 0,
    blocking: g.violations.length > 0 || g.changed === 0,
    detail:
      g.changed === 0
        ? "nothing changed yet"
        : g.violations.length === 0
          ? `${g.changed} file${g.changed === 1 ? "" : "s"} changed; nothing the runner would refuse`
          : g.violations.map((v) => `${v.kind}${v.path ? ` ${v.path}` : ""}: ${v.detail}`).join("; "),
  });
  return steps;
}

/** The report the agent reads. */
export function renderCheck(steps: CheckStep[]): string {
  const lines: string[] = [];
  for (const s of steps) {
    lines.push(`${s.ok ? "ok  " : s.blocking ? "FAIL" : "warn"}  ${s.name}: ${s.detail}`);
    if (s.output) lines.push(...s.output.trimEnd().split("\n").map((l) => `      ${l}`));
  }
  const failing = steps.filter((s) => s.blocking).length;
  lines.push(
    failing === 0
      ? "chef-check: everything the runner checks passes. It checks again after you finish; only that counts."
      : `chef-check: ${failing} step${failing === 1 ? "" : "s"} would fail the build. Fix ${failing === 1 ? "it" : "them"} and run chef-check again.`,
  );
  return lines.join("\n") + "\n";
}

/** Runs one command in the checkout, its output kept (the end of it), bounded in time. */
function spawnRun(cwd: string, timeoutMs: number): CheckDeps["run"] {
  return (argv, env) =>
    new Promise((resolve) => {
      const child = spawn(argv[0], argv.slice(1), { cwd, env: env as NodeJS.ProcessEnv, stdio: ["ignore", "pipe", "pipe"] });
      let output = "";
      let timedOut = false;
      const add = (d: Buffer) => (output = (output + d.toString("utf8")).slice(-64 * 1024));
      child.stdout.on("data", add);
      child.stderr.on("data", add);
      const timer = setTimeout(() => {
        timedOut = true;
        child.kill("SIGKILL");
      }, timeoutMs);
      child.on("error", (e) => {
        clearTimeout(timer);
        resolve({ code: 127, output: output + String(e.message), timedOut });
      });
      child.on("close", (code) => {
        clearTimeout(timer);
        resolve({ code, output, timedOut });
      });
    });
}

/** `chef-check [--config <path>]`. */
export async function checkMain(argv: string[], env: Record<string, string | undefined>, cwd: string, out: (s: string) => void): Promise<number> {
  const i = argv.indexOf("--config");
  const path = i >= 0 ? argv[i + 1] : "/home/chefagent/chef/check.json";
  let cfg: CheckConfig;
  try {
    cfg = JSON.parse(readFileSync(path!, "utf8")) as CheckConfig;
  } catch (e) {
    out(`chef-check: can't read ${path}: ${(e as Error).message}\n`);
    return 2;
  }
  const steps = await runCheck(cfg, { run: spawnRun(cwd, cfg.timeoutMs ?? 10 * 60_000), cwd, env });
  out(renderCheck(steps));
  return steps.some((s) => s.blocking) ? 1 : 0;
}
