// When `npm ci` fails in the install step, what npm's own debug log says
// went wrong, as one line for the run's log. npm can hide the cause: with
// every registry fetch failing (no proxy CA, so UNABLE_TO_VERIFY_LEAF_SIGNATURE)
// npm 10.9 retries for 70 seconds and then prints only "Exit handler never
// called!" (wishbox build #8). The debug log has the error codes.
//
// Only error codes and counts leave the log, never a URL or a line of it.
//
// pnpm (runner/chef-install.mjs runs it through `npm exec`) writes no debug
// log; it prints its error codes (ERR_PNPM_OUTDATED_LOCKFILE, ...) in its
// output, and collectPnpmErrorCodes keeps just those. npm's log still says
// why fetching pnpm itself failed.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

const CODE = /^[A-Z][A-Z0-9_]{2,63}$/;

/** "fetches failed with X (n), Y (m); npm error code Z", or null if the log names no cause. */
export function npmLogSummary(log: string): string | null {
  const fetches = new Map<string, number>();
  const codes = new Set<string>();
  for (const line of log.split("\n")) {
    const f = / attempt \d+ failed with (\S+)$/.exec(line);
    if (f && CODE.test(f[1])) fetches.set(f[1], (fetches.get(f[1]) ?? 0) + 1);
    const c = /^\d+ error (?:code|errno) (\S+)$/.exec(line);
    if (c && CODE.test(c[1])) codes.add(c[1]);
  }
  const parts: string[] = [];
  if (fetches.size) {
    const list = [...fetches].sort((a, b) => b[1] - a[1]).slice(0, 5);
    parts.push(`fetches failed with ${list.map(([k, n]) => `${k} (${n})`).join(", ")}`);
  }
  if (codes.size) parts.push(`npm error code ${[...codes].slice(0, 5).join(", ")}`);
  return parts.length ? parts.join("; ") : null;
}

/** The summary of the newest debug log in `<home>/.npm/_logs`, or null. Never throws. */
export function newestNpmLogSummary(home: string): string | null {
  try {
    const dir = join(home, ".npm", "_logs");
    const newest = readdirSync(dir)
      .filter((f) => /^[0-9TZ_-]+-debug-\d+\.log$/.test(f))
      .sort()
      .pop();
    if (!newest) return null;
    return npmLogSummary(readFileSync(join(dir, newest), "utf8"));
  } catch {
    return null;
  }
}

const PNPM_CODE = /\b(ERR_PNPM_[A-Z0-9_]{1,60})\b/g;

/** Adds the ERR_PNPM_* codes in one output line to `into` (at most 5, no repeats). */
export function collectPnpmErrorCodes(line: string, into: string[]): void {
  for (const m of line.matchAll(PNPM_CODE)) {
    if (into.length < 5 && !into.includes(m[1])) into.push(m[1]);
  }
}
