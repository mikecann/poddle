#!/usr/bin/env bash
# The repair sandbox's script (docs/chef-pipeline.md, "Repair commits"):
# runs chef-repair.mjs, delivered next to it, with the launcher's envs.
# Usage: chef-repair.sh <40 character sha of main>
set -euo pipefail
self="${BASH_SOURCE[0]}"
while [ -L "$self" ]; do
  link="$(readlink "$self")"
  case "$link" in /*) self="$link" ;; *) self="$(dirname "$self")/$link" ;; esac
done
d="$(cd "$(dirname "$self")" && pwd -P)"
# Daytona's egress proxy re-signs HTTPS; git and npm need its CA (as the deploy scripts' sandbox does).
ca=/etc/daytona/netleash/ca.crt
if [ -r "$ca" ]; then
  if [ -x /opt/chef/bin/trust-daytona-proxy-ca ]; then /opt/chef/bin/trust-daytona-proxy-ca >/dev/null 2>&1 || true; fi
  export NODE_EXTRA_CA_CERTS="$ca"
fi
exec node "$d/chef-repair.mjs" "$@"
