// The exact environment the runner gives Claude Code, which runs as
// `chefagent`. Nothing is inherited: every variable is built here from fixed
// values, plus the inference placeholder from CHEF_AI_TOKEN and, when the
// runner started one, the local backend's URL and admin key. The runner's own
// placeholders (CHEF_RUN_TOKEN, CHEF_GIT_AUTH) and anything else in its
// environment never reach the agent.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

export const AGENT_USER = "chefagent";
export const AGENT_HOME = "/home/chefagent";
export const AGENT_PATH = "/usr/local/bin:/usr/bin:/bin";

/** The one variable taken from the runner's environment. */
export const AGENT_TOKEN_SOURCE = "CHEF_AI_TOKEN";

/** Daytona secret placeholders look like `dtn_secret_...`. */
const PLACEHOLDER = /^dtn_secret_[A-Za-z0-9_-]+$/;

/**
 * Every key the agent may see. The only one carrying a real credential's
 * placeholder is the token. The two CONVEX_SELF_HOSTED_* values belong to
 * the throwaway local backend inside the sandbox: an admin key that works on
 * 127.0.0.1 and nowhere else, so they are fine for the agent to hold.
 * VITE_CONVEX_URL is the same local backend's URL, for the app's frontend
 * (Vite apps read it from the environment). PLAYWRIGHT_BROWSERS_PATH is the
 * image's browsers, for `chef-screenshot` (runner/screenshot-helper.ts).
 */
export const AGENT_ENV_KEYS: readonly string[] = [
  "HOME",
  "USER",
  "LOGNAME",
  "SHELL",
  "PATH",
  "LANG",
  "TERM",
  "TMPDIR",
  "CI",
  "CLAUDE_CONFIG_DIR",
  "CONVEX_AGENT_MODE",
  "CONVEX_SELF_HOSTED_URL",
  "CONVEX_SELF_HOSTED_ADMIN_KEY",
  "ANTHROPIC_AUTH_TOKEN",
  "NODE_EXTRA_CA_CERTS",
  "PLAYWRIGHT_BROWSERS_PATH",
  "VITE_CONVEX_URL",
  // The Convex plugin's own telemetry opt-outs (runner/convex-plugin.ts).
  "CONVEX_PLUGIN_TELEMETRY",
  "DO_NOT_TRACK",
];

/** Never in the agent's environment, whatever else changes. */
export const AGENT_ENV_FORBIDDEN: readonly string[] = [
  "ANTHROPIC_API_KEY",
  "MAX_THINKING_TOKENS",
  "CHEF_RUN_TOKEN",
  "CHEF_GIT_AUTH",
  "CHEF_AI_TOKEN",
  "CONVEX_DEPLOY_KEY",
  "CONVEX_DEPLOYMENT",
];

export type Env = Record<string, string | undefined>;

/** The local backend the runner started (runner/local-backend.ts). */
export type LocalBackendEnv = { url: string; adminKey: string };

const LOCAL_URL = /^http:\/\/127\.0\.0\.1:\d{1,5}$/;
// A path to a PEM bundle, never a value: Daytona's egress proxy re-signs TLS
// with its own CA (/etc/daytona/netleash/ca.crt), and Node (Claude Code, npm,
// the agent's tests) only trusts it through this variable.
const CA_BUNDLE_PATH = /^\/[A-Za-z0-9._/-]{1,255}\.(crt|pem)$/;
const CONFIG_DIR = /^\/[A-Za-z0-9._/-]{1,255}$/;
const ADMIN_KEY = /^[A-Za-z0-9_|:.-]{1,2000}$/;

export function buildAgentEnv(
  runnerEnv: Env,
  opts: {
    home?: string;
    path?: string;
    localBackend?: LocalBackendEnv;
    claudeConfigDir?: string;
    /** The image's Playwright browsers (runner/screenshots.ts). */
    playwrightBrowsersPath?: string;
  } = {},
): Record<string, string> {
  const token = runnerEnv[AGENT_TOKEN_SOURCE];
  if (!token) throw new Error(`${AGENT_TOKEN_SOURCE} is not set`);
  if (!PLACEHOLDER.test(token)) {
    // Chef runs only in gateway mode, where the sandbox holds placeholders.
    // Anything else could be a real credential, so refuse.
    throw new Error(`${AGENT_TOKEN_SOURCE} is not a Daytona secret placeholder`);
  }
  const home = opts.home ?? AGENT_HOME;
  const env: Record<string, string> = {
    HOME: home,
    USER: AGENT_USER,
    LOGNAME: AGENT_USER,
    SHELL: "/bin/bash",
    PATH: opts.path ?? AGENT_PATH,
    LANG: "C.UTF-8",
    TERM: "dumb",
    TMPDIR: "/tmp",
    CI: "1",
    // The runner prepares it (runner/skills.ts prepareClaudeConfigDir): the
    // agent can add files but not skills, settings or CLAUDE.md.
    CLAUDE_CONFIG_DIR: opts.claudeConfigDir ?? `${home}/.claude`,
    // The agent's test loop runs against the local backend with no login.
    CONVEX_AGENT_MODE: "anonymous",
    // Claude Code sends this as the Bearer token. It is a placeholder that
    // the egress proxy swaps only toward the app's own .convex.site.
    ANTHROPIC_AUTH_TOKEN: token,
    // The Convex plugin's hooks send nothing (runner/convex-plugin.ts); egress
    // would refuse it anyway.
    CONVEX_PLUGIN_TELEMETRY: "0",
    DO_NOT_TRACK: "1",
  };
  if (!CONFIG_DIR.test(env.CLAUDE_CONFIG_DIR) || env.CLAUDE_CONFIG_DIR.split("/").includes("..")) {
    throw new Error("CLAUDE_CONFIG_DIR must be an absolute plain path");
  }
  const ca = runnerEnv.NODE_EXTRA_CA_CERTS;
  if (ca !== undefined && ca !== "") {
    if (!CA_BUNDLE_PATH.test(ca) || ca.includes("..")) {
      throw new Error("NODE_EXTRA_CA_CERTS must be an absolute path to a .crt or .pem file");
    }
    env.NODE_EXTRA_CA_CERTS = ca;
  }
  if (opts.playwrightBrowsersPath !== undefined) {
    if (!CONFIG_DIR.test(opts.playwrightBrowsersPath) || opts.playwrightBrowsersPath.split("/").includes("..")) {
      throw new Error("PLAYWRIGHT_BROWSERS_PATH must be an absolute plain path");
    }
    env.PLAYWRIGHT_BROWSERS_PATH = opts.playwrightBrowsersPath;
  }
  const lb = opts.localBackend;
  if (lb) {
    // The runner started the backend itself, so the CLI talks to it as a
    // self-hosted deployment and never sets one up (which would ask
    // version.convex.dev for the latest binary).
    if (!LOCAL_URL.test(lb.url)) throw new Error("the local backend URL must be http://127.0.0.1:<port>");
    if (!ADMIN_KEY.test(lb.adminKey) || lb.adminKey.includes("dtn_secret_")) {
      throw new Error("the local backend's admin key doesn't look like one");
    }
    delete (env as Record<string, string | undefined>).CONVEX_AGENT_MODE;
    env.CONVEX_SELF_HOSTED_URL = lb.url;
    env.CONVEX_SELF_HOSTED_ADMIN_KEY = lb.adminKey;
    // How a Vite app's frontend finds its backend: the agent's dev server
    // and the final screenshots' build both talk to the local backend.
    env.VITE_CONVEX_URL = lb.url;
  }
  assertCleanAgentEnv(env, runnerEnv);
  return env;
}

const SECRET_NAME = /TOKEN|KEY|SECRET|AUTH|PASSWORD|CREDENTIAL/i;

/**
 * Checks an agent environment: only allowlisted keys, nothing forbidden, and
 * no secret-looking value from the runner's environment (by name, or any
 * Daytona placeholder) except the inference placeholder.
 */
export function assertCleanAgentEnv(
  env: Record<string, string>,
  runnerEnv: Env,
): void {
  for (const key of Object.keys(env)) {
    if (!AGENT_ENV_KEYS.includes(key)) {
      throw new Error(`agent env has a key outside the allowlist: ${key}`);
    }
    if (AGENT_ENV_FORBIDDEN.includes(key)) {
      throw new Error(`agent env must not have ${key}`);
    }
  }
  const token = runnerEnv[AGENT_TOKEN_SOURCE];
  const values = Object.values(env);
  for (const [key, value] of Object.entries(runnerEnv)) {
    // Values under 8 characters ("0", "1") can't be told from chance
    // matches, such as a digit in the local backend's hex admin key.
    if (key === AGENT_TOKEN_SOURCE || !value || value.length < 8 || value === token) continue;
    if (!SECRET_NAME.test(key) && !value.includes("dtn_secret_")) continue;
    if (values.some((v) => v.includes(value))) {
      // Name only, never the value.
      throw new Error(`agent env carries the value of the runner's ${key}`);
    }
  }
}
