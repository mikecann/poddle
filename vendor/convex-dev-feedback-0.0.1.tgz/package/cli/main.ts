// The `chef` command line (`npx chef ...` in an app that has
// @convex-dev/feedback installed). `chef.mjs` loads this after installing
// hooks so Node can run the TypeScript, including from node_modules.
//
//   chef init [--cloud | --no-cloud] [--cloud-from <spec>] [--write]
//             [--no-commit] [--enable] [--admin <userId>]
//             [--skip-preview] [--rotate-preview-key]
//             [--deploy-key | --skip-deploy-key] [--rotate-deploy-key]
//             [--beta <deployment> | --skip-beta]
//   chef upgrade              after updating the package: push the functions
//                             and run the upgrade steps (cli/init.ts)
//   chef guard                refuse (exit 3) if a deploy from here would roll
//                             back what "Ship it" shipped (cli/guard.ts)
//   chef sync                 push HEAD to chef's main through the `chef` remote
//   chef ios <runId|itemId>   build that commit with Xcode, install it on your
//                             iPhone, report back to the run (cli/ios.ts)
//   chef status               the deployment, the repo, and cloud build setup
//   chef cleanup              Chef's cleanup sweep and checks now (it has no crons;
//                             they run on their own when a run or ship ends)
//   chef work [...]           build approved requests on this machine (cli/work.ts)
//   chef worker-key [--name]  a new worker key on stdout, only into a pipe:
//                             npx chef worker-key | npx chef work --save-key
//   chef git-credential get   git's credential helper for the `chef` remote
//
// Everywhere: --module <name> (the convex/ module with the chef functions,
// default `chef`), --prod (production instead of .env.local's deployment).
//
// Exit codes: 0 done, 1 failed, 2 usage, 3 something to fix first.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { scrub } from "../src/chef/scrub.ts";
import { Convex } from "./convex.ts";
import { gitCredential } from "./credential.ts";
import { runIos } from "./ios.ts";
import { CliError, defaultDeps, type Deps } from "./deps.ts";
import { deployGuard, mainBehindHead, pullFirst } from "./guard.ts";
import { enabledFrom, init, migrateAgentKeys } from "./init.ts";
import { deployCheck, parseDeployment, readConvexDeployment, renderChecks } from "./preflight.ts";
import { checkLockfile } from "./lockcheck.ts";
import { MAIN, normalizeRefs, REMOTE_NAME, syncToMain } from "./repo.ts";
import { work, type WorkDeps } from "./work.ts";

export const USAGE = `usage: chef <command> [options]

  init            set this app up for Chef (prints the code edits): the
                  feedback board, and with --cloud, cloud builds
    --cloud               cloud builds too (@convex-dev/chef-cloud, vendored
                          into vendor/ if it isn't installed)
    --no-cloud            the feedback board alone, without asking
    --cloud-from <spec>   where to get @convex-dev/chef-cloud (default
                          github:sethconvex/feedback-chef#dist/chef-cloud)
    --write               make and commit the code edits
    --no-commit           with --write: write the edits only (uncommitted work
                          is fine) and stop: no commit, deploy, repo or keys
    --enable              turn cloud builds on without asking
    --admin <userId>      name the app's admin (approves builds, ships); the
                          panel shows a signed-in user "your Chef user id"
    --admin-email <email> not supported: emails can't be mapped to ids here
    --skip-preview        no preview deploy key or preview env defaults
    --rotate-preview-key  a new preview deploy key even if one is set
    --deploy-key          create "Ship it"'s deploy key without asking
    --skip-deploy-key     don't create or ask about it
    --rotate-deploy-key   a new "Ship it" deploy key even if one is set
    --beta <deployment>   create the beta channel's deploy key for that
                          deployment (another one than the app's) without
                          asking; chefCloud's \`beta\` option turns it on
    --skip-beta           don't create or ask about the beta's deploy key
  upgrade         after updating @convex-dev/feedback: push the functions and
                  run the upgrade steps (hashes /agent/* keys still stored in
                  plaintext and says which to rotate)
  guard           refuse (exit 3) while chef's main has commits this checkout
                  lacks and "Ship it" deploys to this deployment; init adds it
                  as \`predev\`, so \`npm run dev\` can't roll back what shipped
  sync            push HEAD to chef's main through the \`chef\` git remote,
                  after the build sandbox's install check (a lockfile it
                  would refuse is refused here, with the fix)
  status          the deployment, chef's repo and cloud build setup
  cleanup         run Chef's cleanup and checks now, by hand: claim an
                  approved build, catch a stuck run or ship, delete leftover
                  sandboxes, secrets and old request branches. Chef has no
                  crons; all of this also happens on its own when it's due
  ios <runId|itemId>
                  on your Mac: fetch that build's commit from the \`chef\`
                  remote, build it with Xcode (chef.ios in package.json),
                  install it on your iPhone with devicectl, launch it against
                  the build's preview, and mark the run "compiled / installed"
    --device <name>       which connected device (default: the only one)
    --backend <preview|beta|none>
                          which backend the launched app uses (default: the
                          preview, else the beta)
    --no-launch           install without launching
  work            build approved requests on this machine with your own
                  Claude Code or Codex login (chef work --help);
                  \`npx chef work --setup\` creates and saves its key
  worker-key      a new worker key (chefCreateWorkerKey), written only into a
                  pipe: npx chef worker-key | npx chef work --save-key
    --name <name>         the key's name (default chef work)
  git-credential  git's credential helper for the \`chef\` remote (git runs it)
    --read                ask for a fetch-only token

  --module <name>  the convex/ module with the chef functions (default chef)
  --prod           production instead of the deployment in .env.local`;

type Flags = {
  cloud?: boolean;
  cloudFrom?: string;
  write: boolean;
  commit: boolean;
  enable: boolean;
  prod: boolean;
  read: boolean;
  skipPreview: boolean;
  rotatePreviewKey: boolean;
  deployKey: boolean;
  skipDeployKey: boolean;
  rotateDeployKey: boolean;
  beta?: string;
  skipBeta: boolean;
  device?: string;
  backend?: "preview" | "beta" | "none";
  noLaunch: boolean;
  module: string;
  admin?: string;
  name?: string;
  adminEmail?: string;
};

function parse(argv: string[]): { positional: string[]; flags: Flags } {
  const flags: Flags = {
    write: false,
    commit: true,
    enable: false,
    prod: false,
    read: false,
    skipPreview: false,
    rotatePreviewKey: false,
    deployKey: false,
    skipDeployKey: false,
    rotateDeployKey: false,
    skipBeta: false,
    noLaunch: false,
    module: "chef",
  };
  const positional: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => {
      const x = argv[++i];
      if (x === undefined || x.startsWith("-")) throw new CliError(`${a} needs a value\n${USAGE}`, 2);
      return x;
    };
    if (a === "-h" || a === "--help") continue;
    else if (a === "--cloud") flags.cloud = true;
    else if (a === "--no-cloud") flags.cloud = false;
    else if (a === "--cloud-from") flags.cloudFrom = val();
    else if (a === "--write") flags.write = true;
    else if (a === "--no-commit") flags.commit = false;
    else if (a === "--enable") flags.enable = true;
    else if (a === "--prod") flags.prod = true;
    else if (a === "--read") flags.read = true;
    else if (a === "--skip-preview") flags.skipPreview = true;
    else if (a === "--rotate-preview-key") flags.rotatePreviewKey = true;
    else if (a === "--deploy-key") flags.deployKey = true;
    else if (a === "--skip-deploy-key") flags.skipDeployKey = true;
    else if (a === "--rotate-deploy-key") flags.rotateDeployKey = true;
    else if (a === "--beta") {
      flags.beta = val();
      if (!/^[a-z0-9][a-z0-9-]{0,63}$/.test(flags.beta)) throw new CliError("--beta takes a deployment name, like happy-otter-123", 2);
    } else if (a === "--skip-beta") flags.skipBeta = true;
    else if (a === "--device") flags.device = val();
    else if (a === "--backend") {
      const b = val();
      if (b !== "preview" && b !== "beta" && b !== "none") throw new CliError("--backend takes preview, beta or none", 2);
      flags.backend = b;
    } else if (a === "--no-launch") flags.noLaunch = true;
    else if (a === "--module") {
      flags.module = val();
      if (!/^[A-Za-z_][\w/]*$/.test(flags.module)) throw new CliError(`--module takes a module path like chef or admin/chef`, 2);
    } else if (a === "--admin") flags.admin = val();
    else if (a === "--name") flags.name = val();
    else if (a === "--admin-email") flags.adminEmail = val();
    else if (a.startsWith("-")) throw new CliError(`Unknown option ${a}\n${USAGE}`, 2);
    else positional.push(a);
  }
  return { positional, flags };
}

export type MainOpts = {
  cwd?: string;
  deps?: Partial<Deps>;
  /** git-credential: what git wrote on stdin (default: read process.stdin). */
  stdin?: string;
  /** git-credential: where the credential goes (default: process.stdout). */
  writeCredential?: (s: string) => void;
  /** work: overrides for `chef work`'s dependencies (tests). */
  work?: Partial<WorkDeps>;
  /** worker-key: whether stdout is a terminal (default: process.stdout.isTTY). */
  stdoutIsTTY?: boolean;
  /** worker-key: where the key goes (default: process.stdout). */
  writeSecret?: (s: string) => void;
  /** ios: the platform and the temp dir (tests). */
  ios?: { platform?: string; tmp?: () => string };
};

async function readStdin(): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const c of process.stdin) chunks.push(c as Buffer);
  return Buffer.concat(chunks).toString("utf8");
}

export async function main(argv: string[], opts: MainOpts = {}): Promise<number> {
  const deps: Deps = { ...defaultDeps(), ...(opts.deps ?? {}) };
  const cwd = opts.cwd ?? process.cwd();
  try {
    return await run(argv, cwd, deps, opts);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    deps.log(`chef: ${scrub(msg)}`);
    return e instanceof CliError ? e.code : 1;
  }
}

async function run(argv: string[], cwd: string, deps: Deps, opts: MainOpts): Promise<number> {
  // `work` has its own options (--agent, --container, ...), so it gets the
  // raw arguments before the shared parser would reject them.
  if (argv[0] === "work") return await dispatchWork(argv.slice(1), cwd, opts);
  const { positional, flags } = parse(argv);
  const [cmd, ...rest] = positional;
  if (argv.includes("-h") || argv.includes("--help") || !cmd) {
    deps.log(USAGE);
    return cmd || argv.length ? 0 : 2;
  }
  const self = deps.env.CHEF_SELF_COMMAND?.trim() || "npx chef";
  const convex = new Convex(deps, { cwd, module: flags.module, prod: flags.prod });
  switch (cmd) {
    case "init":
      if (rest.length) throw new CliError(USAGE, 2);
      if (flags.adminEmail !== undefined) {
        // Each auth library keeps emails its own way, so there is no generic
        // email -> user id lookup to run from here.
        throw new CliError(
          `chef can't turn an email into a user id for every auth setup. Sign in to the app as ${flags.adminEmail}, ` +
            `open the Chef panel, copy "your Chef user id", and run: npx chef init --admin <that id>`,
          2,
        );
      }
      if (!flags.commit && !flags.write) throw new CliError(`--no-commit goes with --write\n${USAGE}`, 2);
      if (flags.skipBeta && flags.beta) throw new CliError(`--skip-beta can't go with --beta\n${USAGE}`, 2);
      if (flags.skipDeployKey && (flags.deployKey || flags.rotateDeployKey)) {
        throw new CliError(`--skip-deploy-key can't go with --deploy-key or --rotate-deploy-key\n${USAGE}`, 2);
      }
      return await init(
        {
          cwd,
          module: flags.module,
          prod: flags.prod,
          write: flags.write,
          commit: flags.commit,
          enable: flags.enable,
          ...(flags.admin ? { admin: flags.admin } : {}),
          skipPreview: flags.skipPreview,
          rotatePreviewKey: flags.rotatePreviewKey,
          deployKey: flags.deployKey,
          skipDeployKey: flags.skipDeployKey,
          rotateDeployKey: flags.rotateDeployKey,
          ...(flags.beta !== undefined ? { beta: flags.beta } : {}),
          ...(flags.skipBeta ? { skipBeta: true } : {}),
          self,
          ...(flags.cloud !== undefined ? { cloud: flags.cloud } : {}),
          ...(flags.cloudFrom !== undefined ? { cloudFrom: flags.cloudFrom } : {}),
        },
        deps,
      );
    case "git-credential":
      return await gitCredential(
        rest[0],
        convex,
        {
          stdin: opts.stdin ?? (rest[0] === "get" ? await readStdin() : ""),
          write: opts.writeCredential ?? ((s) => process.stdout.write(s)),
          log: deps.log,
        },
        { read: flags.read },
      );
    case "upgrade": {
      if (rest.length) throw new CliError(USAGE, 2);
      const guard = await deployGuard(convex, deps, cwd, { prod: flags.prod });
      if (!guard.ok) throw new CliError(guard.message, 3);
      deps.log(`chef upgrade: pushing the functions to ${flags.prod ? "production" : "the deployment in .env.local"}`);
      await convex.push();
      await migrateAgentKeys(convex, deps.log, flags.module);
      deps.out("chef upgrade: done");
      return 0;
    }
    case "guard": {
      if (rest.length) throw new CliError(USAGE, 2);
      const g = await deployGuard(convex, deps, cwd, { prod: flags.prod });
      if (!g.ok) throw new CliError(`chef guard: ${g.message}`, 3);
      deps.log(`chef guard: ok (${g.why})`);
      return 0;
    }
    case "sync": {
      if (rest.length) throw new CliError(USAGE, 2);
      // Chef's main may have commits a "Ship it" put there: say so before
      // pushing (the push itself is never forced, so it would be refused).
      if ((await deps.exec("git", ["remote", "get-url", REMOTE_NAME], { cwd })).code === 0) {
        let behind: Awaited<ReturnType<typeof mainBehindHead>> | null = null;
        try {
          behind = await mainBehindHead(convex, deps, cwd);
        } catch {
          behind = null; // can't read the refs here; the push is a compare-and-swap anyway
        }
        if (behind && !behind.contained && behind.main) {
          throw new CliError(pullFirst(behind.main, behind.fetched, `Syncing now would be refused: chef's ${MAIN} only moves forward.`), 3);
        }
      }
      // What the preview deploy refuses (a tracked .env or .npmrc, symlinks,
      // ...; src/chef/deployChecks.ts): a main with any of it would make
      // every cloud build fail at its preview, after paying for the agent.
      const dc = await deployCheck(cwd, deps);
      if (dc && dc.status === "fail") {
        for (const l of renderChecks([dc])) deps.log(l);
        throw new CliError("Not syncing: the preview deploy refuses this commit, so every cloud build of it would fail. Fix it as shown above, commit, and sync again.", 3);
      }
      // What a cloud build installs from: a lockfile the sandbox's frozen
      // install would refuse is refused here, before any build pays for it.
      const lock = await checkLockfile(cwd, deps);
      if (lock.status !== "ok") for (const l of renderChecks([lock])) deps.log(l);
      if (lock.status === "fail") {
        throw new CliError(`Not syncing: a cloud build of this commit would fail at install. Fix the lockfile as shown above, commit, and sync again.`, 3);
      }
      const r = await syncToMain(deps, cwd);
      for (const l of r.output.split("\n").filter((l) => l && !/^Done$|^To /.test(l))) deps.log(`  ${l}`);
      deps.out(`chef's ${MAIN} is ${r.sha}`);
      return 0;
    }
    case "ios":
      if (rest.length !== 1) throw new CliError(`chef ios takes one run id or request id\n${USAGE}`, 2);
      return await runIos(rest[0], cwd, deps, convex, {
        ...(flags.device !== undefined ? { device: flags.device } : {}),
        ...(flags.backend !== undefined ? { backend: flags.backend } : {}),
        ...(flags.noLaunch ? { noLaunch: true } : {}),
      }, opts.ios ?? {});
    case "status":
      if (rest.length) throw new CliError(USAGE, 2);
      return await status(cwd, deps, convex, flags);
    case "cleanup": {
      if (rest.length) throw new CliError(USAGE, 2);
      // What the old every-minute and hourly crons did, once.
      await convex.run("chefSweep");
      await convex.run("chefCleanup");
      deps.out(`chef cleanup: checked the build slot, live runs and open ships; the cleanup sweep is queued (${flags.module}:chefCleanup)`);
      return 0;
    }
    case "work":
      return await dispatchWork(rest, cwd, opts);
    case "worker-key": {
      if (rest.length) throw new CliError(USAGE, 2);
      // The key goes only into a pipe, never onto a screen or into a log.
      if (opts.stdoutIsTTY ?? process.stdout.isTTY) {
        throw new CliError(
          "worker-key writes the key only into a pipe: npx chef worker-key | npx chef work --save-key (or just npx chef work --setup)",
          2,
        );
      }
      const name = (flags.name ?? "chef work").trim();
      if (!/^[A-Za-z0-9 ._@:-]{1,100}$/.test(name)) throw new CliError("--name takes up to 100 letters, digits, spaces and ._@:-", 2);
      const key = await convex.run<string>("chefCreateWorkerKey", { name });
      if (typeof key !== "string" || !/^chefk_[A-Za-z0-9]{16,256}$/.test(key)) {
        throw new CliError(`${flags.module}:chefCreateWorkerKey didn't return a Chef agent key`);
      }
      (opts.writeSecret ?? ((s) => process.stdout.write(s)))(key + "\n");
      deps.log(`chef: created worker key "${name}"; it lets \`npx chef work\` build, and doesn't turn cloud builds on`);
      return 0;
    }
    default:
      throw new CliError(`Unknown command ${cmd}\n${USAGE}`, 2);
  }
}

function dispatchWork(argv: string[], cwd: string, opts: MainOpts): Promise<number> {
  return work(argv, { cwd, ...(opts.work ?? {}) });
}

function oneLine(v: unknown): string {
  const s = typeof v === "string" ? v : JSON.stringify(v);
  return scrub(s.length > 120 ? s.slice(0, 117) + "..." : s);
}

async function status(cwd: string, deps: Deps, convex: Convex, flags: Flags): Promise<number> {
  const out = deps.out;
  const d = parseDeployment(readConvexDeployment(cwd, deps.env));
  out(`deployment    ${flags.prod ? "production" : "error" in d ? `none (${d.error})` : `${d.kind}:${d.name}`}`);
  const git = (args: string[]) => deps.exec("git", args, { cwd });
  const head = (await git(["rev-parse", "HEAD"])).stdout.trim();
  const branch = (await git(["rev-parse", "--abbrev-ref", "HEAD"])).stdout.trim();
  out(`HEAD          ${head ? `${head.slice(0, 12)} (${branch})` : "none"}`);
  const remote = await git(["remote", "get-url", REMOTE_NAME]);
  const url = remote.code === 0 ? remote.stdout.trim() : null;
  if (url) {
    const helpers = (await git(["config", "--get-all", `credential.${url}.helper`])).stdout;
    out(`git remote    ${REMOTE_NAME} ${scrub(url)}${/git-credential/.test(helpers) ? "" : " (no chef credential helper: run init)"}`);
  } else out(`git remote    none (run \`npx chef init\`)`);

  let refs: Record<string, string> = {};
  try {
    refs = normalizeRefs(await convex.run("chefRepoRefs"));
    const main = refs[MAIN];
    let rel = "";
    if (main && head) {
      if (main === head) rel = "same as HEAD";
      else if ((await git(["cat-file", "-e", `${main}^{commit}`])).code !== 0) rel = `not fetched here: git fetch ${REMOTE_NAME}`;
      else if ((await git(["merge-base", "--is-ancestor", main, head])).code === 0) rel = "behind HEAD: `npx chef sync`";
      else if ((await git(["merge-base", "--is-ancestor", head, main])).code === 0) rel = `ahead of HEAD: git pull ${REMOTE_NAME} ${MAIN}`;
      else rel = "diverged from HEAD";
    }
    out(`chef ${MAIN}     ${main ? `${main.slice(0, 12)} (${rel})` : "none"}`);
    for (const [k, v] of Object.entries(refs)) if (k !== MAIN) out(`  ${k.padEnd(11)} ${v.slice(0, 12)}`);
  } catch (e) {
    out(`chef ${MAIN}     unknown (${e instanceof Error ? e.message.split("\n")[0] : String(e)})`);
  }

  try {
    const s = await convex.run<Record<string, unknown> | null>("chefSetupStatus");
    out(`cloud builds  ${enabledFrom(s) ? "on" : "off"}`);
    if (typeof s?.deployKeyPrefix === "string" && s.deployKeyPrefix) {
      out(`ship it       deploys here (${s.deployKeyPrefix}); deploys from a checkout without chef's ${MAIN} are refused`);
    }
    const workers = typeof s?.workerKeys === "number" ? s.workerKeys : null;
    if (workers !== null) out(`worker keys   ${workers}${workers ? " (npx chef work can build)" : " (npx chef work --setup adds one)"}`);
    for (const [k, v] of Object.entries(s ?? {})) out(`  ${k}: ${oneLine(v)}`);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (/Could not find|not found|No such function|unknown function/i.test(msg)) {
      out("cloud builds  not set up (the feedback board alone; `npx chef init --cloud` adds them)");
    } else out(`cloud builds  unknown (${msg.split("\n")[0]})`);
  }
  return 0;
}

