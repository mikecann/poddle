// The sandbox's install check, run here first (`chef init --cloud`, `chef
// sync`): a lockfile the build sandbox's frozen install would refuse is
// caught before a paid sandbox launches, with the exact fix. Both sides
// decide by runner/chef-install.mjs, so they agree on npm or pnpm and on
// the pnpm version.
//
// Two steps: the offline comparison of pnpm-lock.yaml's specifiers with
// package.json (instant, no network), then the sandbox's own install with
// nothing written (`npm ci --dry-run`, or the pinned pnpm, frozen, with
// --lockfile-only), through the npm the CLI was told to use. A check that
// can't run here (offline, say) is a warning, not a refusal.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import type { Deps } from "./deps.ts";
import type { Check } from "./preflight.ts";
import { installPlan, lockfileCheckArgv, lockfileFix, pnpmSpecifierMismatches } from "../runner/chef-install.mjs";

/** What says the lockfile itself is the problem, in npm's or pnpm's output. */
const OUTDATED = /ERR_PNPM_OUTDATED_LOCKFILE|ERR_PNPM_LOCKFILE_CONFIG_MISMATCH|ERR_PNPM_LOCKFILE_MISSING_DEPENDENCY|ERR_PNPM_BROKEN_LOCKFILE|can only install packages when your package\.json and package-lock\.json|npm error code EUSAGE/;
/** What says the check couldn't run (no network, no npm), not that the lockfile is wrong. */
const COULDNT_RUN = /ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|ETIMEDOUT|network|ERR_PNPM_META_FETCH_FAIL|ERR_PNPM_FETCH_|ENOENT|not found|E404/i;

/** The offline part alone: a pnpm-lock.yaml whose specifiers disagree with package.json. Null when fine or not pnpm. */
export function offlineLockfileProblem(appDir: string): Check | null {
  const plan = installPlan(appDir);
  if ("error" in plan || plan.manager !== "pnpm") return null;
  const diff = pnpmSpecifierMismatches(appDir);
  if (!diff || diff.length === 0) return null;
  return {
    name: "lockfile",
    status: "fail",
    detail: `pnpm-lock.yaml is out of date with package.json; the build sandbox's frozen install (pnpm ${plan.version}) would refuse it (ERR_PNPM_OUTDATED_LOCKFILE)`,
    help: [...diff.slice(0, 8).map((d) => `  ${d}`), ...(diff.length > 8 ? [`  and ${diff.length - 8} more`] : []), "Fix:", ...lockfileFix(plan).map((l) => `  ${l}`)],
  };
}

/**
 * The full check: the offline comparison, then the sandbox's install with
 * nothing written. It checks the working tree; the cloud builds what is
 * committed, so uncommitted changes to package.json or the lockfile are a
 * warning.
 */
export async function checkLockfile(appDir: string, deps: Deps): Promise<Check> {
  const plan = installPlan(appDir);
  if ("error" in plan) return { name: "lockfile", status: "fail", detail: plan.error, help: plan.help };
  const what = plan.manager === "pnpm" ? `pnpm ${plan.version}, frozen` : "npm ci";
  const offline = offlineLockfileProblem(appDir);
  if (offline) return offline;
  const dirty = await deps.exec("git", ["status", "--porcelain", "--", "package.json", plan.lockfile], { cwd: appDir });
  const uncommitted = dirty.code === 0 && dirty.stdout.trim() !== "";
  const argv = lockfileCheckArgv(plan);
  // `npm ...` through the npm the CLI uses (CHEF_NPM_COMMAND), like its other npm calls.
  const [cmd, ...args] = [...deps.npm, ...argv.slice(1)];
  const r = await deps.exec(cmd, args, { cwd: appDir });
  const out = `${r.stdout}\n${r.stderr}`;
  if (r.code === 0) {
    return uncommitted
      ? {
          name: "lockfile",
          status: "warn",
          detail: `installs as the sandbox would (${what}), but package.json or ${plan.lockfile} has uncommitted changes; the cloud builds what you commit`,
          help: [`git add package.json ${plan.lockfile} && git commit`],
        }
      : { name: "lockfile", status: "ok", detail: `${plan.lockfile} installs as the sandbox would (${what})` };
  }
  const tail = out
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l && !/^npm (error|warn) (Usage|Options|aliases|\[|Run "npm help)/.test(l))
    .slice(-6);
  if (OUTDATED.test(out)) {
    return {
      name: "lockfile",
      status: "fail",
      detail: `${plan.lockfile} doesn't install as the sandbox would (${what}): it is out of date with package.json`,
      help: [...tail.map((l) => `  ${l}`), "Fix:", ...lockfileFix(plan).map((l) => `  ${l}`)],
    };
  }
  if (COULDNT_RUN.test(out)) {
    return {
      name: "lockfile",
      status: "warn",
      detail: `couldn't run the sandbox's install check here (${argv[0]} ${argv[1]} ...); the offline comparison passed`,
      help: tail.map((l) => `  ${l}`),
    };
  }
  return {
    name: "lockfile",
    status: "fail",
    detail: `${plan.lockfile} doesn't install as the sandbox would (${what})`,
    help: [...tail.map((l) => `  ${l}`), `Check: ${argv.join(" ")}`],
  };
}
