// The code `chef init` adds to an app. For the feedback board alone: the
// component in convex.config, and the exposeChefApi and chefAdmin exports.
// With cloud builds (@convex-dev/chef-cloud) also: chef-cloud in
// convex.config, the chefCloud exports in place of chefAdmin's (no crons:
// Chef schedules nothing recurring), the runner's HTTP routes, the localEnv script and its
// `chef:local-env` npm script, and the deploy guard before `npm run dev`.
// Then (printed only) the panel. Each edit is planned from
// the file as it is: a new file, lines inserted into an existing one, or
// nothing when it is already there. Existing lines are never changed or
// removed; when a file doesn't look the way an insert needs, the edit is
// printed for the person to make instead.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { LOCAL_ENV_NPM_SCRIPT, LOCAL_ENV_SCRIPT, localEnvScript } from "./envvars.ts";
import { frontendFiles, type Frontend } from "./preflight.ts";
import { containedPath } from "./paths.ts";

export type Insert = { at: number; lines: string[] };

export type Edit = {
  /** Relative to the app directory. */
  file: string;
  /** What it is, in a few words. */
  title: string;
  /**
   * create: a new file; insert: lines added to an existing file; done:
   * already there; manual: printed for the person, never applied.
   */
  action: "create" | "insert" | "done" | "manual";
  /** create: the file. */
  content?: string;
  /** insert: where and what, in the file's current lines. */
  inserts?: Insert[];
  /** manual (and notes on done): what to do and why it isn't automatic. */
  note?: string[];
  /** manual: the code to add. */
  snippet?: string[];
  /** manual: init carries on without it (the panel, a missing panel name). */
  optional?: boolean;
};

export type EditOptions = {
  appDir: string;
  convexDir: string;
  /** The module for the chef functions (default `chef`, so convex/chef.ts). */
  module: string;
  frontend: Frontend;
  requiredEnv: string[];
  /** Cloud builds too (@convex-dev/chef-cloud), or the feedback board alone. */
  cloud: boolean;
};

// ------------------------------------------------------------------ source helpers

function read(path: string): string | null {
  try {
    return readFileSync(path, "utf8");
  } catch {
    return null;
  }
}

/** The line index just after the last import declaration (0 if none). */
export function afterImports(lines: string[]): number {
  let end = 0;
  let inImport = false;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i].trim();
    if (inImport) {
      if (/from\s+["'][^"']+["']\s*;?\s*$/.test(l)) {
        inImport = false;
        end = i + 1;
      }
      continue;
    }
    if (/^import\s/.test(l)) {
      if (/from\s+["'][^"']+["']\s*;?\s*$/.test(l) || /^import\s+["'][^"']+["']\s*;?\s*$/.test(l)) end = i + 1;
      else inImport = true;
      continue;
    }
    if (l === "" || l.startsWith("//") || l.startsWith("/*") || l.startsWith("*") || l.startsWith("*/")) continue;
    break;
  }
  return end;
}

/** Whether `name` is imported from `from` (a named import). */
export function importsName(src: string, name: string, from: RegExp): boolean {
  const re = /import\s+(?:type\s+)?\{([^}]*)\}\s*from\s*["']([^"']+)["']/g;
  for (let m = re.exec(src); m; m = re.exec(src)) {
    if (from.test(m[2]) && m[1].split(",").some((s) => s.trim().split(/\s+as\s+/).pop() === name)) return true;
  }
  return false;
}

function exportDefaultLine(lines: string[], name: string): number {
  const re = new RegExp(`^\\s*export\\s+default\\s+${name}\\s*;?\\s*$`);
  return lines.findIndex((l) => re.test(l));
}

const GENERATED_API = /^\.\/_generated\/api(\.js)?$/;

// ------------------------------------------------------------------ the code

/** Every function chefCloud returns (packages/chef-cloud/src/client/chefCloud.ts), in the README's order; checked like CHEF_API_EXPORTS. */
export const CHEF_CLOUD_EXPORTS = [
  "chefStep",
  "chefSweep",
  "chefCleanup",
  "chefRunStart",
  "chefShipStart",
  "chefReconcile",
  "chefSetup",
  "chefSetupStatus",
  "chefEnableCloudBuilds",
  "chefDisableCloudBuilds",
  "chefCreateWorkerKey",
  "chefSetAdmin",
  "chefSetPreviewDeployKey",
  "chefSetDeployKey",
  "chefCancelRun",
  "chefMigrateAgentKeys",
  "chefRepoSetup",
  "chefRepoUploadUrl",
  "chefRepoPushPack",
  "chefGitCredential",
  "chefRepoRefs",
  "chefRepairApply",
  "chefIos",
  "chefPlanBatches",
];
const CHEF_CLOUD_ROWS = [
  CHEF_CLOUD_EXPORTS.slice(0, 6),
  CHEF_CLOUD_EXPORTS.slice(6, 11),
  CHEF_CLOUD_EXPORTS.slice(11, 16),
  CHEF_CLOUD_EXPORTS.slice(16),
];

/** What chefAdmin returns (src/client/chefAdmin.ts): an app with the feedback board alone. chefCloud has them too. */
export const CHEF_ADMIN_EXPORTS = ["chefSetAdmin", "chefMigrateAgentKeys"];

/** The package with chefCloud and chef-cloud's convex.config. */
export const CHEF_CLOUD_PACKAGE = "@convex-dev/chef-cloud";

/**
 * Every function exposeChefApi returns (src/client/chef.ts), in the README's
 * rows. All of them: a client may call any (ChefKit subscribes to
 * whatsNew). tests/cli/exportLists.test.ts checks this against what
 * exposeChefApi actually returns, so a new one can't be left out.
 */
const CHEF_API_ROWS = [
  ["agentState", "listPublicItems", "submitRequest", "upvoteRequest", "answerRefinement", "skipRefinement"],
  ["generateUploadUrl", "submitRequestWithMedia", "listAttachments"],
  ["mine", "amAdmin", "whoAmI", "awaitingApproval", "review", "whatsNew"],
  ["approvalSnapshot", "prepareApproval", "approveSnapshot", "runLogs", "skillFeedback"],
  ["approvalRequests", "approveApprovalRequest", "declineApprovalRequest", "runScreenshots"],
  ["runStatus", "recentRuns", "buildState", "buildInCloud"],
  ["shipCandidate", "shipDiffChunk", "shipApprove"],
  ["retryRun", "appLearnings", "forgetLearning", "buildCosts", "applyRepair", "buildCard"],
  ["previewDataMode", "setPreviewData", "splitFromBatch"],
];
export const CHEF_API_EXPORTS = CHEF_API_ROWS.flat();

function chefCloudBlock(): string[] {
  return [
    "// Cloud builds: the build steps and sweeps, setup and the on switch, the",
    "// deploy keys, and the app's repo on Code Storage. All internal; the",
    "// workflows, the feedback component and `npx chef` (through `npx convex run`) call them.",
    "export const {",
    ...CHEF_CLOUD_ROWS.map((r) => `  ${r.join(", ")},`),
    "} = chefCloud(components.feedback, components.chefCloud);",
  ];
}

function chefAdminBlock(): string[] {
  return [
    "// For `npx chef`: name the app's admin, and the upgrade steps. Internal.",
    "export const {",
    `  ${CHEF_ADMIN_EXPORTS.join(", ")},`,
    "} = chefAdmin(components.feedback);",
  ];
}

/**
 * The names `export const { ... } = <fn>(` in `src` doesn't export yet, and
 * where a line listing them can go: just before the line that closes the
 * braces, when the list spans lines and its last line ends in a comma.
 * Null when there is no such destructure.
 */
function missingFromDestructure(
  src: string,
  fn: string,
  names: string[],
): { missing: string[]; at: number | null; indent: string } | null {
  const m = new RegExp(`export\\s+const\\s*\\{([^}]*)\\}\\s*=\\s*${fn}\\s*\\(`).exec(src);
  if (!m) return null;
  const have = new Set(m[1].replace(/\/\/[^\n]*|\/\*[\s\S]*?\*\//g, "").split(",").map((x) => x.trim().split(/\s*:\s*/)[0]).filter(Boolean));
  const missing = names.filter((n) => !have.has(n));
  const lines = src.split("\n");
  const closeLine = src.slice(0, m.index + m[0].length).split("\n").length - 1;
  const openLine = src.slice(0, m.index).split("\n").length - 1;
  if (closeLine === openLine || !/^\s*\}/.test(lines[closeLine])) return { missing, at: null, indent: "  " };
  const prev = lines[closeLine - 1] ?? "";
  if (!/[,{]\s*$/.test(prev)) return { missing, at: null, indent: "  " };
  const indent = (closeLine - 1 > openLine ? /^\s*/.exec(prev)?.[0] : "") || "  ";
  return { missing, at: closeLine, indent };
}

function usesConvexAuth(appDir: string): boolean {
  const pkg = read(join(appDir, "package.json"));
  return pkg !== null && /"@convex-dev\/auth"/.test(pkg);
}

function chefModuleFile(o: EditOptions): string {
  const auth = usesConvexAuth(o.appDir);
  return [
    o.cloud
      ? `// Chef: the panel's API (exposeChefApi) and cloud builds (chefCloud).`
      : `// Chef: the panel's API (exposeChefApi) and the CLI's admin functions (chefAdmin).`,
    `// Written by \`npx chef init\`.`,
    ...(o.cloud
      ? [`import { exposeChefApi } from "@convex-dev/feedback";`, `import { chefCloud } from "${CHEF_CLOUD_PACKAGE}";`]
      : [`import { chefAdmin, exposeChefApi } from "@convex-dev/feedback";`]),
    `import { components } from "./_generated/api";`,
    ...(auth ? [`import { getAuthUserId } from "@convex-dev/auth/server";`] : []),
    "",
    "export const {",
    ...CHEF_API_ROWS.map((r) => `  ${r.join(", ")},`),
    "} = exposeChefApi(components.feedback, {",
    auth
      ? "  getUserId: getAuthUserId, // who is calling (null = signed out)"
      : "  // Who is calling (null = signed out), from your auth provider's identity.\n  getUserId: async (ctx) => (await ctx.auth.getUserIdentity())?.subject ?? null,",
    "});",
    "",
    ...(o.cloud ? chefCloudBlock() : chefAdminBlock()),
    "",
  ].join("\n");
}

// ------------------------------------------------------------------ planning

/** The components convex.config needs: the feedback board, and chef-cloud with cloud builds. */
function configComponents(o: EditOptions): Array<{ name: string; from: string }> {
  return [
    { name: "feedback", from: "@convex-dev/feedback/convex.config.js" },
    ...(o.cloud ? [{ name: "chefCloud", from: `${CHEF_CLOUD_PACKAGE}/convex.config.js` }] : []),
  ];
}

function planConfig(o: EditOptions): Edit {
  const file = relative(o.appDir, join(o.convexDir, "convex.config.ts"));
  const title = o.cloud ? "install the components" : "install the component";
  const src = read(join(o.appDir, file));
  const wanted = configComponents(o);
  const comment = (names: string[]) =>
    names.includes("feedback")
      ? o.cloud
        ? "// Chef: requests and approvals (feedback), and cloud builds (chefCloud)."
        : "// Chef: requests, voting and approvals."
      : "// Chef's cloud builds: Daytona, Code Storage, Resend and workflows come with it.";
  if (src === null) {
    return {
      file,
      title,
      action: "create",
      content: [
        `import { defineApp } from "convex/server";`,
        ...wanted.map((c) => `import ${c.name} from "${c.from}";`),
        "",
        "const app = defineApp();",
        comment(wanted.map((c) => c.name)),
        ...wanted.map((c) => `app.use(${c.name});`),
        "",
        "export default app;",
        "",
      ].join("\n"),
    };
  }
  const esc = (x: string) => x.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");
  const state = wanted.map((c) => ({
    ...c,
    imported: new RegExp(`["']${esc(c.from.replace(/\.js$/, ""))}(\\.js)?["']`).test(src),
    used: new RegExp(`\\.use\\(\\s*${c.name}\\s*[,)]`).test(src),
  }));
  const missing = state.filter((c) => !c.imported || !c.used);
  if (missing.length === 0) return { file, title, action: "done" };
  const lines = src.split("\n");
  const appVar = /(?:const|let)\s+(\w+)\s*=\s*defineApp\s*\(/.exec(src)?.[1];
  const exportAt = appVar ? exportDefaultLine(lines, appVar) : -1;
  const manual = (why: string): Edit => ({
    file,
    title,
    action: "manual",
    note: [why],
    snippet: [...missing.map((c) => `import ${c.name} from "${c.from}";`), ...missing.map((c) => `${appVar ?? "app"}.use(${c.name});`)],
  });
  const half = missing.find((c) => c.imported !== c.used);
  if (half) return manual(`It imports or uses \`${half.name}\`, but not both; finish it by hand.`);
  if (!appVar || exportAt < 0) return manual("Couldn't find `const app = defineApp(...)` and `export default app`.");
  for (const c of missing) {
    const taken = new RegExp(
      `(?:\\bimport\\s+${c.name}\\b|\\b(?:const|let|var|function|class)\\s+${c.name}\\b|[{,]\\s*${c.name}\\s*(?:,|\\}))`,
    );
    if (taken.test(src)) return manual(`The name \`${c.name}\` is already taken in this file.`);
  }
  return {
    file,
    title,
    action: "insert",
    inserts: [
      { at: afterImports(lines), lines: missing.map((c) => `import ${c.name} from "${c.from}";`) },
      { at: exportAt, lines: [comment(missing.map((c) => c.name)), ...missing.map((c) => `${appVar}.use(${c.name});`), ""] },
    ],
  };
}

/**
 * convex/chef.ts from before chef-cloud was its own package: chefCloud
 * imported from @convex-dev/feedback, or called with only
 * components.feedback. Init only inserts lines, so this is for the person.
 */
function oldChefCloud(src: string): boolean {
  if (importsName(src, "chefCloud", /^@convex-dev\/feedback$/)) return true;
  const call = /\bchefCloud\s*\(\s*components\.\w+\s*(\)|,\s*\{)/.exec(src);
  return call !== null;
}

const MIGRATE_CHEF_CLOUD = [
  "chefCloud is in @convex-dev/chef-cloud now, and takes both components. Change, by hand:",
  `  import { chefCloud } from "@convex-dev/feedback"   ->   import { chefCloud } from "${CHEF_CLOUD_PACKAGE}"`,
  "  chefCloud(components.feedback, ...)               ->   chefCloud(components.feedback, components.chefCloud, ...)",
  "Then run init again: it adds app.use(chefCloud) and the new exports.",
];

function planChefModule(o: EditOptions): Edit {
  const file = relative(o.appDir, join(o.convexDir, `${o.module}.ts`));
  const title = o.cloud ? "expose the Chef API and cloud builds" : "expose the Chef API";
  const src = read(join(o.appDir, file));
  if (src === null) return { file, title, action: "create", content: chefModuleFile(o) };
  if (oldChefCloud(src)) return { file, title, action: "manual", note: MIGRATE_CHEF_CLOUD };
  // An app already on chefCloud has cloud builds, whatever this run was asked for.
  if (/\bchefCloud\b/.test(src)) return exportsEdit(file, title, fillExports(src, "chefCloud"));
  if (!o.cloud) {
    if (/\bchefAdmin\b/.test(src)) return exportsEdit(file, title, fillExports(src, "chefAdmin"));
    return addBlock(file, title, src, `import { chefAdmin } from "@convex-dev/feedback";`, CHEF_ADMIN_EXPORTS, chefAdminBlock());
  }
  if (/\bchefAdmin\b/.test(src)) {
    return {
      file,
      title,
      action: "manual",
      note: [
        "It exports chefAdmin's functions, and chefCloud's include the same two. Remove the",
        "`export const { ... } = chefAdmin(components.feedback);` block, then run init again.",
      ],
    };
  }
  return addBlock(file, title, src, `import { chefCloud } from "${CHEF_CLOUD_PACKAGE}";`, CHEF_CLOUD_EXPORTS, chefCloudBlock());
}

/** Insert an import and an `export const { ... } = fn(...)` block at the end of an existing module. */
function addBlock(file: string, title: string, src: string, importLine: string, names: string[], block: string[]): Edit {
  const lines = src.split("\n");
  const imports: string[] = [importLine];
  if (!importsName(src, "components", GENERATED_API)) {
    if (/\bcomponents\b/.test(src)) {
      return {
        file,
        title,
        action: "manual",
        note: ["`components` here isn't imported from ./_generated/api; add the block by hand."],
        snippet: [imports[0], "", ...block],
      };
    }
    imports.push(`import { components } from "./_generated/api";`);
  }
  const clash = names.find((n) => new RegExp(`\\b${n}\\b`).test(src));
  if (clash) {
    return {
      file,
      title,
      action: "manual",
      note: [`\`${clash}\` is already defined here; export the functions by hand.`],
      snippet: [imports[0], "", ...block],
    };
  }
  const end = lines.length > 0 && lines[lines.length - 1] === "" ? lines.length - 1 : lines.length;
  const api = fillExports(src, null);
  if (api.blocking) return exportsEdit(file, title, api);
  return {
    file,
    title,
    action: "insert",
    inserts: [{ at: afterImports(lines), lines: imports }, ...api.inserts, { at: end, lines: ["", ...block] }],
    ...(api.notes.length ? { note: api.notes, snippet: api.snippet } : {}),
  };
}

type Filled = { inserts: Insert[]; notes: string[]; snippet: string[]; blocking: boolean };

function exportsEdit(file: string, title: string, f: Filled): Edit {
  if (f.blocking || (f.notes.length > 0 && f.inserts.length === 0)) {
    return { file, title, action: "manual", note: f.notes, snippet: f.snippet, optional: !f.blocking };
  }
  if (f.inserts.length > 0) {
    return { file, title, action: "insert", inserts: f.inserts, ...(f.notes.length ? { note: f.notes, snippet: f.snippet } : {}) };
  }
  return { file, title, action: "done" };
}

/**
 * An existing module's exposeChefApi exports, and its chefCloud or chefAdmin
 * ones, brought up to the full lists: the missing names go on a new line
 * before the closing brace. A name defined elsewhere in the file, or a list
 * on one line, is left for the person. Missing chefCloud or chefAdmin names
 * stop init (the workflows, the feedback component and the CLI need them); missing
 * exposeChefApi names only mean the panel lacks those views, so init
 * carries on.
 */
function fillExports(src: string, required: "chefCloud" | "chefAdmin" | null): Filled {
  const inserts: Insert[] = [];
  const notes: string[] = [];
  const snippet: string[] = [];
  let blocking = false;
  const lists: Array<readonly [string, string[], boolean]> = [
    ...(required === "chefCloud" ? [["chefCloud", CHEF_CLOUD_EXPORTS, true] as const] : []),
    ...(required === "chefAdmin" ? [["chefAdmin", CHEF_ADMIN_EXPORTS, true] as const] : []),
    ["exposeChefApi", CHEF_API_EXPORTS, false] as const,
  ];
  for (const [fn, names, isRequired] of lists) {
    const d = missingFromDestructure(src, fn, [...names]);
    if (!d || d.missing.length === 0) continue;
    const clash = d.missing.find((n) => new RegExp(`\\b${n}\\b`).test(src));
    if (d.at === null || clash) {
      notes.push(
        clash
          ? `\`${clash}\` is already defined here; add ${fn}'s missing exports by hand: ${d.missing.join(", ")}.`
          : `Add ${fn}'s missing exports to its \`export const { ... }\`: ${d.missing.join(", ")}.`,
      );
      snippet.push(`  ${d.missing.join(", ")},`);
      if (isRequired) blocking = true;
      continue;
    }
    inserts.push({ at: d.at, lines: [`${d.indent}${d.missing.join(", ")},`] });
  }
  return { inserts, notes, snippet, blocking };
}

function planHttp(o: EditOptions): Edit {
  const file = relative(o.appDir, join(o.convexDir, "http.ts"));
  const title = "mount the cloud runner's routes";
  const src = read(join(o.appDir, file));
  const call = `mountChefAgentRoutes(http, components.feedback);`;
  if (src === null) {
    return {
      file,
      title,
      action: "create",
      content: [
        `import { httpRouter } from "convex/server";`,
        `import { mountChefAgentRoutes } from "@convex-dev/feedback/http";`,
        `import { components } from "./_generated/api";`,
        "",
        "const http = httpRouter();",
        "",
        "// /chef-agent/*: the cloud runner's API and its model proxy.",
        call,
        "",
        "export default http;",
        "",
      ].join("\n"),
    };
  }
  if (/\bmountChefAgentRoutes\b/.test(src)) {
    // A third argument (runConfig, ...) replaces what chefCloud records for
    // the runner: the repo URL, gates, frontend and local env.
    const withOptions = /\bmountChefAgentRoutes\s*\(\s*\w+\s*,\s*[\w.]+\s*,/.test(src);
    return {
      file,
      title,
      action: "done",
      ...(withOptions
        ? {
            note: [
              "It passes mountChefAgentRoutes its own options. With chefCloud, drop them unless you mean to:",
              "a `runConfig` there replaces chefCloud's (the repo URL, gates, frontend and local env the runner gets).",
            ],
          }
        : {}),
    };
  }
  const lines = src.split("\n");
  const router = /(?:const|let)\s+(\w+)\s*=\s*httpRouter\s*\(/.exec(src)?.[1];
  const exportAt = router ? exportDefaultLine(lines, router) : -1;
  const routerCall = call.replace("(http,", `(${router ?? "http"},`);
  const imports = [`import { mountChefAgentRoutes } from "@convex-dev/feedback/http";`];
  const needComponents = !importsName(src, "components", GENERATED_API);
  if (needComponents) imports.push(`import { components } from "./_generated/api";`);
  if (!router || exportAt < 0 || (needComponents && /\bcomponents\b/.test(src))) {
    return {
      file,
      title,
      action: "manual",
      note: [
        !router || exportAt < 0
          ? "Couldn't find `const http = httpRouter()` and `export default http`."
          : "`components` here isn't imported from ./_generated/api.",
      ],
      snippet: [...imports, "", routerCall],
    };
  }
  return {
    file,
    title,
    action: "insert",
    inserts: [
      { at: afterImports(lines), lines: imports },
      { at: exportAt, lines: ["// /chef-agent/*: the cloud runner's API and its model proxy.", ...routerCall.split("\n"), ""] },
    ],
  };
}

/**
 * Chef has no crons (chefCrons registers nothing; README, "No crons"), so
 * there is nothing to add to convex/crons.ts. An app whose crons.ts still
 * calls chefCrons is told it can go; it pushes fine either way.
 */
function planCronsLeftover(o: EditOptions): Edit | null {
  const file = relative(o.appDir, join(o.convexDir, "crons.ts"));
  const src = read(join(o.appDir, file));
  if (src === null || !/\bchefCrons\s*\(/.test(src)) return null;
  return {
    file,
    title: "chefCrons is a no-op now: Chef has no crons",
    action: "done",
    note: [
      "chefCrons(...) registers nothing any more: builds are claimed on approval and when one finishes, stuck runs and",
      "ships get one deadline check each, and the cleanup runs when a run ends. Remove the call (and the file, if that",
      "was all it had) whenever convenient; the old \"chef sweep\" and \"chef cleanup\" crons go away at the next push.",
    ],
  };
}

/**
 * package.json's `chef:local-env` script, which chefCloud's localEnv "auto"
 * runs in the build. A line inserted at the top of "scripts" (or a new
 * "scripts" at the top of the file); anything else is printed.
 */
function planLocalEnvScript(o: EditOptions): Edit | null {
  if (o.requiredEnv.length === 0) return null;
  const file = "package.json";
  const title = `the \`${LOCAL_ENV_NPM_SCRIPT}\` script the build runs`;
  const src = read(join(o.appDir, file)) ?? "";
  const entry = `${JSON.stringify(LOCAL_ENV_NPM_SCRIPT)}: ${JSON.stringify(`node ${LOCAL_ENV_SCRIPT}`)}`;
  let pkg: { scripts?: Record<string, unknown> } | null = null;
  try {
    pkg = JSON.parse(src);
  } catch {
    pkg = null;
  }
  const manual = (why: string): Edit => ({ file, title, action: "manual", note: [why, "Add to its \"scripts\":"], snippet: [entry] });
  if (!pkg || typeof pkg !== "object") return manual("package.json isn't JSON init can read.");
  if (pkg.scripts && typeof pkg.scripts === "object" && LOCAL_ENV_NPM_SCRIPT in pkg.scripts) {
    const own = pkg.scripts[LOCAL_ENV_NPM_SCRIPT];
    // The app's own script: init writes no scripts/chef-local-env.mjs then.
    if (typeof own === "string" && !own.includes(LOCAL_ENV_SCRIPT)) {
      return {
        file,
        title,
        action: "done",
        note: [`It runs \`${own}\`, the app's own, so init writes no ${LOCAL_ENV_SCRIPT}. It must set ${o.requiredEnv.join(", ")}.`],
      };
    }
    return { file, title, action: "done" };
  }
  const lines = src.split("\n");
  if (pkg.scripts && typeof pkg.scripts === "object") {
    const at = lines.findIndex((l) => /^\s*"scripts"\s*:\s*\{\s*$/.test(l));
    const next = lines[at + 1];
    if (at < 0 || next === undefined || /^\s*\}/.test(next)) return manual("Couldn't find a multi-line \"scripts\" block.");
    const indent = /^\s*/.exec(next)?.[0] ?? "    ";
    return { file, title, action: "insert", inserts: [{ at: at + 1, lines: [`${indent}${entry},`] }] };
  }
  if (lines[0]?.trim() !== "{" || lines.length < 3) return manual("Couldn't find where the top-level object starts.");
  const indent = /^\s*/.exec(lines[1])?.[0] || "  ";
  return {
    file,
    title,
    action: "insert",
    inserts: [{ at: 1, lines: [`${indent}"scripts": {`, `${indent}${indent}${entry}`, `${indent}},`] }],
  };
}

/** package.json's `chef:local-env` script, or null. */
export function localEnvNpmScript(appDir: string): string | null {
  try {
    const pkg = JSON.parse(read(join(appDir, "package.json")) ?? "");
    const s = pkg?.scripts?.[LOCAL_ENV_NPM_SCRIPT];
    return typeof s === "string" ? s : null;
  } catch {
    return null;
  }
}

function planLocalEnv(o: EditOptions): Edit | null {
  if (o.requiredEnv.length === 0) return null;
  const file = LOCAL_ENV_SCRIPT;
  const title = "throwaway env vars for the build's local backend";
  // The app's own `chef:local-env` script, running something else: that is
  // the one the build runs, so init writes none.
  const own = localEnvNpmScript(o.appDir);
  if (own !== null && !own.includes(LOCAL_ENV_SCRIPT)) return null;
  if (existsSync(join(o.appDir, file))) {
    const src = read(join(o.appDir, file)) ?? "";
    const missing = o.requiredEnv.filter((n) => !src.includes(JSON.stringify(n)));
    if (missing.length === 0) return { file, title, action: "done" };
    return {
      file,
      title,
      action: "manual",
      note: [`It doesn't set ${missing.join(", ")}, which convex.config now requires. Add them to VARS.`],
    };
  }
  return { file, title, action: "create", content: localEnvScript(o.requiredEnv) };
}

function planPanel(o: EditOptions): Edit {
  const files = frontendFiles(o.appDir);
  const title = "show the panel";
  const at = files.find((f) => /ChefPanelMount|ChefPanel\b|<chef-panel/.test(read(f) ?? ""));
  if (at) return { file: relative(o.appDir, at), title, action: "done" };
  const auth = usesConvexAuth(o.appDir);
  const urlExpr =
    o.frontend.kind === "vite"
      ? `import.meta.env.${o.frontend.urlVar ?? "VITE_CONVEX_URL"}`
      : o.frontend.kind === "next"
        ? `process.env.${o.frontend.urlVar ?? "NEXT_PUBLIC_CONVEX_URL"}!`
        : `"https://YOUR-DEPLOYMENT.convex.cloud"`;
  const snippet =
    o.frontend.kind === "none"
      ? [
          `<script type="module" src="https://cdn.jsdelivr.net/gh/sethconvex/feedback@main/panel/chef-panel.browser.js"></script>`,
          `<chef-panel convex-url="https://YOUR-DEPLOYMENT.convex.cloud" prefix="${o.module}"></chef-panel>`,
        ]
      : [
          `import { ChefPanelMount } from "@convex-dev/feedback/react";`,
          ...(auth ? [`import { useAuthToken } from "@convex-dev/auth/react";`] : []),
          "",
          "// Inside your ConvexProvider, once:",
          auth
            ? `<ChefPanelMount convexUrl={${urlExpr}} token={useAuthToken()}${o.module === "chef" ? "" : ` prefix="${o.module}"`} />`
            : `<ChefPanelMount convexUrl={${urlExpr}} getToken={/* your provider's Convex token */}${o.module === "chef" ? "" : ` prefix="${o.module}"`} />`,
        ];
  return {
    file: o.frontend.kind === "none" ? "index.html" : "src/",
    title,
    action: "manual",
    note: ["Where the panel goes and where its sign-in token comes from are up to your app, so init doesn't add it."],
    snippet,
    optional: true,
  };
}

/** The npm script that runs before `npm run dev`. */
export const GUARD_NPM_SCRIPT = "predev";
export const GUARD_COMMAND = "chef guard";

/**
 * Whether `npm run dev` runs `convex dev` (the long-running one, not
 * `convex dev --once`): the `dev` script itself, or a script it names (`npm
 * run x`, `npm-run-all dev:*`, `concurrently "npm:x"`), and so on down. A
 * `convex dev --once` elsewhere (a ship script, say) doesn't count: `predev`
 * runs only before `npm run dev`.
 */
export function devRunsConvexDev(scripts: Record<string, unknown>): boolean {
  const runs = (x: string) => /\bconvex\s+dev\b(?![^&|;]*--once)/.test(x);
  const names = Object.keys(scripts).filter((n) => typeof scripts[n] === "string");
  const seen = new Set<string>();
  const queue = ["dev"];
  while (queue.length > 0) {
    const name = queue.shift() as string;
    if (seen.has(name) || typeof scripts[name] !== "string") continue;
    seen.add(name);
    const body = scripts[name] as string;
    if (runs(body)) return true;
    for (const raw of body.split(/[\s"'&|;()]+/)) {
      const t = raw.replace(/^npm:/, "");
      if (!t) continue;
      if (t.endsWith("*")) queue.push(...names.filter((n) => n.startsWith(t.slice(0, -1))));
      else if (t !== name && names.includes(t)) queue.push(t);
    }
  }
  return false;
}

/**
 * The deploy guard before `npm run dev`: `chef guard` refuses to let a dev
 * push go to the deployment "Ship it" deploys to while chef's `main` has
 * commits this checkout lacks (a local `convex dev` would roll back what
 * shipped). Added as package.json's `predev` when `npm run dev` runs
 * `convex dev` (devRunsConvexDev) and there is no `predev`; otherwise printed.
 */
function planGuardScript(o: EditOptions): Edit | null {
  const file = "package.json";
  const title = "the deploy guard before `npm run dev`";
  const src = read(join(o.appDir, file)) ?? "";
  let pkg: { scripts?: Record<string, unknown> } | null = null;
  try {
    pkg = JSON.parse(src);
  } catch {
    return null;
  }
  const scripts = pkg?.scripts && typeof pkg.scripts === "object" ? pkg.scripts : {};
  if (!devRunsConvexDev(scripts)) return null;
  const existing = scripts[GUARD_NPM_SCRIPT];
  if (typeof existing === "string") {
    if (existing.includes(GUARD_COMMAND)) return { file, title, action: "done" };
    return {
      file,
      title,
      action: "manual",
      optional: true,
      note: [`It has its own "${GUARD_NPM_SCRIPT}". Start it with the guard, so \`npm run dev\` can't roll back what shipped:`],
      snippet: [`"${GUARD_NPM_SCRIPT}": "${GUARD_COMMAND} && ${existing.replace(/"/g, '\\"')}"`],
    };
  }
  const lines = src.split("\n");
  const at = lines.findIndex((l) => /^\s*"scripts"\s*:\s*\{\s*$/.test(l));
  const next = lines[at + 1];
  if (at < 0 || next === undefined || /^\s*\}/.test(next)) {
    return { file, title, action: "manual", optional: true, note: ["Couldn't find a multi-line \"scripts\" block. Add to it:"], snippet: [`"${GUARD_NPM_SCRIPT}": "${GUARD_COMMAND}"`] };
  }
  const indent = /^\s*/.exec(next)?.[0] ?? "    ";
  return { file, title, action: "insert", inserts: [{ at: at + 1, lines: [`${indent}"${GUARD_NPM_SCRIPT}": "${GUARD_COMMAND}",`] }] };
}

export function planEdits(o: EditOptions): Edit[] {
  const cloud = o.cloud
    ? [planCronsLeftover(o), planHttp(o), planLocalEnv(o), planLocalEnvScript(o), planGuardScript(o)]
    : [];
  return [planConfig(o), planChefModule(o), ...cloud, planPanel(o)].filter((e): e is Edit => e !== null);
}

// ------------------------------------------------------------------ rendering and applying

/** The edits as text for the terminal: whole new files, inserted lines with a line of context. */
export function renderEdit(e: Edit, appDir: string): string[] {
  const out: string[] = [];
  const tag = { create: "new file", insert: "add lines", done: "already there", manual: "by hand" }[e.action];
  out.push(`  ${e.file}: ${e.title} (${tag})`);
  if (e.action === "create") {
    for (const l of (e.content ?? "").replace(/\n$/, "").split("\n")) out.push(`    + ${l}`);
    for (const n of e.note ?? []) out.push(`    ${n}`);
  } else if (e.action === "insert") {
    const lines = (read(join(appDir, e.file)) ?? "").split("\n");
    for (const ins of e.inserts ?? []) {
      out.push(`    @@ line ${ins.at + 1}`);
      if (ins.at > 0) out.push(`      ${lines[ins.at - 1]}`);
      for (const l of ins.lines) out.push(`    + ${l}`);
      if (ins.at < lines.length && lines[ins.at] !== undefined) out.push(`      ${lines[ins.at]}`);
    }
    // Something init leaves for the person, next to what it adds.
    for (const n of e.note ?? []) out.push(`    ${n}`);
    for (const l of e.snippet ?? []) out.push(`    | ${l}`);
  } else if (e.action === "manual") {
    for (const n of e.note ?? []) out.push(`    ${n}`);
    for (const l of e.snippet ?? []) out.push(`    | ${l}`);
  }
  return out;
}

/**
 * Applies create and insert edits; returns the files written. Never
 * overwrites an existing file wholesale, and never writes outside appDir:
 * every target is checked (by its real path) before anything is written,
 * and again right before its own write.
 */
export function applyEdits(edits: Edit[], appDir: string): string[] {
  const written: string[] = [];
  const writes = edits.filter((e) => e.action === "create" || e.action === "insert");
  for (const e of writes) containedPath(appDir, e.file);
  for (const e of writes) {
    const path = containedPath(appDir, e.file);
    if (e.action === "create") {
      if (existsSync(path)) throw new Error(`${e.file} appeared while init was running; not overwriting it`);
      mkdirSync(dirname(path), { recursive: true });
      writeFileSync(path, e.content ?? "", { flag: "wx", mode: e.file.endsWith(".mjs") ? 0o755 : 0o644 });
      written.push(e.file);
    } else if (e.action === "insert") {
      const lines = readFileSync(path, "utf8").split("\n");
      // Bottom first, so earlier indexes stay right.
      const inserts = [...(e.inserts ?? [])].sort((a, b) => b.at - a.at);
      for (const ins of inserts) lines.splice(ins.at, 0, ...ins.lines);
      writeFileSync(path, lines.join("\n"));
      written.push(e.file);
    }
  }
  return written;
}

export function pendingEdits(edits: Edit[]): Edit[] {
  return edits.filter((e) => e.action === "create" || e.action === "insert");
}
