// @convex-dev/chef-cloud from the CLI's side: whether an app has it, and
// vendoring it. It ships from this repo's `dist/chef-cloud` branch (built by
// scripts/publish-dist.sh), which an app's `npm ci` and Chef's build sandbox
// can't reach (they reach only the npm registry), so `chef init --cloud`
// packs it into the app's vendor/ and installs the tarball, as the runbook
// does for @convex-dev/feedback itself.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { scrub } from "../src/chef/scrub.ts";
import { CliError, lastLines, type Deps } from "./deps.ts";

export const CHEF_CLOUD = "@convex-dev/chef-cloud";
/** Where `--cloud` gets chef-cloud unless --cloud-from (or CHEF_CLOUD_PACKAGE) says otherwise. */
export const DEFAULT_CHEF_CLOUD_SOURCE = "github:sethconvex/feedback-chef#dist/chef-cloud";
export const VENDOR_DIR = "vendor";

/** Whether the app has @convex-dev/chef-cloud installed. */
export function chefCloudInstalled(appDir: string): boolean {
  return existsSync(join(appDir, "node_modules", "@convex-dev", "chef-cloud", "package.json"));
}

/** Whether the app's package.json depends on it (installed or not). */
export function chefCloudDeclared(appDir: string): boolean {
  try {
    const pkg = JSON.parse(readFileSync(join(appDir, "package.json"), "utf8"));
    return [pkg?.dependencies, pkg?.devDependencies].some((d) => d && typeof d === "object" && CHEF_CLOUD in d);
  } catch {
    return false;
  }
}

/** The app's package manager, by lockfile. */
export function packageManager(appDir: string): "npm" | "pnpm" | "yarn" | "bun" | null {
  if (existsSync(join(appDir, "package-lock.json"))) return "npm";
  if (existsSync(join(appDir, "pnpm-lock.yaml"))) return "pnpm";
  if (existsSync(join(appDir, "yarn.lock"))) return "yarn";
  if (existsSync(join(appDir, "bun.lock")) || existsSync(join(appDir, "bun.lockb"))) return "bun";
  return null;
}

/** What vendoring chef-cloud runs, for the person to read (or run themselves with pnpm, yarn or bun). */
export function installLines(source: string, pm: ReturnType<typeof packageManager>): string[] {
  const add = pm === "pnpm" ? "pnpm add" : pm === "yarn" ? "yarn add" : pm === "bun" ? "bun add" : "npm install";
  return [
    `npm pack ${source} --pack-destination ${VENDOR_DIR}`,
    `${add} ./${VENDOR_DIR}/<the .tgz it wrote>   # "${CHEF_CLOUD}": "file:${VENDOR_DIR}/<file>"`,
  ];
}

/**
 * Vendor @convex-dev/chef-cloud: `npm pack <source>` into vendor/, then
 * `npm install` the tarball, which records `file:vendor/<tgz>` in
 * package.json and the lockfile. npm only: with another package manager
 * the person runs installLines' commands. Returns the files it changed.
 */
export async function installChefCloud(appDir: string, deps: Deps, source: string): Promise<string[]> {
  const pm = packageManager(appDir);
  if (pm !== "npm") {
    throw new CliError(
      [
        `This app uses ${pm ?? "no lockfile"}; install ${CHEF_CLOUD} yourself, then run init again:`,
        ...installLines(source, pm).map((l) => `  ${l}`),
      ].join("\n"),
      3,
    );
  }
  const [cmd, ...pre] = deps.npm;
  mkdirSync(join(appDir, VENDOR_DIR), { recursive: true });
  const pack = await deps.exec(cmd, [...pre, "pack", source, "--pack-destination", VENDOR_DIR, "--json"], { cwd: appDir });
  if (pack.code !== 0) throw new CliError(`npm pack ${source} failed:\n${scrub(lastLines(pack.stderr, 12))}`);
  let filename: unknown;
  try {
    const out = JSON.parse(pack.stdout);
    filename = Array.isArray(out) ? out[0]?.filename : undefined;
  } catch {
    filename = undefined;
  }
  if (typeof filename !== "string" || !/^[\w.@-]+\.tgz$/.test(filename.replace(/^.*\//, ""))) {
    throw new CliError(`npm pack ${source} didn't say which tarball it wrote`);
  }
  const tgz = `${VENDOR_DIR}/${filename.replace(/^.*\//, "")}`;
  const install = await deps.exec(cmd, [...pre, "install", `./${tgz}`], { cwd: appDir });
  if (install.code !== 0) throw new CliError(`npm install ./${tgz} failed:\n${scrub(lastLines(install.stderr, 12))}`);
  if (!chefCloudInstalled(appDir)) throw new CliError(`npm install ./${tgz} finished, but ${CHEF_CLOUD} isn't in node_modules`);
  return [tgz, "package.json", "package-lock.json"];
}
