// `npx chef work`: a worker on the developer's own machine that builds
// approved Chef requests with their own Claude Code subscription (or Codex),
// instead of a cloud build sandbox.
//
//   chef work [--agent claude|codex] [--container docker|none] [--once]
//             [--preview auto|cloud|local|none] [--url <https://x.convex.site>]
//             [--image <tag>] [--skills <dir> | --no-skills] [--model <name>]
//             [--keep] [--poll <seconds>]
//   chef work --setup [--name <n>]  a new worker key from the deployment
//                                   (chefCreateWorkerKey), saved 0600, never shown
//   chef work --save-key            a Chef agent key, from stdin, to a 0600 file
//   chef work --save-claude-token   a `claude setup-token` token, from stdin, to a 0600 file
//
// It presents the Chef agent key to POST /chef-agent/enroll every few
// seconds (backing off while there's nothing to do). Enroll claims the
// oldest request an admin approved, through the same claim as every other
// path, and returns a credential bound to that one run. The run then goes
// through the cloud runner in local mode (runner/local/run.ts): the same
// clone, prompt, skills, gates, guards, commit, push and phase reports, so
// the panel shows it like any other build, marked "built locally".
//
// Only requests an admin wrote, always. The agent holds the developer's
// reusable Claude or Codex login (a long-lived token in its environment, or
// a readable auth.json), and the container's network is open, so a member's
// request text could tell the agent to send that login somewhere. Enroll
// asks the server for admin-written requests only, and the server gives a
// worker key nothing else (the claim checks the author's role); members'
// requests are built only in the cloud, where the agent gets a run-bound
// inference proxy and a sandbox's egress. There is no flag to change that.
// A safe local path for members' requests needs the login out of the
// agent's reach: a host-side inference proxy holding it, a short-lived
// capability bound to the run, and container egress limited to that proxy
// and Chef. That's future work.
//
// The agent is the developer's own login, so Chef's spend ceiling doesn't
// apply to it. By default it runs in a Docker container that sees only the
// run's checkout and its own files (runner/local/docker.ts); `--container
// none` runs it as the developer, and says so.
//
// After the push: `--preview auto` (the default) hands the run to the app's
// cloud preview if the app registered one, else finishes it without a
// preview; `local` deploys the request's preview (chef-req-<number>) from here with the developer's
// preview deploy key (runner/local/preview.ts); `none` finishes it.
//
// The key comes from CHEF_AGENT_KEY or ~/.config/chef/<deployment>.key
// (0600). It only ever travels in enroll's Authorization header: never in an
// argv, a log line, or a child process's environment. A "worker" key
// (chefCreateWorkerKey) only lets this worker enroll; it doesn't turn the
// app's cloud builds on.
//
// Exit codes: 0 done, 1 failed, 2 usage, 3 something to set up first, 130
// cancelled.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { Convex } from "./convex.ts";
import { defaultDeps as defaultCliDeps } from "./deps.ts";
import { chmodSync, existsSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from "node:fs";
import { homedir, hostname } from "node:os";
import { join, resolve } from "node:path";
import { scrub } from "../src/chef/scrub.ts";
import { enroll, finish, heartbeat, type Claim, type FinishBody } from "../runner/local/api.ts";
import { dockerCli, defaultImageTag, ensureImage } from "../runner/local/docker.ts";
import type { AgentKind, Container } from "../runner/local/env.ts";
import { chefRemoteUrl, fillGitAuth } from "../runner/local/git-auth.ts";
import { deployLocalPreview, type LocalPreview, type LocalPreviewOpts } from "../runner/local/preview.ts";
import { itemNumberOfBranch } from "../src/chef/preview.ts";
import { startLocalRun, type LocalRunHandle, type LocalRunOpts } from "../runner/local/run.ts";

export const WORK_USAGE = `usage: chef work [options]

Builds approved Chef requests on this machine with your own Claude Code
(or Codex) login, one at a time, until you stop it.

  --agent claude|codex       the agent (default claude)
  --container docker|none    where the agent runs (default docker: a container that
                             sees only the run's checkout); none runs it as you
  --once                     exit after one run
  --preview auto|cloud|local|none
                             after the push: auto (default) hands the run to the app's
                             cloud preview if it has one; local deploys chef-req-<n>
                             from here with CHEF_PREVIEW_DEPLOY_KEY; none skips it
  --url <site url>           the app's https://<deployment>.convex.site
                             (default: from .env.local)
  --image <tag>              the container image (default: built once from the pinned
                             Dockerfile)
  --skills <dir>             skills to load, <dir>/<name>/SKILL.md (default: the app's
                             .claude/skills, if any)
  --no-skills                no skills
  --model <name>             the agent's model (default: its own default)
  --keep                     keep each run's directory
  --poll <seconds>           how often to ask for work (default 5)

Only requests an admin wrote are built here; members' requests are built in the
cloud. The agent holds your reusable login, and a member's text could get it to
send that login away.

  --setup                    create a worker key on the deployment (chefCreateWorkerKey,
                             through npx convex run) and save it like --save-key,
                             without showing it. A worker key lets this machine build;
                             it never turns the app's cloud builds on
    --name <name>            the key's name (default chef work on <hostname>)
    --module <name>          the convex/ module with the chef functions (default chef)
    --new-key                replace a key already saved for this deployment
  --save-key                 save a Chef agent key (read from stdin) for this
                             deployment, to ~/.config/chef/<deployment>.key, mode 0600:
                             npx chef worker-key | npx chef work --save-key
  --save-claude-token        save a \`claude setup-token\` token (read from stdin), which
                             Claude Code in a container needs

The key can also come from CHEF_AGENT_KEY.`;

export type WorkFlags = {
  help: boolean;
  agent: AgentKind;
  container: Container;
  once: boolean;
  preview: "auto" | "cloud" | "local" | "none";
  url?: string;
  image?: string;
  skills?: string | false;
  model?: string;
  keep: boolean;
  pollMs: number;
  saveKey: boolean;
  saveClaudeToken: boolean;
  setup: boolean;
  newKey: boolean;
  module: string;
  keyName?: string;
};

export class WorkError extends Error {
  code: number;
  constructor(message: string, code: number) {
    super(message);
    this.code = code;
  }
}

export function parseWorkArgs(argv: string[]): WorkFlags {
  const f: WorkFlags = {
    help: false,
    agent: "claude",
    container: "docker",
    once: false,
    preview: "auto",
    keep: false,
    pollMs: 5000,
    saveKey: false,
    saveClaudeToken: false,
    setup: false,
    newKey: false,
    module: "chef",
  };
  const usage = (m: string) => new WorkError(`${m}\n${WORK_USAGE}`, 2);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => {
      const x = argv[++i];
      if (x === undefined || x.startsWith("--")) throw usage(`${a} needs a value`);
      return x;
    };
    if (a === "-h" || a === "--help") f.help = true;
    else if (a === "--agent") {
      const x = val();
      if (x !== "claude" && x !== "codex") throw usage("--agent is claude or codex");
      f.agent = x;
    } else if (a === "--container") {
      const x = val();
      if (x !== "docker" && x !== "none") throw usage("--container is docker or none");
      f.container = x;
    } else if (a === "--preview") {
      const x = val();
      if (x !== "auto" && x !== "cloud" && x !== "local" && x !== "none") throw usage("--preview is auto, cloud, local or none");
      f.preview = x;
    } else if (a === "--once") f.once = true;
    else if (a === "--url") f.url = val();
    else if (a === "--image") f.image = val();
    else if (a === "--skills") f.skills = val();
    else if (a === "--no-skills") f.skills = false;
    else if (a === "--model") {
      f.model = val();
      if (!/^[A-Za-z0-9._:/-]{1,100}$/.test(f.model)) throw usage("--model takes a plain model name");
    } else if (a === "--keep") f.keep = true;
    else if (a === "--poll") {
      const n = Number(val());
      if (!Number.isFinite(n) || n < 1 || n > 600) throw usage("--poll takes 1 to 600 seconds");
      f.pollMs = n * 1000;
    } else if (a === "--save-key") f.saveKey = true;
    else if (a === "--setup") f.setup = true;
    else if (a === "--new-key") f.newKey = true;
    else if (a === "--name") {
      f.keyName = val();
      if (!/^[A-Za-z0-9 ._@:-]{1,100}$/.test(f.keyName)) throw usage("--name takes up to 100 letters, digits, spaces and ._@:-");
    } else if (a === "--module") {
      f.module = val();
      if (!/^[A-Za-z_][\w/]*$/.test(f.module)) throw usage("--module takes a module path like chef or admin/chef");
    }
    else if (a === "--save-claude-token") f.saveClaudeToken = true;
    else if (a === "--allow-member-requests") {
      throw usage(
        "--allow-member-requests is gone: members' requests are built only in the cloud, since a local agent holds your reusable login",
      );
    } else throw usage(`Unknown option ${a}`);
  }
  if (f.setup && f.saveKey) throw usage("--setup and --save-key are two ways to get a key; pick one");
  if (f.image !== undefined && !/^[A-Za-z0-9._/:@-]{1,200}$/.test(f.image)) throw usage("--image takes an image reference");
  return f;
}

// ------------------------------------------------------------- settings

/** A value from a dotenv file's text, or null. */
export function dotenvValue(text: string, name: string): string | null {
  for (const line of text.split("\n")) {
    const m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(line);
    if (!m || m[1] !== name) continue;
    let v = m[2].replace(/\s+#.*$/, "");
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    return v;
  }
  return null;
}

/** The app's site URL: --url, CHEF_SITE_URL, then .env.local (CONVEX_SITE_URL, a *.convex.cloud URL, or CONVEX_DEPLOYMENT). */
export function resolveSiteUrl(appDir: string, env: Record<string, string | undefined>, flag?: string): string {
  const file = join(appDir, ".env.local");
  const text = existsSync(file) ? readFileSync(file, "utf8") : "";
  const from = (name: string) => env[name] ?? dotenvValue(text, name);
  let url = flag ?? env.CHEF_SITE_URL ?? from("CONVEX_SITE_URL");
  if (!url) {
    for (const name of ["CONVEX_URL", "VITE_CONVEX_URL", "NEXT_PUBLIC_CONVEX_URL"]) {
      const c = from(name);
      const m = c ? /^https:\/\/([a-z0-9-]+)\.convex\.cloud\/?$/.exec(c) : null;
      if (m) {
        url = `https://${m[1]}.convex.site`;
        break;
      }
    }
  }
  if (!url) {
    const dep = from("CONVEX_DEPLOYMENT");
    const m = dep ? /^(?:dev|prod):([a-z0-9-]+)(?:\s|$)/.exec(dep) : null;
    if (m) url = `https://${m[1]}.convex.site`;
  }
  if (!url) throw new WorkError("Couldn't tell the app's site URL; pass --url https://<deployment>.convex.site", 3);
  return checkSiteUrl(url);
}

export function checkSiteUrl(url: string): string {
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    throw new WorkError(`--url ${JSON.stringify(url)} is not a URL`, 2);
  }
  const local = u.protocol === "http:" && (u.hostname === "127.0.0.1" || u.hostname === "localhost");
  if (u.protocol !== "https:" && !local) throw new WorkError("the site URL must be https", 2);
  if (u.username || u.password || u.search || u.hash || (u.pathname !== "/" && u.pathname !== "")) {
    throw new WorkError("the site URL must be an origin, like https://happy-otter-123.convex.site", 2);
  }
  return u.origin;
}

/** The deployment's name, for the key file: the first label of a *.convex.site host. */
export function deploymentOf(siteUrl: string): string {
  const host = new URL(siteUrl).hostname;
  const m = /^([a-z0-9-]+)\.convex\.site$/.exec(host);
  return (m ? m[1] : host).replace(/[^A-Za-z0-9.-]/g, "_");
}

export const configDir = (home: string) => join(home, ".config", "chef");
export const keyPath = (home: string, deployment: string) => join(configDir(home), `${deployment}.key`);
export const claudeTokenPath = (home: string) => join(configDir(home), "claude-token");

/** A secret from a file only its owner can read. */
export function readSecretFile(path: string): string | null {
  if (!existsSync(path)) return null;
  const st = statSync(path);
  if ((st.mode & 0o077) !== 0) {
    throw new WorkError(`${path} can be read by others; chmod 600 it (or save it again)`, 3);
  }
  if (process.getuid && st.uid !== process.getuid()) throw new WorkError(`${path} isn't yours`, 3);
  return readFileSync(path, "utf8").trim();
}

/** Writes a secret 0600 in a 0700 dir, atomically. */
export function writeSecretFile(path: string, value: string): void {
  const dir = resolve(path, "..");
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  chmodSync(dir, 0o700);
  const tmp = `${path}.tmp-${process.pid}`;
  writeFileSync(tmp, value + "\n", { mode: 0o600 });
  chmodSync(tmp, 0o600);
  renameSync(tmp, path);
}

const CHEF_KEY = /^chefk_[A-Za-z0-9]{16,256}$/;

/** Every variable that holds one of this worker's secrets; children never get them. */
export const WORKER_SECRET_ENV = ["CHEF_AGENT_KEY", "CLAUDE_CODE_OAUTH_TOKEN", "CHEF_PREVIEW_DEPLOY_KEY"];

// ------------------------------------------------------------------ deps

export type WorkDeps = {
  cwd: string;
  env: Record<string, string | undefined>;
  home: string;
  hostname: string;
  /** Progress, to stderr. Every line is scrubbed first. */
  log: (line: string) => void;
  fetch: typeof fetch;
  sleep: (ms: number) => Promise<void>;
  readStdin: () => Promise<string>;
  /** Registers Ctrl-C; returns the unregister function. */
  onInterrupt: (handler: () => void) => () => void;
  startRun: (o: LocalRunOpts) => LocalRunHandle;
  deployPreview: (o: LocalPreviewOpts) => Promise<LocalPreview>;
  /** Checks Docker and the image; throws a WorkError if it can't be used. */
  prepareDocker: (image: string | undefined, env: Record<string, string | undefined>, log: (l: string) => void) => string;
  remoteUrl: (appDir: string, env: Record<string, string | undefined>) => Promise<string>;
  /** A new worker key from the deployment's chefCreateWorkerKey (npx convex run). Kept in memory only. */
  createWorkerKey: (o: { appDir: string; module: string; name: string }) => Promise<string>;
  /** A second Ctrl-C. */
  exit: (code: number) => void;
};

async function readAll(): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const c of process.stdin) chunks.push(c as Buffer);
  return Buffer.concat(chunks).toString("utf8");
}

function realPrepareDocker(image: string | undefined, env: Record<string, string | undefined>, log: (l: string) => void): string {
  const docker = dockerCli("docker", env);
  let ok = false;
  try {
    ok = docker(["version", "--format", "{{.Server.Version}}"]).code === 0;
  } catch {
    ok = false;
  }
  if (!ok) {
    throw new WorkError(
      "Docker isn't running here. Start it, or run with --container none (the agent then runs as you, with access to everything you can reach).",
      3,
    );
  }
  const tag = image ?? defaultImageTag();
  ensureImage(docker, tag, log);
  return tag;
}

export function defaultWorkDeps(): WorkDeps {
  return {
    cwd: process.cwd(),
    env: process.env,
    home: homedir(),
    hostname: hostname(),
    log: (l) => process.stderr.write(l + "\n"),
    fetch: (...a) => fetch(...a),
    sleep: (ms) => new Promise((r) => setTimeout(r, ms)),
    readStdin: readAll,
    onInterrupt: (h) => {
      process.on("SIGINT", h);
      process.on("SIGTERM", h);
      return () => {
        process.off("SIGINT", h);
        process.off("SIGTERM", h);
      };
    },
    startRun: startLocalRun,
    deployPreview: deployLocalPreview,
    prepareDocker: realPrepareDocker,
    remoteUrl: (appDir, env) => chefRemoteUrl(appDir, { env }),
    createWorkerKey: async ({ appDir, module, name }) =>
      await new Convex(defaultCliDeps(), { cwd: appDir, module, prod: false }).run<string>("chefCreateWorkerKey", { name }),
    exit: (code) => process.exit(code),
  };
}

// ------------------------------------------------------------------ main

export async function work(argv: string[], partial: Partial<WorkDeps> = {}): Promise<number> {
  const deps: WorkDeps = { ...defaultWorkDeps(), ...partial };
  const secrets: string[] = [];
  const log = (l: string) => deps.log(scrub(l, { knownValues: secrets }));
  try {
    return await workMain(argv, deps, secrets, log);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    log(`chef work: ${msg}`);
    return e instanceof WorkError ? e.code : 1;
  }
}

async function workMain(argv: string[], deps: WorkDeps, secrets: string[], log: (l: string) => void): Promise<number> {
  const flags = parseWorkArgs(argv);
  if (flags.help) {
    deps.log(WORK_USAGE);
    return 0;
  }
  const appDir = deps.cwd;

  if (flags.saveClaudeToken) {
    const token = (await deps.readStdin()).trim().split("\n")[0]?.trim() ?? "";
    secrets.push(token);
    if (!/^[A-Za-z0-9._~+/=-]{20,4096}$/.test(token)) throw new WorkError("That doesn't look like a token from `claude setup-token`", 2);
    const path = claudeTokenPath(deps.home);
    writeSecretFile(path, token);
    log(`chef work: saved the Claude Code token to ${path} (mode 0600)`);
    return 0;
  }

  const siteUrl = resolveSiteUrl(appDir, deps.env, flags.url);
  const deployment = deploymentOf(siteUrl);

  if (flags.saveKey) {
    // `npx convex run` prints a string as JSON, quotes and all.
    const key = (await deps.readStdin()).trim().split("\n")[0]?.trim().replace(/^"(.*)"$/, "$1") ?? "";
    secrets.push(key);
    if (!CHEF_KEY.test(key)) throw new WorkError("That isn't a Chef agent key (chefk_...)", 2);
    const path = keyPath(deps.home, deployment);
    writeSecretFile(path, key);
    log(`chef work: saved the Chef agent key for ${deployment} to ${path} (mode 0600)`);
    return 0;
  }

  if (flags.setup) {
    const path = keyPath(deps.home, deployment);
    if (!flags.newKey && existsSync(path)) {
      readSecretFile(path); // refuses a file others can read
      log(`chef work: ${path} already holds a key for ${deployment}; nothing to do (--new-key replaces it)`);
      log("chef work: start building with: npx chef work");
      return 0;
    }
    const name = flags.keyName ?? `chef work on ${deps.hostname}`.replace(/[^A-Za-z0-9 ._@:-]/g, "").slice(0, 100);
    let key: string;
    try {
      key = String(await deps.createWorkerKey({ appDir, module: flags.module, name }));
    } catch (e) {
      throw new WorkError(
        `Couldn't create a worker key: ${(e as Error).message}\n` +
          `Is chefCreateWorkerKey exported from convex/${flags.module}.ts and pushed? (npx chef init adds it)`,
        3,
      );
    }
    secrets.push(key);
    if (!CHEF_KEY.test(key)) throw new WorkError(`${flags.module}:chefCreateWorkerKey didn't return a Chef agent key`, 1);
    writeSecretFile(path, key);
    log(`chef work: created worker key "${name}" for ${deployment} and saved it to ${path} (mode 0600)`);
    log("chef work: it lets this machine build approved requests; it doesn't turn cloud builds on");
    log("chef work: start building with: npx chef work");
    return 0;
  }

  const key = deps.env.CHEF_AGENT_KEY?.trim() || readSecretFile(keyPath(deps.home, deployment));
  if (!key) {
    throw new WorkError(
      `No Chef agent key for ${deployment}. Run: npx chef work --setup (creates a worker key with chefCreateWorkerKey and saves it)`,
      3,
    );
  }
  secrets.push(key);
  if (!CHEF_KEY.test(key)) throw new WorkError("The Chef agent key isn't one (chefk_...)", 3);

  let claudeToken: string | undefined;
  if (flags.agent === "claude") {
    claudeToken = deps.env.CLAUDE_CODE_OAUTH_TOKEN?.trim() || readSecretFile(claudeTokenPath(deps.home)) || undefined;
    if (claudeToken) secrets.push(claudeToken);
  }
  const codexAuthPath = join(deps.env.CODEX_HOME ?? join(deps.home, ".codex"), "auth.json");

  // Children get the developer's environment minus this worker's secrets.
  const hostEnv: Record<string, string | undefined> = { ...deps.env };
  for (const k of WORKER_SECRET_ENV) delete hostEnv[k];

  const remoteUrl = await deps.remoteUrl(appDir, hostEnv);
  const skillsDir =
    flags.skills === false ? false : flags.skills !== undefined ? resolve(appDir, flags.skills) : existsSync(join(appDir, ".claude", "skills")) ? join(appDir, ".claude", "skills") : false;
  if (skillsDir !== false && !existsSync(skillsDir)) throw new WorkError(`no skills at ${skillsDir}`, 2);

  let image: string | undefined;
  if (flags.container === "docker") {
    if (flags.agent === "claude" && !claudeToken) {
      throw new WorkError(
        "Claude Code in a container needs a long-lived token: run `claude setup-token`, then `npx chef work --save-claude-token` and paste it. " +
          "Or run with --container none to use your normal login (the agent then runs as you).",
        3,
      );
    }
    if (flags.agent === "codex" && !existsSync(codexAuthPath)) throw new WorkError("Codex isn't logged in here; run `codex login`", 3);
    image = deps.prepareDocker(flags.image, hostEnv, log);
  } else {
    log("chef work: WARNING: --container none runs the agent as you, on this machine, with your files, keys and logins");
    log("chef work: within reach of the code it writes. Use it only for requests you'd run yourself.");
  }

  log("chef work: building only requests an admin wrote; members' requests are built in the cloud");
  log(`chef work: ${siteUrl}, agent ${flags.agent}, ${flags.container === "docker" ? `container ${image}` : "no container"}, preview ${flags.preview}`);
  log(
    `chef work: the agent uses your own ${flags.agent === "claude" ? "Claude" : "Codex"} login; Chef's spend ceiling doesn't apply to it. Ctrl-C stops.`,
  );

  // Ctrl-C: the first one stops the run (failed, worktree removed) or, mid-push,
  // lets the push finish; the second leaves at once.
  let stopping = false;
  let current: { handle: LocalRunHandle; runId: string; credential: string } | null = null;
  let interrupts = 0;
  let cancelled: Promise<void> | null = null;
  const unregister = deps.onInterrupt(() => {
    interrupts++;
    stopping = true;
    if (interrupts > 1) {
      log("chef work: stopping now; the run, if any, goes stale and is cleaned up on the server");
      deps.exit(130);
      return;
    }
    if (!current) {
      log("chef work: stopping");
      return;
    }
    const c = current;
    if (["pushing", "pushed", "previewing", "done"].includes(c.handle.phase())) {
      log("chef work: the run is pushing; letting it finish (Ctrl-C again to leave now)");
      return;
    }
    log("chef work: cancelling the run");
    cancelled = (async () => {
      const r = await finish(siteUrl, c.credential, { outcome: "failed", error: `cancelled on ${deps.hostname}` }, { fetch: deps.fetch, sleep: deps.sleep });
      if (!r.ok) log(`chef work: couldn't mark the run cancelled: ${r.status} ${r.error}`);
      await c.handle.killAgents().catch(() => {});
    })();
  });

  try {
    let wait = flags.pollMs;
    let lastState = "";
    let lastCode = 0;
    const say = (state: string, line: string) => {
      if (state !== lastState) log(line);
      lastState = state;
    };
    while (!stopping) {
      let a;
      try {
        a = await enroll(siteUrl, key, deps.fetch, { requests: "admin" });
      } catch (e) {
        say("offline", `chef work: can't reach ${siteUrl} (${(e as Error).message}); retrying`);
        await deps.sleep(wait);
        wait = Math.min(wait * 2, 60_000);
        continue;
      }
      if (a.kind === "refused") {
        if (a.status === 401) throw new WorkError(`The Chef agent key was refused: ${a.error}`, 1);
        say(`refused${a.status}`, `chef work: enroll refused (${a.status}): ${a.error}; retrying`);
        await deps.sleep(wait);
        wait = Math.min(wait * 2, 60_000);
        continue;
      }
      if (a.kind === "wait") {
        say(stateOf(a.claim), `chef work: ${describe(a.claim)}`);
        await deps.sleep(wait);
        wait = Math.min(Math.round(wait * 1.5), 30_000);
        continue;
      }
      lastState = "";
      wait = flags.pollMs;
      secrets.push(a.credential);
      log(`chef work: claimed run ${a.runId}${a.rotated ? " (again, after a lost answer)" : ""}`);
      if (a.requestedBy !== "admin") {
        // The server only hands out admin-written requests when asked; an
        // older deployment may not know to. Never run the agent on it.
        lastCode = await failed(
          deps,
          log,
          siteUrl,
          a.credential,
          "npx chef work only builds requests an admin wrote, and the deployment didn't say this one is; " +
            "update the deployment (npx convex deploy), or build it in the cloud",
        );
        if (flags.once) return lastCode;
        continue;
      }
      const handle = deps.startRun({
        runId: a.runId,
        credential: a.credential,
        siteUrl,
        appDir,
        remoteUrl,
        agent: flags.agent,
        container: flags.container,
        hostEnv,
        baseDir: join(deps.home, ".cache", "chef", "work"),
        hostname: deps.hostname,
        ...(claudeToken ? { claudeToken } : {}),
        ...(flags.agent === "codex" ? { codexAuthPath } : {}),
        skillsDir,
        ...(image ? { image } : {}),
        ...(flags.model ? { model: flags.model } : {}),
        deny: [configDir(deps.home), join(deps.home, ".ssh"), join(deps.home, ".convex"), join(deps.home, ".aws"), join(deps.home, ".config", "gh")],
        keep: flags.keep,
        fetch: deps.fetch,
        print: log,
        onPhase: (p) => log(`chef work: phase ${p}`),
      });
      current = { handle, runId: a.runId, credential: a.credential };
      const result = await handle.done;
      if (cancelled) await cancelled;
      current = null;
      if (cancelled) {
        log(`chef work: run ${a.runId} cancelled`);
        return 130;
      }
      lastCode = result.ok
        ? await afterPush(flags, deps, log, {
            siteUrl,
            appDir,
            remoteUrl,
            hostEnv,
            credential: a.credential,
            sha: result.commitSha!,
            itemNumber: itemNumberOfBranch(result.branch),
          })
        : await failed(deps, log, siteUrl, a.credential, `${result.stage}: ${result.error ?? "failed"}`);
      if (flags.once) return lastCode;
    }
    return 130;
  } finally {
    unregister();
  }
}

function stateOf(c: Claim): string {
  return "runId" in c ? `${c.outcome}:${c.runId}` : c.outcome;
}

function describe(c: Claim): string {
  switch (c.outcome) {
    case "empty":
      return c.memberRequests
        ? `${c.memberRequests} approved request${c.memberRequests === 1 ? "" : "s"} from members ${c.memberRequests === 1 ? "is" : "are"} left for a cloud build ` +
            "(this worker builds only requests an admin wrote, since its agent holds your login); checking every few seconds"
        : "no approved request waiting; checking every few seconds";
    case "busy":
      return `another build is running (run ${c.runId}); waiting`;
    case "reconciling":
      return `the last build (run ${c.runId}) is being cleaned up; waiting`;
    case "disabled":
      return `builds are off: ${c.reason}; waiting`;
    case "planning":
      return "Chef is grouping the approved requests into builds; waiting";
    default:
      return "waiting";
  }
}

async function failed(deps: WorkDeps, log: (l: string) => void, siteUrl: string, credential: string, error: string): Promise<number> {
  log(`chef work: the run failed: ${error}`);
  const r = await finish(siteUrl, credential, { outcome: "failed", error }, { fetch: deps.fetch, sleep: deps.sleep });
  if (!r.ok) log(`chef work: couldn't report the failure: ${r.status} ${r.error}`);
  return 1;
}

/** The run is pushed: the preview the flag asks for, then the run's end. */
async function afterPush(
  flags: WorkFlags,
  deps: WorkDeps,
  log: (l: string) => void,
  r: {
    siteUrl: string;
    appDir: string;
    remoteUrl: string;
    hostEnv: Record<string, string | undefined>;
    credential: string;
    sha: string;
    /** The request's number (from its branch), for its preview's name. */
    itemNumber: number | null;
  },
): Promise<number> {
  const done = async (body: FinishBody, what: string) => {
    const x = await finish(r.siteUrl, r.credential, body, { fetch: deps.fetch, sleep: deps.sleep });
    if (!x.ok) {
      log(`chef work: couldn't finish the run: ${x.status} ${x.error}`);
      return { ok: false as const, status: x.status };
    }
    log(`chef work: ${what}`);
    return { ok: true as const, status: 200 };
  };
  if (flags.preview === "auto" || flags.preview === "cloud") {
    const x = await finish(r.siteUrl, r.credential, { outcome: "built", handoff: true }, { fetch: deps.fetch, sleep: deps.sleep });
    if (x.ok) {
      log("chef work: pushed; the app's cloud preview takes it from here (watch it in the panel)");
      return 0;
    }
    if (x.status !== 409) {
      log(`chef work: couldn't hand the run to the cloud preview: ${x.status} ${x.error}`);
      return 1;
    }
    log(`chef work: ${flags.preview === "cloud" ? "WARNING: " : ""}the app has no cloud preview set up; finishing without one`);
    return (await done({ outcome: "built" }, "built, without a preview")).ok ? 0 : 1;
  }
  if (flags.preview === "none") return (await done({ outcome: "built" }, "built")).ok ? 0 : 1;

  // local: keep the run alive while the deploy runs.
  const beat = setInterval(() => void heartbeat(r.siteUrl, r.credential, deps.fetch), 60_000);
  let p: LocalPreview;
  try {
    p = await deps.deployPreview({
      sha: r.sha,
      itemNumber: r.itemNumber,
      appDir: r.appDir,
      remoteUrl: r.remoteUrl,
      baseDir: join(deps.home, ".cache", "chef", "work"),
      // The preview key is the one secret the deploy script gets.
      hostEnv: { ...r.hostEnv, CHEF_PREVIEW_DEPLOY_KEY: deps.env.CHEF_PREVIEW_DEPLOY_KEY },
      gitAuth: () => fillGitAuth({ appDir: r.appDir, remoteUrl: r.remoteUrl, env: r.hostEnv }),
      print: log,
    });
  } finally {
    clearInterval(beat);
  }
  if (!p.ok) {
    log(`chef work: the local preview failed: ${p.error}`);
    await done({ outcome: "built", error: `local preview failed: ${p.error}` }, "built, without a preview");
    return 1;
  }
  return (await done({ outcome: "built", previewDeploymentName: p.deploymentName }, `built; preview https://${p.deploymentName}.convex.site`)).ok ? 0 : 1;
}
