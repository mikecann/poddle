// The env vars an app's convex.config requires (`defineApp({ env: { ... } })`
// without `v.optional`), and throwaway values for them. Previews and the
// build sandbox's local backend get these, never the real ones: a fresh
// signing keypair for each *_PRIVATE_KEY / *_JWKS pair, a placeholder for
// emails and URLs, and random strings for the rest.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { generateKeyPairSync, randomBytes, randomUUID } from "node:crypto";

/** The index just past the brace that closes the one at `open`, skipping strings and comments. */
function closeBrace(src: string, open: number): number {
  let depth = 0;
  for (let i = open; i < src.length; i++) {
    const c = src[i];
    if (c === '"' || c === "'" || c === "`") {
      for (i++; i < src.length && src[i] !== c; i++) if (src[i] === "\\") i++;
    } else if (c === "/" && src[i + 1] === "/") {
      while (i < src.length && src[i] !== "\n") i++;
    } else if (c === "/" && src[i + 1] === "*") {
      i = src.indexOf("*/", i + 2);
      if (i < 0) return -1;
      i++;
    } else if (c === "{" || c === "(" || c === "[") depth++;
    else if (c === "}" || c === ")" || c === "]") {
      depth--;
      if (depth === 0) return i + 1;
    }
  }
  return -1;
}

/** Strip comments, keeping string contents as they are. */
function stripComments(src: string): string {
  return src.replace(/("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|\/\/[^\n]*|\/\*[\s\S]*?\*\//g, (m, str) => str ?? " ");
}

export type DeclaredEnv = { name: string; required: boolean };

/**
 * The env block of `defineApp({ env: { ... } })`, top-level entries only.
 * Null when there is no such block (nothing is required).
 */
export function declaredEnv(configSource: string): DeclaredEnv[] | null {
  const src = stripComments(configSource);
  const call = /defineApp\s*\(\s*\{/.exec(src);
  if (!call) return null;
  const objStart = call.index + call[0].length - 1;
  const objEnd = closeBrace(src, objStart);
  if (objEnd < 0) return null;
  const obj = src.slice(objStart, objEnd);
  const envKey = /[{,]\s*env\s*:\s*\{/.exec(obj);
  if (!envKey) return null;
  const envStart = envKey.index + envKey[0].length - 1;
  const envEnd = closeBrace(obj, envStart);
  if (envEnd < 0) return null;
  const body = obj.slice(envStart + 1, envEnd - 1);
  // Split the top level on commas.
  const entries: string[] = [];
  let depth = 0;
  let cur = "";
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (c === '"' || c === "'" || c === "`") {
      let j = i + 1;
      for (; j < body.length && body[j] !== c; j++) if (body[j] === "\\") j++;
      cur += body.slice(i, j + 1);
      i = j;
      continue;
    }
    if (c === "{" || c === "(" || c === "[") depth++;
    if (c === "}" || c === ")" || c === "]") depth--;
    if (c === "," && depth === 0) {
      entries.push(cur);
      cur = "";
    } else cur += c;
  }
  entries.push(cur);
  const out: DeclaredEnv[] = [];
  for (const e of entries) {
    const m = /^\s*["']?([A-Za-z_][A-Za-z0-9_]*)["']?\s*:\s*([\s\S]+?)\s*$/.exec(e);
    if (!m) continue;
    out.push({ name: m[1], required: !/^v\s*\.\s*optional\s*\(/.test(m[2]) });
  }
  return out;
}

export function requiredEnvNames(configSource: string | null): string[] {
  if (configSource === null) return [];
  return (declaredEnv(configSource) ?? []).filter((e) => e.required).map((e) => e.name);
}

/** An RS256 PKCS8 key (base64 of the PEM) and its JWKS, the shape Convex Auth reads. */
export function signingKeyPair(): { privateKey: string; jwks: string } {
  const { privateKey, publicKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });
  const pem = privateKey.export({ type: "pkcs8", format: "pem" });
  const jwk = publicKey.export({ format: "jwk" });
  return {
    privateKey: Buffer.from(pem).toString("base64"),
    jwks: JSON.stringify({ keys: [{ ...jwk, kid: randomUUID(), alg: "RS256", use: "sig" }] }),
  };
}

/** The prefix a keypair's two names share: AUTH for AUTH_PRIVATE_KEY and AUTH_JWKS. */
function pairPrefix(name: string): string | null {
  const m = /^(.*?)_?(PRIVATE_KEY|JWKS)$/.exec(name);
  return m ? m[1] : null;
}

export type ValueKind = "keypair" | "email" | "url" | "random";

/** How each name gets a throwaway value. Pure, so the generated script and the CLI agree. */
export function valueKinds(names: string[]): Record<string, ValueKind> {
  const set = new Set(names);
  const kinds: Record<string, ValueKind> = {};
  for (const name of names) {
    const p = pairPrefix(name);
    const sep = p ? "_" : "";
    if (p !== null && set.has(`${p}${sep}PRIVATE_KEY`) && set.has(`${p}${sep}JWKS`)) kinds[name] = "keypair";
    else if (/SECRET|TOKEN|KEY|PASSWORD/.test(name)) kinds[name] = "random";
    else if (/(^|_)EMAIL$/.test(name)) kinds[name] = "email";
    else if (/(^|_)(URL|ORIGIN)$/.test(name)) kinds[name] = "url";
    else kinds[name] = "random";
  }
  return kinds;
}

export const PLACEHOLDER_EMAIL = "owner@example.test";
export const PLACEHOLDER_URL = "https://example.test";

/** Fresh throwaway values for `names`. Never printed by anything in this CLI. */
export function throwawayValues(names: string[]): Record<string, string> {
  const kinds = valueKinds(names);
  const out: Record<string, string> = {};
  const pairs = new Map<string, { privateKey: string; jwks: string }>();
  for (const name of names) {
    switch (kinds[name]) {
      case "keypair": {
        const p = pairPrefix(name)!;
        if (!pairs.has(p)) pairs.set(p, signingKeyPair());
        const kp = pairs.get(p)!;
        out[name] = name.endsWith("JWKS") ? kp.jwks : kp.privateKey;
        break;
      }
      case "email":
        out[name] = PLACEHOLDER_EMAIL;
        break;
      case "url":
        out[name] = PLACEHOLDER_URL;
        break;
      default:
        out[name] = randomBytes(32).toString("base64url");
    }
  }
  return out;
}

export const LOCAL_ENV_SCRIPT = "scripts/chef-local-env.mjs";
/** The package.json script chefCloud's localEnv "auto" runs (AUTO_LOCAL_ENV_SCRIPT in runner/runner.ts). */
export const LOCAL_ENV_NPM_SCRIPT = "chef:local-env";

/**
 * `scripts/chef-local-env.mjs`: the runner's `localEnv` command. Sets
 * throwaway values for the required env vars on the build sandbox's local
 * backend, and refuses any other deployment.
 */
export function localEnvScript(names: string[]): string {
  const kinds = valueKinds(names);
  const list = names.map((n) => `  [${JSON.stringify(n)}, ${JSON.stringify(kinds[n])}],`).join("\n");
  return `#!/usr/bin/env node
// Written by \`npx chef init\`. Throwaway values for the env vars
// convex/convex.config.ts requires, on the build sandbox's local backend,
// which starts with none: Chef's runner runs this after each local backend
// start, through package.json's \`chef:local-env\` script (chefCloud's
// localEnv "auto"), with CONVEX_SELF_HOSTED_URL and
// CONVEX_SELF_HOSTED_ADMIN_KEY pointing the CLI at that backend.
//
//   npm run ${LOCAL_ENV_NPM_SCRIPT}
//
// Every value is made up here: a fresh signing keypair for each
// *_PRIVATE_KEY / *_JWKS pair, a placeholder for emails and URLs, random
// strings for the rest. Values go to the CLI on stdin, never in argv, and
// only names are printed. Vars already set are left alone. When you add a
// required env var, add it below.
import { execFileSync } from "node:child_process";
import { generateKeyPairSync, randomBytes, randomUUID } from "node:crypto";

const VARS = [
${list}
];

const url = process.env.CONVEX_SELF_HOSTED_URL ?? "";
if (!/^http:\\/\\/(127\\.0\\.0\\.1|localhost)(:\\d+)?\\/?$/.test(url) || !process.env.CONVEX_SELF_HOSTED_ADMIN_KEY) {
  console.error("chef-local-env: CONVEX_SELF_HOSTED_URL (a local backend) and CONVEX_SELF_HOSTED_ADMIN_KEY must be set");
  process.exit(2);
}

function convex(args, input) {
  return execFileSync("npx", ["convex", ...args], {
    encoding: "utf8",
    // stdout is captured and dropped: \`env list\` holds values.
    stdio: ["pipe", "pipe", "inherit"],
    ...(input === undefined ? {} : { input }),
  });
}

const have = new Set(
  convex(["env", "list"])
    .split("\\n")
    .map((l) => /^([A-Za-z_][A-Za-z0-9_]*)=/.exec(l)?.[1])
    .filter(Boolean),
);

const pairs = new Map();
function keypair(prefix) {
  if (!pairs.has(prefix)) {
    const { privateKey, publicKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });
    const pem = privateKey.export({ type: "pkcs8", format: "pem" });
    const jwk = publicKey.export({ format: "jwk" });
    pairs.set(prefix, {
      privateKey: Buffer.from(pem).toString("base64"),
      jwks: JSON.stringify({ keys: [{ ...jwk, kid: randomUUID(), alg: "RS256", use: "sig" }] }),
    });
  }
  return pairs.get(prefix);
}

function value(name, kind) {
  if (kind === "keypair") {
    const kp = keypair(name.replace(/_?(PRIVATE_KEY|JWKS)$/, ""));
    return name.endsWith("JWKS") ? kp.jwks : kp.privateKey;
  }
  if (kind === "email") return ${JSON.stringify(PLACEHOLDER_EMAIL)};
  if (kind === "url") return ${JSON.stringify(PLACEHOLDER_URL)};
  return randomBytes(32).toString("base64url");
}

// A keypair is set as a pair, so a half-set pair gets both halves fresh.
const missing = new Set(VARS.filter(([n]) => !have.has(n)).map(([n]) => n));
for (const [n, kind] of VARS) {
  if (kind !== "keypair" || !missing.has(n)) continue;
  const prefix = n.replace(/_?(PRIVATE_KEY|JWKS)$/, "");
  for (const [m, k] of VARS) if (k === "keypair" && m.replace(/_?(PRIVATE_KEY|JWKS)$/, "") === prefix) missing.add(m);
}
const set = [];
for (const [name, kind] of VARS) {
  if (!missing.has(name)) continue;
  convex(["env", "set", name], value(name, kind));
  set.push(name);
}
console.log(set.length ? \`chef-local-env: set \${set.join(", ")}\` : "chef-local-env: all set already");
`;
}
