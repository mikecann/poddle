// The deploy guard. "Ship it" deploys chef's commit to one deployment and
// then moves chef's `main`; a later deploy of an older checkout to that same
// deployment (a local `npx convex dev`, `chef upgrade`, `chef init`) puts
// the old code back and rolls back what shipped. So before any deploy to the
// deployment "Ship it" deploys to, and in `chef sync`, chef refuses while
// chef's `main` has commits this checkout lacks: `git pull chef main` first.
//
// `chef guard` runs it on its own; `chef init --cloud` adds it as the app's
// `predev` script, so `npm run dev` runs it before `convex dev`.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import type { Convex } from "./convex.ts";
import type { Deps } from "./deps.ts";
import { parseDeployment, readConvexDeployment } from "./preflight.ts";
import { MAIN, normalizeRefs, REMOTE_NAME } from "./repo.ts";

export const SKIP_ENV = "CHEF_SKIP_DEPLOY_GUARD";

/** Why the guard lets a deploy through to a deployment without chefCloud's functions. */
export const NOT_SET_UP = (module: string) =>
  `Chef's cloud builds aren't set up on this deployment yet (no ${module}:chefSetupStatus there), so nothing has ` +
  "shipped here to roll back. To set them up: `npx chef init --cloud` (review), then `npx chef init --cloud --write`";

export type GuardResult = { ok: true; why: string } | { ok: false; message: string };

const firstLine = (e: unknown) => (e instanceof Error ? e.message : String(e)).split("\n").find((l) => l.trim()) ?? "";
const missingFunction = (e: unknown) => /Could not find|not found|No such function|unknown function/i.test(e instanceof Error ? e.message : String(e));

/**
 * Whether HEAD has everything on chef's `main`: an ancestor of HEAD, or HEAD
 * itself. Null when chef has no main yet. Reads the refs through the
 * deployment (chefRepoRefs); never fetches.
 */
export async function mainBehindHead(
  convex: Convex,
  deps: Deps,
  cwd: string,
): Promise<{ main: string | null; contained: boolean; fetched: boolean }> {
  const refs = normalizeRefs(await convex.run("chefRepoRefs"));
  const main = refs[MAIN] ?? null;
  if (!main) return { main: null, contained: true, fetched: true };
  const git = (args: string[]) => deps.exec("git", args, { cwd });
  const head = (await git(["rev-parse", "HEAD"])).stdout.trim();
  if (head === main) return { main, contained: true, fetched: true };
  if ((await git(["cat-file", "-e", `${main}^{commit}`])).code !== 0) return { main, contained: false, fetched: false };
  return { main, contained: (await git(["merge-base", "--is-ancestor", main, "HEAD"])).code === 0, fetched: true };
}

export function pullFirst(main: string, fetched: boolean, what: string): string {
  return [
    `chef's ${MAIN} is at ${main.slice(0, 12)}, ${fetched ? "with commits HEAD doesn't have" : "which this checkout doesn't have"}.`,
    what,
    `Run \`git pull ${REMOTE_NAME} ${MAIN}\` first, then try again.`,
  ].join("\n");
}

/**
 * The guard for a deploy from `cwd` to the deployment `convex` targets. Only
 * a deployment with "Ship it" set up (a deploy key recorded there,
 * chefSetupStatus' deployKeyPrefix) is guarded; anywhere else is fine. When
 * it can't tell, it refuses; CHEF_SKIP_DEPLOY_GUARD=1 skips it.
 */
export async function deployGuard(convex: Convex, deps: Deps, cwd: string, opts: { prod: boolean }): Promise<GuardResult> {
  if (deps.env[SKIP_ENV] === "1") return { ok: true, why: `skipped (${SKIP_ENV}=1)` };
  if (!opts.prod) {
    const d = parseDeployment(readConvexDeployment(cwd, deps.env));
    if ("error" in d) return { ok: true, why: "not a cloud deployment" };
  }
  const cantTell = (e: unknown): GuardResult => ({
    ok: false,
    message:
      `Can't tell whether "Ship it" deploys here (${firstLine(e)}), so not deploying.\n` +
      `Fix that, or deploy anyway with ${SKIP_ENV}=1.`,
  });
  let status: Record<string, unknown> | null;
  let target: string;
  try {
    status = await convex.run<Record<string, unknown> | null>("chefSetupStatus");
    if (typeof status?.deployKeyPrefix !== "string" || !status.deployKeyPrefix) return { ok: true, why: `"Ship it" doesn't deploy here` };
    target = status.deployKeyPrefix;
  } catch (e) {
    // No chefCloud here (the feedback board alone, or Chef's setup not run
    // yet): nothing shipped, so nothing to guard. Say so plainly.
    if (missingFunction(e)) return { ok: true, why: NOT_SET_UP(convex.t.module) };
    // A deployed pair that fails chef-cloud's version handshake can't say
    // where Ship it deploys. Assume here, so the deploy that fixes the pair
    // goes through whenever HEAD has chef's main.
    if (!/contract/i.test(e instanceof Error ? e.message : String(e))) return cantTell(e);
    target = "unknown: the deployed packages failed their version handshake";
  }
  let r: Awaited<ReturnType<typeof mainBehindHead>>;
  try {
    r = await mainBehindHead(convex, deps, cwd);
  } catch (e) {
    return cantTell(e);
  }
  if (!r.main) return { ok: true, why: `chef has no ${MAIN} yet` };
  if (r.contained) return { ok: true, why: `HEAD has chef's ${MAIN}` };
  return {
    ok: false,
    message: pullFirst(
      r.main,
      r.fetched,
      `"Ship it" deploys to this deployment (${target}), so deploying this checkout would roll back what shipped.`,
    ),
  };
}
