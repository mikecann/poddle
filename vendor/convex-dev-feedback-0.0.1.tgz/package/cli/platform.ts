// The Convex platform API, with the CLI's own login (~/.convex/config.json),
// for the two things the deployment can't do for itself: a preview deploy
// key for the project, and the project's default env vars for preview
// deployments. Only preview defaults are ever written; values are never
// printed and never copied from another deployment.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { readFileSync } from "node:fs";
import { join } from "node:path";
import { scrub } from "../src/chef/scrub.ts";
import { CliError, type Deps } from "./deps.ts";

export const PLATFORM_API = "https://api.convex.dev/v1";

export type DefaultEnvVar = { name: string; value: string; deploymentTypes: string[] };

const PREVIEW_KEY = /^preview:[^:|\s]+:[^:|\s]+\|\S+$/;

export class Platform {
  deps: Deps;
  private token: string;

  constructor(deps: Deps) {
    this.deps = deps;
    let t: unknown;
    try {
      t = JSON.parse(readFileSync(join(deps.home, ".convex", "config.json"), "utf8")).accessToken;
    } catch {
      t = undefined;
    }
    if (typeof t !== "string" || t === "") throw new CliError("The Convex CLI is not logged in: run `npx convex login`");
    this.token = t;
  }

  private async call<R>(method: string, path: string, body?: unknown): Promise<R> {
    const res = await this.deps.fetch(`${PLATFORM_API}/${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${this.token}`,
        ...(body === undefined ? {} : { "Content-Type": "application/json" }),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    const text = await res.text();
    if (!res.ok) {
      // Error bodies name the problem; scrubbed anyway, and never the request.
      throw new CliError(`${method} ${path}: HTTP ${res.status} ${scrub(text.slice(0, 300))}`);
    }
    return (text === "" ? null : JSON.parse(text)) as R;
  }

  async projectId(deploymentName: string): Promise<number> {
    const d = await this.call<{ projectId?: number }>("GET", `deployments/${encodeURIComponent(deploymentName)}`);
    if (typeof d?.projectId !== "number") throw new CliError(`No project id for deployment ${deploymentName}`);
    return d.projectId;
  }

  /** A new preview deploy key; the caller hands it straight to `convex env set`. */
  async createPreviewDeployKey(projectId: number, name: string): Promise<string> {
    const r = await this.call<{ previewDeployKey?: string }>("POST", `projects/${projectId}/create_preview_deploy_key`, {
      name,
    });
    const key = r?.previewDeployKey;
    if (typeof key !== "string" || !PREVIEW_KEY.test(key)) {
      throw new CliError("create_preview_deploy_key answered without a preview deploy key");
    }
    return key;
  }

  async listDefaults(projectId: number): Promise<DefaultEnvVar[]> {
    const r = await this.call<{ items?: DefaultEnvVar[] }>("GET", `projects/${projectId}/list_default_environment_variables`);
    return r?.items ?? [];
  }

  /** Sets preview defaults only; anything else is refused before the call. */
  async setPreviewDefaults(projectId: number, values: Record<string, string>): Promise<void> {
    const changes = Object.entries(values).map(([name, value]) => ({ name, deploymentType: "preview", value }));
    if (changes.length === 0) return;
    if (changes.some((c) => c.deploymentType !== "preview")) throw new CliError("only preview defaults change here");
    await this.call("POST", `projects/${projectId}/update_default_environment_variables`, { changes });
  }
}

/** Names that have a preview default already. */
export function previewDefaultNames(items: DefaultEnvVar[]): Set<string> {
  return new Set(items.filter((i) => i.deploymentTypes.includes("preview")).map((i) => i.name));
}
